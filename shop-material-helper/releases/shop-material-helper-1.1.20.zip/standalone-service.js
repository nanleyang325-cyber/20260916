'use strict';
importScripts('image-models.js','featured-quality.js','standalone-core.js','standalone-cutout.js','standalone-local.js');
(function(){
 const C=MaterialIndependentCore,BASE=chrome.runtime.getURL('local-api'),SECRET='independent-api-profile-v1',CONTROL='independent-ai-control-v1';
 const Models=MaterialImageModels,IMAGE_CHOICES=Models.catalog.map(m=>m.id);
 const originalFetch=globalThis.fetch.bind(globalThis);
 const privateReady=chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
 const dbPromise=new Promise((resolve,reject)=>{const r=indexedDB.open('material-independent-v1',2);r.onupgradeneeded=()=>{for(const name of ['jobs','assets','batches','workspaces','videoInputs','cutouts','cutoutSources','cutoutAssets','recoveries'])if(!r.result.objectStoreNames?.contains(name))r.result.createObjectStore(name);};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
 async function get(store,key){const db=await dbPromise;return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
 async function all(store){const db=await dbPromise;return new Promise((resolve,reject)=>{const r=db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
 async function put(store,key,value){const db=await dbPromise;return new Promise((resolve,reject)=>{const tx=db.transaction(store,'readwrite');tx.objectStore(store).put(value,key);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||Error('本机保存中断'));});}
 const hash=async value=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',typeof value==='string'?new TextEncoder().encode(value):value))].map(x=>x.toString(16).padStart(2,'0')).join('');
 async function dataURL(blob){let s='';const a=new Uint8Array(await blob.arrayBuffer());for(let i=0;i<a.length;i+=8192)s+=String.fromCharCode(...a.subarray(i,i+8192));return 'data:'+blob.type+';base64,'+btoa(s);}
 async function config(){await privateReady;return(await chrome.storage.local.get(SECRET))[SECRET];}
 async function paused(id){const values=await chrome.storage.local.get([CONTROL,'material-global-control-v1']),local=values[CONTROL];return !!(values['material-global-control-v1']?.paused||values['material-global-control-v1']?.draining||local?.paused&&!(typeof id==='string'&&local.allowedIds?.includes(id)));}
 async function imageFallbackGate(job){
  const key='material-flow-runs-v1',runs=(await chrome.storage.local.get(key))[key]||[];
  const run=runs.find(candidate=>candidate.id===job.request.imageFallbackRunId);
  if(run?.module!=='search'||run.selection?.imageFallback!==job.request.imageFallback||run.draining)return 'closed';
  const item=run.items?.find(candidate=>candidate.generations?.some(g=>g.id===job.id&&g.intent));
  if(!item||item.failureSkipped||item.phase!=='generate'||JSON.stringify(item.productIds)!==JSON.stringify(job.request.productIds))return 'closed';
  return run.enabled&&run.status==='running'?'allow':run.status==='paused'?'wait':'closed';
 }
 async function imageAsset(url,request){
  C.publicURL(url);
  const r=await originalFetch(url,{credentials:'omit',redirect:'error',signal:AbortSignal.timeout(24000)});
  const video=request?.media==='video';
  if(!r.ok||!(video?/^video\/mp4(;|$)/i:/^image\/(png|jpeg|webp)(;|$)/i).test(r.headers.get('content-type')||''))throw Error('媒体格式未通过');
  const chunks=[];let count=0;const reader=r.body.getReader();
  try{for(;;){const part=await reader.read();if(part.done)break;count+=part.value.length;if(count>32*1024*1024)throw Error('图片超过32MB');chunks.push(part.value);}}finally{await reader.cancel().catch(()=>{});}
  const raw=new Blob(chunks,{type:r.headers.get('content-type').split(';')[0]});
  if(video){
   const signature=new Uint8Array(await raw.slice(0,12).arrayBuffer());if(String.fromCharCode(...signature.slice(4,8))!=='ftyp')throw Error('不是MP4文件');
   await put('videoInputs',request.id,{blob:raw});
   const mediaInfo=await decodeVideo(request.id);
   if(!Number.isFinite(mediaInfo.duration)||mediaInfo.duration<8||mediaInfo.duration>12||!mediaInfo.width||!mediaInfo.height)throw Error('视频实际时长/尺寸不符，未交给平台');
   return {blob:raw,raw,sha256:await hash(await raw.arrayBuffer()),mediaInfo:{...mediaInfo,format:'mp4',bytes:raw.size}};
  }
  const bitmap=await createImageBitmap(raw);
  try{
   if(bitmap.width<1||bitmap.height<1||bitmap.width*bitmap.height>40000000)throw Error('尺寸超出可处理范围');
   const canvas=new OffscreenCanvas(bitmap.width,bitmap.height);canvas.getContext('2d').drawImage(bitmap,0,0);
   const blob=await canvas.convertToBlob({type:'image/png'});
   return {blob,raw,sha256:await hash(await blob.arrayBuffer()),mediaInfo:{format:'png',width:bitmap.width,height:bitmap.height,bytes:blob.size}};
  }finally{bitmap.close();}
 }
 let videoDecode=Promise.resolve();
 function decodeVideo(id){
  const result=videoDecode.catch(()=>{}).then(async()=>{
   const url=chrome.runtime.getURL('media-decode.html'),contexts=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[url]});
   if(!contexts.length)await chrome.offscreen.createDocument({url:'media-decode.html',reasons:['BLOBS'],justification:'仅在本插件离屏解码已下载MP4，确认真实尺寸和时长，不播放声音'});
   try{const r=await chrome.runtime.sendMessage({type:'MATERIAL_VIDEO_DECODE',id});if(!r?.ok||r.id!==id)throw Error('视频解码未完成');return r.info;}finally{await chrome.offscreen.closeDocument().catch(()=>{});}
  });videoDecode=result;return result;
 }
 let ticking=null,reviewing=null;
 const engine=C.engine({get,put,all,hash,config,paused,imageFallbackGate,dataURL,now:Date.now,fetch:originalFetch,download:imageAsset,keepAlive:()=>{const timer=setInterval(()=>chrome.runtime.getPlatformInfo?.().catch(()=>{}),20000);return ()=>clearInterval(timer);},allowed:origin=>chrome.permissions.contains({origins:[origin]}),wake:async()=>{await chrome.alarms.create('independent-media',{when:Date.now()+500,periodInMinutes:.5});}});
 globalThis.independentPreflight=async run=>{if(run.module==='search'&&run.selection.mode!=='cleanup'&&['ai','process'].includes(FullFlowPolicy.source(run.selection))){const c=await config();if(run.selection.imageFallback!==undefined&&(!Models.isSearchFallback(run.selection.imageFallback)||run.selection.imageFallback!==c?.imageFallback||c.imageModel!=='gpt-image-2.6'||run.selection.mode==='replica'||run.selection.searchMode==='replica'||run.selection.variant==='video'))throw Error('图片备用模型设置已变化，请重新选择本次执行。');if(!c?.key)throw Object.assign(Error('尚未配置GrsAI，请先打开API设置，选择图片模型并保存密钥，再开始；本次未建立任务、未提交生成。'),{code:'API_NOT_CONFIGURED'});if(run.selection.creativePlanVersion===4){run.selection.qualityReview={version:2,enabled:false,mode:'manual'};run.consentScope=FullFlowRun.scope(run);}if(await paused())throw Object.assign(Error('新增AI请求已暂停。请在API设置恢复后再开始；本次未建立任务、未提交生成、未产生费用。'),{code:'AI_REQUESTS_PAUSED'});}};
 globalThis.MaterialQualityStorage={get:key=>get('workspaces',key),put:(key,value)=>put('workspaces',key,value),lock:engine.lock,reference:async id=>{const job=await get('jobs',id);return job?{productIds:job.request.productIds,data:job.request.references?.[0]}:null;},hash,dataURL};
 const local=MaterialLocal.create({get,put,all,hash,config,paused,now:Date.now,fetch:originalFetch,lock:engine.lock,wake:()=>chrome.alarms.create('independent-media',{when:Date.now()+500,periodInMinutes:.5}),
  downloadSource:async url=>{const r=await originalFetch(url,{credentials:'omit',redirect:'error',signal:AbortSignal.timeout(20000)});if(!r.ok||!/^image\/(png|jpeg|webp)(;|$)/i.test(r.headers.get('content-type')||''))throw Error('SOURCE_FORMAT');const parts=[];let size=0;const reader=r.body.getReader();try{for(;;){const p=await reader.read();if(p.done)break;size+=p.value.length;if(size>8*1024*1024)throw Error('SOURCE_TOO_LARGE');parts.push(p.value);}}finally{await reader.cancel().catch(()=>{});}return new Blob(parts,{type:r.headers.get('content-type').split(';')[0]});},
  cut:async(source,algorithm)=>{const bitmap=await createImageBitmap(source);try{if(bitmap.width!==800||bitmap.height!==800)throw Error('WHITE_SOURCE_MUST_BE_800');const canvas=new OffscreenCanvas(800,800),ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(bitmap,0,0);let pixels=ctx.getImageData(0,0,800,800),paddingApplied=algorithm.padding(pixels.data);if(paddingApplied){ctx.fillStyle='#fff';ctx.fillRect(0,0,800,800);ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(bitmap,0,0,800,800,12,12,776,776);pixels=ctx.getImageData(0,0,800,800);}const r=algorithm.cut(pixels.data);ctx.putImageData(new ImageData(r.pixels,800,800),0,0);const blob=await canvas.convertToBlob({type:'image/png'});return {blob,info:{...r.info,paddingApplied}};}finally{bitmap.close();}}
 });
 async function tick(){if(!reviewing)reviewing=engine.reviewTick().catch(()=>{}).finally(()=>{reviewing=null;});if(ticking)return ticking;ticking=(async()=>{await local.tick();await engine.tick();})().catch(()=>{}).finally(async()=>{ticking=null;const jobs=await all('jobs'),batches=await all('batches'),cutouts=await all('cutouts');if(!jobs.some(j=>!C.terminal(j.status)&&j.status!=='submission_unconfirmed')&&!batches.some(b=>b.enabled)&&!cutouts.some(c=>!['completed','failed'].includes(c.status)))await chrome.alarms.clear('independent-media');});return ticking;}
 chrome.alarms.onAlarm.addListener(a=>{if(a.name==='independent-media')tick();});
 // On browser restart pending intents are preserved; polling never creates another paid task.
 chrome.runtime.onStartup.addListener(()=>chrome.alarms.create('independent-media',{when:Date.now()+1000,periodInMinutes:.5}));
 chrome.runtime.onInstalled.addListener(()=>chrome.alarms.create('independent-media',{when:Date.now()+1000,periodInMinutes:.5}));
 const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 const error=(message,status=400)=>{throw Object.assign(Error(message),{status});};
 async function route(request){
  try{
   const url=new URL(request.url),path=url.pathname.replace(/^\/local-api/,''),method=request.method;
   if(!request.url.startsWith(BASE+'/'))return json({error:'非本机素材路由'},404);
   let body={};if(method!=='GET'){const raw=await request.text();if(raw.length>64*1024*1024)error('请求超过64MB',413);try{body=raw?JSON.parse(raw):{};}catch{error('JSON格式无效');}}
   if(path==='/api/status'&&method==='GET')return json({version:'1.1.7',standalone:true,toolAvailable:true,credentialConfigured:!!(await config())?.key,imageModel:(await config())?.imageModel||'nano-banana-pro',imageModels:IMAGE_CHOICES,imageSettings:Models.settings((await config())?.imageModel||'nano-banana-pro',(await config())?.imageSettings),imageFallbackVersion:0,imageCapabilityRecoveryVersion:1,videoModel:'minimax-h3',videoContractVersion:2,liveVideoVerified:false,transparentAvailable:true});
   if(path==='/api/grsai/credits'&&method==='GET')return json(await local.credits());
   if(path==='/api/history'&&method==='GET'){const id=url.searchParams.get('productId');return json({jobs:(await all('jobs')).filter(j=>!id||j.request.productIds.includes(id)).map(C.view)});}
   if(path==='/api/media'&&method==='POST')return json(await engine.submit(body),202);
   const media=path.match(/^\/api\/media\/([^/]+)(?:\/(resume|data|data-scene|data-white|file|scene|white))?$/);
   if(media){
    const [,id,operation]=media;if(!C.UUID.test(id))error('任务编号无效');
    if(!operation&&method==='GET')return json(await engine.query(id));
    if(operation==='resume'&&method==='POST')return json(await engine.query(id));
    if(method==='GET'&&operation&&operation!=='resume'){
     const job=await get('jobs',id),asset=await get('assets',id);if(job?.status!=='completed'||!asset?.blob)error('素材文件尚未验证',409);
     let blob=asset.blob,info=asset.mediaInfo,sha=asset.sha256;
     if(['data-scene','data-white','scene','white'].includes(operation)){
      if(job.request.media!=='image')error('视频没有图片派生文件',400);
      const bitmap=await createImageBitmap(blob);try{const canvas=new OffscreenCanvas(800,800),ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,800,800);const scale=Math.min(800/bitmap.width,800/bitmap.height);ctx.drawImage(bitmap,(800-bitmap.width*scale)/2,(800-bitmap.height*scale)/2,bitmap.width*scale,bitmap.height*scale);blob=await canvas.convertToBlob({type:'image/png'});info={format:'png',width:800,height:800,bytes:blob.size};sha=await hash(await blob.arrayBuffer());}finally{bitmap.close();}
     }
     const name='material-'+id+(job.request.media==='video'?'.mp4':'.png');
     if(operation.startsWith('data'))return json({name,data:await dataURL(blob),sha256:sha,...info});
     return new Response(blob,{headers:{'Content-Type':blob.type,'Content-Disposition':'inline; filename="'+name+'"','Cache-Control':'no-store'}});
    }
   }
   if(path==='/api/workbench/state'){
    const workspace=method==='GET'?url.searchParams.get('workspace'):body.workspace;
    if(!/^[a-z][a-z0-9_-]{0,50}$/.test(workspace||''))error('工作区名称无效');
    return engine.lock('workspace:'+workspace,async()=>{
     const old=await get('workspaces',workspace)||{workspace,revision:0,state:null};
     if(method==='GET')return json(old);
     if(method!=='POST')return json({error:'方法不支持'},405);
     if(body.baseRevision!==old.revision)return json({error:'另一窗口已修改此任务，请刷新后再操作',current:old},409);
     const next={workspace,state:body.state,revision:old.revision+1,updatedAt:new Date().toISOString()};await put('workspaces',workspace,next);return json(next);
    });
   }
   if(path==='/api/media-batches'&&method==='POST')return json(await engine.batch(body),202);
   if(path==='/api/media-batches/control'&&method==='POST'){
    if(body.action==='status')return json({ok:true,paused:await paused(),active:(await all('jobs')).some(j=>j.sent&&['pending','download_pending'].includes(j.status))});
    if(!['pause','resume','stop','drain'].includes(body.action))error('控制指令无效');
    const pause=body.action!=='resume';await chrome.storage.local.set({[CONTROL]:{paused:pause,at:new Date().toISOString()}});
    if(['stop','drain'].includes(body.action))for(const b of await all('batches'))if(b.enabled)await engine.batchControl(b.id,false);
    if(!pause)await chrome.alarms.create('independent-media',{when:Date.now()+500,periodInMinutes:.5});
    return json({ok:true,paused:pause,note:'仅控制本插件后续AI提交；已提交的服务商任务不取消'});
   }
   const batch=path.match(/^\/api\/media-batches\/([^/]+)(?:\/(resume|stop))?$/);
   if(batch){const[,id,action]=batch;if(!C.UUID.test(id))error('批次编号无效');if(method==='POST'&&action)return json(await engine.batchControl(id,action==='resume'));if(method==='GET'&&!action){await engine.batchTick(id);const b=await get('batches',id);if(!b)error('原批次不存在',404);return json(engine.batchView(b));}}
   if(path==='/api/transparent'&&method==='POST')return json(await local.createCutout(body),202);
   const tp=path.match(/^\/api\/transparent\/([^/]+)(?:\/(data|file))?$/);
   if(tp&&method==='GET'){const[,id,op]=tp;if(!op)return json(await local.state(id));const a=await local.artifact(id),name='tp-'+id+'.png';if(op==='data')return json({name,data:await dataURL(a.blob),...a.info,sourceSha256:a.state.sourceSha256,sourceMaterialId:a.state.sourceMaterialId,productIds:a.state.productIds});return new Response(a.blob,{headers:{'Content-Type':'image/png','Content-Disposition':'attachment; filename="'+name+'"'}});}
   if(path==='/api/media-recovery/plan'&&method==='POST')return json(await engine.recoveryPlan(body));
   if(path==='/api/media-recovery/recover'&&method==='POST')return json(await engine.recover(body),202);
   return json({error:'此功能尚未有独立适配，不会回连公司服务器'},501);
  }catch(e){return json({error:e.status?e.message:'本机素材处理未完成；原任务记录保留',...(['API_NOT_CONFIGURED','AI_REQUESTS_PAUSED'].includes(e.code)?{code:e.code,notSubmitted:true}:{})},e.status||500);}
 }
 // Explicit package route. All other fetches retain their original semantics.
 globalThis.fetch=(input,init)=>{const raw=typeof input==='string'?input:input.url;return raw?.startsWith(BASE+'/')?route(new Request(input,init)):originalFetch(input,init);};
 self.addEventListener('fetch',event=>{if(event.request.url.startsWith(BASE+'/'))event.respondWith(route(event.request));});
 chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(!m?.type?.startsWith('INDEPENDENT_')||m.type==='INDEPENDENT_RECOVER_EXISTING_IMAGES')return false;
  // No web page/content script may change the destination/key or ask for media submission.
  if(sender.id!==chrome.runtime.id||!sender.url?.startsWith(chrome.runtime.getURL(''))||sender.url?.startsWith(chrome.runtime.getURL('local-api')))return false;
  (async()=>{
   if(m.type==='INDEPENDENT_STATUS'){
    const c=await config(),jobs=await all('jobs');return {ok:true,configured:!!c?.key,qualityReview:false,qualityReviewMode:'manual',base:c?.base||'https://grsaiapi.com',imageModel:c?.imageModel||'nano-banana-pro',imageFallback:c?.imageFallback||'',imageModels:IMAGE_CHOICES,imageSettings:Models.settings((await config())?.imageModel||'nano-banana-pro',(await config())?.imageSettings),paused:await paused(),jobs:jobs.length,pending:jobs.filter(j=>!C.terminal(j.status)).length,downloadOrigins:[...new Set(jobs.map(j=>j.downloadOrigin).filter(Boolean))],limitations:['真实账号生图/视频及店铺现场待验收','APIKey余额与账户总额口径分开']};
   }
   if(m.type==='INDEPENDENT_CONFIG_SAVE'){
    if(!sender.url.startsWith(chrome.runtime.getURL('api-settings.html')))error('仅能在API设置保存配置',403);
    const u=C.publicURL(m.base);if(u.pathname!=='/'||u.search||u.hash)error('接口地址只填HTTPS域名，不附加路径');
    if(!await chrome.permissions.contains({origins:[u.origin+'/*']}))error('未授权此接口域名',403);
    const old=await config(),key=typeof m.key==='string'&&m.key.trim()?m.key.trim():old?.base===u.origin?old.key:'';
    if(!key||key.length>2048||/[\r\n]/.test(key))error('请填写有效API密钥');
    if((old?.key!==key||old?.base!==u.origin)&&(await all('jobs')).some(j=>!C.terminal(j.status)))error('尚有未核清任务，不能切换接口或账号；请先核对原任务',409);
    const imageModel=m.imageModel===undefined?(old?.imageModel||'nano-banana-pro'):m.imageModel;if(!IMAGE_CHOICES.includes(imageModel))error('请选择列表中已接入的图片模型');
    const imageFallback=m.imageFallback??old?.imageFallback??'';
    if(imageFallback!==''&&!Models.isSearchFallback(imageFallback))error('请选择支持的搜推图文备用模型');
    let imageSettings;try{imageSettings=Models.settings(imageModel,m.imageSettings??(old?.imageModel===imageModel?old.imageSettings:undefined));}catch(e){error(e.message);}
    const revision=old?.key===key&&old?.base===u.origin?old.revision:crypto.randomUUID();await privateReady;await chrome.storage.local.set({[SECRET]:{imageFallback,base:u.origin,key,revision,imageModel,imageSettings,qualityReview:false}});return {ok:true};
   }
   if(m.type==='INDEPENDENT_CONFIG_CLEAR'){
    if(!sender.url.startsWith(chrome.runtime.getURL('api-settings.html')))error('仅能在API设置清除配置',403);
    if((await all('jobs')).some(j=>!C.terminal(j.status)))error('仍有未确认的原任务，请先处理后再清除密钥',409);
    await chrome.storage.local.remove(SECRET);return {ok:true};
   }
   if(m.type==='INDEPENDENT_PAUSE'){await chrome.storage.local.set({[CONTROL]:{paused:!!m.paused,at:new Date().toISOString()}});return {ok:true};}
   error('未知独立插件命令');
  })().then(reply,e=>reply({ok:false,error:e.status?e.message:'本机设置操作失败，未输出敏感信息'}));return true;
 });
})();

importScripts('existing-image-recovery.js');
importScripts('unsent-image-recovery.js');
