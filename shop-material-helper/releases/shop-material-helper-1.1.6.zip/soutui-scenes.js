(function(root){
 'use strict';
 const switchScenes=[
  ['走廊生活中景','明亮中性的住宅走廊，商品安装在近处合理墙面；远处可有一位虚化成人，不呈现可识别面容。中景，保留走廊生活动线。'],
  ['正常触控近景','干燥成人手指自然轻触参考图已确认的触控位置；商品清晰，正常家居背景虚化。不得增加按键或发光标识。'],
  ['卧室门边中景','卧室门边的合理墙面位置，背景有床和床头灯，商品仍为正常手掌大小。'],
  ['厨房侧墙中景','干燥厨房侧墙，避开水槽、灶火及溅水区；橱柜和台面提供背景，商品保持参考图安装方式。'],
  ['材质细节','深色或中性墙面上的面板材质近景，展现原有反射和边框，控制符号、颜色和数量只按参考图。'],
  ['客厅生活中景','客厅墙面中景，沙发、绿植或家具作为背景，商品在空间中清晰可辨。'],
  ['侧面边框近景','斜侧角度近景，呈现封闭面板边缘和正常墙面接触，不拆壳，不虚构内部结构。'],
  ['夜间正常使用','夜间入户环境，成人以干燥手指自然触控已确认位置；暖色室内光，标识只按原图，不夸张发光。'],
  ['门边客厅中景','另一侧门边或空间连接处的墙面中景，客厅家具和日常动线作背景。']
 ];
 const rooms=['白色客厅：白色布艺沙发、浅木茶几、宽窗，柔和日光。','暖木卧室：浅木床、奶油色床品、床头灯与高窗，晨间自然光，不出现客厅沙发。','傍晚客厅：夕照、暖色落地灯与宽窗，保持生活空间的尺度。'];
 const views=['整体安装远景，完整窗宽及合理轨道支撑，电机在室内保持真实小体积。','同一套房间的窗上部中景，显示轨道、原款电机、窗帘上沿与相邻墙面。','同一套安装位置的局部结构近景，电机与轨道连接、支撑和电源入口均只按商品参考图，不虚构接口。'];
 const genericScenes=['正常使用空间中景','参考图已确认的正常使用动作近景','第二处符合真实用途的空间中景','适用功能区中景','参考图可见材质细节','第三处适用空间中景','封闭外部结构细节','另一合理时段的正常使用','另一角度或空间连接处中景'];
 function enabled(run){return run.selection?.scenePlanVersion===2&&['search','guanghe'].includes(run.module)&&run.selection.variant!=='video';}
 function category(title,selection={}){if(['switch','electricCurtain','other'].includes(selection.soutuiCategory))return selection.soutuiCategory;if(/电动窗帘|窗帘电机|窗帘轨道/.test(title))return 'electricCurtain';if(/开关|触摸面板/.test(title))return 'switch';return 'other';}
 function slot(run,item,index){const group=Number(item.context?.articleIndex||0);if(!Number.isInteger(group)||group<0||group>8||!Number.isInteger(index)||index<0||index>2)throw Error('场景图须为一至九组、每组三张。');const type=category(item.title||'',run.selection),n=group*3+index,styleIndex=n%9,cycle=Math.floor(group/3),variation=['','采用另一侧合理机位，调整背景布置与自然光方向，保持商品真实安装位置、原款外观和用途。','采用另一处同类真实空间与不同取景距离，保持商品原款结构、尺寸关系和真实用途，不新增功能。'][cycle],base=type==='switch'?switchScenes[styleIndex][1]:type==='electricCurtain'?rooms[group%3]+views[index]:genericScenes[styleIndex]+'；根据参考图和已核对用途选择适用环境。用途无法确认时只展示商品外观与中性日常环境，不增加操作或安装假设。',total=Math.max(9,Math.min(27,siblings(run,item).length*3));return {type,group,index,n,styleIndex,total,ratio:type==='electricCurtain'?'1:1':'3:4',name:(type==='switch'?switchScenes[styleIndex][0]:type==='electricCurtain'?['整体安装','中景使用','局部结构'][index]:genericScenes[styleIndex])+(cycle?'·视角'+(cycle+1):''),scene:base+variation};}
 function prompt(run,item,index){const s=slot(run,item,index);return [
  '生成一张完整的真实商业生活场景照片，比例'+s.ratio+'。不是九宫格，不拼图，不切图。',
  '商品：'+(item.title||'以商品参考图为准')+'。参考图用于当前商品身份；严格保留外形、颜色、表面材质、原有控制位置、部件数量与标识。不得将同类商品的外观套到本商品。',
  '已核对资料：'+(run.selection.facts||'未提供额外资料；未知尺寸、功能和认证不得编造。'),
  '场景 '+(s.n+1)+'/'+s.total+'：'+s.scene,
  s.type==='electricCurtain'?'通过镜头远近改变景别，不放大实际电机；保持参考图中的安装方向、壳体比例、接缝、轨道连接和电源入口。尺寸仅按已核对资料，不能套用其他型号。':'尺度按合理相对关系处理，通过镜头距离改变景别，不改变商品物理大小。',
  '人物与手仅在用途明确时出现，手部自然，不遮挡关键商品特征。保持合理墙面或台面接触、反射和光线。无广告字、参数字、箭头、水印、边框；不增加未知配件、结构或能力。',
  (s.type==='switch'?'开关仅使用当前商品原图作为图像参考，生活场景只依据文字描述。逐一保留原图面板分区、分缝方向、按键形状、原色和指示点位置，不新增圆形触控图案或发光环，不借用其他型号外观。':s.type==='electricCurtain'&&index>0?'参考图2是本套已完成整体场景，保持同一房间、安装方向与连接位置，只改变镜头距离。':'如有后续参考图，其角色由输入资料明确。')+'保持同款同色同结构。输出一张'+s.ratio+'独立照片。'
 ].join('\n');}
 function copy(run,item,all=false){if(run.module==='guanghe'&&run.parentFlowId&&item.prepared?.reusedSoutuiCopy){const p=item.prepared;if(run.selection.maxCalls!==0||!p.title||Array.from(p.title).length>20||!p.body||!p.uploadedAssets?.length||p.uploadedAssets.length>9||p.uploadedAssets.length!==item.generations?.length||item.generations.some(g=>g.status!=='completed'||g.available!==true||g.productIds?.join()!==item.productIds.join()))throw Error('光合同步的原素材、文案或零生图范围未确认。');return {title:p.title,body:p.body,sceneCategory:p.sceneCategory};}const type=category(item.title||'',run.selection),group=Number(item.context?.articleIndex||0),name=Array.from(item.title||'商品').slice(0,10).join(''),labels=all?type==='electricCurtain'?'白色客厅、暖木卧室、傍晚客厅三套场景':type==='switch'?'走廊、卧室、厨房、客厅的生活中景、触控近景及外观细节':'日常环境、正常使用与外观细节':type==='electricCurtain'?rooms[group%3].split('：')[0]:[0,1,2].map(i=>slot(run,item,i).name).join('、');return {title:Array.from(name+(all?'家居场景搭配':'场景搭配'+(group+1))).slice(0,20).join(''),body:labels+'，展示同一款商品的外观与空间搭配。实际产品、配置、尺寸及安装条件请以商品详情和现场条件为准。',sceneCategory:type};}
 function siblings(run,item){return run.items.filter(x=>x.productIds?.join()===item.productIds.join()).sort((a,b)=>Number(a.context?.articleIndex||0)-Number(b.context?.articleIndex||0));}
 function syncAssets(run,item){const parts=siblings(run,item);if(parts.some(x=>!x.receipt))throw Error('同商品素材尚未逐组取得发布回执。');const reused=parts.slice(0,3),assets=reused.flatMap(x=>x.prepared?.uploadedAssets||[]),generations=reused.flatMap(x=>x.generations||[]);if(!assets.length||assets.length>9||assets.length!==reused.length*3||new Set(assets.map(x=>x.name)).size!==assets.length)throw Error('同步图片数量或原文件名不唯一。');return {assets,generations,articleIds:reused.map(x=>x.id),totalArticleCount:parts.length};}
 function batchPrefix(run,item){const uuid=String(run.id||'').replace(/-/g,''),pid=item.productIds?.length===1?String(item.productIds[0]):'';if(!/^[a-f0-9]{32}$/i.test(uuid)||!/^[1-9]\d{5,19}$/.test(pid))throw Error('搜推文件命名缺少明确轮次或商品身份。');return 'mat-'+BigInt('0x'+uuid).toString(36)+'-'+BigInt(pid).toString(36);}
 function fileName(run,item,asset){const n=Number(asset.sceneIndex);if(!Number.isInteger(n)||n<0||n>26)throw Error('搜推原素材序号无效。');return batchPrefix(run,item)+'-'+String(n+1).padStart(2,'0')+'.png';}
 // Match the platform's checksum of the original uploaded file; CDN copies may be recompressed.
 function md5Bytes(bytes){const length=bytes.length,size=Math.ceil((length+9)/64)*64,buffer=new Uint8Array(size);buffer.set(bytes);buffer[length]=128;const view=new DataView(buffer.buffer);view.setUint32(size-8,(length*8)>>>0,true);view.setUint32(size-4,Math.floor(length/536870912),true);let a0=0x67452301,b0=0xefcdab89,c0=0x98badcfe,d0=0x10325476;const shifts=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21],constants=Array.from({length:64},(_,i)=>Math.floor(Math.abs(Math.sin(i+1))*4294967296)|0);
  for(let offset=0;offset<size;offset+=64){let a=a0,b=b0,c=c0,d=d0;for(let i=0;i<64;i++){let f,g;if(i<16){f=(b&c)|(~b&d);g=i;}else if(i<32){f=(d&b)|(~d&c);g=(5*i+1)%16;}else if(i<48){f=b^c^d;g=(3*i+5)%16;}else{f=c^(b|~d);g=(7*i)%16;}const sum=(a+f+constants[i]+view.getInt32(offset+g*4,true))|0,shift=shifts[(i>>4)*4+(i%4)],oldD=d;d=c;c=b;b=(b+((sum<<shift)|(sum>>>(32-shift))))|0;a=oldD;}a0=(a0+a)|0;b0=(b0+b)|0;c0=(c0+c)|0;d0=(d0+d)|0;}
  return [a0,b0,c0,d0].flatMap(word=>[0,8,16,24].map(n=>((word>>>n)&255).toString(16).padStart(2,'0'))).join('');
 }
 function md5Data(data){const match=/^data:image\/(?:png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(data||'');if(!match)throw Error('原生成文件数据无效，未恢复截名图片。');return md5Bytes(Uint8Array.from(atob(match[1]),c=>c.charCodeAt(0)));}
 const api={enabled,category,slot,prompt,copy,siblings,syncAssets,batchPrefix,fileName,md5Bytes,md5Data};root.FullSoutuiScenes=api;if(typeof module==='object')module.exports=api;
})(globalThis);
