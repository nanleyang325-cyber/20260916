(function(root){
 'use strict';
 const KEY='material-white-journal-v1',RETENTION={recent:1500,archive:3500,block:200},PROGRESS_RETENTION={days:3,maxEvents:60000};
 const copy=x=>structuredClone(x),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),pid=x=>/^\d{6,}$/.test(String(x)),stamp=x=>Number.isFinite(Date.parse(x))?Date.parse(x):0;
 function clean(value){return String(value??'').replace(/data:[^\s]+/gi,'[已省略数据]').replace(/https?:\/\/[^\s]+/gi,'[已省略链接]').replace(/\bBearer\s+[^\s,;]+/gi,'Bearer <REDACTED>').replace(/((?:authorization|api[_ -]?key|access[_ -]?token|token|password|secret|密码|密钥|令牌)["']?\s*[:=]\s*["']?)[^\s,;"']+/gi,'$1<REDACTED>').replace(/\b(?:sk|grs)-[A-Za-z0-9_-]{12,}/g,'<REDACTED>').slice(0,4000);}
 const labels={wait:'等待',generating:'生成中',generated:'待回填',filling:'回填中',done:'✅完成',failed:'⛔失败',skip:'⏭跳过',unknown:'待确认',boundary:'已停在执行边界'};
 function matching(ids,expected){return Array.isArray(ids)&&same([...new Set(ids.map(String))].sort(),[...new Set(expected.map(String))].sort());}
 function itemPhase(item,run){
  const ids=(item.productIds||[]).map(String),gs=item.generations||[];
  if(item.reviewOutcome?.code==='4'&&item.reviewOutcome.name==='审核不通过'&&item.receipt)return 'failed';
  if(item.status==='verified'&&item.receipt?.source==='platform-readback'&&item.receipt.contentId&&matching(item.receipt.productIds,ids))return 'done';
  if(run.status==='boundary_blocked'&&matching(run.boundaryBlocked?.productIds,ids))return 'boundary';
  if(item.whiteTerminal==='failed'||item.status==='failed'||gs.some(g=>g.status==='failed'))return 'failed';
  if(item.whiteTerminal==='skipped'||item.status==='skipped')return 'skip';
  if(item.whiteTerminal==='unconfirmed'||['blocked','submitted_unconfirmed','needs_attention','verified'].includes(item.status)||gs.some(g=>['submission_unconfirmed','downloaded_unverified'].includes(g.status)))return 'unknown';
  if(item.whiteConsumed)return 'unknown';
  if(item.publication||item.prepared?.whiteUploaded||Object.keys(item.uploadIntents||{}).length)return 'filling';
  if(gs.length&&gs.every(g=>g.status==='completed'&&g.available===true&&matching(g.productIds,ids)))return 'generated';
  if(gs.some(g=>g.intent&&['pending','running','processing','queued'].includes(g.status)))return 'generating';
  if(item.nativeIntent)return item.nativeResult?.status==='completed'?'generated':'generating';
  return 'wait';
 }
 function snapshot(run,now=Date.now()){
  if(!run||run.module!=='white'||!run.id)return null;
  const rows=[],byPid=new Map(),at=new Date(now).toISOString();
  for(const item of run.items||[]){const phase=itemPhase(item,run),note=clean(item.detail||item.error||(phase==='boundary'?run.boundaryBlocked?.action:'')||'');
   for(const id of item.productIds||[]){if(!pid(id))continue;const row={pid:String(id),phase,status:phase,label:labels[phase],note,costText:'费用待确认',step:'白底图',executionPhase:clean(item.phase||''),updatedAt:at};
    if(byPid.has(row.pid)){const existing=byPid.get(row.pid);if(existing.phase!==row.phase||existing.note!==row.note)Object.assign(existing,{phase:'unknown',status:'unknown',label:labels.unknown,note:'同一商品存在不同结果，待核对'});}else{byPid.set(row.pid,row);rows.push(row);}}
  }
  const counts={total:rows.length,done:0,failed:0,skip:0,unknown:0,boundary:0,wait:0,generating:0,generated:0,filling:0};for(const row of rows)counts[row.phase]++;
  const source=clean(run.selection?.source||run.selection?.whiteBgSourceMethod||'ai_generate');
  return {id:clean(run.id),startedAt:stamp(run.createdAt)?run.createdAt:at,updatedAt:at,status:clean(run.status||''),mode:['ids','custom'].includes(run.selection?.mode)?'ids':'all',source,ai:source==='ai_generate',discoveryComplete:run.whitePaging?.exhausted===true||(!run.whitePaging&&run.phase!=='discover'),rows,counts};
 }
 function initial(){return {version:1,nextLine:1,runLog:[],archive:[],latest:null,runs:[],progressEvents:[],cursors:{}};}
 function stateOf(previous){return previous?.version===1?copy(previous):initial();}
 function append(state,text,at,runId){state.runLog.push({seq:state.nextLine++,at,text:clean(text),runId:clean(runId||'')});while(state.runLog.length>RETENTION.recent){const line=state.runLog.shift();let block=state.archive.at(-1);if(!block||block.length>=RETENTION.block){block=[];state.archive.push(block);}block.push(line);}let total=state.archive.reduce((n,b)=>n+b.length,0);while(total>RETENTION.archive&&state.archive.length>1)total-=state.archive.shift().length;}
 function timeLabel(at){return new Date(at).toLocaleTimeString('zh-CN',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'});}
 function trim(state,now){const cutoff=now-PROGRESS_RETENTION.days*86400000;state.runs=state.runs.filter(r=>stamp(r.updatedAt)>=cutoff);state.progressEvents=state.progressEvents.filter(e=>stamp(e.at)>=cutoff).slice(-PROGRESS_RETENTION.maxEvents);for(const id of Object.keys(state.cursors))if(stamp(state.cursors[id].updatedAt)<cutoff&&id!==state.latest?.id)delete state.cursors[id];}
 function ingest(previous,run,now=Date.now()){
  if(!run||run.module!=='white'||!run.id)return previous||initial();
  const state=stateOf(previous),next=snapshot(run,now),events=Array.isArray(run.events)?run.events:[],cursor=state.cursors[next.id],prior=state.runs.find(r=>r.id===next.id);
  if(prior&&!stamp(run.createdAt))next.startedAt=prior.startedAt;
  if(cursor&&events.length<cursor.eventCount)return previous;
  if(cursor&&cursor.eventCount&&events[cursor.eventCount-1]&&clean(JSON.stringify(events[cursor.eventCount-1]))!==cursor.lastEvent)return previous;
  for(let i=cursor?.eventCount||0;i<events.length;i++){const event=events[i],at=stamp(event.at)?event.at:next.updatedAt;append(state,'['+timeLabel(at)+'][白底图] '+clean(event.detail||''),at,next.id);}
  // Row time is the last evidenced change, not the time a popup happened to reopen.
  for(const row of next.rows){const old=prior?.rows.find(r=>r.pid===row.pid);if(old&&same({...old,updatedAt:null},{...row,updatedAt:null}))row.updatedAt=old.updatedAt;else state.progressEvents.push({at:next.updatedAt,runId:next.id,pid:row.pid,phase:row.phase,status:row.status,note:row.note});}
  const changed=!prior||!same({...prior,updatedAt:null},{...next,updatedAt:null});
  if(!changed)next.updatedAt=prior.updatedAt;
  if(cursor&&events.length===cursor.eventCount&&!changed)return previous;
  state.runs=state.runs.filter(r=>r.id!==next.id);state.runs.push(next);state.runs.sort((a,b)=>stamp(b.startedAt)-stamp(a.startedAt));
  if(!state.latest||state.latest.id===next.id||stamp(next.startedAt)>=stamp(state.latest.startedAt))state.latest=copy(next);
  state.cursors[next.id]={eventCount:events.length,lastEvent:events.length?clean(JSON.stringify(events.at(-1))):'',updatedAt:next.updatedAt};trim(state,now);return state;
 }
 async function readState(){return (await root.chrome.storage.local.get(KEY))[KEY]||initial();}
 async function record(run){return root.FullStateStore.update(KEY,previous=>{const next=ingest(previous,run);return next===previous?undefined:next;});}
 async function recordNotice(text,level='info'){return root.FullStateStore.update(KEY,previous=>{const state=stateOf(previous),at=new Date().toISOString();append(state,'['+timeLabel(at)+'] '+(level==='error'?'⛔ ':'')+clean(text),at,'');return state;});}
 async function readHistory(state){state=state||await readState();const archived=(state.archive||[]).flat();return {lines:[...archived,...state.runLog||[]].map(r=>r.text),total:archived.length+(state.runLog||[]).length,recentCount:(state.runLog||[]).length,archiveCount:archived.length,retention:{...RETENTION}};}
 async function readProgressHistory(state){state=stateOf(state||await readState());trim(state,Date.now());return {runs:state.runs,events:state.progressEvents,total:state.progressEvents.length,retention:{...PROGRESS_RETENTION}};}
 const moduleNames={white:'白底图',transparent:'透明图',scene:'场景图',buyer:'买家秀',mainvideo:'主图视频',fission:'链接裂变',outfit:'批量换装',search:'搜推图文',searchvideo:'搜推视频',trend:'趋势提报',selling:'卖点素材',incubate:'新品孵化',guanghe:'光合',follow:'关注图文'};
 const stepNames={sections:'读取趋势分类',opportunity:'读取趋势主题',page:'核对候选商品',submit:'提交冻结批次',discover:'读取商品集合',prepare:'核对商品与素材',copy:'生成并核对文案',generate:'生成素材',native:'处理平台原生素材',cutout:'本地抠图',attach:'上传并绑定素材',publish:'核对表单并提交',readback:'回查平台结果',sync:'同步已选渠道',done:'本项结束'};
 function validReceipt(item){const r=item.receipt;return item.status==='verified'&&r?.source==='platform-readback'&&(!!r.contentId||r.resultKind==='trend-report'&&r.activityId&&r.api&&r.platformStatus&&['shopId','tabId','windowId','sectionKey','activityId','opportunityType'].every(k=>String(r.scope?.[k]??'')!==''&&String(r.scope[k])===String(item.intent?.scope?.[k]))&&r.intentId===item.intent?.id)&&matching(r.productIds,item.productIds||[]);}
 function receiptNote(item){const r=item.receipt,n=Number.isSafeInteger(r?.imageCount)?r.imageCount:item.prepared?.uploadedAssets?.length;if(r.resultKind==='trend-report')return clean('活动ID '+r.activityId+' · '+r.platformStatus);return clean('作品ID '+r.contentId+' · '+(n>0?n+'张图 · ':'')+(r.status||'审核状态未确认'));}
 function taskEvents(run){
  const events=[],seen=new Set();
  function walk(node,depth){if(!node||depth>2||seen.has(node.id||node))return;seen.add(node.id||node);const own=Array.isArray(node.events)?node.events:[];
   for(const e of own)events.push({at:e.at,phase:e.phase,position:e.position,detail:clean(e.detail||''),module:node.module,moduleName:moduleNames[node.module]||'素材任务',runId:node.id,child:depth>0});
   if(depth>0||node.module==='guanghe')for(const item of node.items||[])if(validReceipt(item))events.push({at:own.at(-1)?.at||null,phase:'readback',detail:'已发布并回查 · '+receiptNote(item),module:node.module,moduleName:moduleNames[node.module]||'素材任务',runId:node.id,child:depth>0,receipt:true});
   for(const item of node.items||[])for(const child of item.syncRuns||[])walk(child,depth+1);
  }walk(run,0);return events.sort((a,b)=>stamp(a.at)-stamp(b.at));
 }
 function channelRows(run){
  const rows=[],seen=new Set();for(const parent of run.items||[])for(const child of parent.syncRuns||[]){if(!moduleNames[child.module]||seen.has(child.id||child))continue;seen.add(child.id||child);
   for(const [index,item]of(child.items||[]).entries()){
    const verified=validReceipt(item),live=child.enabled===true&&child.position===index;let phase=verified?'done':item.status==='skipped'||child.status==='skipped'?'skip':item.status==='failed'||child.status==='failed'?'failed':!live&&(['blocked','stopped'].includes(child.status)||['verified','submitted_unconfirmed','blocked'].includes(item.status))?'unknown':['attach','publish','readback','sync'].includes(item.phase)?'filling':'wait';
    const note=verified?receiptNote(item):clean(item.error||child.error||item.detail||stepNames[item.phase]||'等待渠道执行');
    for(const id of item.productIds||[])if(pid(id))rows.push({pid:String(id),module:child.module,phase,status:phase,label:verified?'已发布 · 已回查':labels[phase],groupLabel:moduleNames[child.module],step:verified?'发布及回查':stepNames[item.phase]||'渠道发布',note,costText:item.prepared?.uploadedAssets?.length?'图片 '+item.prepared.uploadedAssets.length+' 张':'',executionPhase:clean(item.phase||''),updatedAt:child.events?.at(-1)?.at||child.createdAt});
   }
  }return rows;
 }
 function downloadState(gs){
  const pending=(gs||[]).filter(g=>g.status==='download_pending');if(!pending.length)return null;
  const permission=pending.some(g=>/授权/.test(g.error||'')||g.downloadOrigin&&!/下载或解码未通过/.test(g.error||''));
  const failed=pending.some(g=>/下载或解码未通过/.test(g.error||''));
  return {count:pending.length,code:permission?'DOWNLOAD_PERMISSION_REQUIRED':failed?'DOWNLOAD_RETRY_PENDING':'DOWNLOAD_PENDING',label:permission?'等待下载授权':failed?'下载失败，等待重试':'正在下载素材',detail:permission?'结果已生成，等待下载授权；请打开「API设置」授权下载':failed?'结果已生成，下载或解码失败，正在重试下载':'结果已生成，正在下载并保存素材'};
 }
 function runtime(run){
  const item=run.items?.[run.position],gs=item?.generations||[],last=(run.events||[]).at(-1),phase=run.kind==='trend'?run.phase:run.phase==='discover'?'discover':item?.phase,group=item?.context?.articleIndex,parts=run.items?.filter(x=>matching(x.productIds,item?.productIds||[]))||[];
  const active=run.enabled===true&&run.status!=='paused',status=({awaiting_review_retry:'审核不通过，等待选择',running:'运行中',paused:'已暂停',draining:'收尾中',done:'本轮结束',blocked:'已阻塞，需回查',pending_review:'结果待确认',boundary_blocked:'已到执行边界',budget_exhausted:'调用预算已用尽',stopped:'已停止',drained:'已收尾停止'})[run.status]||'状态待确认';
  const complete=gs.filter(g=>g.status==='completed'&&g.available===true&&matching(g.productIds,item?.productIds||[])).length;
  let detail=stepNames[phase]||'等待下一步';
  if(phase==='generate'&&gs.length){const pending=gs.find(g=>g.status!=='completed'||g.available!==true||!matching(g.productIds,item?.productIds||[]));detail='素材已完成 '+complete+'/'+gs.length+(pending?' · 第'+(gs.indexOf(pending)+1)+'张'+({draft:'待开始',pending:'等待通道返回',queued:'排队中',running:'生成中',processing:'处理中',submission_unconfirmed:'提交待确认',downloaded_unverified:'下载待核验',failed:'生成失败'}[pending.status]||'状态待确认'):' · 等待上传');}
  if(phase==='generate'&&run.module==='search'&&run.selection?.scenePlanVersion===2){const batch=(run.items||[]).filter(i=>matching(i.productIds,item.productIds)).flatMap(i=>i.generations||[]);if(batch.length>gs.length){const done=batch.filter(g=>g.status==='completed'&&g.available===true).length,submitted=batch.filter(g=>g.intent).length;detail='素材已完成 '+done+'/'+batch.length+' · 已提交 '+submitted+' 张 · 并发生成中';}}
  if(phase==='generate'){const batch=(run.items||[]).filter(i=>matching(i.productIds,item?.productIds||[])).flatMap(i=>i.generations||[]),download=downloadState(batch);if(download)detail=download.detail+'（'+download.count+'张）';}
  if(run.kind==='trend')detail=(run.trend.sections[run.trend.sectionIndex]?.name||'趋势分类')+' · '+(run.trend.opportunity?.title||stepNames[phase]||'等待')+' · 已回查 '+run.trend.stats.submitted+' · 跳过 '+run.trend.stats.skipped+' · 失败 '+run.trend.stats.failed+' · 免费';
  if(phase==='readback')detail='已提交，等待平台回查；不重复提交';
  if(phase==='sync'){const child=item?.syncRuns?.find(r=>!['done','skipped'].includes(r.status));detail='搜推已回查，'+(child?.module==='guanghe'?'光合'+(stepNames[child.items?.[child.position]?.phase]||'发布与回查'):'继续同步已选渠道');}
  if(run.status==='paused')detail='已暂停，保留当前步骤：'+(stepNames[phase]||'等待');
  else if(!active&&run.status!=='done')detail=clean(run.error)||status;
  else if(run.status==='done'){const channels=channelRows(run);detail=run.kind==='trend'?'本轮结束 · 处理 '+run.trend.stats.trendsProcessed+' 个趋势 · 已回查 '+run.trend.stats.submitted+' 个商品提报 · 跳过 '+run.trend.stats.skipped+' · 失败 '+run.trend.stats.failed+' · 免费':'本轮已结束，逐项结果见下方'+(channels.length?'；'+channels.map(r=>r.groupLabel+' '+r.label+' · '+r.note).join('；'):'');}
  if(run.selection?.mode==='cleanup'&&run.status==='done'){detail=run.taskFailures?.length?'清理未完成：'+clean(run.taskFailures.at(-1).reason):run.selection.dryRun?'演练完成，命中 '+(run.items||[]).filter(i=>i.status==='preview').length+' 条素材，未删除':'本轮清理已结束，请查看逐项结果';}
  return {moduleName:run.selection?.mode==='cleanup'?'清理素材':moduleNames[run.module]||'素材任务',status,active,phase,detail:clean(detail),productId:clean(item?.productIds?.join('、')||''),groupLabel:Number.isInteger(group)?'第'+(group+1)+'/'+parts.length+'组':'',lastAt:stamp(last?.at)?last.at:stamp(run.createdAt)?run.createdAt:null,lastDetail:clean(last?.detail||''),generationCalls:Number.isInteger(run.usedCalls)?run.usedCalls:null};
 }
 // Display projection only: does not change persisted task state, scope, or receipts.
 function view(run,now=Date.now()){
  if(!run?.id||!moduleNames[run.module])return null;
  let next;if(run.module==='white')next=snapshot(run,now);else if(run.module==='transparent')next=root.FullTransparentRun?.snapshot(run);
  if(!next){const rows=[];for(const [index,item]of(run.items||[]).entries()){
   if(run.kind==='trend'&&item.status==='cancelled_before_submit'&&item.preflight?.dispatchNeverStarted===true){for(const id of item.productIds||[])if(pid(id))rows.push({pid:String(id),phase:'cancelled',status:'cancelled',label:'未提交，重新检索',note:clean(item.detail),costText:'免费 · 生成调用 0',step:'提交前复核',executionPhase:'preflight',groupLabel:'活动 '+item.context?.activityId,updatedAt:item.preflight.checkedAt});continue;}
   const ids=item.productIds||[],gs=item.generations||[],live=run.enabled===true&&index===run.position;let phase='wait';
   if(validReceipt(item))phase='done';
   else if(item.status==='skipped')phase='skip';else if(item.status==='preview')phase='preview';else if(item.status==='failed'||gs.some(g=>g.status==='failed'))phase='failed';
   else if(!live&&(['blocked','submitted_unconfirmed','pending_confirmation','verified','sync_blocked'].includes(item.status)||item.phase==='done'&&item.status!=='pending'))phase='unknown';
   else if(item.publication||item.intent||['attach','publish','readback','sync'].includes(item.phase)||Object.keys(item.uploadIntents||{}).length)phase='filling';
   else if(gs.length&&gs.every(g=>g.status==='completed'&&g.available===true&&matching(g.productIds,ids)))phase='generated';
   else if(downloadState(gs))phase='download';
   else if(gs.some(g=>g.intent)||item.nativeIntent||item.textIntent)phase='generating';
   else if(live&&['prepare','copy','native','generate'].includes(item.phase))phase='working';
   for(const id of ids)if(pid(id))rows.push({pid:String(id),phase,status:phase,label:phase==='download'?downloadState(gs).label:phase==='working'?(stepNames[item.phase]||'正在处理'):phase==='preview'?'演练完成':labels[phase],note:clean(phase==='download'?(downloadState(gs).code==='DOWNLOAD_PERMISSION_REQUIRED'?'请在API设置授权，原任务会继续':downloadState(gs).code==='DOWNLOAD_RETRY_PENDING'?'保留生成结果，正在重试下载':'保存后继续上传'):phase==='working'?'':run.kind==='trend'&&validReceipt(item)?receiptNote(item):live?(stepNames[item.phase]||'处理中'):(item.detail||item.error||(index===run.position&&run.status==='blocked'?run.error:'')||'')),costText:run.kind==='trend'?'免费 · 生成调用 0':gs.length?'素材 '+gs.filter(g=>g.status==='completed'&&g.available===true&&matching(g.productIds,ids)).length+'/'+gs.length:'费用待确认',step:stepNames[item.phase]||moduleNames[run.module],executionPhase:clean(item.phase||''),groupLabel:run.kind==='trend'?'活动 '+item.context?.activityId:Number.isInteger(item.context?.articleIndex)?'第'+(item.context.articleIndex+1)+'组':'',updatedAt:run.events?.at(-1)?.at||run.createdAt});
  }if(run.kind==='trend'){const seen=new Set();for(const e of run.events||[]){const key=String(e.activityId)+'|'+String(e.productId);if(!/^跳过商品 /.test(e.detail||'')||!pid(e.productId)||!/^\d+$/.test(String(e.activityId||''))||seen.has(key))continue;seen.add(key);rows.push({pid:String(e.productId),phase:'skip',status:'skip',label:labels.skip,note:clean(e.detail),costText:'免费 · 生成调用 0',step:'核对候选商品',executionPhase:'page',groupLabel:'活动 '+e.activityId,updatedAt:e.at});}}const counts={total:rows.length,done:0,failed:0,skip:0,unknown:0,boundary:0,wait:0,generating:0,generated:0,filling:0,preview:0,download:0,working:0};if(run.kind==='trend')counts.cancelled=0;for(const row of rows)counts[row.phase]++;next={id:clean(run.id),module:run.module,startedAt:run.createdAt,updatedAt:run.events?.at(-1)?.at||run.createdAt,status:run.status,mode:['ids','custom'].includes(run.selection?.mode)?'ids':'all',discoveryComplete:run.phase!=='discover',rows,counts};}
  const channels=channelRows(run);if(channels.length){const rows=[...next.rows,...channels],counts={...next.counts,total:rows.length};for(const key of Object.keys(counts))if(key!=='total')counts[key]=0;for(const row of rows)counts[row.phase]=(counts[row.phase]||0)+1;next={...next,rows,counts};}
  return {...next,module:run.module,runtime:runtime(run)};
 }
 const api={downloadState,KEY,RETENTION,PROGRESS_RETENTION,clean,itemPhase,snapshot,view,runtime,taskEvents,initial,ingest,readState,record,recordNotice,readHistory,readProgressHistory};root.FullWhiteJournal=api;if(typeof module==='object')module.exports=api;
})(globalThis);
