(function(root){
 'use strict';
 const vis=e=>e?.getClientRects().length>0,text=e=>(e?.innerText||e?.textContent||'').trim(),pause=ms=>new Promise(r=>setTimeout(r,ms));
 async function wait(fn,label){for(let n=0;n<50;n++){if(/请拖动下方滑块完成验证|验证失败，点击框体重试/.test(document.body.innerText))throw Error('淘宝要求本人验证，请完成后继续原任务。');const value=fn();if(value)return value;await pause(200);}throw Error(label+'未就绪，保留原任务。');}
 function one(values,label){if(values.length!==1)throw Error(label+'不唯一。');return values[0];}
 function button(scope,label){return one([...scope.querySelectorAll('button')].filter(vis).filter(e=>!e.disabled&&text(e)===label),label);}
 function set(input,value){Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,value);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
 function selectedProduct(dialog,pid){
  const boxes=[...dialog.querySelectorAll('input[type="checkbox"]:checked')];if(!boxes.length)return false;
  // The platform can render the same selected product in more than one card.
  // Verify every checked card's identity, then the distinct selected count.
  for(const box of boxes){const card=box.closest('[class*="item-v2--itemCard"]'),links=card?[...card.querySelectorAll('a[href]')]:[];if(!links.length||links.some(a=>{try{const u=new URL(a.href);return u.protocol!=='https:'||!['item.taobao.com','detail.tmall.com'].includes(u.hostname)||u.searchParams.get('id')!==pid;}catch{return true;}}))throw Error('已勾选商品身份不符或不明确，保留原关联弹层。');}
  const badges=[...dialog.querySelectorAll('[class*="selected-items--"] .next-badge[title]')].filter(vis);if(badges.length!==1||badges[0].getAttribute('title')!=='1')throw Error('已选商品总数未确认唯一，保留原关联弹层。');return true;
 }
 async function bind(pid){
  const bound=()=>[...document.querySelectorAll('[class*="item-v2--list-item"][data-id]')].filter(vis).map(e=>e.getAttribute('data-id'));
  const dialogs=()=>[...document.querySelectorAll('.next-dialog')].filter(vis).filter(e=>e.querySelector('input[placeholder*="商品ID"]'));
  if(bound().length&&bound().join()!==pid)throw Error('表单已有其他关联商品。');
  const opened=dialogs();if(opened.length>1)throw Error('商品关联弹层不唯一。');if(!opened.length&&bound().join()===pid)return bound();
  if(!opened.length)one([...document.querySelectorAll('[class*="items-trigger-hover"]')].filter(vis),'添加商品入口').click();
  const dialog=opened[0]||await wait(()=>{const a=dialogs();return a.length===1?a[0]:null;},'商品关联弹层');
  const confirm=async()=>{if(!selectedProduct(dialog,pid))throw Error('原商品尚未勾选，未确认关联。');button(dialog,'确定').click();await wait(()=>!vis(dialog),'关联弹层关闭');if(bound().join()!==pid)throw Error('保存到表单的商品身份不符。');return bound();};
  if(selectedProduct(dialog,pid))return confirm();
  const shop=[...dialog.querySelectorAll('li.next-tabs-tab')].filter(e=>/^本店商品\s*[?？]?$/.test(text(e)));if(shop.length===1){shop[0].click();await pause(400);}
  const active=dialog.querySelector('.next-tabs-tabpane.active')||dialog,input=one([...active.querySelectorAll('input[placeholder*="商品ID"]')].filter(vis),'商品ID搜索框');set(input,pid);await pause(250);for(const type of ['keydown','keyup'])input.dispatchEvent(new KeyboardEvent(type,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));const icon=active.querySelector('.next-icon-search');if(icon)icon.click();
  const anchor=await wait(()=>[...active.querySelectorAll('a[href]')].find(a=>{try{return new URL(a.href).searchParams.get('id')===pid;}catch{return false;}}),'同商品关联卡片');
  let card;for(let c=anchor,n=0;c?.parentElement&&n<7;n++,c=c.parentElement){const r=c.getBoundingClientRect(),ids=[...c.querySelectorAll('a[href]')].map(a=>{try{return new URL(a.href).searchParams.get('id');}catch{return null;}}).filter(Boolean);if(r.width>=140&&r.width<=340&&r.height>=150&&c.querySelector('img')&&ids.length&&ids.every(id=>id===pid)){card=c;break;}}
  if(!card)throw Error('商品卡片归属未唯一确认。');card.click();await wait(()=>selectedProduct(dialog,pid),'单商品勾选');return confirm();
 }
 function declaration(required){const labels=[...document.querySelectorAll('label')].filter(vis).filter(l=>/^(?:含AI生成内容|内容无需(?:标注|注明)|含虚构演绎内容|含个人观点|含医疗建议|含金融投资建议)$/.test(text(l)));const chosen=labels.filter(l=>l.querySelector('input:checked'));if(chosen.length>1)throw Error('创作者声明选择不唯一，请本人核对。');const mandatory=required||labels.some(l=>l.closest('[aria-required="true"],.next-form-item-required,.ant-form-item-required')||l.querySelector('input[required]'));if(mandatory&&!chosen.length)throw Error('平台要求内容声明，请本人选择后继续；插件不自动勾选任何声明，素材保留。');return {available:labels.length>0,selected:chosen.length===1,value:chosen.length?text(chosen[0]):null,automatic:false};}
 async function options(){
  one([...document.querySelectorAll('*')].filter(e=>vis(e)&&!e.children.length&&text(e)==='点击添加话题'),'添加话题入口').click();
  let dialog=await wait(()=>[...document.querySelectorAll('[role="dialog"]')].find(vis),'话题弹层');const name='家居好东西重点推荐';
  // The default recommendation list is personalized and need not contain this topic.
  const home=await wait(()=>{const a=[...dialog.querySelectorAll('[role="option"]')].filter(vis).filter(e=>text(e)==='家居');return a.length?one(a,'家居话题分类'):null;},'家居话题分类');home.click();
  const card=await wait(()=>{const a=[...dialog.querySelectorAll('[data-autolog-container="topic-item-card"]')].filter(vis).filter(e=>[...e.querySelectorAll('[class*="topic-title-font"]')].some(t=>text(t)===name));return a.length?one(a,'家居话题'):null;},'家居话题');card.click();const info=card.querySelector('[class*="topic-info"]');if(info)info.click();button(dialog,'确认提交').click();await wait(()=>!vis(dialog),'话题选择完成');if(!text(document.querySelector('.topic-v2-root')).includes(name))throw Error('话题未回读。');
  one([...document.querySelectorAll('[class*="music-selector--selector_card"]')].filter(vis),'音乐入口').click();dialog=await wait(()=>[...document.querySelectorAll('[role="dialog"]')].find(vis),'音乐弹层');one([...dialog.querySelectorAll('.menu-card')].filter(e=>text(e)==='一周热歌榜'),'热歌榜').click();await wait(()=>dialog.querySelectorAll('.card-list .music-space-card').length,'热歌曲目');const cards=[...dialog.querySelectorAll('.card-list .music-space-card')],index=Math.floor(Math.random()*Math.min(6,cards.length)),music=cards[index],lines=text(music).split('\n').map(s=>s.trim()).filter(Boolean);music.click();button(dialog,'确定').click();await wait(()=>!vis(dialog),'音乐选择完成');if(!lines[1]||!text(document.querySelector('.music-selector-container')).includes(lines[1]))throw Error('音乐未回读。');return {topic:{name,verified:true},music:{name:lines[1],artist:lines[2]||'',source:'平台一周热歌榜前六首',verified:true}};
 }
 function verify(job){const clean=s=>String(s||'').replace(/[\uFEFF\u200B]/g,'').trim(),title=[...document.querySelectorAll('input[placeholder*="加个标题"],input[maxlength="20"],input[name="shortTitle"]')].find(vis),rich=[...document.querySelectorAll('.rich-text-content[data-cangjie-content="true"]')].find(vis),ta=[...document.querySelectorAll('textarea')].find(vis),images=[...document.querySelectorAll('.picture-list-item')].filter(vis).map(c=>c.querySelector('img')?.src||''),ids=[...document.querySelectorAll('[class*="item-v2--list-item"][data-id]')].filter(vis).map(e=>e.getAttribute('data-id')),declarationState=declaration(job.module==='guanghe'),declarationSelected=declarationState.selected;if(clean(title?.value)!==job.title||clean(rich?rich.innerText:ta?.value)!==job.body)throw Error('图文正文或标题不匹配。');if(job.module==='guanghe'){if(images.length!==job.uploadedAssets.length||images.some((u,i)=>!u.startsWith(job.uploadedAssets[i].url)))throw Error('保存的光合图片数量、顺序或来源不符。');if(ids.join()!==job.productIds.join()||!declarationSelected)throw Error('光合关联商品或创作者声明不符。');}return {title:job.title,body:job.body,productIds:ids,images,creatorDeclaration:declarationState.value,topic:text(document.querySelector('.topic-v2-root')),music:text(document.querySelector('.music-selector-container'))};}
 function pictureState(job){
  const files=job.uploadedAssets,ids=[...document.querySelectorAll('[class*="item-v2--list-item"][data-id]')].filter(vis).map(e=>e.getAttribute('data-id'));
  if(job.module!=='guanghe'||job.productIds?.length!==1||ids.join()!==job.productIds.join())throw Error('光合表单关联商品不符，未重复选图。');
  if(!Array.isArray(files)||!files.length||files.length>9||files.some(f=>{try{const u=new URL(f.url);return u.protocol!=='https:'||!/(^|\.)alicdn\.com$/.test(u.hostname);}catch{return true;}})||new Set(files.map(f=>f.url)).size!==files.length)throw Error('光合原图清单无效，未打开选图器。');
  const uploader=one([...document.querySelectorAll('.content-picture-uploader-wrapper')].filter(vis),'光合图片区域'),cards=[...uploader.querySelectorAll('.picture-list-item')].filter(vis),images=cards.map(c=>c.querySelector('img')?.src||'');
  if(!cards.length)return {state:'empty',count:0};
  const matches=(src,url)=>src===url||src.startsWith(url+'_')||src.startsWith(url+'?');
  if(images.length!==files.length||images.some((src,i)=>!matches(src,files[i].url)))throw Error('光合表单已有图片与本批的数量、顺序或来源不符；已保留当前图片，未重复加入。请核对表单后继续原任务。');
  return {state:'complete',count:images.length,images};
 }
 function openPictures(){const existing=[...document.querySelectorAll('iframe')].filter(vis).filter(e=>{try{return /\/app\/crs-qn\/sucai-selector-ng/.test(new URL(e.src,location.href).pathname);}catch{return false;}});if(existing.length>1)throw Error('已打开的图片选择器不唯一。');if(existing.length===1)return {opened:true,reused:true};const a=[...document.querySelectorAll('.next-picture-uploader')].filter(vis);one(a,'官方选图入口').click();return {opened:true};}
 root.FullSoutuiForm={bind,declaration,options,verify,openPictures,pictureState};
})(globalThis);
