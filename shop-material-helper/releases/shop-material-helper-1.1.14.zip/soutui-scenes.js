(function(root){
 'use strict';
 const switchScenes=[
  ['走廊生活中景','明亮中性的住宅走廊，商品安装在近处合理墙面；远处可有一位虚化成人，不呈现可识别面容。中景，保留走廊生活动线。'],
  ['正常触控近景','干燥成人手指自然轻触参考图已确认的触控位置；商品清晰，正常家居背景虚化。不得增加按键或发光标识。'],
  ['卧室门边中景','卧室门边的合理墙面位置，背景有床和床头灯，商品仍为正常手掌大小。'],
  ['厨房侧墙中景','干燥厨房侧墙，避开水槽、灶火及溅水区；橱柜和台面提供背景，商品保持参考图安装方式。'],
  ['材质细节','深色或中性墙面上的面板材质近景，展现原有反射和边框，控制符号、颜色和数量只按参考图。'],
  ['客厅生活中景','客厅墙面中景，沙发、绿植或家具作为背景，商品在空间中清晰可辨。'],
  ['侧面边框近景','斜侧角度近景，呈现封闭面板边缘和正常墙面接触，不拆壳，不虚构内部结构。'],
  ['夜间正常使用','夜间入户环境，成人以干燥手指自然触控已确认位置；暖色室内光，标识只按原图，不夸张发光。'],
  ['门边客厅中景','另一侧门边或空间连接处的墙面中景，客厅家具和日常动线作背景。']
 ];
 const rooms=['白色客厅：白色布艺沙发、浅木茶几、宽窗，柔和日光。','暖木卧室：浅木床、奶油色床品、床头灯与高窗，晨间自然光，不出现客厅沙发。','傍晚客厅：夕照、暖色落地灯与宽窗，保持生活空间的尺度。'];
 const views=['整体安装远景，完整窗宽及合理轨道支撑，电机在室内保持真实小体积。','同一套房间的窗上部中景，显示轨道、原款电机、窗帘上沿与相邻墙面。','同一套安装位置的局部结构近景，电机与轨道连接、支撑和电源入口均只按商品参考图，不虚构接口。'];
 const genericScenes=['正常使用空间中景','参考图已确认的正常使用动作近景','第二处符合真实用途的空间中景','适用功能区中景','参考图可见材质细节','第三处适用空间中景','封闭外部结构细节','另一合理时段的正常使用','另一角度或空间连接处中景'];
 const rackScenes=[
  ['厨房放哪里','厨房操作台侧边的完整整架，周围保留实际通行和篮筐展开空间。用台面边缘说明摆放关系，少量密封食材；可确认旋转结构时单篮适度转出。'],
  ['备餐如何拿取','厨房中的完整整架，一只成人手从已确认能转出的篮筐拿一件密封食材；通过拿取路径讲清用途，不遮挡支柱、连接和其余篮筐。动作无法确认时展示相同位置的可见收纳状态。'],
  ['食材如何分层','适度俯视的完整整架，各层少量不同包装食材；只按原图可确认的旋转连接错开篮筐，重点呈现分层而非孔洞特写。'],
  ['沙发旁收起状态','沙发扶手旁的完整整架，各篮合拢，少量零食分层；沙发只提供位置关系，不拍整个豪华客厅。'],
  ['坐着如何取物','完整整架与少量坐姿成人前臂，朝沙发一侧的已确认转篮打开，一件小包装零食正被取出。保持真实比例，不声称适合所有座高。'],
  ['零食纸巾如何分开','完整整架，适量小包装零食和纸巾分别放在不同层，按已确认结构适度错开两篮，清楚看到两类物品的取用位置。'],
  ['桌边能放什么','书桌外侧完整整架，只放尺寸确实适配篮筐的小文具盒和小本子；不塞入未经核实的桌底或窄缝，展示桌边与收纳架的位置关系。'],
  ['篮筐如何展开','完整整架在明亮桌边，手部轻扶支柱和篮沿辅助呈现参考已确认的旋转方向；连接始终可见。缺少动作依据则只呈现已确认的展开姿态，不虚构转轴或转角。'],
  ['用后如何归位','明亮桌边完整整架，所有篮筐合拢且少量物品仍分层，保留与桌腿和通道的关系；明确表现收起状态，不用傍晚氛围替代信息。']
 ];
 const switchScenesV3=[
  ['入户安装位置','近处门边墙面的完整原款面板，门框与入户动线作为位置参照。'],['正常触控位置','完整面板和少量干燥成人手指，轻触参考已确认位置；分缝和所有原按键仍清楚可见。'],['面板分区','完整面板正面，适度斜向自然光使原有分区和标识清晰，不凭外观编造按键功能。'],
  ['卧室门边位置','完整面板位于卧室门边，少量门框与床边背景说明使用位置。'],['侧向操作视角','完整面板，成人手从正常站位伸向已确认控制位置，保持合理安装尺度和接触。'],['墙面安装关系','略侧机位拍完整面板，清楚看到原边框与墙面接合，不拆壳，不虚构暗盒内部。'],
  ['客厅动线位置','完整面板和一小段空间连接处，沙发虚化且不抢主体，说明从客厅经过时的使用位置。'],['原有标识辨认','完整面板在自然室内光下，所有原符号、颜色和指示点清楚，不新增发光环或灯光功能。'],['安装后整体外观','完整面板正侧组合视角的一张照片，体现安装后与墙面及门边比例，非拼图、非微小裁切重复。']
 ];
 const curtainScenesV3=[
  ['客厅安装关系','完整展示本次售卖配置的电机及安装关系，窗边环境只辅助说明位置，电机清楚可辨。'],['窗边连接关系','保留完整电机及参考确认的轨道连接，窗帘上沿提供用途信息，不拍裁切电机的特写。'],['安装空间关系','完整电机与墙边及轨道的空间关系清楚，尺度仅按已核实资料，不承诺任意空间适装。'],
  ['卧室安装位置','卧室窗侧的完整原款电机和实际连接，床品仅作弱背景。'],['窗帘与电机关系','同一卧室完整电机，展示参考可见的窗帘与轨道关系，不编造开合幅度和操控方式。'],['原款外部结构','同一安装处完整电机，边缘和真实走线清楚，不拆壳、不臆造接口。'],
  ['书房窗边位置','书房窗侧完整电机，桌面一角提供安装位置背景。'],['支撑与连接','完整电机连同参考图已确认的支撑连接，避免远景使商品过小。'],['安装后外观','完整电机及窗帘在正常使用位置，连接清楚、背景简洁，补充实际安装信息。']
 ];
 const genericScenesV3=[
  ['放置位置','完整商品与真实适用环境的摆放关系'],['取用位置','完整商品及依据参考已确认的取用关系，未确认动作时保留静态外观'],['分区关系','完整商品的可见分区或外部结构'],
  ['使用前状态','完整商品在参考已确认的使用前状态'],['正常使用状态','完整商品及参考已确认的正常使用状态，不臆造功能'],['使用后状态','完整商品在已确认的收纳或归位状态'],
  ['空间关系','完整商品与周围实际适配物体的位置关系，不宣称具体尺寸适配'],['外部结构','完整商品的一张斜侧照片，所有关键部件可辨，不用局部特写'],['日常摆放','完整商品与参考已确认配件的日常摆放，不添加未知配件']
 ];
 function creativeType(run,item){const title=item.title||'';return /旋转/.test(title)&&/置物架|收纳架|零食架|收纳篮|置物篮|转篮/.test(title)?'rotatingRack':category(title,run.selection);}
 function creativeSlot(run,item,index){
  const group=Number(item.context?.articleIndex||0);if(!Number.isInteger(group)||group<0||group>8||!Number.isInteger(index)||index<0||index>2)throw Error('场景图须为一至九组、每组三张。');
  const type=creativeType(run,item),n=group*3+index,styleIndex=n%9,cycle=Math.floor(group/3),plans=type==='rotatingRack'?rackScenes:type==='switch'?switchScenesV3:type==='electricCurtain'?curtainScenesV3:genericScenesV3,[name,scene]=plans[styleIndex];
  const extra=cycle===1?'本轮补充购买问题：实际使用需要留出哪些周围空间？以合理的相邻家具关系说明，不标未经核对的尺寸。':cycle===2?'本轮补充购买问题：物品或手从哪个方向接近商品？用参考已确认的接近路径和遮挡关系说明，不重复前轮摆放。':'';
  return {type,group,index,n,styleIndex,total:Math.max(3,Math.min(27,siblings(run,item).length*3)),ratio:type==='electricCurtain'?'1:1':'3:4',name:name+(cycle===1?'与周围空间':cycle===2?'与接近路径':''),scene:scene+extra};
 }
 function creativePrompt(run,item,index){const s=creativeSlot(run,item,index);return [
  '生成一张'+s.ratio+'真实家居使用照片，用于淘宝天猫搜推素材。独立照片，不拼图、不分格。商品：'+(item.title||'以当前SKU参考图为准')+'。',
  '当前SKU参考图是商品身份依据，严格保留颜色、外形、材质、部件数量、标识和连接。已核实资料：'+(run.selection.facts||'未提供额外资料；尺寸、性能、认证及未知功能不得编造。'),
  '本张 '+(s.n+1)+'/'+s.total+' 只回答购买问题：'+s.name+'。画面：'+s.scene,
  '商品完整入镜并清楚可辨，上下左右留安全空间，不能裁切关键部件、不能被手或物品遮住。商品始终为第一视觉主体，环境只帮助解释本张用途；不要非重点局部特写，不要过远大景。',
  s.type==='rotatingRack'?'逐一保留参考SKU的层数、篮筐形状、孔洞、支柱、顶盘、底座、脚轮和旋转连接；有则保留，无则不加。不把转篮改成可拆卸、抽拉或磁吸结构，不套用另一SKU。开合幅度及动作必须有参考依据；无法确认时只展示参考中已确认的姿态。道具适量且尺寸可放入，不遮挡层间关系。':s.type==='switch'?'完整面板的分区、分缝、按键、原色和指示点逐项忠于原图，不新增圆形触控图案或发光环；仅正常墙面安装，手干燥且不遮主体。':s.type==='electricCurtain'?'电机保持真实小体积，通过镜头取景让它清楚，不改变物理大小。完整原款电机、原轨道连接和电源入口清晰，同组后续图片沿用参考图2房间及安装位置。':'只呈现参考和已核实资料支持的用途；未知用途采用中性摆放，不臆造安装和使用方法。',
  '自然柔和光线，真实表面、接触阴影、比例及手部接触。避免明显广告海报、夸张棚拍光效、悬浮部件、塑料质感、虚假滤镜和豪宅背景抢主体。',
  '与商品主图提供不同且可见的购买信息；同组在摆放关系、动作或状态上明确变化，不只换墙色、换道具色、镜像或微小裁切。不要直接复刻主图构图。',
  '默认无字是本次创作选择，并非平台一律禁字；本图不生成价格、促销、水印、边框或夸大承诺。如需补充文字，只预留少量不抢主体的位置，由真实资料后期添加。输出一张独立照片。'
 ].join('\n');}
 function creativeCopy(run,item,all){
  const s=creativeSlot(run,item,0),group=s.group%3,clean=String(item.title||'商品').replace(/[\uFEFF\u200B]/g,'').trim(),name=s.type==='rotatingRack'?'旋转置物架':s.type==='switch'?'开关面板':s.type==='electricCurtain'?'电动窗帘':Array.from(clean).slice(0,8).join('');
  const titles=s.type==='rotatingRack'?['厨房旋转置物架，分层放与拿','沙发旁的旋转零食收纳架','桌边旋转置物架，打开与归位']:s.type==='switch'?['入户开关，安装与操作位置','卧室开关，面板与墙面关系','客厅开关，位置与原款外观']:s.type==='electricCurtain'?['客厅电动窗帘，安装连接关系','卧室窗帘电机，窗边安装位置','书房窗帘电机，支撑与外观']:[name+'的摆放与取用',name+'的使用与归位',name+'的空间与结构'];
  const bodies=s.type==='rotatingRack'?[
   '厨房台侧收纳，可以关注食材分层、拿取路径与篮筐展开空间。摆放前核对所选规格尺寸，层数、配置与允许开合方式以实际SKU为准。',
   '沙发旁收纳，可以关注零食与纸巾分层、座位附近的拿取位置以及合拢状态。请核对架体高度和展开空间，避免挡住日常通道。',
   '桌边收纳，可以关注小件物品分层、篮筐展开和用后归位。先核对物品与篮筐尺寸，旋转方式和部件配置以所选SKU为准。'
  ]:s.type==='switch'?[
   '入户位置选开关，可以关注安装位置、原款按键分区及正常操作是否方便。功能、尺寸和安装条件请核对所选型号资料。',
   '卧室门边的开关，可以关注面板外观、操作位置和墙面安装关系。按键用途与接线要求以所选型号说明为准。',
   '客厅选开关，可以关注动线中的位置、原有标识和安装后的面板外观。实际配置以所选型号为准。'
  ]:s.type==='electricCurtain'?[
   '客厅窗帘电机选型，可以关注电机、轨道与窗边的安装连接关系。安装空间、供电和兼容条件须核对所选配置。',
   '卧室窗帘电机，可以关注窗侧位置、原款外部结构与轨道连接。不可仅凭场景判断尺寸或轨道兼容。',
   '书房窗帘电机，可以关注安装位置、支撑连接和安装后的外观。尺寸、接口及供电条件请核对所选型号。'
  ]:[name+'选购可关注实际摆放位置、取用方式和可见外部结构。用途及尺寸以所选规格资料为准。',name+'选购可关注正常使用前后的状态和归位条件。未在商品资料确认的功能不作承诺。',name+'选购可关注与周围空间的关系及原款外部结构。请核对尺寸和实际配置。'];
  const cycle=Math.floor(s.group/3),suffix=cycle===1?' 同时核对相邻家具与使用空间，避免未经测量就判断适配。':cycle===2?' 同时关注物品或手的接近路径，避免遮挡商品操作位置。':'';
  return {title:Array.from(all?name+'的摆放与使用':cycle===1?name+'与周围使用空间':cycle===2?name+'的取用与接近路径':titles[group]).slice(0,20).join(''),body:all?bodies.join('\n'):bodies[group]+suffix,sceneCategory:s.type};
 }

 const rackFeaturedScenes=[
  ['厨房摆放位置','厨房操作台侧边的完整整架，少量密封食材；台面与通道同时可见，以相邻位置回答放在哪里，不以打开篮筐为主题。'],
  ['备餐拿取路径','完整整架放在备餐台侧，只有在参考支持取物动作时，干燥成人手从上方拿起篮内一件小包装食材，手不遮结构；否则静态显示物品与取物开口之间的无遮挡路径。'],
  ['上层使用空间','完整整架，以略俯视机位清楚展示最上层放置一件尺寸适配的小物后，仍能看清的开口和余量；若参考含顶盘则保留顶盘但不新增。其他篮保持少量物品，不重复多层分类。'],
  ['座位旁的相对位置','完整整架位于沙发扶手外侧，扶手边缘与架顶同时可见，突出坐席与放置高度关系，不画手，不以所有篮筐合拢为主题。'],
  ['侧边接近空间','完整整架在沙发外侧，镜头由座位朝通道取景；篮内一件小包装与侧边无遮挡接近空间可见，不再画另一张手拿零食。'],
  ['不同物品如何分层','完整整架正面，少量密封零食与独立纸巾各占不同层；层与层之间关系清楚，重点是物品分类，不用换墙色冒充差异。'],
  ['桌边小件收纳','完整整架位于书桌外侧，篮内只有尺寸适配的小文具盒和小本子，桌面保留实际工作区；不塞入未经测量的桌底。'],
  ['开合需要的空间','完整整架和周围桌腿、通道一起可见；只有参考确认旋转结构时才适度展开一个篮，展示展开所占空间；否则用参考姿态展示架体周围应核对的空间，不画动作。'],
  ['用后回到摆放位置','完整整架回到桌外侧的常用位置，桌面一小件文具与篮内同类物品呈现归位关系；篮筐姿态严格沿用参考，不用另一张展开或多层分类代替。']
 ];
 function featuredSlot(run,item,index){const s=creativeSlot(run,item,index);if(s.type!=='rotatingRack')return s;const [name,scene]=rackFeaturedScenes[s.styleIndex];return {...s,name,scene:scene+(Math.floor(s.group/3)===1?'补充相邻家具空间关系。':Math.floor(s.group/3)===2?'补充另一种已核实物品的接近路径。':'')};}
 function featuredPrompt(run,item,index){const old=creativeSlot(run,item,index),s=featuredSlot(run,item,index),proof=item.reviewedReference;let prompt=creativePrompt(run,item,index).replace('同组后续图片沿用参考图2房间及安装位置。','同组保持一致的房间和安装关系，不把另一SKU作为房间参考。').replace('只回答购买问题：'+old.name+'。画面：'+old.scene,'只回答购买问题：'+s.name+'。画面：'+s.scene);prompt+='\n本次模型参考审查仅是可见外观辅助判断，不能视为卖家确认的SKU、材质、尺寸或性能。';if(proof)prompt+='\n参考审查看到：'+proof.visibleFacts+'\n参考支持动作：'+proof.supportedActions.join('、')+'。未列出的动作一律不要演示；优先保留参考静态姿态。';return prompt;}
 function featuredCopy(run,item,all){const copy=creativeCopy(run,item,all);if(creativeType(run,item)!=='rotatingRack')return copy;const n=Number(item.context?.articleIndex||0)%3;return {...copy,title:all?'旋转置物架的摆放与收纳':['厨房置物架，位置与取用空间','沙发旁收纳，分层与接近空间','桌边置物架，小件收纳与归位'][n],body:all?'厨房、沙发旁和桌边的收纳用途，可分别核对摆放位置、取用空间与物品分类。实际尺寸、配置及允许动作以所选规格资料为准。':['厨房收纳可关注台侧摆放位置、备餐拿取路径和上层使用空间。请核对尺寸及所选规格，开合方式以真实结构为准。','沙发旁收纳可关注与座位的相对位置、侧边接近空间，以及零食和纸巾的分类。请核对实物尺寸，保留通道空间。','桌边收纳可关注小文具的放置、周围空间和用后归位。物品与篮筐尺寸、部件及开合方式以所选规格资料为准。'][n]};}

 function enabled(run){return run.selection?.scenePlanVersion===2&&['search','guanghe'].includes(run.module)&&run.selection.variant!=='video';}
 function category(title,selection={}){if(['switch','electricCurtain','other'].includes(selection.soutuiCategory))return selection.soutuiCategory;if(/电动窗帘|窗帘电机|窗帘轨道/.test(title))return 'electricCurtain';if(/开关|触摸面板/.test(title))return 'switch';return 'other';}
 function slot(run,item,index){if(run.selection?.creativePlanVersion===4)return featuredSlot(run,item,index);if(run.selection?.creativePlanVersion===3)return creativeSlot(run,item,index);const group=Number(item.context?.articleIndex||0);if(!Number.isInteger(group)||group<0||group>8||!Number.isInteger(index)||index<0||index>2)throw Error('场景图须为一至九组、每组三张。');const type=category(item.title||'',run.selection),n=group*3+index,styleIndex=n%9,cycle=Math.floor(group/3),variation=['','采用另一侧合理机位，调整背景布置与自然光方向，保持商品真实安装位置、原款外观和用途。','采用另一处同类真实空间与不同取景距离，保持商品原款结构、尺寸关系和真实用途，不新增功能。'][cycle],base=type==='switch'?switchScenes[styleIndex][1]:type==='electricCurtain'?rooms[group%3]+views[index]:genericScenes[styleIndex]+'；根据参考图和已核对用途选择适用环境。用途无法确认时只展示商品外观与中性日常环境，不增加操作或安装假设。',total=Math.max(9,Math.min(27,siblings(run,item).length*3));return {type,group,index,n,styleIndex,total,ratio:type==='electricCurtain'?'1:1':'3:4',name:(type==='switch'?switchScenes[styleIndex][0]:type==='electricCurtain'?['整体安装','中景使用','局部结构'][index]:genericScenes[styleIndex])+(cycle?'·视角'+(cycle+1):''),scene:base+variation};}
 function prompt(run,item,index){if(run.selection?.creativePlanVersion===4)return featuredPrompt(run,item,index);if(run.selection?.creativePlanVersion===3)return creativePrompt(run,item,index);const s=slot(run,item,index);return [
  '生成一张完整的真实商业生活场景照片，比例'+s.ratio+'。不是九宫格，不拼图，不切图。',
  '商品：'+(item.title||'以商品参考图为准')+'。参考图用于当前商品身份；严格保留外形、颜色、表面材质、原有控制位置、部件数量与标识。不得将同类商品的外观套到本商品。',
  '已核对资料：'+(run.selection.facts||'未提供额外资料；未知尺寸、功能和认证不得编造。'),
  '场景 '+(s.n+1)+'/'+s.total+'：'+s.scene,
  s.type==='electricCurtain'?'通过镜头远近改变景别，不放大实际电机；保持参考图中的安装方向、壳体比例、接缝、轨道连接和电源入口。尺寸仅按已核对资料，不能套用其他型号。':'尺度按合理相对关系处理，通过镜头距离改变景别，不改变商品物理大小。',
  '人物与手仅在用途明确时出现，手部自然，不遮挡关键商品特征。保持合理墙面或台面接触、反射和光线。无广告字、参数字、箭头、水印、边框；不增加未知配件、结构或能力。',
  (s.type==='switch'?'开关仅使用当前商品原图作为图像参考，生活场景只依据文字描述。逐一保留原图面板分区、分缝方向、按键形状、原色和指示点位置，不新增圆形触控图案或发光环，不借用其他型号外观。':s.type==='electricCurtain'&&index>0?'参考图2是本套已完成整体场景，保持同一房间、安装方向与连接位置，只改变镜头距离。':'如有后续参考图，其角色由输入资料明确。')+'保持同款同色同结构。输出一张'+s.ratio+'独立照片。'
 ].join('\n');}
 function copy(run,item,all=false){if(run.module==='guanghe'&&run.parentFlowId&&item.prepared?.reusedSoutuiCopy){const p=item.prepared;if(run.selection.maxCalls!==0||!p.title||Array.from(p.title).length>20||!p.body||!p.uploadedAssets?.length||p.uploadedAssets.length>9||p.uploadedAssets.length!==item.generations?.length||item.generations.some(g=>g.status!=='completed'||g.available!==true||g.productIds?.join()!==item.productIds.join()))throw Error('光合同步的原素材、文案或零生图范围未确认。');return {title:p.title,body:p.body,sceneCategory:p.sceneCategory};}if(run.selection?.creativePlanVersion===4)return featuredCopy(run,item,all);if(run.selection?.creativePlanVersion===3)return creativeCopy(run,item,all);const type=category(item.title||'',run.selection),group=Number(item.context?.articleIndex||0),name=Array.from(item.title||'商品').slice(0,10).join(''),labels=all?type==='electricCurtain'?'白色客厅、暖木卧室、傍晚客厅三套场景':type==='switch'?'走廊、卧室、厨房、客厅的生活中景、触控近景及外观细节':'日常环境、正常使用与外观细节':type==='electricCurtain'?rooms[group%3].split('：')[0]:[0,1,2].map(i=>slot(run,item,i).name).join('、');return {title:Array.from(name+(all?'家居场景搭配':'场景搭配'+(group+1))).slice(0,20).join(''),body:labels+'，展示同一款商品的外观与空间搭配。实际产品、配置、尺寸及安装条件请以商品详情和现场条件为准。',sceneCategory:type};}
 function siblings(run,item){return run.items.filter(x=>x.productIds?.join()===item.productIds.join()).sort((a,b)=>Number(a.context?.articleIndex||0)-Number(b.context?.articleIndex||0));}
 function syncAssets(run,item){const parts=siblings(run,item);if(parts.some(x=>!x.receipt))throw Error('同商品素材尚未逐组取得发布回执。');const reused=parts.slice(0,3),assets=reused.flatMap(x=>x.prepared?.uploadedAssets||[]),generations=reused.flatMap(x=>x.generations||[]);if(!assets.length||assets.length>9||assets.length!==reused.length*3||new Set(assets.map(x=>x.name)).size!==assets.length)throw Error('同步图片数量或原文件名不唯一。');return {assets,generations,articleIds:reused.map(x=>x.id),totalArticleCount:parts.length};}
 function batchPrefix(run,item){const uuid=String(run.id||'').replace(/-/g,''),pid=item.productIds?.length===1?String(item.productIds[0]):'';if(!/^[a-f0-9]{32}$/i.test(uuid)||!/^[1-9]\d{5,19}$/.test(pid))throw Error('搜推文件命名缺少明确轮次或商品身份。');return 'mat-'+BigInt('0x'+uuid).toString(36)+'-'+BigInt(pid).toString(36);}
 function fileName(run,item,asset){const n=Number(asset.sceneIndex);if(!Number.isInteger(n)||n<0||n>26)throw Error('搜推原素材序号无效。');return batchPrefix(run,item)+'-'+String(n+1).padStart(2,'0')+'.png';}
 // Match the platform's checksum of the original uploaded file; CDN copies may be recompressed.
 function md5Bytes(bytes){const length=bytes.length,size=Math.ceil((length+9)/64)*64,buffer=new Uint8Array(size);buffer.set(bytes);buffer[length]=128;const view=new DataView(buffer.buffer);view.setUint32(size-8,(length*8)>>>0,true);view.setUint32(size-4,Math.floor(length/536870912),true);let a0=0x67452301,b0=0xefcdab89,c0=0x98badcfe,d0=0x10325476;const shifts=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21],constants=Array.from({length:64},(_,i)=>Math.floor(Math.abs(Math.sin(i+1))*4294967296)|0);
  for(let offset=0;offset<size;offset+=64){let a=a0,b=b0,c=c0,d=d0;for(let i=0;i<64;i++){let f,g;if(i<16){f=(b&c)|(~b&d);g=i;}else if(i<32){f=(d&b)|(~d&c);g=(5*i+1)%16;}else if(i<48){f=b^c^d;g=(3*i+5)%16;}else{f=c^(b|~d);g=(7*i)%16;}const sum=(a+f+constants[i]+view.getInt32(offset+g*4,true))|0,shift=shifts[(i>>4)*4+(i%4)],oldD=d;d=c;c=b;b=(b+((sum<<shift)|(sum>>>(32-shift))))|0;a=oldD;}a0=(a0+a)|0;b0=(b0+b)|0;c0=(c0+c)|0;d0=(d0+d)|0;}
  return [a0,b0,c0,d0].flatMap(word=>[0,8,16,24].map(n=>((word>>>n)&255).toString(16).padStart(2,'0'))).join('');
 }
 function md5Data(data){const match=/^data:image\/(?:png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(data||'');if(!match)throw Error('原生成文件数据无效，未恢复截名图片。');return md5Bytes(Uint8Array.from(atob(match[1]),c=>c.charCodeAt(0)));}
 const api={enabled,category,slot,prompt,copy,siblings,syncAssets,batchPrefix,fileName,md5Bytes,md5Data};root.FullSoutuiScenes=api;if(typeof module==='object')module.exports=api;
})(globalThis);
