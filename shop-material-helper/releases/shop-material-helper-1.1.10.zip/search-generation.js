(function(root){
 'use strict';
 const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),done=g=>g.status==='completed'&&g.available===true;
 function enabled(run){const s=run.selection||{};return run.module==='search'&&s.scenePlanVersion===2&&s.variant!=='video'&&!['replica','cleanup'].includes(s.mode)&&s.searchMode!=='replica'&&(!s.searchSource||s.searchSource==='ai');}
 function peers(run,item){return (run.items||[]).filter(i=>same(i.productIds,item.productIds)&&Number.isInteger(i.context?.articleIndex)&&i.context.articleIndex>=0&&i.context.articleIndex<9);}
 function ready(item,g){return g.sceneCategory!=='electricCurtain'||g.viewIndex===0||item.generations?.[0]?.status==='completed'&&item.generations[0].available===true;}
 async function advance(run,item,io){
  await io.check();const groups=peers(run,item).filter(i=>['prepare','generate'].includes(i.phase)).slice(0,3);
  if(!groups.includes(item))throw Error('并发生图的原商品与组别未确认。');
  const max=run.module==='search'?Infinity:Number(run.selection.maxCalls);if(run.module!=='search'&&(!Number.isInteger(max)||max<0))throw Error('原任务生图预算无效。');
  let remaining=max-run.usedCalls;const selected=[];
  for(const group of groups){
   const need=group.generations?group.generations.filter(g=>!g.intent&&!done(g)).length:3;
   if(need>remaining&&!run.draining){if(group===item)throw Error('剩余预算不足本组原素材，未新增生成。');continue;}
   if(!group.generations){
    if(run.draining)continue;
    await io.check();
    // Discovery fixed these siblings to one product. Reuse the already checked source,
    // and leave upload, form binding and publication to their existing serial steps.
    group.mainImage=item.mainImage;group.title=item.title;group.emptySlots=item.emptySlots;
    const plan=await io.planGeneration(run,group);await io.check();
    if(plan?.length!==3||plan.some(g=>!same(g.productIds,item.productIds)))throw Error('九图计划的商品或数量不符。');
    group.generations=plan;group.prepared={productIds:[...group.productIds],needsGeneration:true};group.phase='generate';
   }
   remaining-=need;selected.push(group);
  }
  const ids=selected.flatMap(i=>i.generations.map(g=>g.id));if(new Set(ids).size!==ids.length||ids.length>9)throw Error('并发原素材编号重复或超过九张。');
  await io.save('已保存同商品本批最多九张的并发计划；其余组串行接续，保留原素材编号，生成按原商品与篇数执行并累计实际次数。');
  // Poll every existing intent, including old serial jobs; never POST an old intent.
  const waiting=selected.flatMap(i=>i.generations.filter(g=>g.intent&&!done(g)).map(g=>({i,g})));
  const polled=await Promise.allSettled(waiting.map(async({i,g})=>{
   const result=await io.queryGeneration(run,i,g);
   if(result.id!==g.id||!same(result.productIds,i.productIds))throw Error('并发查询的原素材编号或商品不符。');
   if(result.status==='completed'&&result.available===true)Object.assign(g,result);
   else if(['failed','violation','submission_unconfirmed','downloaded_unverified','not_completed','missing'].includes(result.status)){g.status=result.status;g.error=result.error||result.message||'通道未返回可用图片';throw Object.assign(Error('原并发素材未确认（'+result.status+'）：'+g.error+'；保留原编号，不重投。'),{failureItemId:i.id});}
   else {g.status=result.status||'pending';g.error=result.error||result.message||'';g.downloadOrigin=result.downloadOrigin||null;}
  }));
  await io.save('已回查原并发素材编号。');await io.check();
  const failed=polled.find(r=>r.status==='rejected');if(failed)throw failed.reason;
  const submissions=[];let interrupted;
  try{for(const group of selected)for(const g of group.generations){
   if(done(g)||g.intent||!ready(group,g)||run.draining)continue;
   await io.check();if(run.draining)break;
   if(run.usedCalls>=max)throw Error('原任务调用预算已用完，未新增生成。');
   g.intent={id:g.id,at:new Date().toISOString()};g.status='pending';run.usedCalls++;
   run.usedCallsByType||={image:0,video:0,text:0};run.usedCallsByType.image=(run.usedCallsByType.image||0)+1;
   await io.save('已登记第'+run.usedCalls+'次原素材请求，准备并发提交。');await io.check();if(run.draining)break;
   // Register each intent durably, then overlap requests. Attach a rejection handler
   // immediately so a fast failure cannot escape while later intents are saved.
   submissions.push(Promise.resolve().then(()=>io.submitGeneration(run,group,g)).then(()=>({ok:true}),error=>({ok:false,error})));
  }}catch(error){interrupted=error;}
  const results=await Promise.all(submissions);await io.save('本轮并发提交 '+submissions.length+' 张；后续按原编号查询。');
  if(interrupted)throw interrupted;await io.check();const rejected=results.find(r=>!r.ok);if(rejected)throw rejected.error;
  for(const group of selected)if(group.generations.every(g=>g.status==='completed'&&g.available===true))group.phase='attach';
  if(run.draining&&selected.every(i=>i.generations.every(g=>g.status==='completed'||!g.intent))){run.enabled=false;run.status='drained';}
  await io.save('同商品素材完成 '+selected.flatMap(i=>i.generations).filter(g=>g.status==='completed'&&g.available===true).length+'/'+ids.length+'；上传、搜推及光合发布继续按原顺序执行。');
 }
 const api={enabled,peers,ready,advance};root.FullSearchGeneration=api;if(typeof module==='object')module.exports=api;
})(globalThis);
