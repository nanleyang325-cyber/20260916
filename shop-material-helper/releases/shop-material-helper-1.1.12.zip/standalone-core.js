/* Independent media engine. No desktop, filesystem, credential import or platform writes. */
(function(root){
 'use strict';
 const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
 const Models=root.MaterialImageModels||(typeof require==='function'?require('./image-models.js'):null);
 const Quality=root.MaterialFeaturedQuality||(typeof require==='function'?require('./featured-quality.js'):null);
 const IMAGE_MODELS=[...Models.catalog.map(m=>m.id),'nano-banana'];
 const terminal=s=>['completed','failed','rejected'].includes(s);
 const requestCount=j=>j.attempts?.length||(j.sent?1:0);
 const nextModel=j=>{const chain=['nano-banana-pro','gpt-image-2.5','gpt-image-2'],i=chain.indexOf(j.currentModel||j.request.model);return i>=0?chain[i+1]:null;};
 function capability(data){const m=typeof data.error==='string'?data.error:typeof data.error?.message==='string'?data.error.message:'';if(/moderation|safety|content.?filter|policy|prohibited|违规|違規|审核|審核|敏感|色情/i.test(String(data.failure_reason||'')+' '+m))return null;if(data.status!=='violation'||data.results?.length)return null;const lead=m.slice(0,220).normalize('NFKC').replace(/[\p{P}\p{Z}\s]/gu,'');return /^(?:我是語言模型，這件事超出我的能力範圍了。|我是语言模型，这件事超出我的能力范围了。)$/.test(m.trim())||/文本(?:人工智能|智能|AI)?(?:助手|模型)/.test(m)&&/(?:不具备|无法|不能).{0,25}(?:生成|渲染).{0,12}(?:图像|图片)/.test(m)||/^(?:作为|我是|我作为).{0,50}(?:人工智能|AI|语言模型|文本模型)/.test(lead)&&/我(?:无法|不能|不具备)(?:(?!但是|不过|但).){0,20}(?:生成|输出|渲染)(?:(?!但是|不过|但).){0,16}(?:图片|图像)(?:文件)?/.test(lead)?{code:'model_unavailable',reason:'text_instead_of_image'}:null;}
 const fail=(message,status=400,code)=>{throw Object.assign(Error(message),{status,...(code?{code}:{})});};
 function publicURL(raw){
  let u;try{u=new URL(raw);}catch{fail('接口地址无效');}
  const h=u.hostname.toLowerCase();
  if(u.protocol!=='https:'||u.username||u.password||u.port&&u.port!=='443'||!h.includes('.')||/^[\d.]+$/.test(h)||h.includes(':')||/(^|\.)(localhost|local|internal|test|invalid)$/.test(h))fail('只允许公开HTTPS服务域名，不使用本机或局域网服务');
  return u;
 }
 function validate(r){
  if(!r||!UUID.test(r.id||'')||r.consent!==true)fail('缺少唯一任务编号或本次费用确认');
  if(!['image','text','video'].includes(r.media))fail('此素材类型没有独立接口',503);
  if(!/^[a-z][a-z0-9_-]{0,39}$/.test(r.module||''))fail('素材模块无效');
  if(!Array.isArray(r.productIds)||r.productIds.some(x=>typeof x!=='string'||!/^\d{6,}$/.test(x))||new Set(r.productIds).size!==r.productIds.length)fail('商品范围无效');
  if(!r.productIds.length&&!['freegen','buyer','outfit','fission','prompt'].includes(r.module))fail('当前模块必须绑定真实商品ID');
  if(typeof r.prompt!=='string'||!r.prompt.trim()||r.prompt.length>12000)fail('提示词为空或过长');
  if(r.media==='image'){
   if(!IMAGE_MODELS.includes(r.model))fail('图片模型未接通',503);
   if(!['auto','1:1','3:4','4:3','9:16','16:9','2:3','3:2','4:5','5:4','21:9'].includes(r.ratio))fail('图片比例无效');
   if(!Array.isArray(r.references)||r.references.length>5||r.references.some(s=>typeof s!=='string'||s.length>9*1024*1024||!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(s)))fail('参考图必须是本次选定的PNG/JPG/WebP数据，最多5张');
  }else if(r.media==='video'){
   if(r.model!=='minimax-h3'||!['9:16','16:9'].includes(r.ratio))fail('视频仅支持原MiniMax H3及横屏/竖屏，不自动换模型或比例',503);
   if(r.videoFallback!==undefined&&(r.videoFallback?.model!=='agnes-video-2.5'||r.videoFallback?.resolution!=='720p'))fail('备用视频只能使用已确认的Agnes 720p单次范围');
   if(r.duration!==undefined&&r.duration!==10||r.resolution!==undefined&&!['480p','768p'].includes(r.resolution))fail('视频仅接续原10秒、480p/768p规格');
   if(!Array.isArray(r.references)||r.references.length<1||r.references.length>2||r.references.some(s=>typeof s!=='string'||s.length>9*1024*1024||!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(s)))fail('视频需要1至2张本次商品参考图');
  }else if(r.model!=='gemini-3.1-pro')fail('文案模型未接通',503);
  if(r.module==='featured-review'){if(r.media!=='text')fail('审图仅返回检查结果，不生成图片');Quality.validateRequest(r);}
  return JSON.parse(JSON.stringify(r));
 }
 function view(j){
  return {id:j.id,module:j.request.module,media:j.request.media,model:j.currentModel||j.request.model,...(j.request.media==='image'&&j.request.imageSettings?{imageSettings:(j.currentModel&&j.currentModel!==j.request.model?Models.settings(j.currentModel):j.request.imageSettings)}:{}),productIds:j.request.productIds,status:j.status,available:!!j.asset&&j.status==='completed',sceneAvailable:j.request.media==='image'&&!!j.asset&&j.status==='completed',mediaInfo:j.mediaInfo||null,sha256:j.sha256||null,text:j.text||null,...(j.request.module==='featured-review'?{review:j.review||null,reviewUsage:j.reviewUsage||null}:{}),error:j.error||'',progress:j.progress||0,providerRequestCount:requestCount(j),createdAt:j.createdAt,updatedAt:j.updatedAt,downloadOrigin:j.downloadOrigin||null,...(j.request.media==='video'?{provider:'grsai',duration:10,resolution:(j.currentModel==='agnes-video-2.5'?'720p':j.request.resolution)||(j.request.module==='searchvideo'?'768p':'480p'),attemptCount:requestCount(j)}:{})};
 }
 function engine(io){
  const locks=new Map();
  function lock(key,fn){const prev=locks.get(key)||Promise.resolve();const run=prev.catch(()=>{}).then(fn);locks.set(key,run);return run.finally(()=>{if(locks.get(key)===run)locks.delete(key);});}
  const stamp=()=>new Date(io.now()).toISOString();
  const save=async j=>{j.updatedAt=stamp();await io.put('jobs',j.id,j);return j;};
  async function config(){const c=await io.config();if(!c?.key)fail('请先在API设置中填写自己的GrsAI接口和密钥',503,'API_NOT_CONFIGURED');publicURL(c.base);return c;}
  async function connection(j){const c=await config();if(c.revision!==j.profile)fail('接口配置与原任务不同，未切换账号或重新提交',409);return c;}
  async function post(c,route,body,timeout=24000){
   const response=await io.fetch(c.base+route,{method:body===undefined?'GET':'POST',headers:{'Authorization':'Bearer '+c.key,'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)}),credentials:'omit',redirect:'error',signal:AbortSignal.timeout(timeout)});
   // Never retain or display provider error bodies, which can echo credentials/prompts.
   if(!response.ok)throw Object.assign(Error('AI接口HTTP '+response.status+'，保留原编号，不自动重发'),{providerHTTP:response.status});
   let data;try{data=await response.json();}catch{throw Error('AI响应无法识别；提交结果未知');}
   if(data.code!==undefined&&data.code!==0&&data.code!==200)throw Object.assign(Error('AI接口返回失败类别；不自动重发'),{providerRejected:true});
   return data.data??data;
  }
  async function submit(raw,registeredSettings){
   const r=validate(raw);
   return lock('job:'+r.id,async()=>{
    const old=await io.get('jobs',r.id);
    if(r.media==='image'){
     if(old){r.model=old.request.model;if(old.request.imageSettings)r.imageSettings={...old.request.imageSettings};else delete r.imageSettings;}
     else{const c=await config();r.model=registeredSettings?r.model:c.imageModel||r.model;if(r.model==='nano-banana')fail('旧nano-banana已下架，请在API设置选择当前模型',400);try{r.imageSettings=Models.settings(r.model,registeredSettings||c.imageSettings);}catch(e){fail(e.message);}}
    }
    const fingerprint=await io.hash(JSON.stringify(r));
    if(old){if(old.fingerprint!==fingerprint)fail('同一任务编号的内容已经变化，禁止重复提交',409);return view(old);}
    const c=await config();
    if(await io.paused(r.id))fail('已暂停新增AI请求；本次未提交，请在API设置恢复后继续原任务',409,'AI_REQUESTS_PAUSED');
    const j={id:r.id,request:r,fingerprint,profile:c.revision,status:'queued',sent:false,createdAt:stamp(),updatedAt:stamp()};
    await save(j);await io.wake();return view(j);
   });
  }
  async function process(id){return lock('job:'+id,async()=>{
   const j=await io.get('jobs',id);if(!j||terminal(j.status))return j&&view(j);
   if(j.sent){return poll(j);}
   if(await io.paused(j.id))return view(j);
   let c;try{c=await connection(j);}catch{j.error='接口未就绪，原任务待处理';await save(j);return view(j);}
   // Durable intent BEFORE network. A worker crash here must never cause a second POST.
   j.status='submission_unconfirmed';j.sent=true;j.error='已记录发送意图，等待接口回执';j.attempts||=[];j.currentModel=j.nextModel||j.currentModel||j.request.model;j.attempts.push({model:j.currentModel,status:'submission_unconfirmed',at:stamp()});await save(j);
   if(await io.paused(j.id)){j.attempts.pop();j.sent=false;j.status='queued';j.error='已暂停，尚未向服务商发送';await save(j);return view(j);}
   delete j.nextModel;const r={...j.request,model:j.currentModel};
   try{
    if(r.module==='featured-review'){
     const release=io.keepAlive?.();let result;try{result=await post(c,'/v1/chat/completions',Quality.requestBody(r),120000);}finally{release?.();}
     j.review=Quality.parse(result.choices?.[0]?.message?.content,r);
     const u=result.usage;j.reviewUsage=u&&Number.isSafeInteger(u.prompt_tokens)&&Number.isSafeInteger(u.completion_tokens)&&u.prompt_tokens>=0&&u.completion_tokens>=0?{inputTokens:u.prompt_tokens,outputTokens:u.completion_tokens,estimatedCredits:u.prompt_tokens*.03+u.completion_tokens*.14,priceBasis:'2026-11-07目录参考，实际扣费以服务商为准'}:null;
     j.status='completed';j.error='';
    }else if(r.media==='text'){
     const result=await post(c,'/v1/chat/completions',{model:r.model,messages:[{role:'user',content:r.prompt}],stream:false});
     const content=result.choices?.[0]?.message?.content;if(typeof content!=='string')throw Error('文案回执格式未确认');
     let text;try{text=JSON.parse(content.replace(/^```(?:json)?\s*/,'').replace(/\s*```$/,''));}catch{throw Error('文案不是约定JSON，未填入商品内容');}
     if(!text||Array.isArray(text)||typeof text!=='object')throw Error('文案结构未确认');
     j.text=Object.fromEntries(['title','body','shortPoint','longPoint'].filter(k=>typeof text[k]==='string').map(k=>[k,text[k].slice(0,12000)]));
     if(!j.text.body)throw Error('文案正文为空');j.status='completed';j.error='';
    }else if(r.media==='video'){
     const secondary=r.model==='agnes-video-2.5';
     const result=await post(c,'/v1/api/generate',{model:r.model,prompt:r.prompt,aspectRatio:secondary?r.ratio:r.ratio==='9:16'?'portrait':'landscape',images:r.references,resolution:secondary?'720p':r.resolution||(r.module==='searchvideo'?'768p':'480p'),duration:10,...(!secondary?{promptSkill:false}:{}),replyType:'async'});
     if(typeof result.id!=='string'||!result.id||result.id.length>256)throw Error('没有视频任务编号');
     j.providerId=result.id;j.status='pending';j.error='';
    }else{
     const route=r.model.startsWith('nano-banana')?'/v1/draw/nano-banana':'/v1/draw/completions';
     const size=r.imageSettings?Models.parameters(r.model,r.ratio,r.model===j.request.model?r.imageSettings:undefined):(r.model.startsWith('nano-banana')?{imageSize:'2K'}:{quality:'auto'});
     const result=await post(c,route,{model:r.model,prompt:r.prompt,aspectRatio:r.ratio,...size,urls:r.references,webHook:'-1',shutProgress:false});
     const pid=result.id;if(typeof pid!=='string'||!pid||pid.length>256)throw Error('未取得服务商任务编号；禁止重新提交');
     j.providerId=pid;j.status='pending';j.error='';
    }
   }catch(e){
    // Only explicit rejection is terminal. 5xx, timeout, malformed replies remain unknown.
    if(e.providerRejected||[400,401,403,404,422,429].includes(e.providerHTTP)){j.status='failed';j.error=e.providerHTTP?'AI接口拒绝请求（HTTP '+e.providerHTTP+'）':'AI接口明确拒绝了请求';}
    else{j.status='submission_unconfirmed';j.error='提交结果未确认，保留编号。请在服务商账单/任务中核对，不自动重发。';}
   }
   Object.assign(j.attempts.at(-1),{status:j.status,...(j.providerId?{providerId:j.providerId}:{})});await save(j);return view(j);
  });}
  async function poll(j){
   if(j.status==='completed'||!j.providerId)return view(j);
   try{
    if(j.resultURL){return await download(j);}
    const c=await connection(j),data=j.request.media==='video'?await post(c,'/v1/api/result?id='+encodeURIComponent(j.providerId)):await post(c,'/v1/draw/result',{id:j.providerId});
    if(data.id&&data.id!==j.providerId)throw Error('服务商回执编号不匹配');
    if(['failed','failure','violation'].includes(data.status)){j.status='failed';j.error='服务商任务失败或拒绝；请核对服务商记录';const diagnosis=j.request.media==='image'&&data.id===j.providerId?capability(data):null;j.failure=diagnosis?{...diagnosis,providerId:j.providerId,fingerprint:j.fingerprint,profile:j.profile,verifiedAt:stamp()}:null;if(j.attempts?.length)j.attempts.at(-1).status='failed';
     if(diagnosis&&j.recoveryPlanSHA&&requestCount(j)<j.recoveryLimit&&nextModel(j)){j.nextModel=nextModel(j);j.status='queued';j.sent=false;j.error='前一备用模型已确认能力失败，在已确认的剩余次数内等待下一模型';delete j.providerId;delete j.failure;await save(j);await io.wake();return view(j);}
     const message=typeof data.error==='string'?data.error:typeof data.error?.message==='string'?data.error.message:'';
     const contentRejected=/违规|違規|审核|審核|敏感|色情|policy|moderation|safety|prohibited|content.?filter/i.test(String(data.failure_reason||'')+' '+message);
     const unavailable=data.status==='violation'?['我是語言模型，這件事超出我的能力範圍了。','我是语言模型，这件事超出我的能力范围了。'].includes(message.trim()):/(?:模型.{0,18}(?:维护|修复|不可用|不支持|不存在|繁忙)|(?:model|channel).{0,45}(?:unavailable|maintenance|unsupported|not.?found|capacity|overload|busy)|(?:unavailable|unsupported).{0,20}(?:model|channel))/i.test(message);
     if(j.request.media==='video'&&data.id===j.providerId&&!data.results?.length&&!contentRejected&&unavailable&&requestCount(j)===1&&(j.currentModel||j.request.model)==='minimax-h3'&&j.request.videoFallback?.model==='agnes-video-2.5'&&j.request.videoFallback.resolution==='720p'){j.attempts||=[{model:'minimax-h3',providerId:j.providerId,status:'failed',at:j.createdAt}];j.nextModel='agnes-video-2.5';j.sent=false;j.status='queued';j.error='主视频通道已确认不可用，按本次已确认范围等待一次Agnes 720p备用请求';delete j.providerId;await io.wake();}
    }
    else if(['succeeded','completed','success'].includes(data.status)||data.progress===100){
     const url=data.results?.[0]?.url;if(typeof url!=='string')throw Error('已完成但没有可下载图片');
     publicURL(url);j.resultURL=url;j.status='download_pending';await save(j);return download(j);
    }else{j.status='pending';j.progress=typeof data.progress==='number'?Math.max(0,Math.min(99,data.progress)):0;j.error='';}
   }catch{j.error='原任务查询未完成，保留编号；不会再次生成';}
   await save(j);return view(j);
  }
  async function download(j){
   try{
    const saved=await io.get('assets',j.id);
    if(saved?.blob&&saved.sha256&&saved.mediaInfo){j.asset=true;j.sha256=saved.sha256;j.mediaInfo=saved.mediaInfo;j.status='completed';j.progress=100;j.error='';delete j.resultURL;delete j.downloadOrigin;await save(j);return view(j);}
    const u=publicURL(j.resultURL);
    if(!await io.allowed(u.origin+'/*')){j.downloadOrigin=u.origin;j.error='结果已生成，请在API设置授权此图片域名后按原任务查询';j.status='download_pending';await save(j);return view(j);}
    delete j.downloadOrigin;
    const asset=await io.download(j.resultURL,j.request);
    // Store artifact BEFORE marking completed. The provider URL alone is not success.
    await io.put('assets',j.id,asset);j.asset=true;j.sha256=asset.sha256;j.mediaInfo=asset.mediaInfo;j.status='completed';j.progress=100;j.error='';delete j.resultURL;delete j.downloadOrigin;
   }catch{j.status='download_pending';j.error='结果图片下载或解码未通过，保留原任务；不会再次生成';}
   await save(j);return view(j);
  }
  async function query(id,refresh=true){
   if(!UUID.test(id||''))fail('任务编号无效');
   return lock('job:'+id,async()=>{const j=await io.get('jobs',id);if(!j)fail('本插件未登记此任务',404);if(refresh&&j.sent&&!terminal(j.status))return poll(j);return view(j);});
  }
  async function batch(raw){return lock('batch:'+raw?.id,async()=>{
   if(!raw||!UUID.test(raw.id||'')||raw.consent!==true||!Array.isArray(raw.requests)||raw.requests.length<1||raw.requests.length>100||!Number.isInteger(raw.maxCalls)||raw.maxCalls<raw.requests.length)fail('批次编号、范围或次数上限不正确');
   if(new Set(raw.requests.map(r=>r.id)).size!==raw.requests.length)fail('批次中有重复任务编号');
   const prepared=[],existing=await io.get('batches',raw.id);const c=existing?null:await config();
   for(const r of raw.requests){const {referenceKeys=[],referenceTaskId,...rest}=r;
    if(referenceTaskId&&!prepared.some(x=>x.id===referenceTaskId))fail('基础图必须在本批之前的已登记项中');
    const references=referenceKeys.map(k=>raw.files?.[k]);validate({...rest,references});
    prepared.push({...rest,references,...(referenceTaskId?{referenceTaskId}:{})});
   }
   for(const r of prepared)if(r.media==='image'){const prev=existing?.requests.find(x=>x.id===r.id);if(prev){r.model=prev.model;if(prev.imageSettings)r.imageSettings={...prev.imageSettings};else delete r.imageSettings;}else{r.model=c.imageModel||r.model;try{r.imageSettings=Models.settings(r.model,c.imageSettings);}catch(e){fail(e.message);}}}
   const fingerprint=await io.hash(JSON.stringify(prepared)),old=existing;
   if(old){if(old.fingerprint!==fingerprint)fail('原批次内容已变，未重新提交',409);return batchView(old);}
   await config();if(await io.paused())fail('已暂停新增请求',409);
   const b={id:raw.id,fingerprint,requests:prepared,items:prepared.map(r=>({id:r.id,status:'draft'})),position:0,enabled:true,status:'running',createdAt:stamp()};
   await io.put('batches',b.id,b);await io.wake();return batchView(b);
  });}
  function batchView(b){return {id:b.id,enabled:b.enabled,status:b.status,items:b.items,error:b.error||''};}
  async function batchTick(id){return lock('batch:'+id,async()=>{
   const b=await io.get('batches',id);if(!b?.enabled||await io.paused())return b&&batchView(b);
   const r=b.requests[b.position];if(!r){b.enabled=false;b.status='completed';}
   else{
    try{
     const request={...r};delete request.referenceTaskId;
     if(r.referenceTaskId){const a=await io.get('assets',r.referenceTaskId);if(!a)fail('基础图尚未落盘，未生成后续变体',409);request.references=[await io.dataURL(a.blob)];}
     await submit(request,r.imageSettings);const result=await process(r.id);b.items[b.position]={id:r.id,status:result.status,error:result.error};
     if(result.status==='completed'){b.position++;if(b.position===b.requests.length){b.enabled=false;b.status='completed';}}
     else if(['failed','submission_unconfirmed'].includes(result.status)){b.enabled=false;b.status=result.status;b.error=result.error;}
    }catch{b.enabled=false;b.status='blocked';b.error='本批次已保留，请核对API配置、原任务与参考图，不重复建立批次';}
   }
   await io.put('batches',id,b);return batchView(b);
  });}
  async function batchControl(id,resume){return lock('batch:'+id,async()=>{
   const b=await io.get('batches',id);if(!b)fail('原批次不存在',404);
   if(b.status!=='completed'){b.enabled=resume;b.status=resume?'running':'stopped';b.error='';await io.put('batches',id,b);if(resume)await io.wake();}
   return batchView(b);
  });}
  function recoveryInput(raw){if(!raw||!UUID.test(raw.runId||'')||!Array.isArray(raw.assetIds)||!raw.assetIds.length||raw.assetIds.length>500||raw.assetIds.some(id=>!UUID.test(id))||new Set(raw.assetIds).size!==raw.assetIds.length||!Number.isInteger(raw.maxCalls)||raw.maxCalls<1||raw.maxCalls>100000)fail('原恢复范围或预算无效');return [...raw.assetIds].sort();}
  async function recoveryPlan(raw){const ids=recoveryInput(raw),jobs=await Promise.all(ids.map(id=>io.get('jobs',id)));if(jobs.some(j=>!j||j.request.media!=='image'||!['completed','failed'].includes(j.status)))fail('只允许恢复本插件已确认失败的图片，未知结果只查原编号',409);let known=0;const recoveries=[],unrecoverable=[];for(const j of jobs){known+=requestCount(j);if(j.status!=='failed')continue;const f=j.failure,next=nextModel(j);if(f?.code==='model_unavailable'&&f.reason==='text_instead_of_image'&&f.providerId===j.providerId&&f.fingerprint===j.fingerprint&&f.profile===j.profile&&next&&requestCount(j)<3){await connection(j);recoveries.push({id:j.id,maxAdditionalRequests:1,code:f.code,reason:f.reason,originalProviderRequestCount:requestCount(j),model:j.currentModel||j.request.model,nextModel:next});}else unrecoverable.push({id:j.id,code:'not_confirmed_capability_failure',reason:'无匹配的能力失败证据、触及内容规则或模型链已耗尽'});}if(known+recoveries.length>raw.maxCalls)fail('原预算不足，未补图',409);let spare=raw.maxCalls-known-recoveries.length;for(const r of recoveries){if(spare>0&&r.model==='nano-banana-pro'&&r.originalProviderRequestCount===1){r.maxAdditionalRequests=2;spare--;}}const additional=recoveries.reduce((n,r)=>n+r.maxAdditionalRequests,0);const state=jobs.map(j=>({id:j.id,fingerprint:j.fingerprint,profile:j.profile,status:j.status,providerId:j.providerId,count:requestCount(j),failure:j.failure||null}));return {ok:true,runId:raw.runId,assetIds:ids,maxCalls:raw.maxCalls,knownProviderRequests:known,maxAdditionalRequests:additional,maximumTotalRequests:known+additional,completedImages:jobs.filter(j=>j.status==='completed').length,recoveries,unrecoverable,planSHA256:await io.hash(JSON.stringify({runId:raw.runId,maxCalls:raw.maxCalls,state,recoveries})),started:false};}
  async function applyRecovery(receipt){for(const r of receipt.recoveries)await lock('job:'+r.id,async()=>{const j=await io.get('jobs',r.id);if(j?.recoveryPlanSHA===receipt.planSHA256)return;if(!j||j.status!=='failed'||requestCount(j)!==r.originalProviderRequestCount||nextModel(j)!==r.nextModel)fail('恢复前原任务已变化',409);await connection(j);j.attempts||=[{model:j.currentModel||j.request.model,providerId:j.providerId,status:'failed',at:j.createdAt}];j.recoveryPlanSHA=receipt.planSHA256;j.recoveryLimit=r.originalProviderRequestCount+r.maxAdditionalRequests;j.nextModel=r.nextModel;j.status='queued';j.sent=false;j.error='原失败素材已确认模型范围及最大追加次数，等待执行';delete j.providerId;delete j.resultURL;delete j.failure;await save(j);});receipt.applied=true;await io.put('recoveries',receipt.runId,receipt);await io.wake();}
  async function recover(raw){return lock('recovery-serial',async()=>{const ids=recoveryInput(raw);if(raw.consent!==true||!/^[a-f0-9]{64}$/.test(raw.planSHA256||''))fail('请确认原失败素材补图范围和费用');let receipt=await io.get('recoveries',raw.runId);if(receipt){if(receipt.planSHA256!==raw.planSHA256||receipt.maxCalls!==raw.maxCalls||JSON.stringify(receipt.assetIds)!==JSON.stringify(ids))fail('已有恢复登记，不重复或扩大补图',409);if(!receipt.applied)await applyRecovery(receipt);return {...receipt,idempotent:true};}if(await io.paused())fail('已暂停补图',409);const plan=await recoveryPlan(raw);if(plan.planSHA256!==raw.planSHA256||!plan.recoveries.length)fail('状态变化或没有可恢复项',409);receipt={...plan,started:true,acceptedAt:stamp(),applied:false};await io.put('recoveries',receipt.runId,receipt);await applyRecovery(receipt);return receipt;});}
  async function tick(){
   if(!await io.paused())for(const r of (await io.all('recoveries')).filter(r=>!r.applied))await lock('recovery-serial',()=>applyRecovery(r));
   // Bound each worker event. Next alarm continues saved positions, not a long-running daemon.
   const jobs=(await io.all('jobs')).filter(j=>!terminal(j.status)&&j.status!=='submission_unconfirmed').sort((a,b)=>String(a.updatedAt).localeCompare(String(b.updatedAt)));
   for(const j of jobs.slice(0,2))await process(j.id);
   if(!await io.paused()){const b=(await io.all('batches')).find(b=>b.enabled);if(b)await batchTick(b.id);}
  }
  return {submit,process,query,batch,batchTick,batchControl,batchView,tick,lock,view,recoveryPlan,recover};
 }
 const api={engine,validate,view,publicURL,terminal,UUID};root.MaterialIndependentCore=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
