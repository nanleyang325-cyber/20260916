'use strict';
async function studioRegister(message,parentId){
   const kind=message.type==='FULL_BUYER_SYNC'?'buyer':'fission';
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(message.requestId||'')||message.consent!==true||!/^\d{6,}$/.test(message.productId||'')||!Array.isArray(message.images)||!message.images.length||message.images.length>(kind==='buyer'?100:9)||JSON.stringify(message.images).length>48*1024*1024||new Set(message.images.map(image=>image.id)).size!==message.images.length||message.images.some(image=>!image.id||typeof image.data!=='string'||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(image.data)||image.data.length>8*1024*1024))throw Error('请核对本次商品、原图片与提交授权（最多48MB）。');
   if(kind==='fission'&&!['new','replace'].includes(message.mode))throw Error('新增或替换模式无效。');if(kind==='fission'&&message.mode==='replace'&&message.syncDetail)throw Error('替换原链接不修改详情。');
   if(kind==='buyer'&&message.generateCopy!==true&&(!message.title?.trim()||!message.body?.trim()))throw Error('请填写标题和正文，或确认额外一次AI文案。');
   if(message.title?.length>60||message.body?.length>4000||message.facts?.length>4000)throw Error('标题、正文或事实资料过长。');
   const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify({kind,productId:message.productId,mode:message.mode,images:message.images,optimizeTitle:!!message.optimizeTitle,changeStyle:!!message.changeStyle,autoSubmit:message.autoSubmit!==false,...(message.syncDetail?{syncDetail:true}:{}),generateCopy:!!message.generateCopy,title:message.title||'',body:message.body||'',facts:message.facts||''}))))].map(v=>v.toString(16).padStart(2,'0')).join('');
   const existing=((await chrome.storage.local.get(STUDIO_KEY))[STUDIO_KEY]||[]).find(t=>t.requestId===message.requestId);if(existing&&existing.fingerprint!==hash)throw Error('原请求编号的商品/图片或操作模式发生变化。');
   if(queueBusy||typeof executionPaused==='function'&&await executionPaused()||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||await studioBatchConflict(parentId)||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled)||(await autoRuns()).some(run=>run.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled)||typeof flowRuns==='function'&&(await flowRuns()).some(r=>r.enabled))throw Error('已有后台流程运行，请先等待或停止。');
   const task=existing||{requestId:message.requestId,kind,mode:message.mode,productId:message.productId,images:message.images.map((image,i)=>({id:image.id,name:`studio-${message.requestId}-${i}.png`})),fingerprint:hash,optimizeTitle:!!message.optimizeTitle,changeStyle:!!message.changeStyle,generateCopy:!!message.generateCopy,title:message.title||'',body:message.body||'',facts:message.facts||'',autoSubmit:message.autoSubmit!==false,syncDetail:kind==='fission'&&!!message.syncDetail,uploads:[],uploadIntents:{},status:'queued',createdAt:new Date().toISOString()};task.parentId=parentId||task.parentId;studioLive.set(task.requestId,message);await FullStateStore.update('material-studio-payloads-v1',previous=>({...previous,[task.requestId]:message}));await studioSave(task);return task;

}
'use strict';
const STUDIO_KEY='material-studio-requests-v1',studioLive=new Map(),studioBusy=new Set();
const STUDIO_BATCH_KEY='material-studio-publish-batches-v1',studioBatchBusy=new Set();
async function studioBatchRuns(){return (await chrome.storage.local.get(STUDIO_BATCH_KEY))[STUDIO_BATCH_KEY]||[];}
async function studioBatchConflict(exceptId){return (await studioBatchRuns()).some(batch=>batch.enabled&&batch.batchId!==exceptId);}
async function studioCheckLive(task){if(typeof executionPaused==='function'&&await executionPaused(false))throw Error('已全局暂停，未继续平台动作。');const global=(await chrome.storage.local.get('material-global-control-v1'))['material-global-control-v1'];if(global?.draining&&!task.copyId&&!task.textId&&!task.publication&&!Object.keys(task.uploadIntents||{}).length)throw Error('已进入全局收尾，未开始新的工作台动作。');if(task.parentId&&!(await studioBatchRuns()).find(batch=>batch.batchId===task.parentId)?.enabled)throw Error('已停止后续发布，保留原记录。');}
async function studioBatchSave(batch){await FullStateStore.update(STUDIO_BATCH_KEY,previous=>{const batches=previous||[],i=batches.findIndex(value=>value.batchId===batch.batchId);if(i<0)batches.push(batch);else{if(batches[i].draining)batch.draining=true;if(batches[i].enabled===false){batch.enabled=false;batch.status=batches[i].status;}globalThis.FullTaskFailures?.save(batch,'studioBatch',batches[i]);batches[i]=batch;}return batches;});}
function studioBatchPublic(batch){return {ok:true,batchId:batch.batchId,status:batch.status,enabled:batch.enabled,position:batch.position,items:batch.items,error:batch.error||'',completionReport:batch.completionReport||null};}
const SEED_URL='https://qn.taobao.com/home.htm/content-center/unifiedPublishContent?pub_url='+encodeURIComponent('https://huodong.taobao.com/wow/z/guang/gg_publish/qianniu-article-m?ugc_scene=qn_pc_detail_content&pageType=picture&site=guangguang')+'&pub_scene=gg';
async function studioSave(task){await FullStateStore.update(STUDIO_KEY,previous=>{const tasks=previous||[],i=tasks.findIndex(t=>t.requestId===task.requestId);if(globalThis.FullTaskFailures&&['verified','prepared','blocked','submitted_unconfirmed','failed'].includes(task.status)){task.completionReport=FullTaskFailures.report(task,'studio');if(!task.parentId){task.completionReport.ended=true;task.completionReport.endedAt=new Date().toISOString();task.completionReport.outcome=['verified','prepared'].includes(task.status)?'completed':'completed_with_failures';}}if(i<0)tasks.push(task);else tasks[i]=task;return tasks;});}
async function studioWait(tabId){for(let n=0;n<40;n++){const tab=await chrome.tabs.get(tabId);if(tab.status==='complete')return tab;await queueDelay(300);}throw Error('平台页面加载超时。');}
async function studioImage(url){const u=new URL(url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('图片地址无效。');const response=await fetch(u.href,{credentials:'omit',redirect:'error',signal:AbortSignal.timeout(15000)});if(!response.ok)throw Error('原图片下载未成功。');const type=(response.headers.get('content-type')||'').split(';')[0].trim();if(!['image/png','image/jpeg','image/webp'].includes(type))throw Error('图片来源未返回PNG、JPEG或WebP。');const reader=response.body.getReader(),chunks=[];let size=0;try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>6*1024*1024)throw Error('来源图片超过6MB。');chunks.push(value);}}finally{await reader.cancel().catch(()=>{});}if(!size)throw Error('来源图片为空。');let binary='';for(const chunk of chunks)for(let n=0;n<chunk.length;n+=8192)binary+=String.fromCharCode(...chunk.subarray(n,n+8192));return 'data:'+type+';base64,'+btoa(binary);}
async function studioPage(tabId,action,task,arg,frameId=0){await chrome.scripting.executeScript({target:{tabId,frameIds:[frameId]},files:['studio-page.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId,frameIds:[frameId]},func:async(action,task,arg)=>{try{return {ok:true,...await FullStudioPage.execute(action,task,arg)};}catch(error){return {ok:false,error:error.message};}},args:[action,task,arg||null]});if(!result?.ok)throw Error(result?.error||'平台工作台操作未确认。');return result;}
async function studioFrame(tabId,kind){for(let n=0;n<40;n++){await chrome.scripting.executeScript({target:{tabId,allFrames:true},files:['studio-page.js']});const frames=await chrome.scripting.executeScript({target:{tabId,allFrames:true},func:()=>FullStudioPage.execute('ready',{})});const found=frames.filter(frame=>frame.result?.[kind]);if(found.length===1)return found[0].frameId;if(found.length>1)throw Error('平台目标表单不唯一。');await queueDelay(400);}throw Error('平台表单/图片选择器未就绪。');}
async function studioFissionSnapshot(tabId,task,pid=task.productId){await chrome.scripting.executeScript({target:{tabId},files:['fission.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId},func:async(job)=>{try{return {ok:true,snapshot:await FullFission.snapshot(job)};}catch(error){return {ok:false,error:error.message};}},args:[{productIds:[pid],expectedSkuCount:task.sourceSnapshot?.expected}]});if(!result?.ok||!result.snapshot.complete)throw Error(result?.error||'完整SKU快照未取得，未提交。');return result.snapshot;}
async function studioDetail(task,action,tabId=task.tabId,pid=task.productId){
 await chrome.scripting.executeScript({target:{tabId},world:'MAIN',files:['studio-detail.js']});
 const check={...task,productId:pid,...(pid!==task.productId?{mode:'replace'}:{})};
 const [{result}]=await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:async(action,task)=>{try{return await FullStudioDetail.execute(action,task);}catch(error){return {ok:false,status:'blocked',error:error.message};}},args:[action,check]});
 if(!result?.ok)throw Error(result?.error||'详情同步或保存后回查未确认。');return result;
}
async function studioSyncDetail(task){
 if(!task.syncDetail)return;
 if(task.detailResult){await studioDetail(task,'verify');return;}
 if(task.detailIntent){const recovered=await studioDetail(task,'recover');task.detailResult=recovered;await studioSave(task);return;}
 await studioCheckLive(task);task.detailIntent={at:new Date().toISOString(),requestId:task.requestId};await studioSave(task);
 task.detailResult=await studioDetail(task,'apply');if(!['applied','skipped'].includes(task.detailResult.status))throw Error('详情动作没有明确结果，未提交商品。');await studioSave(task);
}
async function studioFields(task){
 if(task.optimizeTitle&&!task.optimizedTitle){
  if(!task.textId||task.textIntent?.notSubmitted){if(typeof executionPaused==='function'&&await executionPaused())throw Error('已暂停或收尾，未发起新的标题优化。');task.textId||=crypto.randomUUID();task.textIntent={at:new Date().toISOString()};await studioSave(task);try{await studioCheckLive(task);}catch(error){task.textIntent.notSubmitted=true;await studioSave(task);throw error;}await flowMedia('',{id:task.textId,module:'fission',media:'text',model:'gemini-3.1-pro',productIds:[task.productId],consent:true,prompt:'仅整理下列原商品标题的词序与重复词，不增加材质、尺寸、功能、销量、认证、价格或优惠。只返回JSON，title为新标题，body为同一标题。标题不超过原长度及60字符。原商品标题：'+task.sourceSnapshot.title});}
  const result=await flowMedia('/'+task.textId);if(result.status!=='completed'){if(['queued','pending','running','processing'].includes(result.status))return {pending:true};throw Error('原标题优化任务未完成，保留编号只查询；未修改商品。');}if(!result.text?.title)throw Error('优化结果没有有效标题，未修改商品。');task.optimizedTitle=result.text.title;if(task.optimizedTitle.length>Math.min(60,task.sourceSnapshot.title.length))throw Error('优化标题超出原长度，未写入。');await studioSave(task);
 }
 task.fieldIntent||={at:new Date().toISOString()};await studioSave(task);const result=await studioPage(task.tabId,'fission-fields',task);task.fieldResult=result;await studioSave(task);
 if(result.requiresReload){await queueDelay(800);await studioWait(task.tabId);task.fieldResult=await studioPage(task.tabId,'fission-fields',task);if(task.fieldResult.requiresReload)throw Error('款号修改尚未完成整页读回，未提交商品。');await studioSave(task);}
}
async function studioSeedContent(task,action){await chrome.scripting.executeScript({target:{tabId:task.spaceTab},world:'MAIN',files:['content-readback.js']});const job={module:'search',productIds:[task.productId],title:task.title||'商品生活场景',uploadedAssets:task.uploads,contentBaseline:task.contentBaseline,publication:task.publication?{submittedAt:task.publication.at}:null};const [{result}]=await chrome.scripting.executeScript({target:{tabId:task.spaceTab},world:'MAIN',func:async(job,action)=>{try{return await FullContent.request(job,action);}catch(error){return {ok:false,error:error.message};}},args:[job,action]});if(!result?.ok)throw Error(result?.error||'商详内容发布前/后查询未确认。');return result;}
async function studioCopy(task){
 if(!task.generateCopy||task.copyComplete)return;
 if(!task.copySourceTitle){const cached=(await queueState())?.products?.find(product=>product.id===task.productId);if(cached?.title)task.copySourceTitle=cached.title;else{const tab=await chrome.tabs.create({url:'https://detail.tmall.com/item.htm?id='+task.productId,active:false});await studioWait(tab.id);const product=await studioPage(tab.id,'source-title',{productId:task.productId});task.copySourceTitle=product.title;}await studioSave(task);}
 if(!task.copyId||task.copyIntent?.notSubmitted){if(typeof executionPaused==='function'&&await executionPaused())throw Error('已暂停或收尾，未发起新的文案生成。');task.copyId||=crypto.randomUUID();task.copyIntent={at:new Date().toISOString()};await studioSave(task);try{await studioCheckLive(task);}catch(error){task.copyIntent.notSubmitted=true;await studioSave(task);throw error;}await flowMedia('',{id:task.copyId,module:'buyer',media:'text',model:'gemini-3.1-pro',productIds:[task.productId],consent:true,prompt:'为AI辅助创作的商品生活场景图片撰写中文标题和正文。仅依据已核对商品标题与用户事实，不冒充买家、不编造体验、认证、尺寸、功能或效果，不声称你看过图片。资料少则写客观的商品展示说明。输出JSON：title最多20字，body最多144字。商品标题：'+task.copySourceTitle+'。用户确认事实：'+(task.facts||'未提供更多事实')+'。用户文案偏好：'+(task.title||'')+' '+(task.body||'')});}
 const result=await flowMedia('/'+task.copyId);if(result.status!=='completed'){if(['queued','pending','running','processing'].includes(result.status))return {pending:true};throw Error('原AI文案尚未完成，保留编号只查询，未再次生成。');}if(!result.text?.title||!result.text?.body)throw Error('原AI文案格式无效，未发布。');if(result.text.title.length>20||result.text.body.length>144)throw Error('原AI文案超过平台长度，未截断冒用，未发布。');task.title=result.text.title;task.body=result.text.body;task.copyComplete=true;await studioSave(task);
}
async function studioReadback(task){
 if(task.kind!=='fission')return studioSeedContent(task,'verify');
 const tab=await chrome.tabs.get(task.tabId),url=new URL(tab.url),pid=url.searchParams.get('itemId');if(!/^\d{6,}$/.test(pid||'')||task.mode==='new'&&pid===task.productId||task.mode==='replace'&&pid!==task.productId)return {status:'submitted_unconfirmed'};
 if(!task.editorUrl)throw Error('原官方编辑地址未保存，不能猜测新商品回查页。');
 const canonical=new URL(task.editorUrl);canonical.searchParams.delete('st_dist_src_id');canonical.searchParams.delete('copyItem');canonical.searchParams.set('itemId',pid);
 if(!task.receiptTabId||task.receiptProductId!==pid){task.receiptTabId=(await chrome.tabs.create({url:canonical.href,active:false})).id;task.receiptProductId=pid;await studioSave(task);}else await chrome.tabs.reload(task.receiptTabId);await studioWait(task.receiptTabId);
 const snapshot=await studioFissionSnapshot(task.receiptTabId,task,pid);const source=task.sourceSnapshot;const sort=value=>JSON.stringify([...value.skus].sort((a,b)=>a.key.localeCompare(b.key)));if(sort(source)!==sort(snapshot)||!task.uploads.every(record=>snapshot.mainImages.some(url=>url===record.url||url.startsWith(record.url+'_'))))return {status:'submitted_unconfirmed'};
 const fields=await studioPage(task.receiptTabId,'fission-read-fields',{...task,productId:pid,mode:'replace'});if(fields.title!==(task.fieldResult?.newTitle||source.title)||task.changeStyle&&fields.style!==task.fieldResult?.styleAfter)return {status:'submitted_unconfirmed'};
 if(task.syncDetail)await studioDetail(task,'verify',task.receiptTabId,pid);
 return {status:'verified',receipt:{source:'platform-readback',contentId:pid,productIds:[task.productId],newProductId:task.mode==='new'?pid:undefined,imageUrls:task.uploads.map(r=>r.url),status:'SKU与主图已回查'}};
}
async function studioUpload(task){
 if(!task.spaceTab){task.spaceTab=(await chrome.tabs.create({url:FullCore.URLS.space,active:false})).id;await studioSave(task);}await studioWait(task.spaceTab);
 const job={module:'white',productIds:[task.productId]};
 for(const image of task.images){if(task.uploads.some(u=>u.id===image.id))continue;
  await studioCheckLive(task);
  let found=await queueScene(task.spaceTab,job,'lookup',image.name);if(!found.ok){if(found.code!=='PICTURE_NOT_FOUND')throw Error(found.error||'图片空间查询未确认。');
   if(task.uploadIntents[image.id])throw Error('原上传尚未查到，只能继续查询，未重复上传。');
   const payload=studioLive.get(task.requestId)?.images.find(i=>i.id===image.id);if(!payload?.data)throw Error('原图片未在内存中，请从结果页按原请求重新查询并附带原图。');
   const opened=await queuePlatform(task.spaceTab,job,'open-upload');if(opened.ok===false)throw Error(opened.error);task.uploadIntents[image.id]={name:image.name,at:new Date().toISOString()};await studioSave(task);
   const uploaded=await queuePlatform(task.spaceTab,job,'upload',[{name:image.name,data:payload.data}]);if(uploaded.ok===false)throw Error(uploaded.error||'上传结果未确认。');
   for(let n=0;n<30;n++){await queueDelay(500);found=await queueScene(task.spaceTab,job,'lookup',image.name);if(found.ok)break;if(found.code!=='PICTURE_NOT_FOUND')throw Error(found.error||'上传回查受阻。');}
   if(!found.ok)throw Error('图片原上传记录未确认，未再次上传。');
  }task.uploads.push({id:image.id,name:image.name,...found.sceneUpload});await studioSave(task);
 }
}
async function studioTick(requestId){
 if(queueBusy||studioBusy.size)return;queueBusy=true;studioBusy.add(requestId);let task;
 try{
  task=((await chrome.storage.local.get(STUDIO_KEY))[STUDIO_KEY]||[]).find(t=>t.requestId===requestId);if(!task||task.status==='verified')return;
  if(task.publication){const result=await studioReadback(task);task.status=result.status;if(result.receipt)task.receipt=result.receipt;await studioSave(task);return;}
  task.status='running';task.error='';await studioSave(task);if(!studioLive.has(task.requestId)){const payload=(await chrome.storage.local.get('material-studio-payloads-v1'))['material-studio-payloads-v1']?.[task.requestId];if(payload)studioLive.set(task.requestId,payload);}await studioCheckLive(task);if(task.kind==='buyer'){const copy=await studioCopy(task);if(copy?.pending){task.status='waiting_text';await studioSave(task);return;}}await studioUpload(task);
  if(!task.tabId){
   if(task.kind==='fission'){
    const list=await chrome.tabs.create({url:FullCore.URLS.products,active:false});await studioWait(list.id);await studioPage(list.id,'product-search',task);await queueDelay(1000);const route=await studioPage(list.id,'fission-route',task);task.editorUrl=route.url;task.tabId=(await chrome.tabs.create({url:route.url,active:false})).id;
   }else task.tabId=(await chrome.tabs.create({url:SEED_URL,active:false})).id;
   await studioSave(task);
  }await studioWait(task.tabId);
  const frame=await studioFrame(task.tabId,task.kind==='fission'?'editor':'seed');
  if(task.kind==='fission'&&!task.sourceSnapshot){task.sourceSnapshot=await studioFissionSnapshot(task.tabId,task);await studioSave(task);}
  if(task.kind==='fission'&&(task.optimizeTitle||task.changeStyle)){const fields=await studioFields(task);if(fields?.pending){task.status='waiting_text';await studioSave(task);return;}}
  await studioCheckLive(task);await studioPage(task.tabId,'open-images',task,null,frame);const picker=await studioFrame(task.tabId,'picker');await studioPage(task.tabId,'picker-empty',task,null,picker);
  for(const image of task.uploads){await studioPage(task.tabId,'picker-search',task,image,picker);await queueDelay(500);await studioPage(task.tabId,'picker-select',task,image,picker);}await studioPage(task.tabId,'picker-confirm',task,null,picker);await queueDelay(500);await studioPage(task.tabId,'verify-images',task,null,frame);
  if(task.kind==='fission'){const current=await studioFissionSnapshot(task.tabId,task);if(JSON.stringify(current.skus)!==JSON.stringify(task.sourceSnapshot.skus))throw Error('回填前后SKU发生变化，未提交。');await studioSyncDetail(task);}
  else{await studioPage(task.tabId,'seed-associate',task,null,frame);try{await studioPage(task.tabId,'seed-fill',task,null,frame);}catch{await studioPage(task.tabId,'seed-search',task,null,frame);await queueDelay(500);await studioPage(task.tabId,'seed-select',task,null,frame);await studioPage(task.tabId,'seed-fill',task,null,frame);}}
  if(task.autoSubmit===false){task.status='prepared';await studioSave(task);return;}
  if(task.kind!=='fission'&&!task.contentBaseline){const result=await studioSeedContent(task,'baseline');task.contentBaseline=result.contentBaseline;await studioSave(task);}
  await studioCheckLive(task);task.publication={at:new Date().toISOString(),requestId:task.requestId};task.status='submitting';await studioSave(task);await studioCheckLive(task);const submitted=await studioPage(task.tabId,'submit',task,null,frame);Object.assign(task.publication,{documentTimeOrigin:submitted.documentTimeOrigin});task.status='submitted_unconfirmed';await studioSave(task);
  if(task.kind!=='fission')await studioPage(task.tabId,'confirm-seed',task,null,frame);await studioSave(task);
 }catch(error){if(task){task.status=task.publication?'submitted_unconfirmed':'blocked';task.error=error.message;await studioSave(task);}}finally{queueBusy=false;studioBusy.delete(requestId);if(task&&['verified','blocked','prepared'].includes(task.status)&&!task.parentId)await chrome.alarms?.clear('studio-request:'+requestId);}
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id)return false;
 if(message.type==='FULL_STUDIO_READ'){
  (async()=>{const collection=await FullCollectionReturn.begin();try{const items=[];if(!Array.isArray(message.inputs)||!message.inputs.length||message.inputs.length>20)throw Error('请输入1至20个商品。');for(const input of message.inputs){let pid=input.productId,url;if(input.url){const u=new URL(input.url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)throw Error('来源链接无效。');if(/\.(?:png|jpe?g|webp)$/i.test(u.pathname)){items.push({productId:'',title:'导入图片',images:[{id:crypto.randomUUID(),url:u.href,data:await studioImage(u.href)}]});continue;}if(u.protocol!=='https:'||!/(^|\.)(taobao|tmall|1688)\.com$/.test(u.hostname))throw Error('商品来源仅支持HTTPS平台商品链接。');pid=u.searchParams.get('id')||u.pathname.match(/\/offer\/(\d+)\.html/)?.[1];url=u.href;}if(!/^\d{6,}$/.test(pid||''))throw Error('来源商品ID无效。');url||='https://detail.tmall.com/item.htm?id='+pid;const tab=await collection.open(url);await studioWait(tab.id);const item=await studioPage(tab.id,'source',{productId:pid});for(const image of item.images)image.data=(await fetchReference({url:image.url})).reference;items.push(item);}reply({ok:true,items});}finally{await collection.finish();}})().catch(error=>reply({ok:false,error:error.message}));return true;
 }
 if(['FULL_STUDIO_PUBLISH','FULL_BUYER_SYNC'].includes(message.type)){
  executionGate(()=>studioRegister(message)).then(task=>{reply({ok:true,requestId:task.requestId,status:task.status});chrome.alarms?.create('studio-request:'+task.requestId,{when:Date.now()+100,periodInMinutes:.5});studioTick(task.requestId).catch(()=>{});}).catch(error=>reply({ok:false,executed:false,error:error.message}));return true;
 }
 if(message.type==='FULL_STUDIO_STATUS'){
  (async()=>{let task=((await chrome.storage.local.get(STUDIO_KEY))[STUDIO_KEY]||[]).find(t=>t.requestId===message.requestId);if(!task)throw Error('未找到原工作台提交。');if(!studioBusy.size&&(task.publication||task.status==='waiting_text'))await studioTick(task.requestId);if(!studioBusy.size&&task.status==='prepared'){const result=await studioReadback(task);if(result.status==='verified'){task.status='verified';task.receipt=result.receipt;await studioSave(task);}}task=((await chrome.storage.local.get(STUDIO_KEY))[STUDIO_KEY]).find(t=>t.requestId===message.requestId);reply({ok:true,requestId:task.requestId,status:task.status,receipt:task.receipt,error:task.error});})().catch(error=>reply({ok:false,error:error.message}));return true;
 }
});

chrome.alarms?.onAlarm.addListener(alarm=>{if(alarm.name.startsWith('studio-request:'))studioTick(alarm.name.slice(15)).catch(()=>{});});
