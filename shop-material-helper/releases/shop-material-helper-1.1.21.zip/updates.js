'use strict';
const el=id=>document.getElementById(id),Config=MaterialUpdateConfig;
const messages={PERMISSION_REQUIRED:'请允许读取公开更新源，之后打开插件时每天最多自动检查一次。',CHECK_IN_PROGRESS:'正在检查更新，请稍候。',NETWORK_FAILED:'更新源暂时连不上；当前版本、配置、任务与素材保持不变。',FEED_INVALID:'版本清单格式或来源核验未通过，未更新下载地址。',RESPONSE_TOO_LARGE:'更新响应超过允许大小，已停止读取。',FEED_ROLLBACK:'版本源返回了较旧版本，已保留之前核验的版本信息。',RELEASE_CHANGED:'版本信息已变化，请刷新状态后再下载。',OLDER_RELEASE:'线上版本比当前版本旧，已阻止下载降级。',PACKAGE_INTEGRITY_FAILED:'安装包大小或SHA256不符，未保存文件；请稍后重新检查。',DOWNLOAD_FAILED:'安装包读取未完成，未交付文件；可以稍后再试。',DOWNLOAD_IN_PROGRESS:'正在读取安装包，请稍候。',UPDATE_STATUS_UNAVAILABLE:'暂时读不到更新状态，请稍后刷新。',no_update:'本次核对未发现更高版本。',update_available:'发现新版本，可以下载升级包。',cached:'刚刚检查过，显示已核验的版本信息。'};
let busy=false,state=null,activeDownload=null;
function setMessage(text){el('message').textContent=text;}
function render(s){
 state=s;el('version').textContent=s.version;el('extension-id').textContent=s.extensionId;
 el('latest').textContent=s.release?.version||'尚未检查';el('source').href=Config.releasesURL;
 el('channel').textContent=s.permission?'更新提醒已开启 · 打开插件时每天最多自动检查一次':'更新提醒未开启 · 点“开启提醒并检查”授权公开更新源';
 el('check').textContent=s.permission?'检查更新':'开启提醒并检查';el('check').disabled=busy||s.checking;
 el('download').disabled=busy||!!activeDownload||!s.canDownload;el('download').textContent=s.newer?'下载新版 '+s.release.version:'下载当前最新版';
 el('pending').hidden=!s.newer;el('pending').textContent=s.newer?'有新版本 '+s.release.version+'。下载后覆盖原目录并重新加载，才会完成升级。':'';
 el('notes').replaceChildren();for(const note of s.release?.notes||[]){const li=document.createElement('li');li.textContent=note;el('notes').append(li);}el('notes').hidden=!s.release?.notes?.length;
 el('checked').textContent=(s.checkedAt?'上次成功检查：'+new Date(s.checkedAt).toLocaleString():'尚无成功检查记录')+(s.lastError?'；最近检查未成功，旧版本信息仅供参考。':'');
 el('integrity').textContent=s.release?'安装包 '+s.release.bytes.toLocaleString()+' 字节；SHA256：'+s.release.sha256:'下载前会核对包大小与 SHA256。校验失败不交付安装包。';
}
async function refresh(){try{const s=await chrome.runtime.sendMessage({type:'MATERIAL_UPDATE_STATUS'});if(!s?.ok)throw Error('status');render(s);return s;}catch{el('download').disabled=true;setMessage(messages.UPDATE_STATUS_UNAVAILABLE);return null;}}
el('refresh').addEventListener('click',()=>refresh());
el('check').addEventListener('click',async()=>{
 if(busy)return;busy=true;el('check').disabled=true;setMessage('正在检查公开版本清单…');
 try{
  // Keep permission request directly inside this user click; never request on a timer.
  const permission=await chrome.permissions.request({origins:[Config.origin+'/*']});
  if(!permission){setMessage('未开启更新源访问；原插件功能不受影响。');return;}
  const r=await chrome.runtime.sendMessage({type:'MATERIAL_UPDATE_CHECK'});setMessage(messages[r?.result||r?.code]||messages.NETWORK_FAILED);
 }catch{setMessage(messages.NETWORK_FAILED);}finally{busy=false;await refresh();}
});
function finishDownload(download){
 if(!activeDownload||download.id!==activeDownload.id)return;
 if(download.state==='complete'||download.state?.current==='complete'){
  URL.revokeObjectURL(activeDownload.url);activeDownload=null;setMessage('安装包下载完成。请按下方三步覆盖原目录并重新加载；当前运行版本尚未改变。');refresh();
 }else if(download.state==='interrupted'||download.state?.current==='interrupted'){
  URL.revokeObjectURL(activeDownload.url);activeDownload=null;setMessage('下载被取消或中断；原配置、任务和素材没有改动。可重新点击下载。');refresh();
 }
}
chrome.downloads.onChanged.addListener(finishDownload);
el('download').addEventListener('click',async()=>{
 if(busy||activeDownload||!state?.canDownload)return;busy=true;el('download').disabled=true;let objectURL=null;
 setMessage('正在下载并核验安装包；连接中断会自动重试一次，请保持此页打开…');
 try{
  const chosen=state.release,r=await chrome.runtime.sendMessage({type:'MATERIAL_UPDATE_PREPARE_DOWNLOAD',version:chosen.version,sha256:chosen.sha256});
  if(!r?.ok){setMessage(messages[r?.code]||messages.DOWNLOAD_FAILED);return;}
  const raw=atob(r.base64),bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
  const hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
  if(bytes.length!==chosen.bytes||hash!==chosen.sha256)throw Error('integrity');
  objectURL=URL.createObjectURL(new Blob([bytes],{type:'application/zip'}));
  const id=await chrome.downloads.download({url:objectURL,filename:'店铺素材助手-'+chosen.version+'-保留数据升级.zip',conflictAction:'uniquify',saveAs:true});
  if(!Number.isInteger(id))throw Error('download');
  activeDownload={id,url:objectURL};objectURL=null;setMessage('校验通过，浏览器正在保存ZIP；请保持此页打开直到下载完成。');
  const records=await chrome.downloads.search({id});if(records[0])finishDownload(records[0]);
 }catch{setMessage('安装包没有完成保存；不会覆盖原程序或改动数据，请稍后重试。');}
 finally{if(objectURL)URL.revokeObjectURL(objectURL);busy=false;await refresh();}
});
window.addEventListener('beforeunload',event=>{if(busy||activeDownload){event.preventDefault();event.returnValue='';}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes['material-extension-download-update-v1'])refresh();});
(async()=>{const s=await refresh();if(s?.permission){const r=await chrome.runtime.sendMessage({type:'MATERIAL_UPDATE_CHECK',automatic:true}).catch(()=>null);if(r&&!r.ok)setMessage(messages[r.code]||messages.NETWORK_FAILED);await refresh();}})();
