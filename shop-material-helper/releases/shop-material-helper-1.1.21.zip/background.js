importScripts('cleanup-direct.js','cleanup-worker.js');
importScripts('update-config.js','update-service.js','standalone-service.js');
importScripts('state-store.js','task-failures.js');

importScripts('background-queue.js');
importScripts('background-auto.js');
importScripts('collection-return.js');
importScripts('material-entry.js');
importScripts('white-review-retry.js');
importScripts('background-flows.js');
importScripts('task-cancel.js','background-capability-recovery.js');
importScripts('trend-run.js','background-trend.js');
importScripts('background-white-retry.js');
importScripts('background-transparent.js');
importScripts('background-studio.js');
importScripts('background-studio-batches.js');
importScripts('multi-run.js','background-multi.js');
importScripts('f88-core.js','f88-run.js','background-f88.js');
importScripts('kmt-core.js','background-kmt.js');
importScripts('background-controls.js');
importScripts('white-journal.js');
importScripts('background-review-rework.js');
importScripts('material-diagnostics.js','background-diagnostics.js');
importScripts('background-log-details.js');
// Persist the committed white state, including a pause/stop merged by flowSave.
// Other modules keep their existing save and processing-record behavior.
const whiteJournalFlowSave=flowSave;
flowSave=async run=>{
 await whiteJournalFlowSave(run);
 if(run.module==='white'){
  const saved=(await flowRuns()).find(value=>value.id===run.id);
  await FullWhiteJournal.record(saved||run);
 }
};
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(message.type!=='FULL_RUNTIME_PROBE'||sender.id!==chrome.runtime.id)return false;
 reply({version:chrome.runtime.getManifest().version,build:'material-return-20261017-v2',returnReady:typeof globalThis.FullCollectionReturn?.backfill==='function',videoDirectProtocol:2});return false;
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(message.type!=='FULL_CREDITS_QUERY')return;
 (async()=>{try{const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/grsai/credits"),{cache:'no-store',signal:AbortSignal.timeout(25000)});if(!response.ok)throw Error();const data=await response.json();reply({ok:true,balance:data?.available===true&&typeof data.credits==='number'&&Number.isFinite(data.credits)&&data.scope==='provider'?{available:true,credits:data.credits,scope:'provider',checkedAt:data.checkedAt}:{available:false}});}catch{reply({ok:true,balance:{available:false}});}})();return true;
});
const collectionRuns = new Map();
async function fetchReference(message) {
  const url = new URL(message.url);
  if (url.protocol !== 'https:' || !/(^|\.)alicdn\.com$/.test(url.hostname) || url.username || url.password) throw new Error('只允许读取HTTPS阿里商品图片，请下载其他来源的图片后手动选择。');
  const response = await fetch(url.href, { credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error('商品图片读取失败，请下载原图后手动选择。');
  const type = (response.headers.get('content-type') || '').split(';')[0].trim();
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(type)) throw new Error('候选图格式不支持，请手动选择PNG、JPG或WebP。');
  const reader = response.body.getReader(); const chunks = []; let size = 0;
  try {
    while (true) { const { done, value } = await reader.read(); if (done) break; size += value.length; if (size > 6 * 1024 * 1024) throw new Error('候选图超过6MB，请手动选择较小的商品原图。'); chunks.push(value); }
  } finally { await reader.cancel().catch(() => {}); }
  if (!size) throw new Error('候选图为空。');
  let binary = ''; for (const chunk of chunks) for (let start = 0; start < chunk.length; start += 8192) binary += String.fromCharCode(...chunk.subarray(start, start + 8192));
  return { ok: true, reference: `data:${type};base64,${btoa(binary)}`, type };
}
async function currentStoreTab(tabId) {
  const tab = Number.isInteger(tabId)?await chrome.tabs.get(tabId):(await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  if (!tab?.id) throw new Error('未找到当前标签页，请在商品页点击插件图标再试。');
  if (!tab.url) throw new Error('浏览器未授予读取商品页的权限，请更新插件并允许访问商品网站。');
  if (!/^https?:/.test(tab.url)) throw new Error('当前标签页不是网站页面，请切回商品列表后读取。');
  if (!/(^|\.)(taobao\.com|tmall\.com|1688\.com|qianniu\.com)$/.test(new URL(tab.url).hostname)) throw new Error('当前仅读取淘宝、天猫、千牛及1688商品页面。');
  return tab;
}
async function snapshot(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['collector.js', 'pager.js'] });
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId }, func: () => ({ ...MaterialCollector.collect(document, location.href), pagination: MaterialPager.info(document) }) });
  return result;
}
async function readAll(tab, id) {
  const route=new URL(tab.url);
  if (route.protocol!=='https:'||!['myseller.taobao.com','qn.taobao.com'].includes(route.hostname)||!/^\/home\.htm\/sellmanage\/(?:on_sale|on_sale_skucenter)\/?$/i.test(route.pathname)) throw new Error('请先打开千牛“出售中”列表，并清空商品搜索与筛选条件，再读取全部在售商品。');
  if (collectionRuns.size) throw new Error('已有全部商品采集正在进行，请等待或停止后再试。');
  const run = { cancelled: false }; collectionRuns.set(id, run);
  const products = new Map(); let pagesRead = 0, expected = null, total = 0;
  const progress = text => chrome.runtime.sendMessage({ type: 'COLLECTION_PROGRESS', id, text }).catch(() => {});
  const delay = () => new Promise(resolve => setTimeout(resolve, 300));
  function check() { if (run.cancelled) throw new Error('已停止采集'); }
  async function stablePage(target, oldSignature) {
    let previous = '', stable = 0;
    for (let count = 0; count < 60; count++) {
      check(); let result;
      try { result = await snapshot(tab.id); } catch { await delay(); continue; }
      const signature = result.products.map(p => p.id).sort().join(',');
      if (result.pagination.current === target && signature && signature !== oldSignature) {
        stable = signature === previous ? stable + 1 : 0; previous = signature;
        if (stable >= 2) return result;
      } else { stable = 0; previous = ''; }
      await delay();
    }
    throw new Error(`第${target}页加载超时或没有识别到商品，采集未完成`);
  }
  async function moveTo(result, direction) {
    const target = result.pagination.current + (direction === 'next' ? 1 : -1);
    const before = result.products.map(p => p.id).sort().join(',');
    try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: direction => MaterialPager.move(document, direction), args: [direction] }); }
    catch (error) { if (!/context|frame|document/i.test(error.message || '')) throw error; }
    return stablePage(target, before);
  }
  try {
    const [{ result: filtered }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => [...document.querySelectorAll('input[placeholder]')].some(input => /商品标题|商品ID|商家编码/.test(input.placeholder) && input.value.trim()) });
    if (filtered) throw new Error('请先清空商品标题、商品ID及商家编码搜索，并取消其他筛选条件。');
    let result = await snapshot(tab.id);
    total = result.pagination.total; expected = result.pagination.expected;
    while (result.pagination.current > 1) { check(); progress(`正在回到第一页：当前第${result.pagination.current}/${total}页`); result = await moveTo(result, 'previous'); }
    result = await stablePage(1, null);
    for (let page = 1; page <= total; page++) {
      check();
      if (result.pagination.total !== total || result.pagination.expected !== expected) throw new Error('商品总数或页数在采集中发生变化，请重新采集。');
      for (const product of result.products) { const old = products.get(product.id); products.set(product.id, { ...product, images: [...new Set([...(old?.images || []), ...product.images])] }); }
      pagesRead = page; progress(`已读取第${page}/${total}页，累计${products.size}${expected != null ? '/' + expected : ''}件商品`);
      if (page < total) result = await moveTo(result, 'next');
    }
    const complete = expected != null && products.size === expected;
    return { ok: true, products: [...products.values()], complete, pagesRead, totalPages: total, expected, note: complete ? `全部在售商品读取完成：${products.size}件，共${total}页。` : `已遍历${pagesRead}页，读取${products.size}件；${expected == null ? '没有识别到页面商品总数，完整性待核对。' : '与页面总数' + expected + '件不一致，采集未完成。'}` };
  } catch (error) { return { ok: true, products: [...products.values()], complete: false, pagesRead, totalPages: total, expected, note: `${error.message}。已保留本次读取的${products.size}件商品。` }; }
  finally { collectionRuns.delete(id); }
}

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (message.type === 'FETCH_REFERENCE') { fetchReference(message).then(reply).catch(error => reply({ ok: false, error: error.message })); return true; }
  if (message.type === 'STOP_COLLECTION') { const run = collectionRuns.get(message.id); if (run) run.cancelled = true; reply({ ok: true }); return false; }
  if (message.type === 'READ_ALL_PRODUCTS') {
    (async () => reply(await readAll(await currentStoreTab(), message.id)))().catch(error => reply({ ok: false, error: error.message })); return true;
  }
  if (message.type === 'READ_PRODUCTS') {
    (async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error('未找到当前标签页，请在商品页点击插件图标再试。');
      if (!tab.url) throw new Error('浏览器未授予读取商品页的权限，请更新插件并允许访问商品网站。');
      if (!/^https?:/.test(tab.url)) throw new Error('当前标签页不是网站页面，请切回商品列表后读取。');
      const host = new URL(tab.url).hostname;
      if (!/(^|\.)(taobao\.com|tmall\.com|1688\.com|qianniu\.com)$/.test(host)) throw new Error('当前仅读取淘宝、天猫、千牛及1688商品页面。');
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['collector.js'] });
      const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => globalThis.MaterialCollector.collect(document, location.href) });
      reply({ ok: true, ...result });
    })().catch(error => reply({ ok: false, error: error.message || '当前页读取失败，请重新点击插件图标后再试。' }));
    return true;
  }
});

chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id) return false;
 if(message.type==='FULL_TABS'){chrome.tabs.query({currentWindow:true}).then(tabs=>reply({ok:true,tabs:tabs.filter(tab=>{try{return /^https?:/.test(tab.url)&&/(^|\.)(taobao\.com|tmall\.com|1688\.com|qianniu\.com)$/.test(new URL(tab.url).hostname);}catch{return false;}}).map(tab=>({id:tab.id,title:tab.title,url:new URL(tab.url).origin+new URL(tab.url).pathname}))}));return true;}
 if(message.type==='FULL_CONTENT'){
  (async()=>{const tab=await currentStoreTab(message.tabId);await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[message.frameId]},world:'MAIN',files:['content-readback.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[message.frameId]},world:'MAIN',func:async(job,action)=>{try{return await FullContent.request(job,action);}catch{return {ok:false,error:'搜推内容回查未确认，请核对平台页面、基线与素材记录。'};}},args:[message.job,message.action]});reply(result);})().catch(()=>reply({ok:false,error:'当前后台内容回查未完成。'}));return true;
 }
 if(message.type==='FULL_FISSION'){
  (async()=>{const tab=await currentStoreTab(message.tabId);await chrome.scripting.executeScript({target:{tabId:tab.id},files:['fission.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:async(action,job)=>{try{return await FullFission.execute(action,job);}catch(error){return {ok:false,error:error.message,executed:false};}},args:[message.action,message.job]});reply(result);})().catch(()=>reply({ok:false,error:'商品克隆操作未完成，请回查平台状态。'}));return true;
 }
 if(message.type==='FULL_SCENE') {
  (async()=>{const tab=await currentStoreTab(message.tabId);await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[message.frameId]},world:'MAIN',files:['scene.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[message.frameId]},world:'MAIN',func:async(job,action,name)=>{try{return await FullScene.request(job,action,name);}catch(error){const safe={PICTURE_NOT_FOUND:'图片空间尚未查到本批唯一文件名。',PICTURE_RECORD_CONFLICT:'图片记录重复或尺寸不符。',LOOKUP_COMPONENT_UNAVAILABLE:'官方图片空间查询组件未就绪。',PLATFORM_LOGIN_UNAVAILABLE:'平台登录未就绪。'};return {ok:false,code:safe[error.code]?error.code:'SCENE_OPERATION_UNCONFIRMED',error:safe[error.code]||'素材槽操作未确认，请核对登录、平台页面和字段身份。'};}},args:[message.job,message.action,message.fileName||'']});reply(result);})().catch(()=>reply({ok:false,error:'平台页面场景操作未完成，请核对当前页面并回查。'}));return true;
 }
 if(message.type==='FULL_PLATFORM') {
  (async()=>{
   const tab=await currentStoreTab(message.tabId);
   await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},world:'MAIN',files:['platform-evidence.js']});
   await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},files:['platform.js']});
   if(message.action==='inspect') {
    const frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:job=>FullPlatform.inspect(job),args:[message.job]});
    reply({ok:true,tabId:tab.id,frames:frames.map(frame=>({frameId:frame.frameId,...frame.result}))});
   } else {
    if(!Number.isInteger(message.frameId)) throw new Error('请先检查当前平台页面并选择对应表单。');
    const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[message.frameId]},func:async(action,job,assets)=>{try{return await FullPlatform.execute(action,job,assets);}catch(error){return {ok:false,error:error.message,executed:false};}},args:[message.action,message.job,message.assets||[]]});
    reply({ok:true,...result});
   }
  })().catch(error=>reply({ok:false,error:error.message}));return true;
 }
 if(message.type==='FULL_OPEN') {
  (async()=>{ const url=new URL(message.url);if(url.protocol!=='https:'||!/(^|\.)taobao\.com$/.test(url.hostname)) throw new Error('平台入口无效。');const tab=await chrome.tabs.create({url:url.href});reply({ok:true,tabId:tab.id}); })().catch(error=>reply({ok:false,error:error.message}));return true;
 }
});

chrome.alarms.onAlarm.addListener(async alarm=>{
 if(!alarm.name.startsWith('full-reminder:')) return;
 const key=alarm.name.slice('full-reminder:'.length);
 const stored=(await chrome.storage.local.get('full-helper-v1'))['full-helper-v1'];
 const schedule=stored?.schedules?.find(s=>s.id===key&&s.enabled);
 if(!schedule) return;
 // 调度提示不自动消耗费用或写店铺；执行队列由已打开侧栏接管。
 await FullStateStore.update('full-helper-v1',latest=>{if(!latest?.schedules?.some(s=>s.id===key&&s.enabled))return;latest.scheduleDue={id:key,time:new Date().toISOString()};return latest;});
 chrome.runtime.sendMessage({type:'FULL_SCHEDULE_DUE',id:key}).catch(()=>{});
});
