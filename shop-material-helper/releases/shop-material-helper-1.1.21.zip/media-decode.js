'use strict';
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
 if(m?.type!=='MATERIAL_VIDEO_DECODE'||sender.id!==chrome.runtime.id||!/^[-a-f0-9]{36}$/i.test(m.id||''))return false;
 (async()=>{
  const db=await new Promise((resolve,reject)=>{const r=indexedDB.open('material-independent-v1');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
  let stored;try{stored=await new Promise((resolve,reject)=>{const r=db.transaction('videoInputs').objectStore('videoInputs').get(m.id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}finally{db.close();}
  if(!stored?.blob||stored.blob.type!=='video/mp4')throw Error('missing media');
  const video=document.createElement('video'),url=URL.createObjectURL(stored.blob);video.muted=true;video.preload='auto';
  try{
   await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('decode timeout')),12000);video.onloadeddata=()=>{clearTimeout(timer);resolve();};video.onerror=()=>{clearTimeout(timer);reject(Error('decode failed'));};video.src=url;video.load();});
   const c=document.createElement('canvas');c.width=1;c.height=1;c.getContext('2d').drawImage(video,0,0,1,1);c.getContext('2d').getImageData(0,0,1,1);
   return {ok:true,id:m.id,info:{width:video.videoWidth,height:video.videoHeight,duration:video.duration,decodedFirstFrame:true}};
  }finally{video.pause();video.removeAttribute('src');video.load();URL.revokeObjectURL(url);}
 })().then(reply,()=>reply({ok:false,id:m.id,error:'本地视频解码未通过'}));return true;
});
