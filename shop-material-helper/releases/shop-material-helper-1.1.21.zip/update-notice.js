'use strict';
// Only the extension's entry pages call this. No background polling or business state access.
(async()=>{
 const link=document.querySelector('a[href="updates.html"]');if(!link)return;
 async function show(){try{const s=await chrome.runtime.sendMessage({type:'MATERIAL_UPDATE_STATUS'});if(!s?.ok)return;link.textContent=s.newer?'有新版 '+s.release.version:'版本与更新';link.classList.toggle('has-update',!!s.newer);link.title=s.newer?'打开后下载新版；升级请保留原目录和扩展ID':s.permission?'更新检查不影响当前任务':'点击后可开启更新提醒';return s;}catch{}}
 const s=await show();if(s?.permission){await chrome.runtime.sendMessage({type:'MATERIAL_UPDATE_CHECK',automatic:true}).catch(()=>{});await show();}
 chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes['material-extension-download-update-v1'])show();});
})();