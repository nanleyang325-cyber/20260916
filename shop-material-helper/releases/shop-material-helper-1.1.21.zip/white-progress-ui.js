(function(root){
'use strict';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function stage(item){
 if(item.whiteTerminal==='unconfirmed')return {kind:'unknown',text:'待确认'};
 if(item.whiteTerminal==='failed'||item.status==='failed')return {kind:'fail',text:'⛔失败'};
 if(item.whiteTerminal==='skipped')return {kind:'skip',text:'⏭跳过'};
 if(item.status==='verified'&&item.receipt?.source==='platform-readback'&&item.receipt.contentId&&Array.isArray(item.receipt.productIds)&&JSON.stringify([...new Set(item.receipt.productIds)].sort())===JSON.stringify([...new Set(item.productIds||[])].sort()))return {kind:'done',text:'✅完成'};
 if(item.status==='skipped')return {kind:'skip',text:'⏭跳过'};
 if(item.status==='submitted_unconfirmed'||item.publication||['readback','done'].includes(item.phase))return {kind:'unknown',text:'待确认'};
 if(item.status==='blocked'){const submitted=item.nativeIntent||item.uploadIntents||item.generations?.some(g=>g.intent);return submitted?{kind:'unknown',text:'待确认'}:{kind:'fail',text:'⛔失败'};}
 if(item.generations?.some(g=>g.status==='failed'))return {kind:'fail',text:'⛔失败'};
 if(item.generations?.some(g=>['submission_unconfirmed','downloaded_unverified'].includes(g.status)))return {kind:'unknown',text:'待确认'};
 if(item.whiteConsumed)return {kind:'unknown',text:'已结算 · 待确认'};
 const text={prepare:'等待',generate:'生成中',attach:'上传中',native:'白底处理中',publish:'回填中',done:'待确认'}[item.phase]||'等待';return {kind:item.phase==='prepare'?'wait':'doing',text};
}
function render(run,control={}){
 const items=run.items||[],states=items.map(stage),count=kind=>states.filter(s=>s.kind===kind).length,custom=['ids','custom'].includes(run.selection?.mode),paused=run.status==='paused'||run.enabled&&control.paused&&control.runs?.['material-flow-runs-v1']?.includes(run.id),draining=!!run.draining&&run.enabled;
 const status=paused?'已暂停':draining?'收尾中':run.enabled?(run.phase==='discover'?'正在查找商品':'运行中'):({done:'本轮结束',pending_review:'本轮结束，仍有待确认项',budget_exhausted:'本轮调用预算已耗尽，其余商品未开始',recovery_exhausted:'页面恢复次数已耗尽，其余商品未继续',drained:'已收尾停止',stopped:'已停止',blocked:'已阻塞，需回查'}[run.status]||'状态待确认');
 const visible=items.map((item,index)=>({item,state:states[index]})).filter(row=>custom||row.state.kind!=='skip');
 const rows=visible.map(({item,state})=>{const cost=run.selection?.source&&run.selection.source!=='ai_generate'?'未调用 AI 生图':item.generations?.some(g=>g.intent)?'已登记生成任务 · 费用以账户记录为准':'未发起生成';const detail=item.detail||(state.kind==='unknown'?run.error:'')||'';return `<tr><td class="white-progress-id">${esc((item.productIds||[]).join('、'))}<small>${cost}</small></td><td class="white-stage-${state.kind}" title="${esc(state.text+(detail?' '+detail:''))}"><div>${esc(state.text+(detail?' '+detail:''))}</div></td></tr>`;}).join('');
 return `<article class="card white-progress" data-white-run="${esc(run.id)}"><h3>白底图 · ${custom?'自定义ID':'全量跑'}</h3><p class="white-run-status" role="status">${status}</p><p class="white-progress-summary">📊 本轮 ${items.length} 个商品 · 成功 ${count('done')} · 跳过 ${count('skip')} · 失败 ${count('fail')} · 待确认 ${count('unknown')} · 未开始 ${count('wait')} · 处理中 ${count('doing')}</p>${run.error?`<p class="white-progress-error">${esc(run.error)}</p>`:''}<div class="white-progress-actions">${run.multiRunId?`<button data-white-parent="${esc(run.multiRunId)}">查看多任务控制</button>`:run.enabled||paused?`<button data-white-pause="${esc(run.id)}" ${draining?'disabled':''}>${paused?'▶ 继续':'⏸ 暂停'}</button><button data-white-stop="${esc(run.id)}">${draining?'⏹ 收尾中 · 再点立即停止':'⏹ 停止'}</button>`:run.status!=='done'?`<button data-flow-resume="${esc(run.id)}" ${control.paused?'disabled':''}>按原范围继续 / 回查</button>`:''}</div>${rows?`<table><thead><tr><th>商品ID</th><th>白底图</th></tr></thead><tbody>${rows}</tbody></table>`:`<p class="white-progress-empty">${items.length?'全量任务的跳过商品仅计入汇总。':run.phase==='discover'?'正在查找待补白底图的商品…':'等待商品阶段明细…'}</p>`}</article>`;
}
root.FullWhiteProgress={stage,render};
})(globalThis);
