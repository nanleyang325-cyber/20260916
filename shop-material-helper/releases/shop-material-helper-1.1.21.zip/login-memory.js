/* Local account-name memory. Never inspect password fields, cookies, tokens,
 * requests or website storage. Never submit, focus, or operate verification. */
(()=>{'use strict';
 const KEY='material-local-login-name-v1';
 const clean=name=>typeof name==='string'&&name.trim().length<=128?name.trim():'';
 const read=async()=>{const raw=(await chrome.storage.local.get(KEY))[KEY];return {enabled:raw?.enabled!==false,name:clean(raw?.name)};};
 const write=value=>chrome.storage.local.set({[KEY]:{enabled:value.enabled===true,name:clean(value.name)}});
 if(location.protocol==='chrome-extension:'){
  if(!location.pathname.endsWith('/panel.html'))return;
  const setup=async()=>{const parent=document.querySelector('#create');if(!parent||document.querySelector('#login-memory-settings'))return;const details=document.createElement('details');details.id='login-memory-settings';details.className='card';const summary=document.createElement('summary');summary.textContent='登录记忆';const label=document.createElement('label'),toggle=document.createElement('input');toggle.type='checkbox';toggle.id='remember-login-name';toggle.style.width='auto';toggle.style.minHeight='0';label.append(toggle,document.createTextNode(' 记住店铺账号（仅本机）'));const status=document.createElement('p');status.className='muted';status.id='remember-login-status';const clear=document.createElement('button');clear.type='button';clear.id='clear-login-name';clear.textContent='清除记住的账号';details.append(summary,label,status,clear);parent.prepend(details);
   const render=async()=>{const state=await read();toggle.checked=state.enabled;status.textContent=state.name?'已记住账号：'+state.name+'。不保存密码，不自动登录。':'网站登录状态由浏览器保留；登录过期时可回填记住的账号，不保存密码。';clear.disabled=!state.name;};toggle.addEventListener('change',async()=>{const previous=await read();await write({enabled:toggle.checked,name:previous.name});await render();});clear.addEventListener('click',async()=>{await write({enabled:false,name:''});await render();});chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[KEY])render();});await render();};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();return;
 }
 if(location.protocol!=='https:'||!['havanalogin.taobao.com','login.taobao.com'].includes(location.hostname))return;
 let state={enabled:false,name:''},restored=false;
 const fields=new WeakSet(),edited=new WeakSet();
 function field(){const input=document.querySelector('input#fm-login-id');return input&&['text','email','tel'].includes(input.type)&&!input.disabled&&!input.readOnly?input:null;}
 async function remember(event){const input=field();if(!event.isTrusted||event.target!==input||!edited.has(input)||!state.enabled)return;const name=clean(input.value);if(name){state={enabled:true,name};await write(state);}}
 function apply(){const input=field();if(!input)return;if(!fields.has(input)){fields.add(input);input.addEventListener('input',event=>{if(event.isTrusted){restored=true;edited.add(input);}});input.addEventListener('change',remember);input.addEventListener('blur',remember);}if(restored||!state.enabled||!state.name||input.value||document.activeElement===input||input.getClientRects().length===0)return;restored=true;Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,state.name);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
 read().then(value=>{state=value;apply();});new MutationObserver(apply).observe(document.documentElement,{childList:true,subtree:true});chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local'||!changes[KEY])return;read().then(value=>{state=value;apply();});});
})();
