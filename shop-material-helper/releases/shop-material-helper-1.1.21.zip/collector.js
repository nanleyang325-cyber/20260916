(function (root) {
  function productId(raw, base) {
    try {
      const u = new URL(raw, base);
      if (!/(^|\.)(taobao\.com|tmall\.com|1688\.com)$/.test(u.hostname)) return null;
      const id = u.searchParams.get('id') || u.pathname.match(/\/offer\/(\d+)\.html/)?.[1];
      return /^\d{6,}$/.test(id || '') ? id : null;
    } catch { return null; }
  }
  function imageUrl(img, base) {
    const raw = img?.getAttribute('data-src') || img?.getAttribute('data-original') || img?.currentSrc || img?.src;
    if (!raw) return null;
    try { const u = new URL(raw, base); return /^https?:$/.test(u.protocol) ? u.href : null; } catch { return null; }
  }
  function collect(doc, pageUrl) {
    const products = new Map();
    const rowSelector = 'tr, [role="row"], [data-item-id], [data-product-id], .next-table-row, .ant-table-row';
    function addRow(row, id) {
      if (!/^\d{6,}$/.test(id || '')) return;
      const images = [...new Set(Array.from(row.querySelectorAll('img')).map(img => imageUrl(img, pageUrl)).filter(Boolean))];
      const titleNode = row.querySelector('.product-title, .item-title, [data-title]');
      let title = titleNode?.getAttribute('data-title') || titleNode?.textContent || row.querySelector('img[alt]')?.getAttribute('alt') || '';
      if (!title.trim()) {
        const walker = doc.createTreeWalker(row, 4);
        while (walker.nextNode()) {
          const value = walker.currentNode.textContent.trim();
          if (value.length >= 4 && !/^(?:商品\s*)?ID\s*[:：]|^(?:￥|¥)|^(?:编辑商品|创建渠道商品|更多|出售中|库存|价格|质量分|基础分|扶优分)/i.test(value)) { title = value; break; }
        }
      }
      title = title.trim().replace(/\s+/g, ' ').slice(0, 150);
      const old = products.get(id);
      products.set(id, { id, title: old?.title && old.title !== '标题待补充' ? old.title : title || '标题待补充', url: old?.url || `https://item.taobao.com/item.htm?id=${id}`, images: [...new Set([...(old?.images || []), ...images])], source: '当前商品列表' });
    }
    for (const link of doc.querySelectorAll('a[href]')) {
      const id = productId(link.getAttribute('href'), pageUrl);
      if (!id) continue;
      const row = link.closest(rowSelector) || link;
      const imgs = Array.from(row.querySelectorAll('img')).map(img => imageUrl(img, pageUrl)).filter(Boolean);
      const title = (link.getAttribute('title') || link.innerText || row.querySelector('img')?.alt || '').trim().replace(/\s+/g, ' ').slice(0, 150);
      const old = products.get(id);
      if (old) { old.images = [...new Set([...old.images, ...imgs])]; if (!old.title && title) old.title = title; }
      else products.set(id, { id, title: title || '标题待补充', url: new URL(link.getAttribute('href'), pageUrl).href, images: [...new Set(imgs)], source: '当前页面' });
    }
    for (const row of doc.querySelectorAll(rowSelector)) {
      const explicit = row.getAttribute('data-item-id') || row.getAttribute('data-product-id');
      const labels = [...row.textContent.matchAll(/(?:商品\s*)?ID\s*[:：]?\s*(\d{6,})(?!\d)/gi)];
      // 单行只对应一个商品；多个ID的容器不把各款图片混在一起。
      if (explicit || labels.length === 1) addRow(row, explicit || labels[0][1]);
    }
    if (/sellmanage|sellitem|products|goods/i.test(pageUrl) && doc.body) {
      const walker = doc.createTreeWalker(doc.body, 4);
      while (walker.nextNode()) {
        const match = walker.currentNode.textContent.trim().match(/^(?:商品\s*)?ID\s*[:：]?\s*(\d{6,})\s*$/i);
        if (!match || products.has(match[1])) continue;
        let node = walker.currentNode.parentElement;
        for (let depth = 0; node && depth < 8 && node !== doc.body; depth++, node = node.parentElement) {
          const labels = [...node.textContent.matchAll(/(?:商品\s*)?ID\s*[:：]?\s*\d{6,}/gi)];
          if (labels.length > 1) break;
          if (node.querySelector('img') && labels.length === 1) { addRow(node, match[1]); break; }
        }
      }
    }
    const currentId = productId(pageUrl, pageUrl);
    // 素材中心把“ID”和数值拆成两个子节点；先合并标签文本，再向上找单品容器。
    if(/material-center|sellmanage/i.test(pageUrl))for(const label of doc.querySelectorAll('span,div')){
      const match=label.textContent.trim().match(/^(?:商品\s*)?ID\s*[:：]?\s*(\d{6,})\s*$/i);
      if(!match||products.has(match[1]))continue;
      let node=label.parentElement;
      for(let depth=0;node&&node!==doc.body&&depth<8;depth++,node=node.parentElement){
        const labels=[...node.textContent.matchAll(/(?:商品\s*)?ID\s*[:：]?\s*\d{6,}/gi)];if(labels.length>1)break;
        if(labels.length===1&&node.querySelector('img')){addRow(node,match[1]);break;}
      }
    }
    if (currentId && !products.has(currentId)) {
      const title = (doc.querySelector('h1')?.innerText || doc.title || '').trim().slice(0, 150);
      const images = Array.from(doc.querySelectorAll('img')).filter(img => img.naturalWidth >= 300 && img.naturalHeight >= 300).map(img => imageUrl(img, pageUrl)).filter(Boolean).slice(0, 15);
      products.set(currentId, { id: currentId, title, url: pageUrl, images: [...new Set(images)], source: '商品详情页·图片待挑选' });
    }
    return { products: [...products.values()].slice(0, 100), page: { url: pageUrl, title: doc.title }, note: '仅读取当前页已加载的商品。没有自动翻页；详情页图片请检查是否属于该商品。' };
  }
  root.MaterialCollector = { productId, collect };
  if (typeof module !== 'undefined') module.exports = root.MaterialCollector;
})(globalThis);
