(function(root){
 'use strict';
 const visible=el=>el&&el.getClientRects().length>0;
 function identity(url,pid,clone=false){const u=new URL(url);if(!/(^|\.)taobao\.com$|(^|\.)tmall\.com$/.test(u.hostname))throw new Error('非平台商品编辑页面。');const source=u.searchParams.get('st_dist_src_id')||u.searchParams.get('itemId');if(source!==pid||clone&&u.searchParams.get('copyItem')!=='true')throw new Error('官方克隆链接源商品ID不符。');return source;}
 function compare(source,target){if(!source?.complete||!target?.complete)return {ok:false,reason:'SKU未完整读取，不能提交新商品。'};const normalize=snapshot=>JSON.stringify([...snapshot.skus].sort((a,b)=>a.key.localeCompare(b.key)));return normalize(source)===normalize(target)?{ok:true}:{ok:false,reason:'SKU规格、价格、库存、商家编码或条码发生变化。'};}
 async function snapshot(job){
  const pid=job.productIds[0];identity(location.href,pid);const table=document.querySelector('#struct-sku');if(!table)throw new Error('未识别完整SKU编辑表格，请打开源商品或官方发布相似品页面。');
  const title=document.querySelector('.sell-component-tbtitle input:not([type="checkbox"]):not([disabled])')?.value||'';
  const scroller=table.querySelector('.ver-scroll-wrap')||document.querySelector('.ver-scroll-wrap');const skus=new Map();let stable=0,lastSize=0,invalid=false;
  const read=()=>{
   const carry=new Map();
   for(const row of table.querySelectorAll('tbody tr')){
    const specs=[];
    for(const [key,value]of carry){if(value.left>0){specs.push([key,value.value]);value.left--;}else carry.delete(key);}
    for(const cell of row.querySelectorAll('td[id]')){if(!/^\d+-p-\d+$/.test(cell.id))continue;const key=cell.id.split('-p-')[1],value=cell.innerText.trim();specs.push([key,value]);if(cell.rowSpan>1)carry.set(key,{left:cell.rowSpan-1,value});}
    const value=suffix=>row.querySelector(`[id$="-${suffix}"] input`)?.value;
    const price=value('skuPrice'),stock=value('skuStock'),outerId=value('skuOuterId'),barcode=value('skuBarcode');const enabled=row.querySelector('[id$="-skuStatus"] [role="switch"]')?.getAttribute('aria-checked');if(price==null||stock==null||outerId==null||barcode==null||enabled==null||!specs.length){if(row.querySelector('[id$="-skuPrice"]'))invalid=true;continue;}
    specs.sort((a,b)=>a[0].localeCompare(b[0]));const key=specs.map(s=>s.join('=')).join(';'),record={key,specs,price,stock,outerId,barcode,enabled};if(skus.has(key)&&JSON.stringify(skus.get(key))!==JSON.stringify(record))invalid=true;skus.set(key,record);
   }
  };
  if(scroller)scroller.scrollTop=0;
  for(let page=0;page<300;page++){
   await new Promise(resolve=>setTimeout(resolve,150));read();
   stable=skus.size===lastSize?stable+1:0;lastSize=skus.size;
   if(!scroller)break;
   if(scroller.scrollTop+scroller.clientHeight>=scroller.scrollHeight-2&&stable>=2)break;
   scroller.scrollTop=Math.min(scroller.scrollHeight,scroller.scrollTop+Math.max(scroller.clientHeight-50,100));
  }
  const advertised=Number(table.getAttribute('data-sku-count')||table.innerText.match(/共\s*(\d+)\s*(?:个|条|款)\s*(?:SKU|规格)/i)?.[1]||job.expectedSkuCount||0);
  return {productId:pid,title,skus:[...skus.values()],expected:advertised,complete:!invalid&&advertised>0&&skus.size===advertised,mainImages:[...document.querySelectorAll('#struct-mainImagesGroup .drag-item img')].map(img=>img.src),capturedAt:new Date().toISOString()};
 }
 async function execute(action,job){
  if(action==='snapshot-source')return {ok:true,status:'prepared',sourceSnapshot:await snapshot(job)};
  if(action==='snapshot-clone'){identity(location.href,job.productIds[0],true);const cloneSnapshot=await snapshot(job);return {ok:true,status:'prepared',cloneSnapshot,comparison:compare(job.sourceSnapshot,cloneSnapshot)};}
  if(action==='submit-clone'){
   identity(location.href,job.productIds[0],true);if(!job.newProductConsent)throw new Error('新增商品尚未明确确认。');const current=await snapshot(job),comparison=compare(job.sourceSnapshot,current);if(!comparison.ok)throw new Error(comparison.reason);
   if(!job.optimizeTitle&&job.sourceSnapshot.title!==current.title)throw new Error('标题发生变化，未允许标题优化。');
   if(!job.reviewedCloneImages)throw new Error('尚未确认新主图属于同一商品且已经填写。');
   const submit=[...document.querySelectorAll('button.next-btn-primary')].filter(el=>visible(el)&&!el.disabled&&el.textContent.trim()==='提交');if(submit.length!==1)throw new Error('商品提交入口不唯一。');submit[0].click();return {ok:true,status:'submitted_unconfirmed',message:'已提交新增商品，需读取新商品ID并逐项回查；未操作原商品。'};
  }
  throw new Error('裂变动作无效。');
 }
 root.FullFission={identity,compare,snapshot,execute};if(typeof module!=='undefined')module.exports=root.FullFission;
})(globalThis);
