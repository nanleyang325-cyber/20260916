(function(root) {
 'use strict';
 function whitePrompt({title='',reason='',fixes=[],previous=[]}={}) {
  return [
   '任务：编辑同商品、同规格SKU参考图制作白底图。保留商品原始外观，只清理商品外部背景及外加营销内容，不重新设计或美化商品。',
   '商品事实：优先依据所选SKU明确提供的商品文案及用户确认信息。未说明的材质、工艺、功能、尺寸或结构不得补写，也不得从同系列其他规格移植；文案未说明时仅保留参考图可见外观。',
   title?'商品识别信息：'+title:'',
   reason?'平台本次拒绝原因：'+reason:'',
   fixes.length?'本次修正要求：\n'+fixes.map((f,i)=>(i+1)+'. '+f).join('\n'):'',
   previous.length?'此前成图问题，仅用于避免重复错误，不作为商品属性：'+previous.join('；'):'',
   '保真：禁止修改产品外形。严格保持参考图同一商品的外轮廓、边角形状与圆角半径、长宽比例、厚度、弧度、分缝、部件数量及位置；不得把直角改为圆角、改变切边、拉伸、重塑或重新设计产品。保持原机位、结构、标识、图案、颜色和表面质感。仅保留原图已有反光、纹理及透明性，不新增或改变任何材质效果。参考图未展示或被遮住的细节不臆造。',
   '完整性：保留一件商品的完整外缘及必要部件；同一件商品的多个结构件不是重复商品。不要裁掉商品，也不机械缩小主体；只在必要时增加画布留白。',
   '清理范围：移除商品外部的背景、道具、人物、促销文字、水印、贴片、横幅及重复展示小图，不留下模糊字迹、半透明条带或颜色残块。只移除外加内容，保留商品自身真实印刷、刻印及必要显示内容。',
   '输出：商品外部为纯白RGB(255,255,255)，主体及完整边缘清晰，不虚化、不用模糊掩盖残留，不新增装饰、宣传文字或未经证实的信息。'
  ].filter(Boolean).join('\n');
 }
 const MODULES = {
  white: { name:'白底图', media:'image', ratio:'1:1', count:1, destination:'material', prompt:whitePrompt() },
  transparent: { name:'透明图', media:null, destination:'material' },
  scene: { name:'场景图', media:'image', ratio:'1:1', count:1, destination:'material', prompt:'真实家居使用场景，产品为主体，保留形状、颜色、结构，不能增加功能。' },
  buyer: { name:'买家秀模拟图', media:'image', ratio:'3:4', count:9, destination:null, prompt:'AI模拟产品生活场景摄影，不冒充真实消费者评价或购买体验。不得生成参考图未展示的背面、接线端子、认证铭牌。' },
  mainvideo: { name:'主图视频', media:'video', ratio:'9:16', count:1, destination:'material', prompt:'围绕参考商品拍摄单一缓慢展示动作，保持结构与颜色，不增加未证实功能，不出现价格、认证或虚构效果。' },
  fission: { name:'链接裂变', media:'image', ratio:'1:1', count:1, destination:'products', prompt:'仅替换图片背景，主体外观、数量、结构、颜色、标识保持一致。' },
  outfit: { name:'批量换装', media:'image', ratio:'3:4', count:1, destination:null, prompt:'将服装参考准确穿在模特参考人物身上，保持人物身份、服装版型、材质、花纹和颜色。不添加其他商品。' },
  search: { name:'搜推图文', media:'image', ratio:'1:1', count:9, destination:'material', prompt:'商品推荐图文配图，产品清晰，真实使用场景，不生成文字或促销标语。' },
  searchvideo: { name:'搜推视频', media:'video', ratio:'9:16', count:1, destination:'material', prompt:'生成10秒商品展示视频。0至3秒展示参考图可见的商品整体，3至7秒镜头缓慢向商品推进，7至10秒平稳停留在原图已展示的细节。保持同一商品的外形、数量、结构、颜色和标识一致；不转到参考图未展示的背面，不展示未经核实的功能，不增加文字、字幕、价格或认证。保持画面稳定、动作连续。' },
  trend: { name:'趋势提报', media:null, destination:'trend' },
  selling: { name:'卖点维护', media:null, destination:'selling' },
  incubate: { name:'新品孵化', media:null, destination:'incubate' },
  guanghe: { name:'光合素材', media:'image', ratio:'3:4', count:9, destination:'guanghe' ,prompt:'竖版生活场景商品内容，商品外观与参考一致，不生成文字或未经证实的使用效果。' },
  follow: { name:'关注运营', media:null, destination:'follow', group:3 }
 };
 const STATUS = { draft:'待开始', generating:'生成中', generated:'素材已生成', prepared:'内容已准备', uploaded:'已上传', submitting:'正在提交', submitted_unconfirmed:'已提交待回查', verified:'后台已核验', failed:'失败', unknown:'状态待核对', stopped:'已停止', ineligible:'不适用' };
 const URLS = {
  products:'https://myseller.taobao.com/home.htm/sellmanage/on_sale',
  material:'https://qn.taobao.com/home.htm/material-center/material-management',
  space:'https://qn.taobao.com/home.htm/material-center/mine-material/sucai-tu',
  trend:'https://myseller.taobao.com/home.htm/trend-product-operation/home',
  selling:'https://qn.taobao.com/home.htm/new-product-operation/home/MaterialTending',
  incubate:'https://qn.taobao.com/home.htm/new-product-operation/home?firstTab=grow&secondTab=await',
  follow:'https://qn.taobao.com/home.htm/Subscription/generator/621',
  followNew:'https://qn.taobao.com/home.htm/Subscription/generator/635',
  guanghe:'https://creator.guanghe.taobao.com/page/pubNew/pic?pub_url='+encodeURIComponent('https://huodong.taobao.com/wow/z/guang/gg_publish/gg-picture?ugc_scene=pc_newcreator_pic&pageType=article&site=guangguang')+'&pub_scene=gg',
  guangheVideo:'https://creator.guanghe.taobao.com/page/pubNew/video?pub_url='+encodeURIComponent('https://huodong.taobao.com/wow/z/guang/gg_publish/gg-video?ugc_scene=pc_newcreator_video&pageType=video&site=guangguang')+'&pub_scene=gg'
 };
 function ids(text) { const values = String(text).split(/[\s,，;；]+/).filter(Boolean); if (!values.length || values.some(id=>!/^\d{6,}$/.test(id))) throw new Error('请填写商品ID，用空格或换行分隔。'); return [...new Set(values)]; }
 function config(name,variant){const module=MODULES[name];if(name==='guanghe'&&variant==='video')return {...module,media:'video',count:1,ratio:'9:16',destination:'guangheVideo',prompt:'真实商品生活场景视频，保留参考商品外观，不增加未经确认的能力。'};return module;}
 function plan(products, settings) {
  if(settings.module==='transparent')throw new Error('透明图使用已有白底图抠图，请从独立透明图按钮启动。');
  const module = config(settings.module,settings.variant); if (!module) throw new Error('请选择功能。');
  const selected = ids(settings.ids).map(id=>{ const product=products.find(p=>p.id===id); if (!product) throw new Error(`商品${id}尚未采集或导入`); return product; });
  if (module.media && !['yes','no'].includes(settings.palette)) throw new Error('请确认本次是否使用南乐杨-1号色调。');
  if (settings.module==='outfit' && settings.category!=='clothing') throw new Error('换装需要确认商品为服装，并提供服装与模特两张参考图。');
  const count = module.media ? Number(settings.count || module.count) : 0;
  if (module.media && (!Number.isInteger(count) || count<1 || count>9)) throw new Error('每商品生成数量应为1至9。');
  const group = settings.module==='follow' ? (settings.followMode==='new' ? 4 : 3) : 1;
  if (selected.length % group) throw new Error(`当前模式每帖${group}款，商品数量须为${group}的整数倍，不自动添加其他商品。`);
  const calls = module.media ? selected.length * count : 0;
  if (calls > Number(settings.maxCalls || 20)) throw new Error(`计划需${calls}次生成，超出本批次数上限。`);
  const jobs=[];
  for (let i=0; i<selected.length; i+=group) {
   const items=selected.slice(i,i+group), id=crypto.randomUUID();
   const prompt = `${module.prompt||''}\n商品：${items.map(p=>p.title).join('；')}\n已确认事实：${settings.facts||'未提供，仅依据参考图展示外观，不推断功能。'}\n${settings.palette==='yes'?'环境用奶油白、自然浅木色、浅灰布艺，保留产品原色。':'保留产品原色，环境色彩自然。'}\n用户要求：${settings.extra||'无'}\n禁止增加未经确认的功能、认证、尺寸、兼容性、价格及标识。`;
   jobs.push({id,module:settings.module,variant:settings.module==='guanghe'&&settings.variant==='video'?'video':'image',productIds:items.map(p=>p.id),titles:items.map(p=>p.title),status:'draft',ratio:settings.ratio||module.ratio,palette:settings.palette,prompt,facts:settings.facts||'',title:settings.title||items.map(p=>p.title).join('、').slice(0,20),body:settings.body||settings.facts||'',followMode:settings.followMode||'list',startDate:settings.startDate||'',category:settings.category||'',assets:Array.from({length:count},(_,index)=>({id:crypto.randomUUID(),index,status:'draft'})),createdAt:new Date().toISOString(),events:[],generationConsent:false,publication:null});
  }
  return {jobs,calls};
 }
 function transition(job, status, detail='') { if (!STATUS[status]) throw new Error('状态无效'); job.status=status; job.events.push({time:new Date().toISOString(),status,detail:String(detail).slice(0,500)}); }
 function reuse(job,records){
  const media=config(job.module,job.variant)?.media;if(!media||job.publication||job.automation?.uploadIntent)throw new Error('该任务不能更换素材，已有上传或提交记录时只能回查。');
  if(!Array.isArray(records)||!records.length||new Set(records.map(r=>r.id)).size!==records.length)throw new Error('请选择不重复的已完成素材编号。');
  const identity=values=>[...new Set(values||[])].sort().join(',');
  if(records.some(r=>r.status!=='completed'||r.available!==true||r.media!==media||identity(r.productIds)!==identity(job.productIds)))throw new Error('复用素材必须已下载验证、类型一致且属于同一商品集合。');
  if(['white','scene','fission','mainvideo','searchvideo'].includes(job.module)&&records.length!==1)throw new Error('此模块只接受一份复用素材。');
  if(job.module==='search'&&records.length<3)throw new Error('搜推图文至少需要3张已完成图片。');
  if(job.module==='scene'&&!records[0].sceneAvailable)throw new Error('场景素材缺少已验证的800×800版本。');
  job.assets=records.map((record,index)=>({...record,index,reused:true}));job.reviewedAssets=false;delete job.automationConsent;transition(job,'generated','复用同商品原素材，未新增生成请求。');
 }
 function publicationKey(job) { return [job.id,job.module,...job.productIds].join(':'); }
 function verifyReceipt(job, receipt) {
  if (!receipt || receipt.source!=='platform-readback' || !receipt.contentId || !Array.isArray(receipt.productIds) || !receipt.status) return false;
  return [...job.productIds].sort().join(',') === [...new Set(receipt.productIds)].sort().join(',') && (!job.publication?.contentId || job.publication.contentId===receipt.contentId);
 }
 root.FullCore={MODULES,STATUS,URLS,config,ids,plan,reuse,transition,publicationKey,verifyReceipt,whitePrompt};
 if (typeof module!=='undefined') module.exports=root.FullCore;
})(globalThis);
