(function(root){
 'use strict';
 const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const complete=g=>g.status==='completed'&&g.available===true;
 const failed=new Set(['failed','rejected','violation','submission_unconfirmed','downloaded_unverified','not_completed','missing']);
 function enabled(run){
  const first=run.items[0]?.productIds[0];
  return run.selection?.searchParallelVersion===1&&root.FullSearchGeneration.enabled(run)&&!run.existingAssetsOnly&&!run.generationOnlyRecovery&&
   run.items.some(item=>item.productIds[0]!==first);
 }
 function windowItems(run){
  const groups=new Map();
  for(let index=run.position;index<run.items.length&&groups.size<3;index++){
   const item=run.items[index];
   if(item.phase==='done')continue;
   if(item.productIds.length!==1||!Number.isInteger(item.context?.articleIndex))throw Error('本批商品与原图文组身份未确认。');
   if(!groups.has(item.productIds[0]))groups.set(item.productIds[0],item);
  }
  return [...groups.values()];
 }
 async function advance(run,io){
  const head=run.items[run.position];
  const groups=run.draining?run.items.filter(item=>item.phase==='generate'&&item.generations?.some(g=>g.intent&&!complete(g))):windowItems(run);
  const ids=groups.flatMap(item=>(item.generations||[]).map(g=>g.id));
  const reserved=new Set(ids);
  if(reserved.size!==ids.length||groups.some(item=>item.generations&&item.generations.length!==3))throw Error('并行窗口的原素材编号或每组数量不符。');
  const errors=new Map();
  function skip(item,detail,reason){
   Object.assign(item,{status:'skipped',phase:'done',detail});
   if(reason)item.skipReason=reason;
  }
  function remember(item,error){
   if(error.stopped)throw error;
   if(item===head&&!run.draining)throw Object.assign(error,{failureItemId:item.id});
   errors.set(item.id,error);
  }
  await io.check();
  const waiting=groups.flatMap(item=>(item.generations||[]).filter(g=>g.intent&&!complete(g)).map(g=>({item,g})));
  const before=JSON.stringify(waiting.map(({g})=>g));
  const results=await Promise.allSettled(waiting.map(async({item,g})=>{
   const result=await io.queryGeneration(run,item,g);
   if(result.id!==g.id||!same(result.productIds,item.productIds))throw Error('回查的原素材编号或商品不符。');
   if(complete(result))Object.assign(g,result);
   else {
    Object.assign(g,{status:result.status||'pending',error:result.error||result.message||'',downloadOrigin:result.downloadOrigin||null});
    if(failed.has(g.status))throw Error('原素材未确认（'+g.status+'）：'+g.error+'。保留原编号。');
   }
  }));
  if(before!==JSON.stringify(waiting.map(({g})=>g)))await io.save('已按原编号更新并行素材状态。');
  await io.check();
  if(run.draining){
   if(results.every((result,index)=>result.status==='fulfilled'?complete(waiting[index].g)||waiting[index].g.status==='queued':failed.has(waiting[index].g.status))){
    run.enabled=false;run.status='drained';
    await io.save('已收尾。保留已登记编号和素材，未开始新的生图。');
   }
   return;
  }
  results.forEach((result,index)=>{if(result.status==='rejected')remember(waiting[index].item,result.reason);});
  const submissions=[];
  let interrupted;
  try{
   for(const item of groups){
    if(run.draining)break;
    if(errors.has(item.id)||!['prepare','generate'].includes(item.phase)||item!==head&&item.parallelDeferred)continue;
    try{
     await io.check();
     if(item.phase==='prepare'){
      const result=await io.prepare(run,item);
      await io.check();
      const excluded=io.searchSkip(item);
      if(excluded||result?.status==='ineligible'){
       skip(item,excluded?.detail||result.message,excluded?.reason||result.skipReason);
       await io.save(item.detail);
       continue;
      }
      if(!result?.needsGeneration||!same(result.productIds,item.productIds))throw Error('本批商品准备结果不符。');
      item.prepared=result;item.phase='generate';
     }else if(!item.generations||item.generations.some(g=>!g.intent&&!complete(g)&&root.FullSearchGeneration.ready(item,g))){
      const excluded=await io.generationEligibility(run,item);
      await io.check();
      if(excluded?.status==='ineligible'){
       skip(item,excluded.message,excluded.skipReason);
       await io.save(item.detail);
       continue;
      }
     }
     if(run.draining)break;
     delete item.parallelDeferred;
     if(item.generations?.every(complete)){
      item.phase='attach';
      await io.save('商品 '+item.productIds[0]+' 的原图已落盘，等待按批次顺序发布。');
      continue;
     }
     const drafts=item.generations?.filter(g=>!g.intent&&!complete(g)&&root.FullSearchGeneration.ready(item,g));
     if(drafts&&!drafts.length)continue;
     const reference=await io.searchReference(run,item);
     await io.check();
     if(run.draining)break;
     if(!item.generations){
      const plan=await io.planGeneration(run,item,reference);
      if(plan?.length!==3||new Set(plan.map(g=>g.id)).size!==3||
       plan.some(g=>reserved.has(g.id)||g.media!=='image'||!same(g.productIds,item.productIds)||g.referenceUrl!==item.mainImage))throw Error('图文组的原编号、商品、参考图或数量不符。');
      for(const g of plan)reserved.add(g.id);
      item.generations=plan;
      await io.save('已保存商品 '+item.productIds[0]+' 的三个原素材编号。');
     }
     for(const g of item.generations){
      if(g.intent||complete(g)||!root.FullSearchGeneration.ready(item,g))continue;
      await io.check();
      if(run.draining)break;
      g.intent={id:g.id,at:new Date().toISOString()};g.status='pending';run.usedCalls++;
      run.usedCallsByType.image++;
      await io.save('已登记商品 '+item.productIds[0]+' 的单次生图请求。');
      try{await io.check();}catch(error){delete g.intent;g.status='draft';run.usedCalls--;run.usedCallsByType.image--;await io.save('停止登记尚未发送的图片。');throw error;}
      if(run.draining){delete g.intent;g.status='draft';run.usedCalls--;run.usedCallsByType.image--;await io.save('收尾时保留尚未发送的图片草稿。');break;}
      submissions.push(io.submitGeneration(run,item,g,reference).then(()=>({item}),error=>({item,error})));
     }
    }catch(error){
     const excluded=error.stopped?null:io.searchSkip(item,error);
     if(excluded){skip(item,excluded.detail,excluded.reason);await io.save(item.detail);}
     else {
      remember(item,error);
      item.parallelDeferred=true;
      await io.save('商品 '+item.productIds[0]+' 的预查待确认，轮到该商品时复核。');
     }
    }
   }
  }catch(error){interrupted=error;}
  const submitted=await Promise.all(submissions);
  if(interrupted)throw interrupted;
  await io.check();
  for(const {item,error} of submitted)if(error)remember(item,error);
 }
 root.FullSearchBatchGeneration={enabled,advance};
 if(typeof module==='object')module.exports=root.FullSearchBatchGeneration;
})(globalThis);
