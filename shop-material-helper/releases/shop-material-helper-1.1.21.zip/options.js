(function (root) {
  'use strict';
  const KEY = 'material-feature-settings-v1', q = s => document.querySelector(s);
  const extension = !!root.chrome?.runtime?.id;
  const defaults = root.FullRunModes.DEFAULTS;
  const read = async () => extension ? (await chrome.storage.local.get(KEY))[KEY] || {} : JSON.parse(localStorage.getItem(KEY) || '{}');
  const status = text => { q('#saveStatus').textContent = text; };
  const safe = action => Promise.resolve().then(action).catch(error => status(error.message));
  function toggleMethodSubsections() {
    const method = q('[name="whiteBgSourceMethod"]:checked')?.value;
    for (const box of document.querySelectorAll('#panel-material [data-method-detail]')) box.style.display = box.dataset.methodDetail === method ? '' : 'none';
  }
  function position(name, id, n) {
    q('#' + id).value = n;
    const choice = n === 1 ? 'first' : n === -1 ? 'last' : 'custom';
    q(`[name="${name}"][value="${choice}"]`).checked = true;
  }
  function bindPosition(name, id) {
    for (const radio of document.querySelectorAll(`[name="${name}"]`)) radio.onchange = () => {
      if (radio.value !== 'custom') q('#' + id).value = radio.value === 'first' ? 1 : -1;
    };
    q('#' + id).oninput = () => { q(`[name="${name}"][value="custom"]`).checked = true; };
  }
  for (const radio of document.querySelectorAll('[name="whiteBgSourceMethod"]')) radio.onchange = toggleMethodSubsections;
  bindPosition('whiteBgMainImagePos', 'whiteBgMainImageN');
  bindPosition('whiteBgSkuImagePos', 'whiteBgSkuImageN');
  for (const [value, label] of Object.entries(root.FullRunModes.SORTS)) {
    const option = document.createElement('option'); option.value = value; option.textContent = label + (value === 'default' ? '（默认）' : ''); q('#whiteBgSortBy').append(option);
  }
  // Retain the original long-page layout without presenting unconnected controls as saved settings.
  for (const panel of document.querySelectorAll('.settings-panel')) {
    if (['panel-material', 'panel-logs', 'panel-account'].includes(panel.id)) continue;
    const note = document.createElement('p'); note.className = 'hint reference-only';
    note.textContent = '原版布局参考（只读）：本分类尚未接入保存。以下原版说明中的点数、授权、服务和运行能力不代表本地版本现状。';
    panel.querySelector('.panel-title').after(note);
    for (const control of panel.querySelectorAll('input,textarea,select,button')) control.disabled = true;
    for (const link of panel.querySelectorAll('a')) { link.removeAttribute('href'); link.setAttribute('aria-disabled', 'true'); }
  }
  // Original default AI-video subsection participates in the long page's intrinsic width.
  // Keep it visible as read-only reference so the adjacent white settings retain their layout.
  q('#soutuiVideoAiSub').style.display = '';
  const nav = [...document.querySelectorAll('.nav-item[data-panel]')];
  const highlight = id => nav.forEach(button => button.classList.toggle('active', button.dataset.panel === id));
  for (const button of nav) button.onclick = () => { highlight(button.dataset.panel); q('#' + button.dataset.panel).scrollIntoView({ behavior: 'smooth', block: 'start' }); };
  const observer = new IntersectionObserver(entries => { for (const entry of entries) if (entry.isIntersecting) highlight(entry.target.id); }, { rootMargin: '-12% 0px -82% 0px' });
  for (const panel of document.querySelectorAll('.settings-panel')) observer.observe(panel);
  function whitePatch() {
    const main = Number(q('#whiteBgMainImageN').value), sku = Number(q('#whiteBgSkuImageN').value);
    if (![main, sku].every(n => Number.isInteger(n) && n !== 0 && Math.abs(n) <= 99)) throw Error('主图和 SKU 位置必须是 -99 至 99 的非零整数。');
    const sizes = q('#targetSizes').value.split(/[,，\s]+/).filter(Boolean);
    if (!sizes.length || sizes.some(value => !/^\d{2,5}x\d{2,5}$/.test(value))) throw Error('尺寸请使用宽x高，以逗号分隔。');
    return { whiteBgSourceMethod: q('[name="whiteBgSourceMethod"]:checked').value, whiteBgMainImageN: main, whiteBgSkuImageN: sku, targetSizes: sizes, whiteBgSortBy: q('#whiteBgSortBy').value };
  }
  q('#btnSave').disabled = true;
  q('#btnSave').onclick = () => safe(async () => {
    const patch = whitePatch(); q('#btnSave').disabled = true;
    try {
      if (extension) await FullStateStore.update(KEY, latest => ({ ...(latest || {}), ...patch }));
      else localStorage.setItem(KEY, JSON.stringify({ ...await read(), ...patch }));
      const verified = await read();
      if (Object.entries(patch).some(([key, value]) => JSON.stringify(value) !== JSON.stringify(verified[key]))) throw Error('白底设置保存后回读不一致，请重试。');
      status('白底设置已保存；其他分类保持原值。');
    } finally { q('#btnSave').disabled = false; }
  });
  q('#btnClose').onclick = () => window.close();
  const publication=document.createElement('div');publication.className='opt-card';publication.style.cssText='padding:18px;margin:18px 0;border:1px solid #33463a;border-radius:10px;background:#151a17;color:#eee';
  publication.innerHTML='<h3>光合自动发布设置</h3><label for="guanghe-declaration">内容声明</label><select id="guanghe-declaration"><option value="manual">每次手动选择</option><option value="none">自动选择“内容无需标注”</option></select><p>默认自动选择内容无需标注并继续发布，无需逐台设置。已保存的手动设置和页面已有声明保留。</p><button type="button" id="save-guanghe-declaration">保存光合发布设置</button><p id="guanghe-save-status" role="status"></p>';
  q('#panel-guanghe .panel-title').after(publication);
  const publicationSelect=q('#guanghe-declaration'),publicationSave=q('#save-guanghe-declaration'),publicationStatus=q('#guanghe-save-status');publicationSave.disabled=true;
  read().then(s=>{publicationSelect.value=s.guangheDeclaration==null||s.guangheDeclaration==='none'?'none':'manual';publicationSave.disabled=false;}).catch(()=>{publicationStatus.textContent='读取失败，请刷新后重试。';});
  publicationSave.onclick=async()=>{publicationSave.disabled=true;try{const choice=publicationSelect.value;if(!['none','manual'].includes(choice))throw Error('请选择有效的内容声明设置。');if(extension)await FullStateStore.update(KEY,latest=>({...latest,guangheDeclaration:choice}));else localStorage.setItem(KEY,JSON.stringify({...await read(),guangheDeclaration:choice}));if((await read()).guangheDeclaration!==choice)throw Error('保存后回读不一致。');publicationStatus.textContent=choice==='none'?'已保存：自动选择内容无需标注，并继续发布。':'已保存：每次手动选择内容声明。';}catch(e){publicationStatus.textContent=e.message;}finally{publicationSave.disabled=false;}};

  let history = { lines: [] }, progress = { runs: [], events: [] }, selectedDay = 'all', selectedFilter = '', currentRows = [];
  const opened = new Map(), unfolded = new Set();
  const el = (tag, cls, text) => { const node = document.createElement(tag); node.className = cls; if (text != null) node.textContent = text; return node; };
  const clock = value => new Date(value).toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' });
  const phaseClass = row => row.live ? 'live' : row.res;
  const localDay = value => { const date = new Date(value); return Number.isNaN(date.getTime()) ? '' : `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; };
  const kinds = [['live', '进行中'], ['fail', '失败'], ['half', '没跑完'], ['skip', '跳过'], ['ok', '成功'], ['fill', '补漏']];
  const uniqueIds = rows => [...new Set(rows.map(row => row.pid).filter(Boolean))];
  const label = row => row.live ? row.phase === 'wait' ? '排队中' : '进行中' : ({ ok: '成功', fail: '失败', skip: '跳过', half: '没跑完' })[row.res] || '';
  function button(cls, text, action) { const node = el('button', cls, text); node.type = 'button'; node.onclick = action; return node; }
  async function copyIds(rows) {
    const ids = uniqueIds(rows);
    try { await navigator.clipboard.writeText(ids.join('\n')); q('#plMeta').textContent = `已复制 ${ids.length} 个 ID`; }
    catch { q('#plMeta').textContent = '复制失败，请手动选中复制'; }
  }
  function historyRows() {
    const times = new Map();
    for (const event of progress.events || []) {
      if (!Number.isFinite(Date.parse(event.at))) continue;
      const key = JSON.stringify([event.runId, event.pid]), existing = times.get(key);
      if (!existing) times.set(key, { first: event.at, last: event.at });
      else { if (Date.parse(event.at) < Date.parse(existing.first)) existing.first = event.at; if (Date.parse(event.at) > Date.parse(existing.last)) existing.last = event.at; }
    }
    return progress.runs.flatMap(run => run.rows.map(row => {
      const eventTime = times.get(JSON.stringify([run.id, row.pid]));
      const res = ({ done: 'ok', failed: 'fail', skip: 'skip' })[row.phase] || 'half';
      // The original infers liveness from a ten-minute timeout. Own journal has a real run state;
      // paused, stopped, unknown and boundary rows must not be relabelled as running.
      const live = ['running', 'draining'].includes(run.status) && ['wait', 'generating', 'generated', 'filling'].includes(row.phase);
      const t0 = eventTime?.first || run.startedAt;
      const t1 = eventTime?.last || row.updatedAt;
      const why = row.note || (res === 'half' ? row.phase === 'boundary' ? '已停在执行边界' : row.phase === 'unknown' ? '待确认' : run.status === 'paused' ? '已暂停' : row.label || '' : '');
      return { ...row, runId: run.id, runStart: run.startedAt, t0, t1, res, live, why,
        origin: row.origin === 'hist_fill' ? 'hist_fill' : '', pts: null };
    }));
  }
  function recentDays() { return Array.from({ length: 3 }, (_, index) => { const date = new Date(); date.setDate(date.getDate() - index); return { key: localDay(date), label: ['今天', '昨天', '前天'][index] }; }); }
  function filterRows(rows, filter = selectedFilter, search = q('#plQ').value.trim()) {
    const days = new Set(recentDays().map(day => day.key));
    return rows.filter(row => days.has(localDay(row.t0)) && (selectedDay === 'all' || localDay(row.t0) === selectedDay)
      && (!search || row.pid.includes(search)) && (!filter || (filter === 'fill' ? row.origin === 'hist_fill' : phaseClass(row) === filter)));
  }
  function summary(rows) {
    const result = { ids: uniqueIds(rows).length, n: rows.length, live: 0, fail: 0, half: 0, skip: 0, ok: 0, fill: 0 };
    for (const row of rows) { result[phaseClass(row)]++; if (row.origin === 'hist_fill') result.fill++; } return result;
  }
  function toCsv(rows) {
    const field = (value, product = false) => { let text = String(value ?? ''); if (/^[=+\-@]/.test(text)) text = "'" + text; if (product) text = '\t' + text; return product || /[,"\r\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text; };
    return ['\uFEFF时间,哪条线,商品ID,结果,说明,点数', ...rows.map(row => {
      const day = localDay(row.t1), date = day ? new Date(row.t1) : null;
      const time = date ? day + ' ' + [date.getHours(), date.getMinutes(), date.getSeconds()].map(value => String(value).padStart(2, '0')).join(':') : '';
      return [field(time), '白底图', field(row.pid, true), field(label(row)), field(row.why), ''].join(',');
    })].join('\r\n');
  }
  function renderProgress() {
    const search = q('#plQ').value.trim(), days = [{ key: 'all', label: '近 3 天' }, ...recentDays()], allRows = historyRows();
    const base = filterRows(allRows, ''), stats = summary(base); currentRows = filterRows(allRows);
    q('#plDays').replaceChildren();
    for (const day of days) { const button = document.createElement('button'); button.type = 'button'; button.className = 'pl-day' + (day.key === selectedDay ? ' on' : ''); button.textContent = day.label; button.onclick = () => { selectedDay = day.key; renderProgress(); }; q('#plDays').append(button); }
    q('#plSum').replaceChildren(el('span', 'pl-total', `${stats.ids} 个商品 · 跑了 ${stats.n} 次`));
    for (const [kind, text] of kinds) {
      if (!stats[kind] && selectedFilter !== kind) continue;
      const control = button('pl-f' + (selectedFilter === kind ? ' on' : ''), text, () => { selectedFilter = selectedFilter === kind ? '' : kind; renderProgress(); });
      control.append(el('b', '', String(stats[kind]))); q('#plSum').append(control);
    }
    q('#plSum').append(el('span', 'pl-sp'));
    if (selectedFilter || search) q('#plSum').append(button('link-btn', `复制这 ${uniqueIds(currentRows).length} 个 ID`, () => copyIds(currentRows)));
    q('#plMeta').textContent = ''; q('#plList').replaceChildren(); let dayKey = '', box;
    const order = { fail: 0, half: 1, live: 2, skip: 3, ok: 4 };
    const runs = progress.runs.map(run => ({ ...run, visibleRows: currentRows.filter(row => row.runId === run.id).sort((a, b) => order[phaseClass(a)] - order[phaseClass(b)] || Date.parse(a.t1) - Date.parse(b.t1)) })).filter(run => run.visibleRows.length).sort((a, b) => Date.parse(b.startedAt) - Date.parse(a.startedAt));
    const firstBad = runs.find(run => run.visibleRows.some(row => ['fail', 'half', 'live'].includes(phaseClass(row))));
    for (const run of runs) {
      const rows = run.visibleRows, day = localDay(run.startedAt);
      if (dayKey !== day) { dayKey = day; if (selectedDay === 'all') q('#plList').append(el('div', 'pl-dayhead', `${days.find(value => value.key === day)?.label || ''} · ${day.slice(5)}`)); box = el('div', 'pl-box'); q('#plList').append(box); }
      const open = opened.has(run.id) ? opened.get(run.id) : !!(selectedFilter || search) || run.id === firstBad?.id;
      const group = el('div', 'pa-run' + (open ? ' open' : '')), title = el('button', 'pa-head'); title.type = 'button'; title.setAttribute('aria-expanded', String(open));
      title.onclick = () => { const next = !group.classList.contains('open'); opened.set(run.id, next); group.classList.toggle('open', next); title.setAttribute('aria-expanded', String(next)); };
      title.append(el('span', 'pl-time', clock(run.startedAt)));
      const name = el('span', 'pa-name', '白底图'); name.append(el('span', 'pl-n', `${uniqueIds(rows).length} 个商品`)); title.append(name);
      const counts = el('span', 'pa-cnt'); for (const [kind, label] of [['live', '进行中'], ['fail', '失败'], ['half', '没跑完'], ['skip', '跳过'], ['ok', '成功']]) { const n = rows.filter(row => phaseClass(row) === kind).length; if (n) counts.append(el('span', 'pl-st ' + kind, `${label} ${n}`)); } title.append(counts);
      const arrow = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); arrow.setAttribute('class', 'pa-chev'); arrow.setAttribute('viewBox', '0 0 24 24');
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path'); path.setAttribute('d', 'M9 6l6 6-6 6'); arrow.append(path); title.append(arrow); group.append(title);
      const body = el('div', 'pa-rows');
      const oks = rows.filter(row => row.res === 'ok'), fold = oks.length > 5 && !unfolded.has(run.id) && selectedFilter !== 'ok' && !search;
      const visible = fold ? rows.filter(row => row.res !== 'ok') : rows;
      for (const row of visible.slice(0, 300)) {
        const line = el('div', 'pa-row'), note = el('span', 'pl-note', row.why); note.title = row.why;
        line.append(el('span', 'pl-st ' + phaseClass(row), label(row)), el('span', 'pl-id', row.pid), note, el('span', 'pl-time', clock(row.t1))); body.append(line);
      }
      if (fold) { const folded = el('div', 'pa-fold'); folded.append(el('span', 'pl-st ok', `成功 ${oks.length} 个`), button('link-btn', '展开', () => { unfolded.add(run.id); opened.set(run.id, true); renderProgress(); }), button('link-btn', '复制 ID', () => copyIds(oks))); body.append(folded); }
      if (visible.length > 300) body.append(el('div', 'pa-fold', `还有 ${visible.length - 300} 条，导出可以看全`));
      group.append(body); box.append(group);
    }
    if (!currentRows.length) { const empty = el('div', 'pl-box'); empty.append(el('div', 'pl-empty', !progress.runs.length ? '（暂无记录，跑一次任务后回来点「刷新」即可）' : search && !base.length ? '近 3 天没跑过这个 ID' : '这一段没有记录')); q('#plList').append(empty); }
  }
  async function refreshHistory() {
    history = await FullWhiteJournal.readHistory(); q('#logHistoryArea').textContent = history.lines.join('\n');
    q('#logHistoryMeta').textContent = `共 ${history.total} 行（近期 ${history.recentCount} / 归档 ${history.archiveCount}）`;
    progress = await FullWhiteJournal.readProgressHistory(); renderProgress();
  }
  function logTab(showProgress) {
    q('#plPaneLog').hidden = showProgress; q('#plPaneProg').hidden = !showProgress;
    q('#plTabLog').classList.toggle('on', !showProgress); q('#plTabProg').classList.toggle('on', showProgress);
  }
  function download(text, name, type = 'text/plain;charset=utf-8') {
    const url = URL.createObjectURL(new Blob([text], { type }));
    const link = document.createElement('a'); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  q('#plTabLog').onclick = () => logTab(false); q('#plTabProg').onclick = () => logTab(true);
  q('#logRefresh').onclick = q('#plRefresh').onclick = () => safe(refreshHistory);
  q('#plQ').oninput = renderProgress;
  q('#logCopy').onclick = () => safe(async () => { await refreshHistory(); await navigator.clipboard.writeText(history.lines.join('\n')); status('历史日志已复制。'); });
  q('#logExport').onclick = () => safe(async () => { await refreshHistory(); download(history.lines.join('\n'), '店铺素材助手-历史日志.txt'); });
  q('#plExport').onclick = () => { renderProgress(); download(toCsv(currentRows), '素材大师-进度日志.csv', 'text/csv;charset=utf-8'); };
  for (const id of ['logClear', 'plClear']) { q('#' + id).disabled = true; q('#' + id).title = '历史记录保留，当前未开放清空。'; }
  const ready = read().then(saved => {
    const settings = { ...defaults, ...saved }, method = ['ai_generate', 'image_space_size', 'detail_main_image', 'detail_sku_image'].includes(settings.whiteBgSourceMethod) ? settings.whiteBgSourceMethod : defaults.whiteBgSourceMethod;
    q(`[name="whiteBgSourceMethod"][value="${method}"]`).checked = true;
    position('whiteBgMainImagePos', 'whiteBgMainImageN', settings.whiteBgMainImageN); position('whiteBgSkuImagePos', 'whiteBgSkuImageN', settings.whiteBgSkuImageN);
    q('#targetSizes').value = settings.targetSizes.join(','); q('#whiteBgSortBy').value = Object.hasOwn(FullRunModes.SORTS, settings.whiteBgSortBy) ? settings.whiteBgSortBy : 'default';
    toggleMethodSubsections(); q('#btnSave').disabled = false;
    const manifest = extension ? chrome.runtime.getManifest() : {};
    q('#ownBuild').textContent = '店铺素材助手完整版 · ' + (manifest.version_name || (manifest.version ? 'v' + manifest.version : '本地界面'));
    if (location.hash === '#task-mode') q('#panel-taskmode').scrollIntoView({ block: 'start' });
    return refreshHistory();
  }).catch(error => { status('设置读取失败：' + error.message); throw error; });
  root.FullOptionsUi = { ready, whitePatch, toggleMethodSubsections, refreshHistory };
})(globalThis);
