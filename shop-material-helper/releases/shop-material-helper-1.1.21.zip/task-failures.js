(function(root){
 'use strict';
 const VERSION=1,FAILURES=new Set(['blocked','pending_review','submitted_unconfirmed','recovery_exhausted','budget_exhausted','boundary_blocked']);
 const CONTROL=new Set(['paused','stopped','drained','cancelled']);
 const names={white:'白底图',transparent:'透明图',scene:'场景图',search:'搜推图文',searchvideo:'搜推视频',mainvideo:'主图视频',guanghe:'光合',follow:'关注图文',trend:'趋势提报',selling:'卖点素材',incubate:'新品孵化',auto:'自动补图',f88:'F88素材',kmt:'快麦铺货',studioBatch:'批量发布',studio:'工作台发布',queue:'后台发布队列',multi:'多任务'};
 function clean(value){return String(value??'').replace(/data:[^\s]+/gi,'[已省略数据]').replace(/https?:\/\/[^\s]+/gi,'[已省略链接]').replace(/\bBearer\s+[^\s,;]+/gi,'Bearer <REDACTED>').replace(/((?:authorization|api[_ -]?key|access[_ -]?token|token|password|secret|密码|密钥|令牌)["']?\s*[:=]\s*["']?)[^\s,;"']+/gi,'$1<REDACTED>').replace(/\b(?:sk|grs)-[A-Za-z0-9_-]{12,}/g,'<REDACTED>').slice(0,4000);}
 const ids=value=>[...new Set((Array.isArray(value)?value:[value]).filter(v=>/^\d{6,20}$/.test(String(v||''))).map(String))];
 function productIds(item,run,family,index){
  if(family==='kmt')return ids(run.plan?.groups?.[index]?.itemId);
  if(family==='studioBatch')return ids(run.requests?.[index]?.productId);
  const found=ids(item?.productIds||item?.productId||item?.platformId);if(found.length)return found;
  if(family==='queue')try{const scope=JSON.parse(item.scope);return ids(scope.productIds);}catch{}
  return [];
 }
 function entries(run,family){if(family==='kmt')return run.groups||[];if(family==='f88')return run.suites||[];if(family==='queue')return run.jobs||[];if(family==='multi')return (run.entries||[]).map((e,n)=>({...e,...run.entryResults?.[n]}));if(family==='studio')return [run];return run.items||[];}
 function uncertain(item,depth=0){
  if(!item||depth>4)return false;
  if(item.taskOutcome?.needsReadback)return true;
  if(item.syncRuns?.some(child=>(child.items||[]).some(i=>uncertain(i,depth+1))))return true;
  if(item.publication&&item.receipt?.source!=='platform-readback'||item.publishIntent&&!item.receipt||item.publishAttempted&&!item.receipt||item.intent&&!['confirmed','rejected','not_submitted','prepared'].includes(item.intent.state))return true;
  if(item.generations?.some(g=>g.intent&&!['completed','failed','violation'].includes(g.status)))return true;
  if(item.generationIntent&&!item.media&&!item.images||item.submissionIntent&&item.job?.assets?.some(a=>!['completed','failed','violation'].includes(a.status)))return true;
  if(item.uploadIntent||Object.keys(item.uploadIntents||{}).length&&!item.prepared?.uploadedAssets?.length||item.videoUploadIntent&&!item.prepared?.videoContentId||item.nativeIntent&&!['completed','failed'].includes(item.nativeResult?.status))return true;
  if(item.copyIntent&&!item.copy&&!item.copyComplete||item.textIntent&&!item.optimizedTitle||item.saveIntent&&!item.savedCopy||item.syncIntent&&item.phase==='sync_query')return true;
  if(item.delivery&&uncertain(item.delivery,depth+1)||item.sync&&uncertain(item.sync,depth+1)||item.job&&uncertain(item.job,depth+1))return true;
  return ['submitted_unconfirmed','pending_confirmation','sync_blocked'].includes(item.status);
 }
 function operations(item){
  const out=[];const add=(kind,id)=>{if(typeof id==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(id)&&!out.some(v=>v.kind===kind&&v.id===id))out.push({kind,id});};
  for(const g of item.generations||[])add('generation',g.id);for(const a of item.job?.assets||[])add('generation',a.id);
  for(const key of ['publication','generationIntent','submissionIntent','intent','cutout','publishIntent','copyIntent','saveIntent','uploadIntent','syncIntent'])add(key,item[key]?.id);
  for(const [key,value]of Object.entries(item.uploadIntents||{}))add('upload',value.id||key);
  for(const key of ['textId','copyId','batchTaskId','requestId','mediaId','hostBatchId'])add(key,item[key]);
  add('content',String(item.receipt?.contentId||''));return out;
 }
 function outcome(item){return {needsReadback:uncertain(item),operations:operations(item),phase:item.phase||item.status||'',status:item.status||'',reason:clean(item.error||item.detail||'')};}
 function mark(run,item,family,index,reason,code,related,at){
  if(item.failureSkipped)return;
  const needsReadback=uncertain(item),phase=item.taskOutcome?.phase||item.phase||run.phase||'',previousStatus=item.status||'pending';
  item.failure={version:VERSION,at,code,reason,phase,previousStatus,productIds:productIds(item,run,family,index),needsReadback,related:!!related};
  item.failureSkipped=true;item.status=needsReadback?'submitted_unconfirmed':related?'skipped':'failed';item.phase='done';
  item.detail=(related?'同商品后续条目跳过：':'本条失败已跳过：')+reason+(needsReadback?'；原操作结果待确认，保留编号，不重投。':'；继续下一商品。');
  if(run.module==='white'){item.whiteConsumed=true;item.whiteTerminal=needsReadback?'unconfirmed':related?'skipped':'failed';}
 }
 function terminal(item){return !!item&&(item.failureSkipped||item.phase==='done'||['verified','skipped','generated','preview'].includes(item.status));}
 function finish(run,family){run.enabled=false;if(family==='queue'){run.done=true;run.phase='done';}run.status=family==='studioBatch'?'completed':'done';if(run.whiteWindow)run.whiteWindow.finished=true;}
 function recordTaskError(run,family,reason,code,at){run.taskFailures||=[];const last=run.taskFailures.at(-1);if(!last||last.reason!==reason||last.phase!==run.phase||last.position!==run.position)run.taskFailures.push({at,code,reason,phase:run.phase||'',position:run.position??null,module:run.module||family});}
 // Called inside each state store's serialized update, with its canonical record.
 // It never changes a consent scope, increments a budget or deletes any intent.
 function settle(run,family,previous,options={}){
  if(!run||run.parentFlowId||run.cancellation||previous?.cancellation||CONTROL.has(run.status)||previous?.enabled===false||CONTROL.has(previous?.status)||options.paused)return false;
  if(!(FAILURES.has(run.status)||family==='queue'&&!run.enabled&&run.error))return false;
  const at=new Date().toISOString(),reason=clean(run.error||run.items?.[run.position]?.detail||'执行结果未确认'),code=clean(run.trend?.error?.code||run.errorCode||'TASK_STEP_FAILED');
  const list=entries(run,family),failedIndex=run.failureItemId?list.findIndex(i=>i.id===run.failureItemId):-1,position=failedIndex>=0?failedIndex:family==='f88'?run.suitePosition||0:run.position||0;delete run.failureItemId;
  let current=list[position];
  if(family==='f88'&&run.phase==='prepare')current=null;
  if(family==='multi'){
   if(run.currentChildId){recordTaskError(run,family,reason,code,at);finish(run,family);}
   else if(current){run.entryResults||={};const result=run.entryResults[position]||={module:current.module};mark(run,result,family,position,reason,code,false,at);run.position++;run.enabled=true;run.status='running';if(run.position>=list.length)finish(run,family);}
   else {recordTaskError(run,family,reason,code,at);finish(run,family);}
  }else if(family==='trend'){
   const active=run.items?.find(i=>i.id===run.trend?.activeIntentId);
   if(active)mark(run,active,'flow',run.items.indexOf(active),reason,code,false,at);else recordTaskError(run,family,reason,code,at);
   if(typeof root.FullTrendRun?.skipFailure==='function')root.FullTrendRun.skipFailure(run,at);else finish(run,family);
  }else if(family==='f88'&&!current&&run.products?.[run.position]){
   run.failedProducts||=[];run.failedProducts.push({productIds:ids(run.products[run.position]),title:'',phase:'prepare',status:'failed',detail:reason,failure:{at,phase:'prepare',code,reason,needsReadback:false}});run.position++;run.phase='prepare';run.enabled=true;run.status='running';if(run.position>=run.products.length)finish(run,family);
  }else if(current){
   const affected=productIds(current,run,family,position);
   for(let n=position;n<list.length;n++){const candidate=list[n];if(terminal(candidate)&&!candidate.failureSkipped)continue;const same=n===position||affected.length&&productIds(candidate,run,family,n).some(id=>affected.includes(id));if(same)mark(run,candidate,family,n,reason,code,n!==position,at);}
   if(family==='f88'){while(terminal(list[run.suitePosition]))run.suitePosition++;run.position++;run.phase='prepare';run.enabled=true;run.status='running';if(run.position>=run.products.length)finish(run,family);}
   else {while(list[run.position]&&terminal(list[run.position]))run.position++;run.enabled=true;run.status='running';if(family==='queue')run.phase='ready';if(run.position>=list.length)finish(run,family);}
   if(run.whiteWindow){run.whiteWindow.active=(run.whiteWindow.active||[]).filter(n=>!run.items[n]?.failureSkipped);run.whiteWindow.failures=0;delete run.whiteWindow.refillIndex;delete run.whiteWindow.pageWindowKey;}
  }else {recordTaskError(run,family,reason,code,at);finish(run,family);}
  if(run.draining||previous?.draining){run.draining=true;run.enabled=false;run.status='drained';}
  run.error='';run.failurePolicyVersion=VERSION;run.events||=[];run.events.push({at,phase:run.phase,position:run.position,code,detail:'卡点已记录并跳过：'+reason+'；'+(run.enabled?'继续原范围的下一商品。':'本轮结束，具体结果与原操作编号已保留。')});
  updateReport(run,family);return true;
 }
 function classify(item,family){
  if(item.failureSkipped)return item.failure?.needsReadback?'pending_confirmation':item.failure?.related?'skipped':'failed';
  if(item.status==='skipped'||item.whiteTerminal==='skipped')return 'skipped';
  if(item.status==='failed'||item.whiteTerminal==='failed')return 'failed';
  if(item.status==='verified'&&(item.receipt?.source==='platform-readback'||item.delivery?.receipt?.source==='platform-readback'||item.job?.receipt?.source==='platform-readback'))return 'verified';
  if(family==='kmt'&&item.status==='verified'&&item.receipt?.status==='verified')return 'verified';
  if(family==='studio'&&item.status==='prepared')return 'preview';
  if(item.status==='generated')return 'generated';if(item.status==='preview')return 'preview';
  if(['submitted_unconfirmed','pending_confirmation','sync_blocked','needs_attention','blocked'].includes(item.status)||item.whiteTerminal==='unconfirmed')return 'pending_confirmation';
  return 'pending';
 }
 function report(run,family){
  const rows=entries(run,family).map((item,index)=>({index:index+1,itemId:clean(item.id||item.requestId||''),productIds:productIds(item,run,family,index),title:clean(item.title||run.plan?.sources?.[run.plan?.groups?.[index]?.sourceIndex]?.data?.title||''),module:clean(item.module||run.module||family),result:classify(item,family),phase:clean(item.failure?.phase||item.taskOutcome?.phase||item.phase||''),code:clean(item.failure?.code||item.skipReason||''),reason:clean(item.failure?.reason||item.detail||item.error||''),failedAt:item.failure?.at||null,needsReadback:!!item.failure?.needsReadback,operations:[...operations(item),...(item.taskOutcome?.operations||[])],channels:(item.syncRuns||[]).map(child=>({module:child.module,status:child.status,reason:clean(child.error||''),items:(child.items||[]).map(i=>({productIds:ids(i.productIds),result:classify(i),phase:clean(i.failure?.phase||i.phase),reason:clean(i.failure?.reason||i.detail||child.error||''),operations:operations(i)}))}))}));
  for(const item of run.failedProducts||[])rows.push({index:rows.length+1,itemId:'',productIds:ids(item.productIds),title:'',module:family,result:'failed',phase:item.failure.phase,code:item.failure.code,reason:clean(item.failure.reason),failedAt:item.failure.at,needsReadback:false,operations:[],channels:[]});
  const counts={total:rows.length,verified:0,generated:0,preview:0,skipped:0,failed:0,pending_confirmation:0,pending:0,taskErrors:(run.taskFailures||[]).length};for(const row of rows)counts[row.result]++;
  const ended=!run.enabled&&(run.done||['done','completed','failed'].includes(run.status));
  return {format:'material-task-results-v1',policyVersion:VERSION,taskId:clean(run.id||run.batchId||run.requestId),module:run.module||family,moduleName:names[run.module]||names[family]||'素材任务',startedAt:run.createdAt||null,endedAt:ended?(run.completionReport?.endedAt||new Date().toISOString()):null,status:run.status||run.phase,ended,outcome:ended?(counts.failed||counts.pending_confirmation||counts.pending||counts.taskErrors?'completed_with_failures':counts.skipped?'completed_with_skips':'completed'):'in_progress',generationCalls:Number.isFinite(run.usedCalls)?run.usedCalls:null,counts,taskErrors:(run.taskFailures||[]).map(e=>({...e,reason:clean(e.reason)})),rows};
 }
 function updateReport(run,family){if(!run.enabled&&(run.done||['done','completed','failed'].includes(run.status)))run.completionReport=report(run,family);return run;}
 function save(run,family,previous){
  if(family==='flow'&&run.module==='white'&&previous?.enabled!==false&&!run.cancellation&&!CONTROL.has(run.status)){
   for(let n=0;n<(run.items||[]).length;n++){const item=run.items[n];if(!item.failureSkipped&&['failed','unconfirmed'].includes(item.whiteTerminal)){
    const at=new Date().toISOString(),reason=clean(item.detail||run.error||'白底图处理失败');mark(run,item,family,n,reason,'WHITE_ITEM_FAILED',false,at);
    for(let j=n+1;j<run.items.length;j++)if(!terminal(run.items[j])&&run.items[j].productIds?.some(id=>item.productIds?.includes(id)))mark(run,run.items[j],family,j,reason,'WHITE_ITEM_FAILED',true,at);
   }}
  }
  settle(run,family,previous);
  if(run.enabled&&['flow','auto','kmt','queue','studioBatch'].includes(family)){
   const list=entries(run,family);while(list[run.position]?.failureSkipped)run.position++;
   if(list.length&&run.position>=list.length&&!(run.module==='white'&&run.whitePaging&&!run.whitePaging.exhausted))finish(run,family);
  }
  updateReport(run,family);return run;
 }
 const api={VERSION,names,clean,productIds,entries,uncertain,operations,outcome,settle,report,updateReport,save};root.FullTaskFailures=api;if(typeof module==='object')module.exports=api;
})(globalThis);
