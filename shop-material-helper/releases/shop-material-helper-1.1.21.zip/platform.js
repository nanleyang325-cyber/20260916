(function(root) {
 'use strict';
 function readCreatorDeclaration(required=false){const labels=[...document.querySelectorAll('label')].filter(l=>l.getClientRects().length>0&&/^(?:含AI生成内容|内容无需(?:标注|注明)|含虚构演绎内容|含个人观点|含医疗建议|含金融投资建议)$/.test(l.textContent.trim()));const chosen=labels.filter(l=>l.querySelector('input:checked')||l.getAttribute('aria-checked')==='true');if(chosen.length>1)throw Error('内容声明不唯一，请本人核对。');if((required||labels.some(l=>l.closest('[aria-required="true"],.next-form-item-required,.ant-form-item-required')||l.querySelector('input[required]')))&&!chosen.length)throw Error('平台要求内容声明，请本人选择后继续；插件不自动勾选，素材保留。');return chosen.length?chosen[0].textContent.trim():null;}
 const visible = element => !!element && element.getClientRects().length>0 && getComputedStyle(element).visibility!=='hidden';
 const buttons = scope => [...scope.querySelectorAll('button,[role="button"],a')].filter(visible);
 const findButton = (scope, names) => buttons(scope).find(el=>names.includes(el.textContent.trim()) && !el.disabled && el.getAttribute('aria-disabled')!=='true');
 function productIds(scope) {
  const ids=new Set();for(const item of scope.querySelectorAll('[class*="item-v2--list-item"][data-id]')){const id=item.getAttribute('data-id');if(/^\d{6,}$/.test(id))ids.add(id);}
  if(scope===document.body&&/\/wow\/z\/guang\/publish-feeds\/(?:imagePreview|videoPreview)/.test(location.pathname)){
   try{let raw=new URL(location.href).searchParams.get('content_data'),data;for(let n=0;n<3;n++){try{data=JSON.parse(raw);break;}catch{raw=decodeURIComponent(raw);}}if(Array.isArray(data?.items))for(const item of data.items)if(/^\d{6,20}$/.test(String(item.itemId||'')))ids.add(String(item.itemId));}catch{}
  }
  const own=scope.getAttribute?.('data-item-id')||scope.getAttribute?.('data-product-id')||scope.getAttribute?.('data-full-product-id');if(/^\d{6,}$/.test(own||''))ids.add(own);
  for (const el of scope.querySelectorAll('[data-item-id],[data-product-id],[data-full-product-id],a[href]')) {
   const direct=el.getAttribute('data-item-id')||el.getAttribute('data-product-id')||el.getAttribute('data-full-product-id'); if (/^\d{6,}$/.test(direct||'')) ids.add(direct);
   if (el.tagName==='A') { try { const url=new URL(el.href,location.href); if (/(^|\.)taobao\.com$|(^|\.)tmall\.com$/.test(url.hostname) && /^\d{6,}$/.test(url.searchParams.get('id')||'')) ids.add(url.searchParams.get('id')); }catch{} }
  }
  for (const match of (scope.innerText||'').matchAll(/(?:商品\s*ID|宝贝\s*ID)\s*[:：]?\s*(\d{6,})/gi)) ids.add(match[1]);
  for(const el of scope.querySelectorAll('span,div')){if(el.closest('[data-next-table-col="2"],[data-next-table-col="3"],[class*="MaterialCell_materialCell"],[data-content-id],[data-full-content-id]'))continue;const match=el.textContent.trim().match(/^ID\s*[:：]?\s*(\d{6,})$/i);if(match)ids.add(match[1]);}
  return [...ids];
 }
 function rowFor(id) {
  const rows=[...document.querySelectorAll('tr,[role="row"],[data-item-id],[data-product-id],.next-table-row')].filter(visible).filter(row=>productIds(row).join(',')===id);
  return rows.sort((a,b)=>a.innerText.length-b.innerText.length)[0] || null;
 }
 function formScope() { if(/\/wow\/z\/guang\/publish-feeds\/(?:imagePreview|videoPreview)/.test(location.pathname))return document.body;return [...document.querySelectorAll('.next-dialog,.next-drawer[aria-hidden="false"],form')].filter(visible).at(-1)||document.body; }
 function sameIds(actual, expected) { return [...new Set(actual)].sort().join(',') === [...new Set(expected)].sort().join(','); }
 function searchSlot(job){
   if(!['search','searchvideo'].includes(job.module))throw new Error('仅搜推任务使用单品素材槽。');
   const existing=[...document.querySelectorAll('iframe')].filter(visible).filter(e=>{try{return /^\/wow\/z\/guang\/publish-feeds\/(?:imagePreview|videoPreview)$/.test(new URL(e.src,location.href).pathname);}catch{return false;}});
   if(existing.length){if(existing.length!==1)throw Error('已打开的搜推表单不唯一。');const u=new URL(existing[0].src,location.href),expected=job.module==='searchvideo'?'videoPreview':'imagePreview';if(u.protocol!=='https:'||!['huodong.taobao.com','pre-wormhole.wapa.taobao.com'].includes(u.hostname)||!u.pathname.endsWith('/'+expected))throw Error('已打开表单的媒体类型或来源不符，未混用图文与视频。');let raw=u.searchParams.get('content_data'),data;for(let n=0;n<3;n++){try{data=JSON.parse(raw);break;}catch{try{raw=decodeURIComponent(raw);}catch{break;}}}const ids=(data?.items||[]).map(i=>String(i.itemId||''));if(!sameIds(ids,job.productIds))throw Error('已打开表单属于其他商品，未接管。');return {status:'prepared',message:'复用同商品的原搜推表单。'};}
   const row=rowFor(job.productIds[0]);if(!row)throw new Error('当前列表未唯一定位目标商品。');
   const column=row.querySelector('[data-next-table-col="3"]');
   const empty=[...column?.querySelectorAll('[class*="MaterialCell_materialCell"]')||[]].filter(visible).find(box=>box.querySelector('[class*="PublishButton_publish"]')&&!/(?:素材\s*)?ID\s*[:：]?\s*\d{6,}/.test(box.innerText));
   const opener=empty?.querySelector('[class*="PublishButton_publish"]');if(!opener)return {status:'ineligible',message:'没有明确空单品素材槽，未替换已有内容。'};
   return {status:'ready',opener};
 }
 async function videoFormProof(job){
  const u=new URL(location.href);if(job.module!=='searchvideo'||u.protocol!=='https:'||!['huodong.taobao.com','pre-wormhole.wapa.taobao.com'].includes(u.hostname)||u.pathname!=='/wow/z/guang/publish-feeds/videoPreview')throw Error('搜推视频必须使用官方视频表单，未提交。');
  if(job.productIds?.length!==1||!sameIds(productIds(document.body),job.productIds))throw Error('视频表单商品身份不一致，未提交。');
  if(job.directVideoFile){if(!root.FullFlowVideo)throw Error('原视频文件校验组件未加载。');const proof=await root.FullFlowVideo.proveDirect(job.directVideoFile);if(!proof.found||proof.fileId!==job.directVideoFile.fileId)throw Error('原视频文件已变化，未提交。');root.FullFlowVideo.declareDirect();const confirms=[...document.querySelectorAll('button')].filter(e=>visible(e)&&!e.disabled&&e.innerText.trim()==='确认');if(confirms.length!==1)throw Error('视频确认按钮未唯一就绪。');return {status:'prepared',productIds:[...job.productIds],videoFileIdentityVerified:true,directVideoFile:proof};}
  const expected=String(job.videoContentId||'');if(!/^\d{6,}$/.test(expected))throw Error('本批视频内容ID未确认。');
  const ids=new Set(),add=v=>{if(/^\d{6,}$/.test(String(v)))ids.add(String(v));};
  for(const el of document.querySelectorAll('[data-video-content-id],[data-video-id],input[name="videoContentId"],input[name="videoId"]')){if(el.tagName!=='INPUT'&&!visible(el))continue;add(el.getAttribute('data-video-content-id'));add(el.getAttribute('data-video-id'));if(el.tagName==='INPUT')add(el.value);}
  const seen=new Set();let scanned=0;function scan(value,depth=0,video=false){if(!value||typeof value!=='object'||depth>6||seen.has(value)||++scanned>1500)return;seen.add(value);for(const [key,v]of Object.entries(value)){if(['videoContentId','videoId'].includes(key)||video&&key==='contentId')add(v);else if(!['children','_owner','ref','stateNode'].includes(key)&&v&&typeof v==='object')scan(v,depth+1,video||/^(?:video|videoInfo|videoData|selectedVideo|selectedVideos|uploadedVideo)$/.test(key));}}
  for(const el of [...document.querySelectorAll('video,[class*="Video"],[class*="video"]')].filter(visible).slice(0,120)){const key=Object.keys(el).find(k=>k.startsWith('__reactFiber$'));if(key){let fiber=el[key];for(let n=0;n<6&&fiber;n++,fiber=fiber.return)scan(fiber.memoizedProps);}}
  if(ids.size!==1||!ids.has(expected))throw Error('视频表单未唯一读回本批视频ID；保留已生成及上传记录，不重复提交。');
  return {status:'prepared',productIds:[...job.productIds],videoContentId:expected,videoIdentityVerified:true};
 }
 function searchOption(job){const label=job.module==='searchvideo'?'发视频':'发图文';const matches=[...new Set([...document.querySelectorAll('[class*="PublishButton_option"],[class*="PublishButtonWidthIcon_option"],.next-balloon-content div')].filter(visible).filter(el=>{const r=el.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2;if(x<0||y<0||x>=innerWidth||y>=innerHeight)return false;const hit=document.elementFromPoint(x,y);return hit===el||el.contains(hit);}).filter(el=>el.textContent.trim()===label).map(el=>el.closest('[class*="PublishButton_option"],[class*="PublishButtonWidthIcon_option"]')||el))];return matches.length===1?matches[0]:null;}
 async function waitFor(read,description){for(let n=0;n<40;n++){const value=read();if(value)return value;await new Promise(resolve=>setTimeout(resolve,250));}throw new Error(description+'未就绪，请检查当前平台页面。');}
 function bound(scope, job) { if (!sameIds(productIds(scope),job.productIds)) throw new Error('当前表单关联商品与任务不一致，请先精确绑定任务商品。'); }
 function setValue(el,value) {
  if (!el) throw new Error('平台字段未识别，请检查当前页面。');
  if (el.maxLength>0 && value.length>el.maxLength) throw new Error(`内容超出平台${el.maxLength}字限制，请修改后再填。`);
  if (el.isContentEditable) { el.textContent=value; el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value})); }
  else { const descriptor=Object.getOwnPropertyDescriptor(el instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,'value'); descriptor.set.call(el,value); el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); }
  el.dispatchEvent(new FocusEvent('blur',{bubbles:true})); if ((el.value??el.textContent)!==value) throw new Error('平台字段读回不一致。');
 }
 function inspect(job) {
  const scope=formScope(), row=job.productIds.length===1?rowFor(job.productIds[0]):null;
  const text=row?.innerText||'';
  return { url:location.origin+location.pathname, productIds:productIds(scope), targetFound:!!row, targetText:text.slice(0,1200), fileInputs:document.querySelectorAll('input[type="file"]').length, declarations:[...scope.querySelectorAll('label')].filter(visible).filter(el=>/AI|人工智能|合成|内容无需标注/i.test(el.textContent)).map(el=>({text:el.textContent.trim().slice(0,100),checked:!!el.querySelector('input:checked')})),buttons:buttons(scope).map(b=>b.textContent.trim()).filter(Boolean).slice(0,50), eligible:job.module==='incubate'?!!(row&&findButton(row,['去报名','重新报名'])):job.module==='selling'?!!(row&&findButton(row,['一键提交'])):job.module==='trend'?!!row&&!/撤销提报|审核中|已提报/.test(text):null };
 }
 async function execute(action, job, assets=[]) {
  if (!Array.isArray(job.productIds)||job.productIds.some(id=>!/^\d{6,}$/.test(id))) throw new Error('任务商品ID无效。');
  const scope=formScope();
  if (action==='inspect') return inspect(job);
  if(action==='open-upload'){
   const existing=[...document.querySelectorAll('.next-dialog')].filter(visible).filter(e=>/上传结果/.test(e.innerText)&&e.querySelector('input[type="file"]:not([disabled])'));
   if(/material-center\/mine-material\/sucai-tu/.test(location.href)&&existing.length===1)return {status:'prepared',message:'复用图片空间已打开的上传面板。'};
   const opener=findButton(scope,['上传文件','本地上传','上传图片','上传视频']);if(!opener)throw new Error('当前页没有唯一可识别的上传入口。');opener.click();await waitFor(()=>document.querySelector('input[type="file"]:not([disabled])'),'上传控件');return {status:'prepared',message:'上传控件已打开，可上传本批已生成素材。'};
  }
  if(action==='verify-video')return videoFormProof(job);
  if(action==='bind-products'){
   if(!['guanghe','follow','search','searchvideo'].includes(job.module))throw new Error('此模块不使用图文商品挂载表单。');
   if(sameIds(productIds(scope),job.productIds))return {status:'prepared',message:'表单已关联并精确核对任务商品。'};
   let opener=findButton(scope,['添加宝贝','添加商品','关联商品','添加']);
   if(!opener)opener=[...scope.querySelectorAll('[class*="items-trigger"]')].find(visible);
   if(!opener)throw new Error('未找到商品关联入口。');opener.click();
   let picker=await waitFor(()=>[...document.querySelectorAll('.next-dialog,.next-drawer,.next-overlay-wrapper')].filter(visible).find(el=>/商品ID|商品关键词|本店商品|按商品ID/.test(el.innerText)),'商品选择器');
   const shop=findButton(picker,['本店商品','按商品ID']);if(shop)shop.click();
   for(const id of job.productIds){
    const active=[...picker.querySelectorAll('.next-tabs-tabpane.active,[role="tabpanel"]')].find(visible)||picker;
    const input=[...active.querySelectorAll('input[placeholder]')].find(el=>visible(el)&&/商品关键词|商品ID/.test(el.placeholder));if(!input)throw new Error('未识别当前商品搜索字段。');
    setValue(input,id);const search=findButton(active,['搜索','查询']);if(!search)throw new Error('未找到商品选择器搜索按钮。');search.click();
    const link=await waitFor(()=>[...active.querySelectorAll('a[href]')].find(el=>{try{return visible(el)&&new URL(el.href).searchParams.get('id')===id;}catch{return false;}}),'指定商品搜索结果');
    let card=link;while(card.parentElement&&card!==active&&!card.querySelector('input[type="checkbox"],input[type="radio"],button'))card=card.parentElement;
    if(!sameIds(productIds(card),[id]))throw new Error('商品选择卡片身份不唯一。');
    const checkbox=card.querySelector('input[type="checkbox"],input[type="radio"]');if(checkbox){if(checkbox.disabled)throw new Error('当前商品不可选。');if(!checkbox.checked)checkbox.click();}else {const choose=findButton(card,['选择','添加']);if(!choose)throw new Error('未识别商品选择控件。');choose.click();}
   }
   const done=findButton(picker,['确定','确认','完成']);if(!done)throw new Error('未找到商品关联确认按钮。');done.click();
   await waitFor(()=>sameIds(productIds(formScope()),job.productIds),'商品关联结果');return {status:'prepared',message:'已关联并核对任务商品集合。'};
  }
  if(action==='search-slot'){
   const state=searchSlot(job);if(state.status!=='ready')return state;const opener=state.opener;
   opener.scrollIntoView({block:'center'});const hover=opener.querySelector('[class*="uploadIcon"]')||opener,rect=hover.getBoundingClientRect(),eventOptions={bubbles:true,cancelable:true,clientX:rect.x+rect.width/2,clientY:rect.y+rect.height/2,view:window};
   for(const name of ['pointerover','pointerenter','mouseover','mouseenter','mousemove'])hover.dispatchEvent(name.startsWith('pointer')?new PointerEvent(name,eventOptions):new MouseEvent(name,eventOptions));
   const label=job.module==='searchvideo'?'发视频':'发图文';
   const option=await waitFor(()=>{const matches=[...new Set([...document.querySelectorAll('[class*="PublishButton_option"],[class*="PublishButtonWidthIcon_option"],.next-balloon-content div')].filter(visible).filter(el=>el.textContent.trim()===label).map(el=>el.closest('[class*="PublishButton_option"],[class*="PublishButtonWidthIcon_option"]')||el))];return matches.length===1?matches[0]:null;},label+'菜单');
   option.click();return {status:'prepared',message:'已从指定商品的明确空槽打开表单，请检查表单商品归属。'};
  }
  if(action==='open-picture-picker'){
   bound(scope,job);const button=findButton(scope,['上传图片']);if(!button)throw new Error('当前商品表单没有上传图片入口。');button.click();return {status:'prepared',message:'已打开官方图片选择器，请检查选择器所在页面。'};
  }
  if(action==='select-pictures'){
   if(!/\/app\/crs-qn\/sucai-selector-ng/.test(location.pathname))throw new Error('当前页面不是官方图片选择器。');
   const files=job.uploadedAssets;if(!Array.isArray(files)||!files.length||files.some(a=>!/^material-[a-f0-9-]+(?:-scene-800)?\.png$/.test(a.name)))throw new Error('缺少本批唯一上传文件记录。');
   const unique=new Set(files.map(a=>a.name));if(unique.size!==files.length)throw new Error('本批文件名重复。');
   const confirmation=()=>buttons(document).find(el=>/^确定\s*[（(]\s*\d+\s*[)）]$/.test(el.textContent.trim()));
   const count=()=>Number(confirmation()?.textContent.match(/\d+/)?.[0]??-1);
   if(count()>0)throw new Error('选择器已有其他选中图片，请先清空再选择本批。');
   const grid=document.querySelector('div[class*="gridWrap"] span[class*="new_grid"]');if(grid&&visible(grid))grid.click();
   for(let index=0;index<files.length;index++){
    const file=files[index];const input=[...document.querySelectorAll('.next-search-input input,input[placeholder]')].find(el=>visible(el)&&/搜索图片|图片名称/.test(el.placeholder));if(!input)throw new Error('未识别图片名称搜索框。');
    setValue(input,file.name);await new Promise(resolve=>setTimeout(resolve,250));input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
    const icon=input.closest('.next-search,[class*="search"]')?.querySelector('.next-icon-search');if(icon)icon.click();
    const card=await waitFor(()=>{
     const candidates=[];for(const leaf of document.querySelectorAll('[title],span,p,div')){
      if(!visible(leaf)||![leaf.getAttribute('title'),leaf.textContent.trim()].includes(file.name))continue;
      let box=leaf;for(let n=0;n<4&&box;n++,box=box.parentElement){const imgs=box.querySelectorAll('img');if(imgs.length>1)break;if(imgs.length===1&&box.querySelector('input[type="checkbox"]')){candidates.push(box);break;}}
     }
     const distinct=[...new Set(candidates)];return distinct.length===1?distinct[0]:null;
    },'唯一图片文件名');
    const checkbox=card.querySelector('input[type="checkbox"]');if(checkbox.disabled)throw new Error('本批图片不可选。');if(!checkbox.checked)checkbox.click();
    await waitFor(()=>checkbox.checked&&count()===index+1,'图片选择计数');
   }
   const done=confirmation();if(!done||count()!==files.length)throw new Error('图片选择计数不符，未确认。');done.click();return {status:'prepared',message:'已精确选择本批文件；回到商品表单核对图片地址和数量。'};
  }
  if(action==='verify-pictures'){
   bound(scope,job);const files=job.uploadedAssets||[],cards=[...scope.querySelectorAll('.content-picture-uploader-wrapper .picture-list-item')].filter(visible);
   if(!files.length||cards.length!==files.length)throw new Error('表单图片数量与本批不符。');
   const remaining=[...files];for(const card of cards){const src=card.querySelector('img')?.src||'';const matches=remaining.filter(file=>src===file.url||src.startsWith(file.url+'_')||src.startsWith(file.url+'?'));if(matches.length!==1)throw new Error('表单图片地址未唯一匹配本批上传记录。');remaining.splice(remaining.indexOf(matches[0]),1);}
   return {status:'prepared',message:'表单图片数量和来源已精确核对。'};
  }
  if(action==='video-slot'){
   if(job.module!=='mainvideo')throw new Error('仅主图视频使用商品视频槽。');const row=rowFor(job.productIds[0]);if(!row)throw new Error('未找到任务商品。');
   const column=row.querySelector('[data-next-table-col="2"]');const opener=column?.querySelector('.material-image-item-placeholder-container,img,[class*="ImageItem_mask"]');if(!opener)throw new Error('未识别视频详情入口。');opener.click();
   const drawer=await waitFor(()=>[...document.querySelectorAll('.next-drawer')].filter(visible).find(el=>/素材详情/.test(el.innerText)&&el.querySelector('[class*="VideoMaterial_videoList"]')),'视频详情');
   const empty=drawer.querySelector('[class*="VideoMaterial_addVideoItem"]');if(!empty)return {status:'ineligible',message:'没有明确空视频槽，未替换现有视频。'};empty.click();return {status:'prepared',message:'已打开明确空视频槽；请选择本批上传的视频并核对内容ID。'};
  }
  if(action==='select-video'){
   if(!/^\d{6,}$/.test(job.videoContentId||''))throw new Error('请填本批上传后平台返回的视频内容ID。');
   const cards=[...document.querySelectorAll('[data-content-id],[data-video-id],.video-item,[class*="videoCard"],[class*="video-card"]')].filter(visible).filter(card=>card.getAttribute('data-content-id')===job.videoContentId||card.getAttribute('data-video-id')===job.videoContentId||new RegExp('(?:内容|视频)\\s*ID\\s*[:：]?\\s*'+job.videoContentId+'(?!\\d)').test(card.innerText));
   if(cards.length!==1)throw new Error('平台视频卡片ID未唯一匹配，不能猜选其他视频。');
   const select=cards[0].querySelector('input[type="checkbox"],input[type="radio"]');if(!select||select.disabled)throw new Error('未识别视频选择控件。');if(!select.checked)select.click();
   const checked=[...scope.querySelectorAll('input[type="checkbox"]:checked,input[type="radio"]:checked')];if(checked.length!==1||!cards[0].contains(checked[0]))throw new Error('视频选择范围不符。');const confirm=findButton(scope,['确定','确认']);if(!confirm)throw new Error('未识别视频选择确认。');confirm.click();return {status:'prepared',message:'已选择指定平台视频，回到目标商品抽屉检查后发布。'};
  }
  if(action==='submit-video'){
   if(job.module!=='mainvideo'||!job.publicationConsent||!/^\d{6,}$/.test(job.videoContentId||''))throw new Error('视频绑定商品与内容ID尚未确认。');
   if(!rowFor(job.productIds[0]))throw new Error('没有定位到目标商品。');const drawer=[...document.querySelectorAll('.next-drawer')].filter(visible).find(el=>el.querySelector('[class*="VideoMaterial_videoList"]'));if(!drawer)throw new Error('未打开商品视频详情。');
   const list=drawer.querySelector('[class*="VideoMaterial_videoList"]');
   const boundVideo=[...list.querySelectorAll('[data-content-id],[data-video-id],[data-full-content-id]')].some(el=>el.getAttribute('data-content-id')===job.videoContentId||el.getAttribute('data-video-id')===job.videoContentId||el.getAttribute('data-full-content-id')===job.videoContentId);
   if(!boundVideo)throw new Error('槽位未能核对指定视频内容ID，需继续适配，不能仅凭封面保存。');
   const publish=findButton(drawer,['发布']);if(!publish)throw new Error('视频发布入口未识别。');publish.click();return {status:'submitted_unconfirmed',message:'已提交商品视频绑定，需重新搜索同一商品回查内容ID与审核状态。'};
  }
  if (action==='open-row') {
   const expected={selling:/\/new-product-operation\/home\/MaterialTending/,incubate:/\/new-product-operation\/home/,trend:/\/trend-product-operation\/home/}[job.module];if(expected&&!expected.test(location.pathname))throw new Error('当前页面不是该运营模块，未点击商品入口。');
   const row=rowFor(job.productIds[0]); if (!row) throw new Error('当前页未找到指定商品，先在后台搜索该ID。');
   if(['selling','trend'].includes(job.module))return {status:'prepared',message:'已定位指定商品。提报/一键提交属于真实写入，请审看后使用确认平台提交。'};
   const names=job.module==='selling'?['一键提交']:job.module==='incubate'?['去报名','重新报名']:job.module==='trend'?['提报']:['添加素材','上传','添加','+'];
   const button=findButton(row,names); if (!button) return {status:'ineligible',message:'此商品未找到对应入口或当前不具备资格。'};
   button.click(); return {status:'prepared',message:'已打开指定商品入口，需核对当前表单关联。'};
  }
  if (action==='clone-link') {
   const row=rowFor(job.productIds[0]); if (!row) throw new Error('未找到源商品。');
   const link=[...row.querySelectorAll('a[href]')].find(a=>/copyItem/i.test(a.href));
   if (!link) throw new Error('请先在该商品“更多”菜单打开“发布相似品”，不能自拼克隆链接。');
   return {status:'prepared',cloneUrl:link.href};
  }
  if (action==='fill') {
   if (job.module==='selling') { const row=rowFor(job.productIds[0]);if (!row) throw new Error('没有定位到任务商品。'); setValue(row.querySelector('input#shortPoint,input[placeholder="请输入短卖点"]'),job.shortPoint||''); setValue(row.querySelector('input#longPoint,input[placeholder="请输入长卖点"]'),job.longPoint||''); }
   else if (job.module==='incubate') {
    bound(scope,job);if(!/^\d{4}-\d{2}-\d{2}$/.test(job.startDate||'')||new Date(job.startDate+'T00:00:00Z').toISOString().slice(0,10)!==job.startDate)throw new Error('请填写合法且明确的期望扶持日期。');
    if(!/期望流量扶持时间/.test(scope.innerText))throw new Error('当前模态不是有日期的报名表单。');
    const input=[...scope.querySelectorAll('input[placeholder]')].filter(visible).find(el=>/选择日期|开始日期|开始时间/.test(el.placeholder));if(!input)throw new Error('报名日期框未识别。');
    if(input.type==='date')setValue(input,job.startDate);else if(input.value!==job.startDate){
     input.click();const calendar=await waitFor(()=>[...document.querySelectorAll('.next-date-picker-panel,.next-calendar2,[class*="picker-dropdown"]')].filter(visible).find(el=>el.querySelector(`[title="${job.startDate}"]`)),'所选日期所在日历（必要时先切换月份）');
     const cells=[...calendar.querySelectorAll(`[title="${job.startDate}"]`)].filter(visible).filter(el=>!/(?:disabled|prev-month|next-month|other-month|last-month|append)/i.test(el.className)&&el.getAttribute('aria-disabled')!=='true');if(cells.length!==1)throw new Error('日期不唯一、不可用或为其他月份占位。');cells[0].click();
    }
    await waitFor(()=>input.value===job.startDate,'日期字段精确读回');return {status:'prepared',dateSelected:job.startDate,message:'报名日期已通过日历选择并精确读回。'};
   }
   else {
    bound(scope,job);
    const title=[...scope.querySelectorAll('input[name="shortTitle"],input[placeholder*="加个标题"],input[placeholder*="标题"],input[maxlength="20"]')].find(visible);
    const body=[...scope.querySelectorAll('textarea[name="description"],textarea,.rich-text-content[data-cangjie-content="true"]')].find(visible);
    setValue(title,job.title); setValue(body,job.body);
   }
   if(['guanghe','follow'].includes(job.module))readCreatorDeclaration(job.module==='guanghe');return {status:'prepared',message:'内容已填入并读回，声明保持本人选择。'};
  }
  if (action==='upload') {
   if (!assets.length) throw new Error('没有可上传的素材。');
   const inSpace=/material-center\/mine-material\/sucai-tu/.test(location.href);
   if (!inSpace) bound(scope,job);
   const spaceInputs=inSpace?[...document.querySelectorAll('.moxie-shim input[type="file"]')].filter(el=>!el.disabled):[];
   const inputs=spaceInputs.length?spaceInputs:[...document.querySelectorAll('input[type="file"]')].filter(el=>!el.disabled);
   if (inputs.length!==1) throw new Error('上传入口不唯一或未打开，请先打开图片/视频上传对话框。');
   const input=inputs[0]; if (assets.length>1&&!input.multiple) throw new Error('当前平台只支持单文件，请逐张上传。');
   const data=new DataTransfer();
   for (const asset of assets) { const match=/^data:(image\/(?:png|jpeg|webp)|video\/mp4);base64,([A-Za-z0-9+/=]+)$/.exec(asset.data||''); if (!match) throw new Error('上传素材格式无效。'); const bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0)); data.items.add(new File([bytes],asset.name,{type:match[1]})); }
   input.files=data.files; input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true}));
   return {status:'prepared',message:'文件已交给平台上传控件；上传结果尚待图片空间或表单回查。',fileNames:assets.map(a=>a.name)};
  }
  if (action==='submit') {
   if(job.module==='searchvideo')await videoFormProof(job);
   if (!job.publicationConsent) throw new Error('未确认这次平台提交。');
   if (['white','transparent','scene','mainvideo','fission'].includes(job.module)) throw new Error('此入口需完成字段绑定与差异核对后提交，当前适配尚未完成。');
   let target=scope;
   if (job.module==='selling') {target=rowFor(job.productIds[0]);if(!target)throw new Error('目标商品已经不在页面，请先回查。');const short=target.querySelector('input#shortPoint,input[placeholder="请输入短卖点"]'),long=target.querySelector('input#longPoint,input[placeholder="请输入长卖点"]');if(!short||!long||short.value!==(job.shortPoint||'')||long.value!==(job.longPoint||''))throw new Error('指定商品的卖点字段未精确读回，未提交。');}
   else if(job.module==='incubate'){bound(scope,job);const input=[...scope.querySelectorAll('input[placeholder]')].filter(visible).find(el=>/选择日期|开始日期|开始时间/.test(el.placeholder));if(job.dateSelected!==job.startDate||!input||input.value!==job.startDate)throw new Error('报名日期未精确确认，未提交。');}
   else if (job.module==='trend') {
    const row=rowFor(job.productIds[0]); if (!row||/撤销提报|审核中|已提报/.test(row.innerText)) throw new Error('商品已提报或未找到，先回查。');
    const checkbox=row.querySelector('input[type="checkbox"]'); if (!checkbox||checkbox.disabled) throw new Error('商品未具备提报资格。');
    if (!checkbox.checked) checkbox.click();
    const checked=[...scope.querySelectorAll('input[type="checkbox"]:checked')].filter(el=>el.closest('tr,[role="row"]'));
    if (checked.length!==1||!row.contains(checked[0])) throw new Error('存在其他选中商品，请清空后再提报。');
   } else bound(scope,job);
   if(job.module==='guanghe'){
    const selected=[...scope.querySelectorAll('label.next-radio-wrapper')].filter(visible).filter(el=>el.querySelector('input[type="radio"]:checked')).map(el=>el.textContent.trim());
     readCreatorDeclaration(true);
   }
   const names=job.module==='incubate'?['确认报名']:job.module==='trend'?['确认提报','确定提报','提报']:job.module==='follow'?['发布内容']:job.module==='guanghe'?['立即发布']:job.module==='selling'?['一键提交','提交','保存','确认']:['确定','确认','提交','发布'];
   const matches=buttons(target).filter(el=>names.includes(el.textContent.trim())&&!el.disabled);
   if(matches.length!==1) throw new Error('提交按钮不唯一或未识别，请核对当前平台表单。');
   matches[0].click(); return {status:'submitted_unconfirmed',documentTimeOrigin:performance.timeOrigin,message:'已单次提交；需后台回查，不能自动重复发布。'};
  }
  if(action==='verify') {
   if(!job.publication) throw new Error('任务没有提交记录，不能把既有平台内容当作本次发布结果。');
   if(['selling','incubate'].includes(job.module)){
    if(!job.publication.documentTimeOrigin||job.publication.documentTimeOrigin===performance.timeOrigin)return {status:'submitted_unconfirmed',message:'请重新打开或刷新目标商品列表，不能将未刷新表单作为保存回读。'};
    const row=rowFor(job.productIds[0]);if(!row)return {status:'submitted_unconfirmed',message:'同ID列表记录未找到，不能把列表消失当成功。'};
    if(job.module==='selling'){
     const short=row.querySelector('input#shortPoint,input[placeholder="请输入短卖点"]'),long=row.querySelector('input#longPoint,input[placeholder="请输入长卖点"]'),status=row.innerText.match(/审核通过|审核中|待审核|已维护/)?.[0];
     if(short&&long&&short.value===(job.shortPoint||'')&&long.value===(job.longPoint||'')&&status)return {status:'verified',receipt:{source:'platform-readback',contentId:'selling:'+job.productIds[0],productIds:job.productIds,status,shortPoint:short.value,longPoint:long.value,url:location.origin+location.pathname}};
    }else{const status=row.innerText.match(/报名成功|已报名|审核中|扶持中|孵化中/)?.[0];if(status&&row.innerText.includes(job.startDate))return {status:'verified',receipt:{source:'platform-readback',contentId:'incubate:'+job.productIds[0],productIds:job.productIds,status,startDate:job.startDate,url:location.origin+location.pathname}};}
    return {status:'submitted_unconfirmed',message:'后台字段内容、日期或审核状态未完整读回。'};
   }
   if(job.module==='mainvideo'){
    const drawer=[...document.querySelectorAll('.next-drawer[data-full-product-id]')].filter(visible).find(el=>el.getAttribute('data-full-product-id')===job.productIds[0]);
    const card=drawer?.querySelector(`[data-full-content-id="${job.videoContentId}"]`);const status=card?.innerText.match(/审核通过|审核中/)?.[0];if(card&&status)return {status:'verified',receipt:{source:'platform-readback',contentId:job.videoContentId,productIds:job.productIds,status,url:location.origin+location.pathname}};
    return {status:'submitted_unconfirmed',message:'视频槽内容ID与商品身份尚未完整回查。'};
   }
   if(job.module!=='trend'&&!job.expectedContentId)throw new Error('请填写本次提交产生的后台素材或内容ID，再回查精确匹配记录。');
   const row=rowFor(job.productIds[0]);
   if(job.module==='trend'&&row&&/撤销提报|审核中|已提报/.test(row.innerText)) return {status:'verified',receipt:{source:'platform-readback',contentId:'trend:'+job.productIds[0],productIds:job.productIds,status:'已提报',url:location.origin+location.pathname}};
   const containers=[...document.querySelectorAll('tr,[data-material-id],[data-content-id],.next-table-row')].filter(visible);
   for(const card of containers) {
    if(!sameIds(productIds(card),job.productIds)) continue;
    const id=card.getAttribute('data-material-id')||card.getAttribute('data-content-id')||card.innerText.match(/(?:素材|作品|内容)\s*ID\s*[:：]\s*(\d{6,})/)?.[1];
    const status=card.innerText.match(/审核通过|审核中|已发布|精选|已报名|已提报/)?.[0];
    if(id&&status&&(!job.expectedContentId||job.expectedContentId===id)) return {status:'verified',receipt:{source:'platform-readback',contentId:id,productIds:productIds(card),status,url:location.origin+location.pathname}};
   }
   return {status:'submitted_unconfirmed',message:'未取得可核验的后台记录，保留待回查状态。'};
  }
  throw new Error('未知平台动作。');
 }
 root.FullPlatform={inspect,execute,searchSlot,searchOption};
})(globalThis);
