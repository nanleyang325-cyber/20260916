(function(root){
 'use strict';
 const material=tab=>{try{const u=new URL(tab?.url);return u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname==='/home.htm/material-center/material-management';}catch{return false;}};
 // Keep the original document alive: its product selection, filters and scroll
 // belong to the page, and cannot be reconstructed by opening the bare URL.
 async function begin(tabId){
  let origin;try{origin=Number.isInteger(tabId)?await chrome.tabs.get(tabId):(await chrome.tabs.query({active:true,currentWindow:true}))[0];}catch{}
  if(!material(origin)||origin.pendingUrl)origin=null;
  const owned=new Map();
  const unchanged=(tab,url)=>{try{const a=new URL(tab.url),b=new URL(url);return !tab.pendingUrl&&a.protocol===b.protocol&&a.host===b.host&&a.pathname===b.pathname&&a.searchParams.get('id')===b.searchParams.get('id');}catch{return false;}};
  return {
   async open(url){const options={url,active:false};if(origin){options.windowId=origin.windowId;options.openerTabId=origin.id;}const tab=await chrome.tabs.create(options);owned.set(tab.id,url);return tab;},
   async finish(){
    const tabs=[];for(const [id,url]of owned)try{const tab=await chrome.tabs.get(id);if(unchanged(tab,url))tabs.push(tab);}catch{}
    let original;try{if(origin){const tab=await chrome.tabs.get(origin.id);if(tab.windowId===origin.windowId&&tab.url===origin.url&&!tab.pendingUrl)original=tab;}}catch{}
    // Only return from a tab created by this collection. A later user switch
    // to an unrelated tab, or a source login/redirect, must remain untouched.
    if(original){try{const active=(await chrome.tabs.query({active:true,windowId:original.windowId}))[0];if(tabs.some(tab=>tab.id===active?.id))await chrome.tabs.update(original.id,{active:true});}catch{}}
    for(const tab of tabs)try{const current=await chrome.tabs.get(tab.id);if(!current.active&&unchanged(current,owned.get(tab.id)))await chrome.tabs.remove(tab.id);}catch{}
   }
  };
 }
 // Returning only changes tab focus. The live product document/editor stays intact.
 const returned=new Set();
 async function capture(run){
  if(run.materialReturn||!['white','transparent','scene'].includes(run.module)||!Number.isInteger(run.tabId))return;
  try{const tab=await chrome.tabs.get(run.tabId);if(material(tab)&&!tab.pendingUrl)run.materialReturn={tabId:tab.id,windowId:tab.windowId,url:tab.url};}catch{}
 }
 async function backfill(run){
  const item=run.items?.[run.position],origin=run.materialReturn;
  const filling=item?.phase==='publish'||item?.phase==='attach'&&(item.prepared?.whiteUploaded||Object.keys(item.uploadIntents||{}).length>0);
  if(!run.enabled||!filling||!origin||returned.has(item.id))return;
  returned.add(item.id);
  try{
   const tab=await chrome.tabs.get(origin.tabId);
   if(!material(tab)||tab.windowId!==origin.windowId||tab.url!==origin.url||tab.pendingUrl)return;
   const active=(await chrome.tabs.query({active:true,windowId:origin.windowId}))[0];
   if(active?.id===tab.id)return;
   if(active?.id!==item.returnUploadTabId||active.pendingUrl||active.url!==item.returnUploadURL)return;
   await chrome.tabs.update(tab.id,{active:true});
  }catch{} // A closed or changed page cannot cancel/retry a material submission.
 }
 root.FullCollectionReturn={begin,capture,backfill};if(typeof module==='object')module.exports=root.FullCollectionReturn;
})(globalThis);
