'use strict';
const $=s=>document.querySelector(s), extension=!!globalThis.chrome?.runtime?.id, BASE=extension?(chrome.runtime.getURL('local-api').replace(/\/$/,'')+""):location.origin, KEY='full-helper-v1';
let state={products:[],jobs:[],schedules:[]}, moduleName='white', stop=false, pending=null, collectionId=null;
const refs=new Map(), frames=new Map(), active=new Set(), multi=new Set();
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function toast(message){$('#toast').textContent=message;$('#toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('#toast').hidden=true,7000);}
async function guard(fn){try{await fn();}catch(error){toast(error.message||'操作未完成。');}}
async function save(){if(extension){const merged=await FullStateStore.update(KEY,latest=>FullStateStore.mergePanelState(latest,state));const current=new Map(state.jobs.map(job=>[job.id,job]));merged.jobs=merged.jobs.map(job=>{const existing=current.get(job.id);if(!existing)return job;const assets=new Map(existing.assets.map(asset=>[asset.id,asset]));job.assets=job.assets.map(asset=>assets.has(asset.id)?Object.assign(assets.get(asset.id),asset):asset);return Object.assign(existing,job);});Object.assign(state,merged);}else localStorage.setItem(KEY,JSON.stringify(state));}
async function api(route,options={}){const response=await fetch(BASE+route,{...options,headers:{'X-Material-Client':'full-v1',...(options.body?{'Content-Type':'application/json'}:{})},signal:AbortSignal.timeout(20000)});const result=await response.json();if(!response.ok)throw Object.assign(new Error(result.error||'请求失败'),{status:response.status});return result;}
async function message(data){if(!extension)throw new Error('操作店铺标签页需安装浏览器插件。');if(!Number.isInteger(data.tabId)&&['FULL_PLATFORM','FULL_SCENE','FULL_FISSION','FULL_CONTENT'].includes(data.type)&&$('#platform-tab')?.value)data.tabId=Number($('#platform-tab').value);const result=await chrome.runtime.sendMessage(data);if(!result?.ok)throw Object.assign(new Error(result?.error||'插件请求失败'),{executed:result?.executed,code:result?.code});return result;}
async function openBackend(url){const result=await message({type:'FULL_OPEN',url});state.selectedTabId=result.tabId;await save();const option=document.createElement('option');option.value=result.tabId;option.textContent=url;$('#platform-tab').append(option);$('#platform-tab').value=result.tabId;}
$('#freegen-open').onclick=()=>guard(async()=>{if(extension)await chrome.tabs.create({url:chrome.runtime.getURL('freegen.html')});else window.open('freegen.html','_blank');});
function tab(name){for(const el of document.querySelectorAll('main>section'))el.hidden=el.id!==name;for(const el of document.querySelectorAll('nav button'))el.classList.toggle('active',el.dataset.tab===name);}
function moduleButtons(){ $('#modules').innerHTML=Object.entries(FullCore.MODULES).map(([id,m])=>`<button data-module="${id}" class="${id===moduleName?'active':''}">${m.name}<small>${id==='white'&&globalThis.FullWhiteUI?escape(FullWhiteUI.label(FullPanelParity.adapter().settings())):m.media==='video'?'视频生成与平台流程':m.media?'图片生成与平台流程':'店铺运营流程'}</small></button>`).join('');$('#multi-modules').innerHTML=Object.entries(FullCore.MODULES).map(([id,m])=>`<button data-multi="${id}" class="${multi.has(id)?'active':''}">${m.name}</button>`).join(''); }
function chooseModule(id){moduleName=id;for(const selector of ['#collect','#plan']){const card=$(selector)?.closest('.card');if(card){card.dataset.whiteLegacy='true';card.hidden=id==='white';}}const m=FullCore.config(id,$('#variant').value);$('#variant-label').hidden=id!=='guanghe';$('#count').value=m.count||1;$('#ratio').value=m.ratio||'1:1';$('#provider-note').textContent=m.media==='video'?'视频拟使用GrsAI MiniMax H3，10秒、480p。费用按GrsAI当前账户报价，确认后才提交。':m.media?'图片：GrsAI Nano Banana Pro · 2K。多图按实际生成次数计费，不是原软件九图套餐。':'运营任务不调用媒体生成；发布内容需你确认商品事实。';moduleButtons();}
function renderProducts(){ $('#products').innerHTML=state.products.map(p=>`<div class="product"><div><strong>${escape(p.title)}</strong><br><small>${escape(p.id)} · ${p.images?.length||0}张候选图</small></div><button data-add-id="${p.id}">加入范围</button></div>`).join(''); }
function renderJobs(){
 $('#job-count').textContent=state.jobs.length;
 $('#jobs').innerHTML=[...state.jobs].reverse().map(job=>{
  const mod=FullCore.config(job.module,job.variant), reference=refs.get(job.id), frameList=frames.get(job.id)||[];
  const assets=job.assets.filter(a=>a.status==='completed');
  return `<article class="job" data-job="${job.id}"><div class="job-head"><div><h3>${escape(mod.name)} · ${escape(job.titles.join('、'))}</h3><p class="muted">商品 ${job.productIds.join('、')} · ${job.assets.length}个生成任务</p></div><span class="badge ${job.status==='verified'?'success':''}">${escape(FullCore.STATUS[job.status])}</span></div>${job.error?`<p class="error">${escape(job.error)}</p>`:''}<details><summary>查看提示词与执行记录</summary><pre>${escape(job.prompt)}\n\n${escape(job.events.map(e=>e.time+' '+FullCore.STATUS[e.status]+' '+e.detail).join('\n'))}</pre></details>${mod.media?`<div class="fields"><label>这款商品的参考图${job.module==='outfit'?'（服装＋模特两张）':''}<input type="file" accept="image/png,image/jpeg,image/webp" ${job.module==='outfit'?'multiple':''} data-ref="${job.id}"></label><small>${reference?reference.map(r=>escape(r.name)).join('、'):'尚未选择；重开侧栏后，未提交任务需重新选图。'}</small><div>${(state.products.find(p=>p.id===job.productIds[0])?.images||[]).map((url,i)=>/^https:\/\/(?:[^/]+\.)?alicdn\.com\//.test(url)?`<button data-candidate="${job.id}" data-index="${i}">使用候选图${i+1}</button>`:'').join('')}</div></div>`:''}<div class="assets">${assets.map(a=>`<div>${mod.media==='video'?`<video controls src="${BASE}/api/media/${a.id}/file"></video>`:`<img src="${BASE}/api/media/${a.id}/file" alt="AI素材，需审看一致性">`}<a href="${BASE}/api/media/${a.id}/file" target="_blank">下载素材${a.index+1}</a>${job.module==='scene'?`<br><a href="${BASE}/api/media/${a.id}/scene" target="_blank">下载800×800版本</a>`:''}</div>`).join('')}</div><div class="fields"><label>标题<input data-field="title" value="${escape(job.title)}"></label><label>正文<textarea data-field="body" rows="2">${escape(job.body)}</textarea></label>${job.module==='selling'?`<label>短卖点（最多7字）<input data-field="shortPoint" maxlength="7" value="${escape(job.shortPoint||'')}"></label><label>长卖点<input data-field="longPoint" value="${escape(job.longPoint||'')}"></label>`:''}<label>后台回查素材/内容ID（发布后填写）<input data-field="expectedContentId" value="${escape(job.expectedContentId||'')}"></label></div><div class="actions">${mod.media?`<button data-run="${job.id}" class="primary" ${active.has(job.id)?'disabled':''}>${job.assets.some(a=>a.status!=='draft')?'继续原任务':'确认并生成本批'}</button><button data-refresh="${job.id}">刷新生成状态</button>`:''}${mod.destination?`<button data-open="${job.id}">打开对应后台</button><button data-inspect="${job.id}">检查当前页面</button>`:''}<button data-stop="${job.id}">停止</button></div>${frameList.length?`<div class="fields"><label>选择当前后台表单<select data-frame="${job.id}">${frameList.map(frame=>`<option value="${frame.frameId}">${escape(frame.url)} · ${frame.targetFound?'已找到目标商品':'未定位商品'} · ${frame.fileInputs}个上传入口</option>`).join('')}</select></label><div class="actions"><button data-action="open-row">打开商品入口</button><button data-action="upload">上传已生成素材</button><button data-action="fill">回填内容</button><button data-action="submit">确认平台提交</button><button data-action="verify">后台回查</button>${job.module==='fission'?'<button data-action="clone-link">打开官方相似品链接</button>':''}</div></div>`:''}<p class="muted">${['white','scene','mainvideo','fission'].includes(job.module)?'生成与上传可执行；槽位绑定/商品克隆字段回填仍在适配，不会自动提交。':''}</p></article>`;
 }).join('');
 for(const article of document.querySelectorAll('[data-job]')){
  const job=state.jobs.find(job=>job.id===article.dataset.job);
  if(job.backgroundQueueLocked){for(const control of article.querySelectorAll('button,input,textarea,select'))control.disabled=true;}
  const actions=article.querySelector('.fields .actions');
  if(actions){const opener=document.createElement('button');opener.dataset.action='open-upload';opener.textContent='打开上传控件';actions.prepend(opener);}
  if(FullCore.config(job.module,job.variant).media){const reuse=document.createElement('div');reuse.className='fields';reuse.innerHTML='<label>复用同商品已完成素材编号（空格或换行分隔，不重新生成）<textarea data-reuse-ids rows="2"></textarea></label><button data-reuse>查询并复用原素材</button>';article.append(reuse);}
  const copyButton=document.createElement('button');copyButton.dataset.copywriter=job.id;copyButton.textContent=job.textId?'查询原文案任务':'生成事实文案';article.querySelector('.actions').append(copyButton);
  if(job.module==='fission'){
   const controls=document.createElement('div');controls.className='fields';controls.innerHTML=`<label>原商品SKU总数<input type="number" data-field="expectedSkuCount" min="1" value="${escape(job.expectedSkuCount||'')}"></label><div class="actions"><button data-fission-action="snapshot-source">读取源商品SKU快照</button><button data-fission-action="snapshot-clone">读取克隆并核对差异</button><button data-fission-action="submit-clone">确认新增商品</button></div><p class="muted">${escape(job.comparison?.ok?'SKU数据一致；仍需核对主图与标题。':job.comparison?.reason||'先打开原商品编辑页，只读快照；再打开官方发布相似品页。')}</p><label><input type="checkbox" data-clone-reviewed ${job.reviewedCloneImages?'checked':''}>已审看并填入新主图，标题未优化、款号未修改</label>`;article.append(controls);
  }
  if(actions&&['guanghe','follow','search','searchvideo'].includes(job.module)){const button=document.createElement('button');button.dataset.action='bind-products';button.textContent='关联任务商品';actions.prepend(button);}
  if(actions&&['search','searchvideo','guanghe'].includes(job.module)){
   const tools=job.module==='searchvideo'?[['search-slot','打开空搜推视频槽']]:FullCore.config(job.module,job.variant).media==='video'?[]:[['open-picture-picker','打开官方选图'],['select-pictures','精确选择本批图片'],['verify-pictures','核对表单图片']];
   if(job.module==='search')tools.unshift(['search-slot','打开空搜推图文槽']);
   for(const [action,label]of tools){const button=document.createElement('button');button.dataset.action=action;button.textContent=label;actions.append(button);}
  }
  if(FullCore.config(job.module,job.variant).media==='image'&&!['white','scene'].includes(job.module)){
   const batch=document.createElement('div');batch.className='fields';batch.innerHTML=`<label><input type="checkbox" data-batch-reviewed>已审看本批全部图片及商品一致性</label><button data-space-batch>上传本批到图片空间</button><small>已有文件按原编号回查，上传未确认时不重复上传。</small>`;article.append(batch);
  }
  if(actions&&['search','searchvideo'].includes(job.module)){for(const [action,label]of [['baseline','读取发布前内容ID基线'],['verify','回查新内容ID']]){const button=document.createElement('button');button.dataset.contentAction=action;button.textContent=label;actions.append(button);}}
  if(actions&&job.module==='mainvideo'){for(const [action,label]of [['video-slot','打开空视频槽'],['select-video','选择指定视频'],['submit-video','确认保存视频槽']]){const button=document.createElement('button');button.dataset.action=action;button.textContent=label;actions.append(button);}const label=document.createElement('label');label.textContent='本批上传后的平台视频内容ID';const input=document.createElement('input');input.dataset.field='videoContentId';input.value=job.videoContentId||'';label.append(input);actions.before(label);}
  if(!['scene','white'].includes(job.module))continue;
  const automatic=document.createElement('div');automatic.className='fields';automatic.innerHTML=`<label><input type="checkbox" data-reviewed ${job.reviewedAssets?'checked':''}>已审看本图，确认与目标商品一致</label><label><input type="checkbox" data-auto-replace ${job.replaceExisting?'checked':''}>允许替换已有素材槽（默认只填空槽）</label><button class="primary" data-automate="${job.id}" ${active.has(job.id)?'disabled':''}>${job.publication?'只回查绑定结果':'自动上传并绑定'}</button><small>${escape(job.automation?.events?.at(-1)?.detail||'复用已有素材，不调用生成模型。')}</small>`;article.append(automatic);
  article.querySelector(':scope > p.muted').textContent='上传到图片空间后，按唯一文件名读回并绑定对应素材槽；只有URL与后台素材ID都匹配才算通过。';
  if(!frames.has(job.id))continue;
  const controls=document.createElement('div');controls.className='fields';controls.innerHTML=`<label><input type="checkbox" data-replace ${job.replaceExisting?'checked':''}>允许替换该商品已有的${job.module==='white'?'白底':'场景'}图</label><div class="actions"><button data-open-space>打开图片空间</button><button data-scene-action="lookup">回查上传文件</button><button data-scene-action="bind">确认绑定素材槽</button><button data-scene-action="verify">回查槽位结果</button></div>`;article.append(controls);
 }
 for(const article of document.querySelectorAll('[data-job]'))if(state.jobs.find(job=>job.id===article.dataset.job)?.backgroundQueueLocked)for(const control of article.querySelectorAll('button,input,textarea,select'))control.disabled=true;
}
async function merge(products){const map=new Map(state.products.map(p=>[p.id,p]));for(const p of products)map.set(p.id,{...map.get(p.id),...p});state.products=[...map.values()];await save();renderProducts();}
function settings(module){return {module,variant:$('#variant').value,ids:$('#ids').value,count:$('#count').value,maxCalls:$('#max-calls').value,ratio:$('#ratio').value,palette:$('#palette').value,category:$('#category').value,facts:$('#facts').value,extra:$('#extra').value,title:$('#title').value,body:$('#body').value,followMode:$('#follow-mode').value,startDate:$('#start-date').value};}
async function plan(modules){if(modules.includes('white'))throw Error('白底图请使用专用全量跑、自定义商品ID或多任务自动执行入口。');const result=modules.map(id=>FullCore.plan(state.products,{...settings(id),count:modules.length>1?FullCore.config(id,$('#variant').value).count||1:$('#count').value,ratio:modules.length>1?FullCore.config(id,$('#variant').value).ratio:$('#ratio').value}));const calls=result.reduce((sum,r)=>sum+r.calls,0);if(calls>Number($('#max-calls').value))throw new Error(`多任务共需${calls}次生成，超出本批上限。`);state.jobs.push(...result.flatMap(r=>r.jobs));await save();renderJobs();tab('queue');toast(`已创建${result.flatMap(r=>r.jobs).length}个任务，计划${calls}次生成，尚未收费。`);}
function confirmAction(title,text,action){pending=action;$('#consent-title').textContent=title;$('#consent-text').textContent=text;$('#consent-check').checked=false;$('#confirm').disabled=true;$('#consent').showModal();}
async function readFile(file){if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>6*1024*1024)throw new Error('参考图应为6MB以内PNG、JPG或WebP。');return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve({name:file.name,data:reader.result});reader.onerror=()=>reject(new Error('参考图读取失败。'));reader.readAsDataURL(file);});}
async function refresh(job){for(const asset of job.assets){if(asset.status==='draft')continue;try{const result=await api('/api/media/'+asset.id);Object.assign(asset,result);}catch(error){asset.error=error.message;}}if(job.assets.length&&job.assets.every(a=>a.status==='completed'))FullCore.transition(job,'generated','本批素材均已下载及格式验证，商品一致性需审看。');await save();renderJobs();}
async function generate(job){
 if(active.has(job.id))return;const reference=refs.get(job.id);if(job.assets.some(a=>a.status==='draft')&&(!reference||job.module==='outfit'&&reference.length!==2))throw new Error('请为这款商品选择所需参考图。');
 stop=false;job.stopRequested=false;job.generationConsent=true;active.add(job.id);FullCore.transition(job,'generating');await save();renderJobs();
 try {
  for(const asset of job.assets){
   if(stop||job.stopRequested)break;if(asset.status==='completed')continue;
   if(asset.status==='draft'){
    asset.status='submitting';await save();
    try{const result=await api('/api/media',{method:'POST',body:JSON.stringify({id:asset.id,productIds:job.productIds,module:job.module,media:FullCore.config(job.module,job.variant).media,model:FullCore.config(job.module,job.variant).media==='video'?'minimax-h3':'nano-banana-pro',ratio:job.ratio,palette:job.palette,prompt:job.prompt+`\n本批第${asset.index+1}/${job.assets.length}张，视角不改变未提供的产品结构。`,references:reference.map(r=>r.data),consent:true})});Object.assign(asset,result);}catch(error){asset.status=[400,403,503].includes(error.status)?'draft':'submission_unconfirmed';throw error;}
   }else if(['pending','not_completed'].includes(asset.status)){Object.assign(asset,await api(`/api/media/${asset.id}/resume`,{method:'POST',body:'{}'}));}
   for(let polls=0;polls<150;polls++){
    if(stop||job.stopRequested)break;
    Object.assign(asset,await api('/api/media/'+asset.id));await save();renderJobs();
    if(asset.status==='completed')break;
    if(['failed','submission_unconfirmed','not_completed','downloaded_unverified','pending'].includes(asset.status))throw new Error(`任务${asset.id}：${asset.status}，保留原编号，请回查后继续。`);
    await delay(5000);
   }
   if(asset.status!=='completed')break;
  }
  if(job.assets.every(a=>a.status==='completed'))FullCore.transition(job,'generated');else if(stop||job.stopRequested)FullCore.transition(job,'stopped','已停止后续生成，已交给平台的任务继续保留。');
 }catch(error){job.error=error.message;FullCore.transition(job,'unknown',error.message);toast(error.message);}finally{active.delete(job.id);await save();renderJobs();}
}
function edited(job,article){for(const el of article.querySelectorAll('[data-field]'))job[el.dataset.field]=el.value;}
async function platform(job,action,article){
 const submission=['submit','submit-video'].includes(action);
 edited(job,article);await save();
 const frameId=Number(article.querySelector('[data-frame]').value);
 if(submission&&job.publication)throw new Error('此任务已有平台提交记录，只能回查，不能重复发布。');
 if(submission&&!job.publicationConsent){confirmAction('提交到店铺后台？',`只处理商品${job.productIds.join('、')}的${FullCore.MODULES[job.module].name}。请先审看全部素材、文案、关联商品与内容声明。`,async()=>{job.publicationConsent=true;await save();await platform(job,action,article);});return;}
 let assets=[];
 if(action==='upload'){if(!job.assets.every(a=>a.status==='completed'))throw new Error('先完成并审看全部生成素材。');assets=await Promise.all(job.assets.map(a=>api(`/api/media/${a.id}/${job.module==='scene'?'data-scene':'data'}`)));}
 if(submission){job.publication={key:FullCore.publicationKey(job),submittedAt:new Date().toISOString(),frameId};FullCore.transition(job,'submitting');await save();}
 try{
  const result=await message({type:'FULL_PLATFORM',action,job,frameId,assets});
  if(result.cloneUrl){await message({type:'FULL_OPEN',url:result.cloneUrl});}
  if(result.dateSelected)job.dateSelected=result.dateSelected;
  if(result.documentTimeOrigin&&job.publication)job.publication.documentTimeOrigin=result.documentTimeOrigin;
  if(result.receipt){if(!FullCore.verifyReceipt(job,result.receipt))throw new Error('后台回查商品集合或内容ID不符。');job.receipt=result.receipt;}
  FullCore.transition(job,result.status,result.message||'');job.error='';toast(result.message||FullCore.STATUS[result.status]);
 }catch(error){if(submission){if(error.executed===false){job.publication=null;job.publicationConsent=false;FullCore.transition(job,'prepared','平台校验未通过，未点击提交。');}else FullCore.transition(job,'unknown','提交结果不明，禁止自动重新发布。');}job.error=error.message;throw error;}finally{await save();renderJobs();}
}
async function automate(job){
 if(active.size)throw new Error('请等待当前任务结束，避免同时操作后台。');
 active.add(job.id);job.stopRequested=false;renderJobs();
 let tabId=null;
 async function open(url){await openBackend(url);tabId=state.selectedTabId;await delay(2000);}
 async function sceneAction(action,fileName){return chrome.runtime.sendMessage({type:'FULL_SCENE',tabId,frameId:0,job,action,fileName});}
 try{
  const result=await FullAutomation.run(job,{
   save:async()=>{await save();renderJobs();},verify:FullCore.verifyReceipt,delay,
   openSpace:()=>open(FullCore.URLS.space),
   lookup:(_job,name)=>sceneAction('lookup',name),
   asset:(id,scene)=>api(`/api/media/${id}/${scene?'data-scene':'data'}`),
   openUpload:()=>message({type:'FULL_PLATFORM',tabId,frameId:0,job,action:'open-upload'}),
   upload:(_job,assets)=>message({type:'FULL_PLATFORM',tabId,frameId:0,job,action:'upload',assets}),
   readSlot:()=>sceneAction('read'),bind:(_job,name)=>sceneAction('bind',name),
   readback:async()=>{await open(FullCore.URLS.space);return sceneAction('verify');}
  });toast(result.status==='verified'?'商品素材绑定已回查通过。':'任务保留待回查状态，未重复提交。');
 }finally{active.delete(job.id);await save();renderJobs();}
}
async function uploadBatch(job){
 if(active.size)throw new Error('请等待当前任务结束。');if(job.publication)throw new Error('已有发布记录，只允许回查。');
 if(!job.assets.length||job.assets.some(a=>a.status!=='completed'))throw new Error('先完成本批所有素材。');
 active.add(job.id);job.stopRequested=false;
 try{
  await openBackend(FullCore.URLS.space);const tabId=state.selectedTabId;await delay(2000);
  const lookup=async name=>{for(let n=0;n<6;n++){const result=await chrome.runtime.sendMessage({type:'FULL_SCENE',tabId,frameId:0,job,action:'lookup',fileName:name});if(result.code!=='LOOKUP_COMPONENT_UNAVAILABLE')return result;await delay(1000);}throw new Error('图片空间未就绪，请完成登录后回查。');};
  const records=[],missing=[];
  for(const asset of job.assets){const file=await api(`/api/media/${asset.id}/data`),result=await lookup(file.name);if(result.ok)records.push(result.sceneUpload);else if(result.code==='PICTURE_NOT_FOUND')missing.push(file);else throw new Error(result.error||'图片查询未确认。');}
  if(missing.length){
   job.batchUploadIntents||={};if(missing.some(file=>job.batchUploadIntents[file.name]))throw new Error('原上传文件尚未回查，禁止重复上传；请稍后只查询。');
   if(job.stopRequested)throw new Error('任务已停止，未开始上传。');
   await message({type:'FULL_PLATFORM',tabId,frameId:0,job,action:'open-upload'});
   for(const file of missing)job.batchUploadIntents[file.name]={at:new Date().toISOString()};await save();
   await message({type:'FULL_PLATFORM',tabId,frameId:0,job,action:'upload',assets:missing});
   for(const file of missing){let result;for(let n=0;n<20;n++){await delay(1500);result=await lookup(file.name);if(result.ok)break;if(result.code!=='PICTURE_NOT_FOUND')throw new Error(result.error||'上传回查失败。');}if(!result.ok)throw new Error('图片上传未确认；保留原上传编号，不重传。');records.push(result.sceneUpload);}
  }
  job.uploadedAssets=job.assets.map(asset=>records.find(record=>record.name===`material-${asset.id}.png`));if(job.uploadedAssets.some(record=>!record))throw new Error('本批文件回查未完整匹配。');
  FullCore.transition(job,'uploaded','已按本批全部唯一文件名回查图片空间。');job.error='';
 }catch(error){job.error=error.message;FullCore.transition(job,job.batchUploadIntents?'unknown':'failed',error.message);throw error;}finally{active.delete(job.id);await save();renderJobs();}
}
let autoRunsState=[];
function renderAutoRuns(){if(!$('#auto-runs'))return;$('#auto-runs').innerHTML=[...autoRunsState].reverse().map(run=>`<article class="card"><h3>${escape(FullCore.MODULES[run.module]?.name)} · 自动补图</h3><p>${run.position}/${run.ids.length} 款 · 已登记 ${run.usedCalls}/${run.maxCalls} 次生图 · ${run.enabled?'执行中':run.status==='done'?'本批结束':'已暂停'}</p>${run.error?`<p class="error">${escape(run.error)}</p>`:''}<div class="actions"><button data-auto-stop="${run.id}" ${!run.enabled?'disabled':''}>停止后续动作</button><button data-auto-resume="${run.id}" ${run.enabled||run.status==='done'?'disabled':''}>按原范围继续 / 回查</button></div><details><summary>逐商品进度</summary>${run.items.map(item=>`<p>${escape(item.productId)} · ${escape(item.phase)} · ${escape(item.detail||item.status)}</p>`).join('')}</details></article>`).join('');}
const runModes=FullRunModes.install({
 autoDefaults:()=>({maxCalls:Number($('#max-calls').value),palette:$('#palette').value||'no',autoPublish:true}),
 ...FullPanelParity.adapter(),
 scope:()=>$('#ids').value,products:()=>state.products,collectAll:collectAllProducts,
 async apply(id,selection){
  if(selection.variant)$('#variant').value=selection.variant;
  chooseModule(id);tab('create');$('#ids').value=selection.ids.join('\n');$('#target').value=selection.ids.length===1?selection.ids[0]:'';
  if(selection.followMode)$('#follow-mode').value=selection.followMode;
  if(selection.category)$('#category').value=selection.category;
  if(selection.extra)$('#extra').value=selection.extra;
  state.scopeIds=$('#ids').value;state.runSelection={module:id,...selection};await save();
  $('#ids').scrollIntoView({block:'center',behavior:'smooth'});toast('已选择'+selection.ids.length+'个商品，请核对商品资料后创建计划。');
 }
});
document.addEventListener('click',event=>guard(async()=>{
 const button=event.target.closest('button');if(!button)return;
 if(button.dataset.autoStop)await message({type:'FULL_AUTO_STOP',runId:button.dataset.autoStop});
 if(button.dataset.autoResume)await message({type:'FULL_AUTO_RESUME',runId:button.dataset.autoResume});
 if(button.dataset.tab)tab(button.dataset.tab);
 if(button.dataset.module){chooseModule(button.dataset.module);runModes.open(button.dataset.module);}
 if(button.dataset.multi){multi.has(button.dataset.multi)?multi.delete(button.dataset.multi):multi.add(button.dataset.multi);moduleButtons();}
 if(button.dataset.addId){const ids=$('#ids').value.trim().split(/\s+/).filter(Boolean);$('#ids').value=[...new Set([...ids,button.dataset.addId])].join('\n');}
 const job=state.jobs.find(j=>j.id===button.closest('[data-job]')?.dataset.job);
 if(button.hasAttribute('data-space-batch')){if(!button.closest('[data-job]').querySelector('[data-batch-reviewed]').checked)throw new Error('请先审看本批全部图片。');confirmAction('上传已生成的本批图片？',`仅商品${job.productIds.join('、')}的${job.assets.length}张已有图片。不调用生成，不发布内容。`,()=>uploadBatch(job));}
 if(button.hasAttribute('data-reuse')){const ids=button.closest('[data-job]').querySelector('[data-reuse-ids]').value.trim().split(/\s+/).filter(Boolean);if(!ids.length||ids.some(id=>! /^[a-f0-9-]{36}$/.test(id)))throw new Error('请填写原素材任务UUID。');const records=await Promise.all(ids.map(id=>api('/api/media/'+id)));FullCore.reuse(job,records);await save();renderJobs();toast('已复用原素材，不新增生成请求。');}
 if(button.dataset.automate){
  if(!extension)throw new Error('自动绑定需要安装浏览器扩展。');
  const article=button.closest('[data-job]');job.reviewedAssets=article.querySelector('[data-reviewed]').checked;job.replaceExisting=article.querySelector('[data-auto-replace]').checked;
  if(job.publication){if(!job.automationConsent)throw new Error('该记录来自手动提交，请使用原后台回查入口。');await automate(job);}
  else{FullAutomation.approve(job);confirmAction('执行这张素材的上传与绑定？',`仅商品${job.productIds[0]}的${FullCore.MODULES[job.module].name}，${job.replaceExisting?'允许替换现有素材':'仅填明确空槽'}。复用已生成图片，不生图、不新增商品；提交后会自动回查。`,()=>automate(job));}
 }
 if(button.dataset.candidate){const url=state.products.find(p=>p.id===job.productIds[0])?.images?.[Number(button.dataset.index)];const result=await message({type:'FETCH_REFERENCE',url});refs.set(job.id,[{name:'商品'+job.productIds[0]+'参考图',data:result.reference}]);renderJobs();}
 if(button.dataset.run){if(job.assets.every(a=>a.status!=='draft'))await generate(job);else confirmAction('确认生成这一批素材？',`商品${job.productIds.join('、')}，共${job.assets.filter(a=>a.status==='draft').length}次付费生成；参考图将发送至GrsAI。${FullCore.config(job.module,job.variant).media==='video'?'MiniMax H3，10秒、480p；':'Nano Banana Pro，2K；'}以账户当前平台价格为准。`,()=>generate(job));}
 if(button.dataset.refresh)await refresh(job);
 if(button.dataset.stop){job.stopRequested=true;FullCore.transition(job,'stopped');await save();renderJobs();}
 if(button.dataset.open){let destination=FullCore.config(job.module,job.variant).destination;if(job.module==='follow'&&job.followMode==='new')destination='followNew';await openBackend(FullCore.URLS[destination]);}
 if(button.dataset.inspect){const result=await message({type:'FULL_PLATFORM',action:'inspect',job});frames.set(job.id,result.frames);renderJobs();toast('已检查当前标签页，请选择匹配的后台表单。');}
 if(button.dataset.action)await platform(job,button.dataset.action,button.closest('[data-job]'));
 if(button.dataset.contentAction){const article=button.closest('[data-job]');edited(job,article);const result=await message({type:'FULL_CONTENT',job,action:button.dataset.contentAction,frameId:Number(article.querySelector('[data-frame]').value)});if(result.contentBaseline)job.contentBaseline=result.contentBaseline;if(result.receipt){if(!FullCore.verifyReceipt(job,result.receipt))throw new Error('内容ID回查不符。');job.receipt=result.receipt;}FullCore.transition(job,result.status,result.message||'已读取发布前基线，未发布内容。');await save();renderJobs();}
 if(button.dataset.fissionAction){
  const action=button.dataset.fissionAction,article=button.closest('[data-job]');edited(job,article);job.reviewedCloneImages=article.querySelector('[data-clone-reviewed]').checked;
  const perform=async()=>{if(action==='submit-clone'){if(job.publication)throw new Error('已有商品提交记录，只能回查，不能再创建。');job.newProductConsent=true;job.publication={key:FullCore.publicationKey(job),submittedAt:new Date().toISOString()};await save();}
   try{const result=await message({type:'FULL_FISSION',action,job});for(const key of ['sourceSnapshot','cloneSnapshot','comparison'])if(result[key])job[key]=result[key];FullCore.transition(job,result.status,result.message||'');toast(result.message||'快照读取完成，请核对完整性。');}
   catch(error){if(action==='submit-clone'&&error.executed===false)job.publication=null;job.error=error.message;throw error;}finally{await save();renderJobs();}};
  if(action==='submit-clone')confirmAction('新增一个商品链接？',`此操作会从源商品${job.productIds[0]}新建商品，可能改变店铺商品数量。SKU、价格、库存、款号必须保持一致，原商品不修改。先前1个测试新增额度已经用完，本次确认代表另一次新增授权。`,perform);else await perform();
 }
 if(button.dataset.copywriter){
  edited(job,button.closest('[data-job]'));
  const perform=async()=>{
   if(!job.textId){if(!job.facts.trim())throw new Error('先在创建任务时提供已确认商品事实；不能凭标题编造卖点。');job.textId=crypto.randomUUID();await save();await api('/api/media',{method:'POST',body:JSON.stringify({id:job.textId,media:'text',model:'gemini-3.1-pro',module:job.module,productIds:job.productIds,prompt:`只依据下列已确认商品事实写中文商品内容，不增加功能、认证、价格、尺寸、兼容性或效果。不能假扮真实购买者。输出纯JSON，键title(最多20字)、body、shortPoint(最多7字)、longPoint。资料不足的字段留空。商品：${job.titles.join('、')}。已确认事实：${job.facts}。`,consent:true})});}
   const result=await api('/api/media/'+job.textId);if(result.status==='completed'&&result.text){Object.assign(job,result.text);FullCore.transition(job,'prepared','AI文案已准备，发布前需核对事实。');await save();renderJobs();toast('文案已填入；请审看后再提交。');}else toast(`原文案任务：${result.status}。只查询，不重复生成。`);
  };
  if(job.textId)await perform();else confirmAction('生成商品文案？','拟调用GrsAI Gemini 3.1 Pro，会产生平台费用。只依据你已确认的商品事实生成，完成后需要审看。',perform);
 }
 if(button.hasAttribute('data-open-space'))await openBackend(FullCore.URLS.space);
 if(button.dataset.sceneAction){
  const action=button.dataset.sceneAction,article=button.closest('[data-job]');edited(job,article);job.replaceExisting=article.querySelector('[data-replace]').checked;
  const perform=async()=>{
   if(action==='bind'){if(job.publication)throw new Error('已有绑定提交记录，请先回查。');job.publicationConsent=true;job.publication={key:FullCore.publicationKey(job),submittedAt:new Date().toISOString()};FullCore.transition(job,'submitting');await save();}
   const asset=job.assets[0];if(!asset)throw new Error('尚无生成素材。');
   try {const result=await message({type:'FULL_SCENE',action,job,frameId:Number(article.querySelector('[data-frame]').value),fileName:`material-${asset.id}${job.module==='scene'?'-scene-800':''}.png`});if(result.sceneUpload)job.sceneUpload=result.sceneUpload;if(result.receipt){if(!FullCore.verifyReceipt(job,result.receipt))throw new Error('场景绑定回查不符。');job.receipt=result.receipt;}FullCore.transition(job,result.status,result.message||'');job.error='';}
   catch(error){job.error=error.message;if(action==='bind')FullCore.transition(job,'unknown','绑定状态待回查，不能自动重复提交。');throw error;}finally{await save();renderJobs();}
  };
  if(action==='bind')confirmAction('绑定素材到指定商品？',`商品${job.productIds.join('、')}，${job.replaceExisting?'允许替换现有图片':'仅允许空槽'}。请先回查唯一上传文件与商品一致性。`,perform);else await perform();
 }
 if(button.dataset.disableSchedule){const schedule=state.schedules.find(s=>s.id===button.dataset.disableSchedule);schedule.enabled=false;if(extension)await chrome.alarms.clear('full-reminder:'+schedule.id);await save();renderSchedules();}
}));
$('#jobs').addEventListener('change',event=>guard(async()=>{const id=event.target.dataset.ref;if(!id)return;const files=[...event.target.files];if(files.length>2)throw new Error('最多两张参考图。');refs.set(id,await Promise.all(files.map(readFile)));renderJobs();}));
$('#import-products').onclick=()=>guard(async()=>{const products=$('#import').value.split(/\r?\n/).filter(l=>l.trim()).map(line=>{const [id,title]=line.trim().split('\t');FullCore.ids(id);return {id,title:title||'标题待补充',images:[],source:'手动导入'};});await merge(products);toast('商品已导入。');});
$('#collect').onclick=()=>guard(async()=>{const result=await message({type:'READ_PRODUCTS'});await merge(result.products);toast(`读取${result.products.length}款。`);});
$('#collect-target').onclick=()=>guard(async()=>{const id=$('#target').value.trim();FullCore.ids(id);const result=await message({type:'READ_PRODUCTS'});const p=result.products.find(p=>p.id===id);if(!p)throw new Error('当前已加载页面没有指定ID，先在后台搜索该商品。');await merge([p]);$('#ids').value=id;});
async function collectAllProducts(){if(collectionId)throw new Error('正在读取商品，请等待或停止采集。');collectionId=crypto.randomUUID();$('#stop-collection').hidden=false;try{const result=await message({type:'READ_ALL_PRODUCTS',id:collectionId});await merge(result.products);$('#collection').textContent=result.note;state.lastCollection=result;await save();return result;}finally{collectionId=null;$('#stop-collection').hidden=true;}}
$('#collect-all').onclick=()=>guard(collectAllProducts);
$('#stop-collection').onclick=()=>guard(async()=>{if(collectionId)await message({type:'STOP_COLLECTION',id:collectionId});});
$('#variant').onchange=()=>chooseModule(moduleName);
$('#plan').onclick=()=>guard(()=>plan([moduleName]));$('#plan-multi').onclick=()=>guard(async()=>{if(!multi.size)throw new Error('先选择多个功能。');await plan([...multi]);});
$('#stop-all').onclick=()=>{if(extension)guard(async()=>{await message({type:'FULL_QUEUE_STOP'});for(const run of autoRunsState.filter(run=>run.enabled))await message({type:'FULL_AUTO_STOP',runId:run.id});});stop=true;for(const job of state.jobs)if(active.has(job.id))job.stopRequested=true;toast('已停止新增动作，平台中已经提交的任务不撤销。');};
$('#refresh-tabs').onclick=()=>guard(async()=>{const result=await message({type:'FULL_TABS'});$('#platform-tab').innerHTML='<option value="">当前活动后台</option>'+result.tabs.map(tab=>`<option value="${tab.id}">${escape(tab.title)} · ${escape(tab.url)}</option>`).join('');if(result.tabs.some(tab=>tab.id===state.selectedTabId))$('#platform-tab').value=state.selectedTabId;});
$('#platform-tab').onchange=()=>guard(async()=>{state.selectedTabId=$('#platform-tab').value?Number($('#platform-tab').value):null;await save();});
$('#ids').onchange=()=>guard(async()=>{state.scopeIds=$('#ids').value;await save();});
$('#load-history').onclick=()=>guard(async()=>{
 const scope=FullCore.ids($('#ids').value);const result=await Promise.all(scope.map(id=>api('/api/history?productId='+id)));
 for(const saved of result.flatMap(r=>r.jobs)){
  if(state.jobs.some(j=>j.id===saved.id))continue;
  const module=saved.module|| (saved.media==='video'?'mainvideo':saved.media==='text'?'selling':saved.sceneAvailable?'scene':'white');
  if(!FullCore.MODULES[module])continue;
  state.jobs.push({id:saved.id,module,variant:module==='guanghe'&&saved.media==='video'?'video':'image',productIds:saved.productIds,titles:saved.productIds.map(id=>state.products.find(p=>p.id===id)?.title||id),status:saved.status==='completed'?'generated':'unknown',palette:'no',ratio:FullCore.MODULES[module].ratio,prompt:'来自主机原生成记录，不重新提交。',title:'',body:'',facts:'',assets:saved.media==='text'?[]:[{...saved,index:0}],textId:saved.media==='text'?saved.id:null,events:[],publication:null});
 }
 await save();renderJobs();toast('已读取同一商品的主机原任务，不新增生成。');
});
$('#export').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify({exportedAt:new Date().toISOString(),...state},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='完整版任务记录.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);};
$('#consent-check').onchange=event=>$('#confirm').disabled=!event.target.checked;
$('#cancel').onclick=()=>{$('#consent').close();pending=null;};$('#confirm').onclick=()=>guard(async()=>{if(!$('#consent-check').checked)return;$('#consent').close();const action=pending;pending=null;await action?.();});
function renderSchedules(){$('#background-queues').innerHTML=(state.backgroundQueues||[]).map(q=>`<p>${escape(new Date(q.runAt).toLocaleString())} · ${q.position}/${q.jobs.length} · ${escape(q.done?'完成':q.enabled?'待执行/执行中':q.error||'已停止')}</p>`).join('');$('#schedules').innerHTML=state.schedules.map(s=>`<p>${escape(s.time)} · ${s.enabled?'提醒已启用':'已关闭'} <button data-disable-schedule="${s.id}">关闭</button></p>`).join('');}
$('#start-background').onclick=()=>guard(async()=>{if(!extension)throw new Error('后台队列需要安装浏览器扩展。');if(active.size)throw new Error('请等待当前任务完成。');const ids=[];for(const article of document.querySelectorAll('[data-job]')){const j=state.jobs.find(j=>j.id===article.dataset.job);if(!FullAutomation.supported.includes(j.module)||j.status==='verified')continue;const reviewed=article.querySelector('[data-reviewed]');if(!reviewed?.checked)continue;j.reviewedAssets=true;j.replaceExisting=article.querySelector('[data-auto-replace]').checked;FullAutomation.approve(j);ids.push(j.id);}if(!ids.length)throw new Error('先在任务中审看并勾选已完成素材。');const runAt=$('#queue-time').value?new Date($('#queue-time').value).getTime():Date.now()+1000;confirmAction('后台执行这些已审看素材？',`共${ids.length}个白底/场景任务，保持各任务商品和替换范围。不调用生成模型；关闭工作台可继续，Chrome须保持运行。`,async()=>{await save();await message({type:'FULL_QUEUE_START',jobIds:ids,runAt});toast('后台队列已登记。');});});
$('#stop-background').onclick=()=>guard(async()=>{await message({type:'FULL_QUEUE_STOP'});toast('停止请求已确认，已经提交的动作只能回查。');});
$('#save-schedule').onclick=()=>guard(async()=>{if(!extension)throw new Error('提醒需要安装插件。');const time=$('#schedule-time').value;if(!/^\d{2}:\d{2}$/.test(time))throw new Error('请选择时间。');const [h,m]=time.split(':').map(Number);const next=new Date();next.setHours(h,m,0,0);if(next<=new Date())next.setDate(next.getDate()+1);const schedule={id:crypto.randomUUID(),time,enabled:true};state.schedules.push(schedule);await save();await chrome.alarms.create('full-reminder:'+schedule.id,{when:next.getTime(),periodInMinutes:1440});renderSchedules();toast('执行提醒已保存；到时不会自动扣费或发布。');});
if(extension)chrome.runtime.onMessage.addListener(message=>{if(message.type==='COLLECTION_PROGRESS'&&message.id===collectionId)$('#collection').textContent=message.text;if(message.type==='FULL_SCHEDULE_DUE')toast('多任务执行时间已到，请检查并确认任务队列。');});
if(extension)chrome.storage.onChanged.addListener((changes,area)=>{const incoming=changes[KEY]?.newValue;if(area==='local'&&incoming?.jobs){state.backgroundQueues=incoming.backgroundQueues||state.backgroundQueues;for(const remote of incoming.jobs||[]){const index=state.jobs.findIndex(j=>j.id===remote.id);if(index>=0&&(remote.backgroundQueueLocked||state.jobs[index].backgroundQueueLocked))state.jobs[index]=remote;else if(index<0&&remote.autoRunId)state.jobs.push(remote);}renderJobs();renderSchedules();}});
(async()=>{if(extension)await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='automation.js';script.onload=resolve;script.onerror=()=>reject(new Error('扩展流程模块未能加载。'));document.head.append(script);});try{const stored=extension?(await chrome.storage.local.get(KEY))[KEY]:JSON.parse(localStorage.getItem(KEY)||'null');if(stored?.jobs&&stored.products)state={schedules:[],...stored};}catch{toast('历史记录未能读取。');}$('#ids').value=state.scopeIds||'';chooseModule('white');renderProducts();renderJobs();renderSchedules();if(extension&&state.selectedTabId)await $('#refresh-tabs').onclick();try{const status=await api('/api/status');$('#service').textContent=status.credentialConfigured?'插件服务在线 · GrsAI凭据已配置 · 未自动生成或发布':'独立插件 · 凭据未配置';}catch{$('#service').textContent='插件服务未启动 · 可以创建计划';}})();

if(extension){chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes['material-auto-runs-v1']){autoRunsState=changes['material-auto-runs-v1'].newValue||[];renderAutoRuns();}});chrome.storage.local.get('material-auto-runs-v1').then(result=>{autoRunsState=result['material-auto-runs-v1']||[];renderAutoRuns();});}

globalThis.addEventListener('white-settings-changed',moduleButtons);
FullPanelParity.ready.then(moduleButtons);
