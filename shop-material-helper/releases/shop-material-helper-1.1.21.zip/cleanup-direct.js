(function(root){
 'use strict';
 const direct=run=>run.selection?.mode==='cleanup'&&run.selection.cleanupExecution==='listed-direct-v1'&&run.selection.dryRun===false;
 const describe=c=>'商品 '+c.productIds.join('、')+' · 素材 '+c.contentId+' · '+(c.contentType==='article'?'图文':'视频')+' · 曝光 '+c.ndPv+'/'+c.pv+' · 发布 '+new Date(c.publishTime).toLocaleDateString('zh-CN')+' · '+(c.featured?'精选':'普通');
 function event(run,detail){run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail});}
 function freeze(run){
  if(!direct(run))return;
  if(!run.discovery?.complete||run.discovery.truncated)throw Error('素材列表未完整读取，本轮未删除。');
  const c=run.selection.criteria,records=run.items.map(i=>structuredClone(i.candidate));
  if(records.some(c=>!c||!/^\d{6,}$/.test(c.contentId))||new Set(records.map(c=>c.contentId)).size!==records.length)throw Error('命中清单身份异常，未删除。');
  run.cleanupPlan={at:new Date().toISOString(),consentScope:run.consentScope,records};
  event(run,'清理条件：'+(c.scope==='ids'?'指定商品 '+c.ids.join('、'):c.scope==='duplicates'?'重复素材':'全部商品')+'；'+(c.scope==='duplicates'?'平台重复标记':'曝光≤'+c.exposure+'、发布满'+c.days+'天')+'；'+[c.article?'图文':'',c.video?'视频':''].filter(Boolean).join('、')+'；'+(c.includeFeatured?'包含精选':'保留精选')+'；关联图片仅删除已确认无引用的文件。');
  event(run,'命中清单已保存，共 '+records.length+' 条；接下来按此清单逐条删除，不扩大范围。');
  for(const record of records)event(run,'命中：'+describe(record));
  if(!records.length)event(run,'没有符合条件的素材，删除 0 条。');
 }
 function ids(run,item){
  if(!direct(run))return run.selection.confirmedContentIds;
  const plan=run.cleanupPlan,c=item.candidate;
  if(!plan||plan.consentScope!==run.consentScope||!root.FullFlowRun.matchesConsent(run)||!plan.records.some(r=>JSON.stringify(r)===JSON.stringify(c)))throw Error('当前素材不在本轮已保存的精确清单中，未删除。');
  return plan.records.map(r=>r.contentId);
 }
 function summary(run){const a=run.items||[],deleted=a.filter(i=>i.receipt?.status==='已删除').length,unknown=a.filter(i=>i.publication&&!i.receipt).length,failed=a.filter(i=>['failed','blocked'].includes(i.status)&&!i.publication).length+(run.taskFailures?.length||0),pictures=a.flatMap(i=>i.pictureCleanup?.results||[]);return '命中 '+a.length+' · 素材已删除 '+deleted+' · 失败 '+failed+' · 待确认 '+unknown+' · 图片已删除 '+pictures.filter(i=>i.status==='deleted').length+' · 图片保留 '+pictures.filter(i=>i.status==='retained').length+' · 图片待确认 '+pictures.filter(i=>i.status==='unknown').length;}
 function view(run){
  const rows=(run.items||[]).map(i=>{const phase=i.status==='verified'?'done':i.status==='failed'?'failed':i.publication&&!i.receipt?'unknown':['blocked','submitted_unconfirmed'].includes(i.status)?'unknown':i.phase==='prepare'?'wait':'working',detail=i.detail||i.error||'';return {pid:i.productIds.join('、'),contentId:i.candidate?.contentId,phase,status:phase,label:i.receipt?.status==='已删除'?'素材已删除':phase==='unknown'?'待确认':phase==='failed'?'失败':phase==='wait'?'待删除':'处理中',note:detail+(i.pictureCleanup?.summary&&!detail.includes(i.pictureCleanup.summary)?'；'+i.pictureCleanup.summary:''),groupLabel:'素材 '+i.candidate?.contentId,costText:'不调用生图',step:i.phase==='readback'?'删除回查':'清理素材',executionPhase:i.phase};});
  const counts={total:rows.length,done:0,failed:0,skip:0,unknown:0,boundary:0,wait:0,working:0};for(const row of rows)counts[row.phase]++;
  return {id:run.id,module:'search',cleanup:true,cleanupSummary:summary(run),mode:'ids',status:run.status,rows,counts,discoveryComplete:run.phase!=='discover',runtime:{moduleName:'清理素材',status:run.enabled?'运行中':run.status==='done'?'本轮结束':'待处理',active:run.enabled,phase:run.phase,detail:run.phase==='discover'?'正在读取完整命中清单，尚未删除':run.error||'素材与关联图片的处理结果见下方，保留原因记入任务日志。',productId:'',groupLabel:''}};
 }
 root.FullCleanupDirect={direct,describe,event,freeze,ids,summary,view};if(typeof module==='object')module.exports=root.FullCleanupDirect;
})(globalThis);
