(function(root){
 'use strict';
 const isWhiteAI=run=>run.module==='white'&&(!run.selection.source||run.selection.source==='ai_generate');
 const idEqual=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const editing=item=>['attach','native','publish','readback'].includes(item?.phase);
 const domBusy=item=>['native','publish','readback'].includes(item?.phase)||item?.phase==='attach'&&(!!item.prepared?.whiteUploaded||Object.keys(item.uploadIntents||{}).length>0);
 const uncertain=item=>item.whiteTerminal==='unconfirmed';
 function state(run){return run.whiteWindow||(run.whiteWindow={version:1,active:[],groupEnd:0,failures:0,refreshes:0,finished:false});}
 async function advance(run,io){
  if(run.module!=='white')return root.FullFlowRun.advance(run,io);
  if(!run.enabled)return;
  if(run.selection?.reviewRejected===true)return root.FullWhiteReview.advance(run,io);
  const w=state(run),save=async detail=>{run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail});await io.save(run);},live=async()=>run.enabled&&(!io.isLive||await io.isLive(run));
  const mark=(item,kind,detail)=>{item.whiteTerminal=kind;item.status=kind==='unconfirmed'?'submitted_unconfirmed':kind;item.detail=detail;};
  const refill=index=>{if(isWhiteAI(run)&&!root.FullWhiteRun.custom(run)){w.refillIndex=w.failures===0?index+3:null;}};
  const seek=()=>{while(run.position<run.items.length&&(run.items[run.position].whiteConsumed||run.items[run.position].status==='verified'))run.position++;};
  const finish=async()=>{w.finished=true;run.enabled=false;run.status=run.draining?'drained':run.items.some(uncertain)?'pending_review':'done';await save(run.status==='pending_review'?'白底图本轮已逐项结算，待确认项保留原编号；继续时只处理这些原任务。':run.draining?'白底图收尾完成，成功、失败与待确认分项保留。':'白底图本轮已逐项结算，成功、跳过和失败分项保留。');};
  try{
   if(!await live())return;
   if(!root.FullFlowRun.matchesConsent(run))throw Error('白底图原执行范围已变化。');
   if(run.draining&&!run.items.some(item=>!item.whiteConsumed&&item.status!=='verified'&&(item.generations?.some(g=>g.intent)||item.nativeIntent||item.publication||Object.keys(item.uploadIntents||{}).length))){run.enabled=false;run.status='drained';await save('没有待收尾的原提交，未开始新生成或店铺动作。');return;}
   if(run.phase==='discover'){await root.FullFlowRun.advance(run,io);return;}
   if(w.finished){const pending=run.items.map((item,index)=>uncertain(item)&&!item.failureSkipped?index:-1).filter(n=>n>=0);if(!pending.length)return finish();for(const index of pending){const item=run.items[index];delete item.whiteTerminal;item.whiteConsumed=false;item.status=item.publication?'submitted_unconfirmed':'pending';}run.position=pending[0];w.active=[];w.groupEnd=0;delete w.pageWindowKey;delete w.refillIndex;w.finished=false;w.failures=0;await save('只恢复待确认的原任务，保留原生成、上传和回填意图。');return;}
   const unsettledEditor=run.items.findIndex((i,index)=>index<run.position&&!i.failureSkipped&&i.whiteTerminal==='unconfirmed'&&i.status!=='verified'&&(i.nativeIntent||i.whiteEditorIntent||i.publication||Object.keys(i.uploadIntents||{}).length));if(unsettledEditor>=0){run.enabled=false;run.status='pending_review';run.error='先前商品编辑器尚未结算，保留原编号，未进入下一商品或再次付费。';await save(run.error);return;}
   seek();if(run.position>=run.items.length){if(!run.draining&&!root.FullWhiteRun.custom(run)&&run.whitePaging&&!run.whitePaging.exhausted){const targets=await io.nextWhitePage(run);root.FullWhiteRun.append(run,targets);await save('本页逐项结算后才读取下一页商品；未提前扫描全店。');return;}return finish();}
   if(w.refreshIntent&&!w.refreshIntent.finished){await io.refresh(run);w.refreshIntent.finished=true;await save('白底图已恢复原页面；所有旧编号和结果继续保留。');return;}
   if(w.failures>=2&&!root.FullTaskFailures){
    if(w.refreshes>=2){run.enabled=false;run.status='recovery_exhausted';await save('白底图连续确定失败，已达到两轮页面恢复上限；其余商品未重建生成编号。');return;}
    w.refreshes++;w.failures=0;w.refreshIntent={id:crypto.randomUUID(),at:new Date().toISOString(),finished:false};await save('连续两项确定失败，先保存原任务和第'+w.refreshes+'轮页面恢复意图。');return;
   }
   w.active=w.active.filter(index=>!run.items[index].whiteConsumed&&run.items[index].status!=='verified');
   const current=run.items[run.position],ai=isWhiteAI(run),custom=ai&&root.FullWhiteRun.custom(run),cap=ai?(custom?6:3):1;
   if(!domBusy(current)&&!run.draining){
    if(custom){if(!w.groupEnd||run.position>=w.groupEnd)w.groupEnd=Math.min(run.items.length,run.position+6);for(let index=run.position;index<w.groupEnd;index++)if(!run.items[index].whiteConsumed&&run.items[index].status!=='verified'&&!w.active.includes(index))w.active.push(index);}
    else {const page=current.context?.page,key=JSON.stringify([page,run.whitePaging?.pageSignature]);const add=index=>{const item=run.items[index];if(item&&(page===undefined||item.context?.page===page)&&!item.whiteConsumed&&item.status!=='verified'&&!w.active.includes(index))w.active.push(index);};if(!ai)add(run.position);else if(w.pageWindowKey!==key){w.pageWindowKey=key;for(let index=run.position;index<Math.min(run.items.length,run.position+cap);index++)add(index);}else if(Number.isInteger(w.refillIndex))add(w.refillIndex);delete w.refillIndex;}
    await save('保存白底图固定'+(custom?'六项分组':ai?'三项预生成窗口':'单项原生处理')+'；商品检索与参考图读取串行执行。');
   }
   if(!w.active.includes(run.position))w.active.unshift(run.position);
   const submit=[];
   for(const index of w.active){
    const item=run.items[index];if(item.whiteTerminal||item.whiteConsumed||editing(item))continue;
    if(item.phase==='prepare'){
     if(run.draining)continue;
     if(!await live())return;
     try{const prepared=await io.prepare(run,item);if(!await live())return;if(prepared?.status==='ineligible'){mark(item,'skipped',prepared.message||'不具备白底图执行条件。');await save(item.detail);continue;}if(prepared?.productIds&&!idEqual(prepared.productIds,item.productIds))throw Error('白底图准备结果商品身份不匹配。');if(ai&&!prepared?.needsGeneration||!ai&&!prepared?.needsAttach&&!prepared?.needsNative)throw Error('白底图来源与处理阶段不符，未扩展执行。');item.prepared=prepared;item.phase=prepared.needsNative?'native':prepared.needsAttach?'attach':'generate';await save('白底图商品资格及来源已确认，按原来源处理。');}catch(error){if(error.whiteScopeBlocked||error.boundaryBlocked)throw error;mark(item,'failed',error.message);await save('白底图生成前检查失败：'+error.message);continue;}
    }
   }
   // Finish every eligibility search in the current group before reading references or reserving submissions.
   for(const index of w.active){const item=run.items[index];if(item.whiteTerminal||item.whiteConsumed)continue;
    if(item.phase!=='generate'||item.generations?.[0]?.intent)continue;
    if(run.draining)continue;
    root.FullWhiteRun.guard(run,'paidGeneration',item);
    if(!await live())return;
    try{if(!item.generations){item.generations=await io.planGeneration(run,item);if(item.generations?.length!==1)throw Error('每商品白底图须恰好一个固定生成编号。');await save('保存白底图固定生成编号。');}}catch(error){mark(item,'failed',error.message);await save('白底图参考图未取得：'+error.message);continue;}
    if(!await live()||run.draining)return;
    const g=item.generations[0];let input;try{input=io.prepareGeneration?await io.prepareGeneration(run,item,g):undefined;}catch(error){mark(item,'failed','白底图参考图下载失败，未发起生成：'+error.message);await save(item.detail);continue;}if(!await live()||run.draining)return;g.intent={id:g.id,at:new Date().toISOString()};g.status='pending';run.usedCalls++;run.usedCallsByType||={image:0,video:0,text:0};run.usedCallsByType.image=(run.usedCallsByType.image||0)+1;await save('先持久登记白底图原生成编号与一次调用；没有隐藏20次上限。');submit.push({index,g,input});
   }
   if(submit.length){
    const results=await Promise.allSettled(submit.map(async entry=>{if(!await live()||run.draining)return {notSent:true};return io.submitGeneration(run,run.items[entry.index],entry.g,entry.input);}));
    for(let n=0;n<results.length;n++){const item=run.items[submit[n].index],result=results[n];if(result.status==='rejected')mark(item,'unconfirmed','原白底图提交结果未知，保留编号不重投：'+result.reason.message);else if(result.value?.notSent)mark(item,'unconfirmed','生成意图已登记但停止前未发出；保留原编号，不自动重投。');}
    await save('本窗口提交调用已返回；只查询原编号，不把请求返回当生成成功。');return;
   }
   for(const index of w.active){const item=run.items[index];if(!item.whiteTerminal&&item.phase==='generate'&&item.generations?.[0]?.status==='completed'&&item.generations[0].available===true)item.phase='attach';}
   const queries=w.active.filter(index=>{const item=run.items[index];return !item.whiteTerminal&&item.phase==='generate'&&item.generations?.[0]?.intent&&item.generations[0].status!=='completed';});
   if(queries.length){const results=await Promise.allSettled(queries.map(index=>io.queryGeneration(run,run.items[index],run.items[index].generations[0])));for(let n=0;n<results.length;n++){const item=run.items[queries[n]],g=item.generations[0],result=results[n];if(result.status==='rejected'){mark(item,'unconfirmed','原白底图查询未确认，保留编号：'+result.reason.message);continue;}const answer=result.value;if(answer?.id!==g.id||!idEqual(answer?.productIds,item.productIds)){mark(item,'unconfirmed','原白底图回执编号或商品不匹配，未采用其他结果。');continue;}if(answer.status==='completed'&&answer.available===true){Object.assign(g,answer);item.phase='attach';}else if(answer.status==='failed'){Object.assign(g,answer);mark(item,'failed','原生成服务明确返回失败，保留原编号不重投。');}else if(['submission_unconfirmed','downloaded_unverified','not_completed'].includes(answer.status)){Object.assign(g,answer);mark(item,'unconfirmed','原生成结果待确认，保留编号不重投。');}else if(Date.now()-Date.parse(g.intent.at)>300000)mark(item,'unconfirmed','原白底图超过五分钟仍未确认，保留原编号等待回查，不重投。');else g.status=answer.status||'pending';}await save('并行查询白底图原编号，结果与商品逐项核对。');}
   if(!await live())return;
   const item=run.items[run.position];
   if(item.whiteTerminal){refill(run.position);item.whiteConsumed=true;if(item.whiteTerminal==='failed')w.failures++;else if(item.whiteTerminal==='unconfirmed')w.failures=0;run.position++;await save(item.detail);return;}
   if(item.phase==='prepare'||item.phase==='generate'&&!item.generations?.[0]?.intent){if(run.draining){run.enabled=false;run.status='drained';await save('白底图已收尾，未发起下一商品生成。');return;}return;}
   if(item.phase==='generate')return;
   if(item.phase==='attach'&&io.recheck){const result=await io.recheck(run,item);if(result?.status==='ineligible'){mark(item,'skipped',result.message);item.whiteConsumed=true;run.position++;await save(item.detail);return;}}
   if(item.phase==='attach'&&item.prepared?.source!=='image_space_size')root.FullWhiteRun.guard(run,'upload',item);
   if(item.phase==='native'&&!item.nativeIntent)root.FullWhiteRun.guard(run,'nativeGenerate',item);
   if(item.phase==='publish'&&!item.publication)root.FullWhiteRun.guard(run,'publish',item);
   let nativeFailed=false,derivativeBlocked=false,boundaryError;const oldPosition=run.position,oldStatus=item.status;const protect=fn=>async(...args)=>{try{return await fn(...args);}catch(error){if(error.boundaryBlocked)boundaryError=error;throw error;}};
   await root.FullFlowRun.advance(run,{...io,finishDrainItem:true,startNative:protect(io.startNative),publish:protect(io.publish),save:async r=>{if(r.status!=='blocked')await io.save(r);},attach:async(...args)=>{try{return await io.attach(...args);}catch(error){if(error.code==='WHITE_DERIVATIVE_UNAVAILABLE')derivativeBlocked=true;if(error.boundaryBlocked)boundaryError=error;throw error;}},queryNative:async(...args)=>{const result=await io.queryNative(...args);if(result?.status==='failed')nativeFailed=true;return result;}});
   if(boundaryError){item.status=oldStatus;run.failureItemId=item?.id;root.FullWhiteRun.block(run,boundaryError,item);await save(boundaryError.message);return;}
   if(run.position!==oldPosition){refill(oldPosition);item.whiteConsumed=true;if(item.status==='verified')w.failures=0;await save('白底图当前商品已结算，回填保持串行。');return;}
   if(run.status==='blocked'){
    const known=!derivativeBlocked&&(nativeFailed||!item.publication&&!item.nativeIntent&&!Object.keys(item.uploadIntents||{}).length);
    if(item.nativeIntent||item.whiteEditorIntent||item.publication||Object.keys(item.uploadIntents||{}).length){mark(item,'unconfirmed',run.error||'当前编辑器结果未确认。');run.enabled=false;run.status='pending_review';await save('当前白底图编辑器尚未结算，暂停本轮并保留所有原编号；未切换下一商品、刷新页面或重新生成。');return;}
    refill(oldPosition);mark(item,known?'failed':'unconfirmed',run.error||'白底图结果未确认。');item.whiteConsumed=true;if(known)w.failures++;else w.failures=0;run.position++;run.enabled=true;run.status=run.draining?'draining':'running';run.error='';await save('保留该商品全部原意图并逐项结算，继续本组其他已确认商品。');
   }
  }catch(error){if(error.boundaryBlocked){const item=run.items.find(i=>i.productIds?.join()===error.productIds?.join())||run.items[run.position];run.failureItemId=item?.id;root.FullWhiteRun.block(run,error,item);await save(error.message);return;}run.enabled=false;run.status='blocked';run.error=error.message;await save('白底图窗口停止：'+error.message);}
 }
 root.FullWhiteWindow={advance,isWhiteAI,handles:run=>run.module==='white'};if(typeof module==='object')module.exports=root.FullWhiteWindow;
})(globalThis);
