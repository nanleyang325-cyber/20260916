(function(root){
 'use strict';
 const WRITE_ACTIONS=new Set(['upload','nativeGenerate','publish']);
 const custom=run=>['ids','custom'].includes(run.selection?.mode);
 function titleSkip(title,productId){
  if(typeof title!=='string')return null;const compact=title.normalize('NFKC').replace(/[\s\u200b-\u200d\ufeff]/g,''),keyword=compact.match(/补差价|補差價|补差|補差|差价|差價|补款|補款|运费|運費|邮费|郵費|补邮|補郵|差额|差額|售后.*(?:链接|专拍)|售後.*(?:連結|專拍)|换货专拍|換貨專拍|单.?拍.?不.?发.?货|單.?拍.?不.?發.?貨/)?.[0];
  return keyword?{status:'ineligible',skipReason:'title_excluded',keyword,message:'跳过商品 '+(productId||'待确认')+'：标题「'+title.replace(/[\r\n\t]/g,' ').slice(0,160)+'」命中「'+keyword+'」，属于补款、运费或专拍类链接；未调用生图或上传替换。'}:null;
 }
 function selection(input={},lockBoundary=false){
  const out={...structuredClone(input),palette:'no',count:1,ratio:'1:1'};
  if(input.reviewRejected===true){out.source='ai_generate';out.whiteBgSourceMethod='ai_generate';out.reviewMaxAttempts=1;out.reviewAutomatic=input.reviewAutomatic===true;}
  delete out.maxCalls;
  const value=input.executionBoundary||{};
  out.executionBoundary={paidGeneration:!lockBoundary&&value.paidGeneration===true,storeWrite:!lockBoundary&&value.storeWrite===true};
  return out;
 }
 function create(input={},lockBoundary=false){return root.FullFlowRun.create('white',selection(input,lockBoundary));}
 function guard(run,action,item){
  if(run.module!=='white')return;
  const key=action==='paidGeneration'?'paidGeneration':WRITE_ACTIONS.has(action)?'storeWrite':null;
  if(!key)throw Error('未知白底图执行边界动作。');
  if(run.selection?.executionBoundary?.[key]===true)return;
  throw Object.assign(Error(key==='paidGeneration'?'本轮禁止付费生成，已停在白底图生成提交之前。':'本轮禁止店铺写入，已停在白底图'+({upload:'上传',nativeGenerate:'原生生成',publish:'回填'}[action])+'之前。'),{boundaryBlocked:true,action,stage:item?.phase||run.phase,productIds:[...(item?.productIds||[])]});
 }
 function block(run,error,item){run.enabled=false;run.status='boundary_blocked';run.error=error.message;run.boundaryBlocked={action:error.action,stage:error.stage||item?.phase||run.phase,productIds:error.productIds||item?.productIds||[],at:new Date().toISOString()};if(item)item.detail=error.message;}
 function append(run,targets){
  if(!Array.isArray(targets)||targets.some(t=>!Array.isArray(t.productIds)||t.productIds.length!==1||!/^\d{6,}$/.test(t.productIds[0])))throw Error('白底图本页商品身份未明确。');
  const requested=custom(run)?root.FullButtonContracts.parseIds(run.selection.ids):null;
  if(requested&&targets.some(t=>!requested.includes(t.productIds[0])))throw Error('白底图检索结果超出原ID范围。');
  const seen=new Set(run.items.map(i=>i.productIds[0]));let added=0;
  for(const target of targets){if(seen.has(target.productIds[0]))continue;seen.add(target.productIds[0]);run.items.push({...target,id:crypto.randomUUID(),phase:'prepare',status:'pending'});added++;}
  return added;
 }
 function revision(run){return Number.isSafeInteger(run?.whiteControlRevision)&&run.whiteControlRevision>=0?run.whiteControlRevision:0;}
 function mergeControl(run,canonical){
  if(run.module!=='white'||!canonical)return run;
  const current=revision(canonical),worker=revision(run),copy=key=>{if(Object.prototype.hasOwnProperty.call(canonical,key))run[key]=structuredClone(canonical[key]);else delete run[key];};
  if(current>worker){for(const key of ['enabled','status','draining','whitePause','error','boundaryBlocked'])copy(key);run.whiteControlRevision=current;}
  else if(current===worker){copy('whitePause');if(canonical.enabled===false){for(const key of ['enabled','status','error','boundaryBlocked'])copy(key);}if(canonical.draining){run.draining=true;if(run.enabled&&run.status==='running'&&canonical.status==='draining')run.status='draining';}}
  return run;
 }
 function change(run,action,paused){
  if(run.module!=='white')throw Error('此控制只用于白底图任务。');
  if(run.status==='done')throw Error('该白底图轮次已结束。');
  if(action==='pause'){
   const value=typeof paused==='boolean'?paused:run.status!=='paused';
   if(value){if(run.status==='paused')return run;if(!run.enabled)throw Error('该白底图任务未在运行。');run.whitePause={status:run.status,draining:!!run.draining};run.enabled=false;run.status='paused';}
   else {if(run.status!=='paused')return run;run.enabled=true;run.draining=run.whitePause?!!run.whitePause.draining:!!run.draining;run.status=run.draining?'draining':'running';delete run.whitePause;}
  }else if(action==='drain'){run.enabled=true;run.draining=true;run.status='draining';delete run.whitePause;}
  else if(action==='stop'){run.enabled=false;run.status='stopped';delete run.whitePause;}
  else if(action==='resume'){
   // Preparation can restart only before any paid or write intent. A formerly
   // unsupported rejection must now have a concrete rule; unknown ones stay put.
   if(run.selection?.reviewAutomatic){let first=-1;for(let n=0;n<run.items.length;n++){const i=run.items[n];if(i.phase!=='done'||i.status!=='needs_attention'||i.generations?.some(g=>g.intent)||i.publication||Object.keys(i.uploadIntents||{}).length)continue;const sourceFailure=i.referenceErrorCode==='WHITE_REFERENCE_UNAVAILABLE'||/SKU参考图未取得/.test(i.detail||'');let supportedRule=false;if(i.referenceErrorCode==='WHITE_REVIEW_RULE_UNSUPPORTED'||/拒绝原因尚无对应修改规则/.test(i.detail||'')){try{supportedRule=!!root.FullReviewRework?.plan(i.reviewOriginal)?.fixes?.length;}catch{}}if(sourceFailure||supportedRule){if(first<0)first=n;i.phase='prepare';i.status='pending';i.detail=supportedRule?'继续原任务，按已支持的实际审核原因修正，先重新核对原素材。':'继续原任务，重新采集同商品参考图。';delete i.generations;delete i.referenceErrorCode;}}if(first>=0)run.position=Math.min(run.position,first);}
   run.enabled=true;run.draining=false;run.status='running';run.error='';delete run.boundaryBlocked;delete run.whitePause;
  }
  else throw Error('未知白底图控制。');
  run.whiteControlRevision=revision(run)+1;
  return run;
 }
 function completedCandidate(run){return run?.module==='white'&&run.selection?.reviewAutomatic&&!run.enabled&&run.status!=='paused'?(run.items||[]).find(i=>i.phase==='done'&&i.status==='failed'&&i.generations?.length===1&&i.generations[0].intent&&i.generations[0].status==='failed'&&!i.publication&&!i.receipt&&!Object.keys(i.uploadIntents||{}).length):null;}
 function restoreCompleted(run,answer){
  const item=completedCandidate(run),g=item?.generations[0];
  if(!item||!root.FullFlowRun.matchesConsent(run)||answer?.id!==g.id||JSON.stringify(answer.productIds)!==JSON.stringify(item.productIds)||answer.status!=='completed'||answer.available!==true)throw Error('原生成尚未完成回查，未重新生成或更改任务。');
  item.generationRecovery={at:new Date().toISOString(),previousStatus:item.status,previousDetail:item.detail,previousGenerationError:g.error,originalGenerationId:g.id};Object.assign(g,structuredClone(answer));delete g.error;item.phase='generate';item.status='pending';item.detail='原生成编号已恢复并下载校验，继续使用此图。';run.position=Math.min(run.position,run.items.indexOf(item));run.enabled=false;run.status='pending_review';run.error='';run.events||=[];run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail:'原生图通道恢复：回查原编号成图成功，复用此图继续上传和替换；未新建生成任务。'});return run;
 }
 root.FullWhiteRun={custom,selection,create,guard,block,append,change,mergeControl,completedCandidate,restoreCompleted,titleSkip};
 if(typeof module==='object')module.exports=root.FullWhiteRun;
})(globalThis);
