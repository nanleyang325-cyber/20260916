(function(root){
 'use strict';
 const handles=run=>run.module==='white'&&run.selection?.reviewRejected===true;
 const key=s=>[s?.productId,s?.materialId,s?.url,s?.review?.auditTime].join('|');
 function exclusion(s){
  const title=s?.title,pid=s?.productId||'待确认',titleSkip=root.FullWhiteRun.titleSkip(title,pid);if(titleSkip)return titleSkip;let skipReason,reason;
  if(typeof title!=='string'||!title.trim()){skipReason='title_unknown';reason='平台未返回可核对的商品标题';}
  else if(s.saleState!=='on_sale'){skipReason=s.saleState==='off_sale'?'not_on_sale':'sale_state_unknown';reason=s.saleState==='off_sale'?'商品非在售（下架或仓库），不执行白底图重做':'商品在售状态未明确，不执行白底图重做';}
  else if(s.review?.code!=='4'||s.review?.name!=='审核不通过'){skipReason='review_not_rejected';reason='当前白底图审核状态为「'+(s.review?.name||'未提供')+'」（代码 '+(s.review?.code||'未提供')+'），不属于审核不通过';}
  else if(!/^\d+$/.test(s.materialId||'')){skipReason='material_identity_unknown';reason='原白底图素材编号无效或缺失';}
  else if(!/^https:\/\/[^/]*alicdn\.com\//.test(s.url||'')){skipReason='material_image_unknown';reason='原白底图图片地址无效或缺失';}
  else return null;
  return {status:'ineligible',skipReason,message:'跳过商品 '+pid+'：'+reason+'；未调用生图或替换。'};
 }
 const eligible=s=>!exclusion(s);
 const same=(a,b)=>eligible(a)&&eligible(b)&&key(a)===key(b)&&a.review.reason===b.review.reason;
 function claimed(runs,s,runId,spec){if(root.FullReviewRework)return root.FullReviewRework.claimed(runs,s,runId,spec,key);return runs.some(r=>r.id!==runId&&r.items?.some(i=>key(i.reviewOriginal)===key(s)&&(i.generations?.some(g=>g.intent)||i.publication)));}
 function prompt(s){const reason=s?.review?.reason||'',rules=['只呈现参考图中一个完整主商品，主体居中，边缘完整，四周留白至少12%，商品占画面65%至75%，禁止裁掉顶部、底部、线缆或必要结构。','纯白背景，只展示一件商品；不同角度、色号或重复相同主体不能拼在一张图。','去掉外加营销文字、促销贴片、价格、二维码、边框和装饰性标语；保留产品自身真实标识和必要屏幕内容。','保持参考图可确认的颜色、接口和结构，不虚构缺失细节；不要保留包装盒、模特、衣架或多件商品展示。'];if(/不完整|裁切/.test(reason))rules.push('本次重点修正主体不完整：拉远构图，完整显示整件主商品，不放大到出画。');if(/多个|重复/.test(reason))rules.push('本次重点修正多个相同主体：只保留单个完整主商品，禁止同款重复、对比图和拼图。');if(/牛皮癣|文字|水印|营销/.test(reason))rules.push('本次重点去除营销文字和贴片，画面中不添加任何后期文字。');return rules.join('\n');}
 async function advance(run,io){
  if(!run.enabled)return;const save=async detail=>{run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail});await io.save(run);},live=async()=>run.enabled&&(!io.isLive||await io.isLive(run));
  const finishItem=async(status,detail)=>{const i=run.items[run.position];i.status=status;i.detail=detail;i.phase='done';run.position++;await save(detail);};
  try{
   if(!await live())return;if(!root.FullFlowRun.matchesConsent(run))throw Error('审核重做范围已变化。');
   if(run.phase==='discover'){await root.FullFlowRun.advance(run,{...io,discover:io.reviewDiscover});return;}
   const i=run.items[run.position];if(!i){run.enabled=false;const attention=run.items.filter(i=>i.status==='needs_attention').length;const rejected=run.items.filter(i=>i.status==='review_rejected').length;run.status=attention?'pending_review':rejected?'awaiting_review_retry':'done';if(attention)run.error=attention+' 个商品需要补充处理信息，其他商品已逐项结算。';await save('审核重做本轮结束：'+(attention?'有 '+attention+' 件需跟进，':'')+'每件最多一次新生成；已提交不代表审核通过，原拒绝记录与新审核状态分别保留。');return;}
   if(run.draining&&!i.generations?.some(g=>g.intent)&&!i.publication&&!Object.keys(i.uploadIntents||{}).length){run.enabled=false;run.status='drained';await save('已停止新增审核重做，仅保留原任务。');return;}
   if(i.phase==='prepare'){const check=await io.reviewCheck(run,i);if(!check.eligible)return finishItem('skipped',check.message||'原素材审核状态或商品资格已变化。');if(run.selection.reviewAutomatic)i.reviewAutoPlan=root.FullReviewRework.plan(i.reviewOriginal);i.phase='generate';await save('已核对原商品、原失败素材ID、审核时间及拒绝原因'+(i.reviewAutoPlan?'；拒绝原因「'+i.reviewAutoPlan.reason+'」，修正「'+i.reviewAutoPlan.fixes.map(f=>f.title).join('、')+'」':'')+'；每件只允许一次新生成。');return;}
   if(i.phase==='generate'){
    if(!i.generations){const check=await io.reviewCheck(run,i);if(!check.eligible)return finishItem('skipped',check.message);i.generations=await io.planGeneration(run,i);if(i.generations?.length!==1)throw Error('审核重做每商品须恰好一个新编号。');await save('保存审核重做唯一生成编号与原拒绝素材快照。');return;}
    const g=i.generations[0];if(g.status==='completed'&&g.available===true){i.phase='attach';await save('原重做编号已完成，只使用该成图。');return;}
    if(!g.intent){root.FullWhiteRun.guard(run,'paidGeneration',i);const check=await io.reviewCheck(run,i);if(!check.eligible)return finishItem('skipped',check.message);if(run.usedCalls>=run.items.length+run.items.reduce((n,i)=>n+(i.reviewAttempts?.length||0),0))throw Error('已达本轮每商品一次重做上限。');const input=io.prepareGeneration?await io.prepareGeneration(run,i,g):undefined;if(!await live())return;g.intent={id:g.id,at:new Date().toISOString()};g.status='pending';run.usedCalls++;run.usedCallsByType.image++;await save('先持久登记一次审核重做付费意图；未知结果不换编号重投。');if(!await live())return;await io.submitGeneration(run,i,g,input);return;}
    const answer=await io.queryGeneration(run,i,g);if(answer?.id!==g.id||JSON.stringify(answer.productIds)!==JSON.stringify(i.productIds))throw Error('重做回执身份不匹配。');Object.assign(g,answer);if(answer.status==='completed'&&answer.available===true){i.phase='attach';await save('审核重做原编号成图已下载校验。');return;}if(['failed','violation'].includes(answer.status))return finishItem('failed','本次重做生成失败：'+(answer.error||answer.message||'通道明确返回失败')+'；保留原编号，不进行第二次付费。');if(['submission_unconfirmed','downloaded_unverified','not_completed'].includes(answer.status))throw Error('本次生成结果未确认，继续时仅查询原编号。');if(run.selection.reviewAutomatic&&Date.now()-Date.parse(g.intent.at)>300000)throw Error('原生成超过五分钟仍未确认，已保留编号；继续时只查询，不重新生成。');await save('仅查询本次重做原编号，不重复提交。');return;
   }
   if(i.phase==='attach'){const check=await io.reviewCheck(run,i);if(!check.eligible)return finishItem('skipped',check.message);root.FullWhiteRun.guard(run,'upload',i);await io.reviewAttach(run,i);if(!await live())return;i.phase='publish';await save('重做成图已按原唯一文件名上传回查；保留旧素材，尚未替换。');return;}
   if(i.phase==='publish'){if(i.publication){i.phase='readback';await save('已有替换提交意图，仅回查新图片，不再次提交。');return;}const check=await io.reviewCheck(run,i);if(!check.eligible)return finishItem('skipped',check.message);root.FullWhiteRun.guard(run,'publish',i);i.publication={id:crypto.randomUUID(),at:new Date().toISOString(),productIds:[...i.productIds]};i.phase='readback';await save('持久登记对原失败素材的一次精确替换意图。');if(!await live())return;i.submitResult=await io.reviewPublish(run,i);await save('替换动作已返回，下一步独立回查；不把保存当审核通过。');return;}
   if(i.phase==='readback'){const result=await io.reviewReadback(run,i);if(root.FullFlowRun.validReceipt(i,result)){i.receipt=result.receipt;i.reviewOutcome=result.review||null;if(root.FullWhiteRetry?.rejected(i))return finishItem('review_rejected','新素材已提交并回查，但审核仍不通过：'+(result.review.reason||'平台未提供具体原因')+'；等待确认是否继续采集其他素材，未自动再次付费。');return finishItem('verified','已重新提交并核对新素材；当前审核：'+(result.review?.name||'待平台确认')+'，本轮不再付费重做。');}if(run.selection.reviewAutomatic&&(i.reviewReadbackPolls||0)<12){i.reviewReadbackPolls=(i.reviewReadbackPolls||0)+1;await save('平台保存结果同步中，自动回查原提交 '+i.reviewReadbackPolls+'/12；未重复生成或替换。');return;}run.enabled=false;run.status='pending_review';run.error=result?.message||'替换结果未确认，只回查原提交。';await save(run.error);return;}
   throw Error('未知审核重做阶段。');
  }catch(e){const item=run.items[run.position];if(run.selection.reviewAutomatic&&item&&!e.boundaryBlocked&&!item.generations?.some(g=>g.intent)&&!item.publication&&!Object.keys(item.uploadIntents||{}).length){item.referenceErrorCode=e.code||(/参考图|详情.*图片/.test(e.message)?'WHITE_REFERENCE_UNAVAILABLE':null);return finishItem('needs_attention','全自动重做暂未处理：'+e.message+'；未扣费或替换，继续下一个商品。');}run.enabled=false;run.status=e.boundaryBlocked?'boundary_blocked':'pending_review';run.error=e.message;await save('审核重做暂停：'+e.message);}
 }
 root.FullWhiteReview={handles,key,eligible,same,claimed,prompt,advance,exclusion};if(typeof module==='object')module.exports=root.FullWhiteReview;
})(globalThis);
