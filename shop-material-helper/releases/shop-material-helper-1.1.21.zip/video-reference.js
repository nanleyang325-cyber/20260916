(function(root){
 'use strict';
 function imageURL(raw){try{const u=new URL(String(raw).startsWith('//')?'https:'+raw:raw);if(u.protocol!=='https:'||u.username||u.password||!/(^|\.)alicdn\.com$/.test(u.hostname))return null;u.pathname=u.pathname.replace(/(\.(?:jpe?g|png|webp))[_.].*$/i,'$1');return u.href;}catch{return null;}}
 function readGroups(doc,pid,url){
  const u=new URL(url),id=u.searchParams.get('id')||u.searchParams.get('itemId');if(u.protocol!=='https:'||!['sell.publish.tmall.com','item.upload.taobao.com'].includes(u.hostname)||id!==pid)throw Error('视频主图编辑页商品身份不一致。');
  if(/发布异常|无权限|账号发生变化|访问被拒绝|请登录|扫码登录/.test((doc.body?.innerText||'').slice(0,1500)))return {ready:false,reason:'编辑页访问受限或需要登录'};
  const sections={'3:4':['struct-threeToFourImages','sell-field-threeToFourImages'],'1:1':['struct-mainImagesGroup','sell-field-mainImagesGroup']},groups={'3:4':[],'1:1':[]};let found=0;
  for(const [aspect,ids]of Object.entries(sections)){
   let box=ids.map(id=>doc.getElementById(id)).find(Boolean);
   if(!box)for(const wrapper of doc.querySelectorAll('.sell-component-info-wrapper-wrap'))if(wrapper.querySelector('.sell-component-info-wrapper-label')?.textContent.trim()===aspect+'主图'){box=wrapper.querySelector('.sell-component-simply-materials');break;}
   if(!box)continue;found++;if(box.querySelector('.next-loading-inline.next-loading-visible'))return {ready:false,reason:'主图正在加载'};
   for(const slot of box.querySelectorAll('.drag-item')){const img=slot.querySelector('img');groups[aspect].push(img?[img.currentSrc,img.src,img.getAttribute('data-src'),img.getAttribute('data-ks-lazyload')].map(imageURL).find(Boolean)||null:null);}
  }
  return {productId:pid,ready:Object.values(groups).some(xs=>xs.some(Boolean)),groups,sections:found};
 }
 function candidates(groups,slots=[1],priority='3:4',index=0){
  const selected=[...new Set((Array.isArray(slots)?slots:[1]).map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=5))],slot=(selected.length?selected:[1])[Math.max(0,index)%Math.max(1,selected.length)],first=priority==='1:1'?'1:1':'3:4',other=first==='3:4'?'1:1':'3:4',seen=new Set(),out=[];
  for(const n of [...new Set([slot,1])])for(const aspect of [first,other]){const url=imageURL(groups?.[aspect]?.[n-1]);if(url&&!seen.has(url)){seen.add(url);out.push({url,aspect,slot:n,fallback:n!==slot||aspect!==first});}}
  return out;
 }
 root.FullVideoReference={readGroups,candidates,imageURL};if(typeof module==='object')module.exports=root.FullVideoReference;
})(globalThis);
