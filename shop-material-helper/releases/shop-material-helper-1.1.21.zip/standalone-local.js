(function(root){'use strict';
 function create(io){const C=root.MaterialIndependentCore,cut=root.MaterialCutout;const stamp=()=>new Date(io.now()).toISOString(),fail=(m,status=400)=>{throw Object.assign(Error(m),{status});};
  function validate(r){if(!r||!C.UUID.test(r.id||'')||r.consent!==true||r.productIds?.length!==1||!/^\d{6,}$/.test(r.productIds[0])||!/^\d+$/.test(r.sourceMaterialId||''))fail('透明图需要固定编号、单个商品和已有白底素材');const u=C.publicURL(r.sourceUrl);if(!/(^|\.)alicdn\.com$/.test(u.hostname)||u.href.length>2048||u.port)fail('只处理已核对的官方白底图');return {id:r.id,productIds:[...r.productIds],sourceMaterialId:r.sourceMaterialId,sourceUrl:u.href,algorithm:'edge-connected-white-v1'};}
  const publicState=s=>({id:s.id,module:'transparent',productIds:s.productIds,status:s.status,sourceMaterialId:s.sourceMaterialId,sourceUrl:s.sourceUrl,sourceSha256:s.sourceSha256||null,available:s.status==='completed'&&!!s.output,output:s.output||null,error:s.error||null,createdAt:s.createdAt,updatedAt:s.updatedAt});
  async function save(s){s.updatedAt=stamp();await io.put('cutouts',s.id,s);}
  async function createCutout(raw){const r=validate(raw),fp=await io.hash(JSON.stringify(r));return io.lock('cutout:'+r.id,async()=>{const old=await io.get('cutouts',r.id);if(old){if(old.fingerprint!==fp)fail('原抠图编号已绑定不同来源',409);return publicState(old);}if(await io.paused())fail('已暂停，未开始抠图',409);const s={...r,fingerprint:fp,status:'queued',createdAt:stamp()};await save(s);await io.wake();return publicState(s);});}
  async function processCutout(id){return io.lock('cutout:'+id,async()=>{const s=await io.get('cutouts',id);if(!s||['completed','failed'].includes(s.status)||await io.paused())return;
   try{let a=await io.get('cutoutAssets',id);if(a?.blob&&a?.source){if(await io.hash(await a.source.arrayBuffer())!==a.sourceSha256||await io.hash(await a.blob.arrayBuffer())!==a.info.sha256)throw Error('SOURCE_CHANGED');s.sourceSha256=a.sourceSha256;s.output=a.info;s.status='completed';await save(s);return;}
    let source=await io.get('cutoutSources',id);if(!source){source=await io.downloadSource(s.sourceUrl);await io.put('cutoutSources',id,source);}s.sourceSha256=await io.hash(await source.arrayBuffer());s.status='cutting';await save(s);if(await io.paused())return;
    const result=await io.cut(source,cut);if(result.blob.type!=='image/png'||result.blob.size>=3*1024*1024)throw Error('TRANSPARENT_PNG_TOO_LARGE');const info={...result.info,sha256:await io.hash(await result.blob.arrayBuffer())};
    await io.put('cutoutAssets',id,{blob:result.blob,source,sourceSha256:s.sourceSha256,info});s.output=info;s.status='completed';s.error=null;
   }catch(e){s.status='failed';s.error=['WHITE_SOURCE_MUST_BE_800','WHITE_BACKGROUND_NOT_CONFIRMED','CUTOUT_SUBJECT_OR_ALPHA_UNCONFIRMED','TRANSPARENT_PNG_TOO_LARGE','SOURCE_CHANGED'].includes(e.message)?e.message:'CUTOUT_UNCONFIRMED';}await save(s);
  });}
  async function state(id){if(!C.UUID.test(id))fail('编号无效');const s=await io.get('cutouts',id);if(!s)fail('本插件没有此抠图任务',404);return publicState(s);}
  async function artifact(id){const s=await state(id),a=await io.get('cutoutAssets',id);if(!s.available||!a?.blob||await io.hash(await a.blob.arrayBuffer())!==s.output.sha256||await io.hash(await a.source.arrayBuffer())!==s.sourceSha256)fail('透明图来源或输出校验不符',409);return {state:s,blob:a.blob,info:a.info};}
  let balance=null,pending=null;
  async function credits(){const config=await io.config();if(!config?.key)return {available:false,scope:'provider',balanceKind:'apiKey',error:'NOT_CONFIGURED'};
   if(balance?.profile===config.revision&&io.now()-balance.at<15000)return balance.value;
   if(pending?.profile===config.revision)return pending.promise;
   const promise=(async()=>{let value;try{const r=await io.fetch(config.base+'/client/openapi/getAPIKeyCredits',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({apiKey:config.key}),credentials:'omit',redirect:'error',signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error();const d=await r.json();if(d.code!==0||typeof d.data?.credits!=='number'||!Number.isFinite(d.data.credits))throw Error();value={available:true,scope:'provider',balanceKind:'apiKey',credits:d.data.credits,checkedAt:stamp()};}catch{value={available:false,scope:'provider',balanceKind:'apiKey',error:'BALANCE_UNAVAILABLE'};}balance={profile:config.revision,at:io.now(),value};return value;})();pending={profile:config.revision,promise};try{return await promise;}finally{if(pending?.promise===promise)pending=null;}
  }
  async function tick(){const s=(await io.all('cutouts')).find(x=>!['completed','failed'].includes(x.status));if(s)await processCutout(s.id);}
  return {createCutout,processCutout,state,artifact,credits,tick,validate};
 }
 root.MaterialLocal={create};if(typeof module!=='undefined')module.exports=root.MaterialLocal;
})(globalThis);
