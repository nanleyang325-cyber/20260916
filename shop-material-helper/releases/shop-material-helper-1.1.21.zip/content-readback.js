(function(root){
 'use strict';
 function extract(response,pid){
  const rows=response?.data?.model?.data;if(!Array.isArray(rows))throw new Error('搜推内容列表结构未确认。');
  const matched=rows.filter(row=>String(row.itemId)===pid);if(matched.length!==1)throw new Error('目标商品内容列表不唯一或未确认。');
  const row=matched[0],contents=Array.isArray(row.selfContents)?row.selfContents:row.selfContents==null&&Number.isInteger(row.selfContentCount)&&row.selfContentCount===0?[]:null;
  if(!contents)throw new Error('目标商品内容列表不唯一或未确认。');
  return contents.map(content=>{
   const base=content.baseInfo;if(!base||!/^\d{6,}$/.test(String(base.contentId)))throw new Error('内容ID未确认。');
   const urls=new Set();let scanned=0;
   function collect(value,depth){if(!value||typeof value!=='object'||depth>6||++scanned>2000)return;for(const [key,child]of Object.entries(value)){if(/^(?:url|fullUrl|picUrl|imageUrl|videoUrl|playUrl)$/.test(key)&&typeof child==='string'){try{const u=new URL(child.startsWith('//')?'https:'+child:child);if(u.protocol==='https:'&&(/(^|\.)alicdn\.com$/.test(u.hostname)||u.hostname==='cloud.video.taobao.com'))urls.add(u.href);}catch{}}else if(child&&typeof child==='object')collect(child,depth+1);}}
   collect(content,0);let publishedAt=null;if(typeof base.publishTime==='number'||/^\d{10,13}$/.test(String(base.publishTime||''))){const value=Number(base.publishTime);publishedAt=value<1e12?value*1000:value;}else if(typeof base.publishTime==='string'){const value=Date.parse(base.publishTime);if(Number.isFinite(value))publishedAt=value;}
   return {videoId:String(base.video?.videoId||content.video?.videoId||''),id:String(base.contentId),type:String(base.contentType??''),title:typeof base.title==='string'?base.title:'',publishedAt,urls:[...urls],productId:pid};
  });
 }
 function publicationCandidates(job,records){
  const start=Date.parse(job.publication?.submittedAt);if(!Number.isFinite(start)||job.contentBaseline?.productId!==job.productIds?.[0]||!Array.isArray(job.contentBaseline.ids)||!job.title)return [];
  return records.filter(record=>record.productId===job.productIds[0]&&(job.module!=='searchvideo'||record.type==='video')&&!job.contentBaseline.ids.includes(record.id)&&record.publishedAt>=start-10000&&record.title===job.title);
 }
 function match(job,records){
  const direct=job.module==='searchvideo'&&job.directVideoFile,proof=job.publicationProof;if(!job.publication||job.contentBaseline?.productId!==job.productIds[0]||!Array.isArray(job.contentBaseline.ids)||!job.title||(!direct&&!job.uploadedAssets?.length))return null;if(direct&&(!proof?.success||!['official-video-publish-request-and-success-response','official-video-detail-file-id-readback'].includes(proof.source)||proof.productIds?.join()!==job.productIds.join()||!/^\d{6,}$/.test(proof.videoId||'')))return null;
  if(direct&&proof.source==='official-video-detail-file-id-readback'&&(proof.fileId!==direct.fileId||proof.originalSha256!==direct.sha256.toLowerCase()))return null;
  const candidates=publicationCandidates(job,records).filter(record=>direct?record.videoId===proof.videoId&&(!proof.contentId||record.id===proof.contentId):job.uploadedAssets.every(asset=>record.urls.some(url=>url===asset.url||url.startsWith(asset.url+'_')||url.startsWith(asset.url+'?'))));
  return candidates.length===1?candidates[0]:null;
 }
 function detailProof(job,record,response){
  const expected=job.directVideoFile,data=response?.data,video=data?.video;
  if(!expected?.fileId||!/^([a-f0-9]{64})$/i.test(expected.sha256||'')||!response.ret?.some(s=>String(s).startsWith('SUCCESS::'))||data?.contentType!=='video'||String(data.id)!==record.id||video?.fileId!==expected.fileId)return null;
  const ids=Array.isArray(data.items)?data.items.map(i=>String(i.itemId)):[];if(ids.length!==1||ids.join()!==job.productIds.join())return null;
  let title;try{title=decodeURIComponent(data.shortTitle);}catch{return null;}if(title!==job.title||Math.min(Number(video.width),Number(video.height))<720||![video.width,video.height,video.duration].every(v=>Number.isFinite(Number(v))&&Number(v)>0)||Math.abs(Number(video.duration)-Number(expected.duration))>1)return null;
  return {source:'official-video-detail-file-id-readback',success:true,contentId:record.id,videoId:record.videoId,productIds:ids,fileId:expected.fileId,originalSha256:expected.sha256.toLowerCase(),width:Number(video.width),height:Number(video.height),duration:Number(video.duration),checkedAt:new Date().toISOString()};
 }
 async function request(job,action){
  if(!['search','searchvideo'].includes(job.module)||job.productIds?.length!==1||!/^\d{6,}$/.test(job.productIds[0]))throw new Error('搜推回查需一个明确商品ID。');
  if(!root.lib?.mtop?.request)throw new Error('平台内容查询组件未就绪。');
  const pid=job.productIds[0],response=await root.lib.mtop.request({api:'mtop.taobao.feeds.material.item.list',v:'1.0',type:'GET',dataType:'json',data:{pageNo:1,pageSize:10,scene:'material_center',condition:JSON.stringify({itemIds:[pid]}),orderBys:'',source:'qn_material_center'}});
  const records=extract(response,pid);
  if(action==='baseline'){if(job.publication)throw new Error('已有提交记录，不能重建发布前基线。');return {ok:true,status:'prepared',contentBaseline:{productId:pid,ids:records.map(record=>record.id),capturedAt:new Date().toISOString()}};}
  if(action!=='verify')throw new Error('未知内容回查操作。');
  let verificationJob=job,sourceProof;
  if(job.module==='searchvideo'&&job.directVideoFile&&!match(job,records)){
   const candidates=publicationCandidates(job,records);
   if(candidates.length===1){const candidate=candidates[0],detail=await root.lib.mtop.request({api:'mtop.taobao.spongebob.item.material.get',v:'1.0',type:'GET',dataType:'json',data:{contentId:candidate.id}});sourceProof=detailProof(job,candidate,detail);if(sourceProof)verificationJob={...job,publicationProof:sourceProof};}
  }
  const record=match(verificationJob,records);if(!record){const candidates=publicationCandidates(job,records),validContext=Number.isFinite(Date.parse(job.publication?.submittedAt))&&job.contentBaseline?.productId===pid&&Array.isArray(job.contentBaseline.ids)&&!!job.title&&!!job.uploadedAssets?.length;
   return {ok:true,status:'submitted_unconfirmed',code:candidates.length>1?'CONTENT_MATCH_AMBIGUOUS':candidates.length?'CONTENT_SOURCE_MISMATCH':'CONTENT_NOT_VISIBLE',retryable:job.module==='search'&&validContext&&candidates.length===0,readbackEvidence:{recordCount:records.length,candidateCount:candidates.length,requestedImageCount:job.uploadedAssets?.length||0},message:'未查到与本次商品、标题、时间和素材来源唯一匹配的发布记录；原表单与提交意图已保留。请检查表单内的平台提示，继续时仅回查，不重新生成或提交。'};
  }
  return {ok:true,status:'verified',receipt:{source:'platform-readback',contentId:record.id,...(record.videoId?{videoId:record.videoId}:{}),...(sourceProof?{videoSourceProof:sourceProof}:{}),productIds:[pid],status:'已发布（审核状态未确认）',publishedAt:record.publishedAt,url:location.origin+location.pathname}};
 }
 root.FullContent={extract,match,detailProof,request};if(typeof module!=='undefined')module.exports=root.FullContent;
})(globalThis);
