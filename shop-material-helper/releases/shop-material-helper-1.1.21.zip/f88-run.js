(function(root){
 'use strict';
 const C=()=>root.FullF88Core;
 const scope=run=>JSON.stringify(run.selection);
 function create(input){const selection=C().settings(input);if(!selection.enabled)throw Error('请先开启 F88 模式；普通店铺不要开启。');if(!selection.consent)throw Error('请确认本批生成费用及参考图发送。');if(selection.delivery==='platform'&&!selection.platformConsent)throw Error('请确认本批平台暂存/发布和同步范围。');const run={id:root.crypto.randomUUID(),selection,enabled:true,status:'running',phase:'discover',position:0,suitePosition:0,products:[],suites:[],usedCalls:0,events:[],createdAt:new Date().toISOString()};run.consentScope=scope(run);return run;}
 function validReceipt(suite,delivery,result){return result?.status==='verified'&&result.receipt?.source==='platform-readback'&&result.receipt.platformId===suite.platformId&&result.receipt.section===delivery.section&&!!result.receipt.contentId&&Array.isArray(result.receipt.imageUrls)&&delivery.upload?.urls?.length===result.receipt.imageUrls.length&&delivery.upload.urls.every(u=>result.receipt.imageUrls.includes(u))&&(delivery.section!=='buyer'||result.receipt.orderId===suite.orderId);}
 async function advance(run,io){
  if(!run.enabled)return;
  const save=async detail=>{run.events.push({at:new Date().toISOString(),detail});await io.save(run);};
  const check=async()=>{if(run.consentScope!==scope(run))throw Error('F88 原范围或预算已改变。');if(!await io.isLive(run))throw Object.assign(Error('F88 已暂停或停止，保留原任务。'),{stopped:true});};
  const stop=async()=>{run.enabled=false;run.status='drained';await save('已收尾；没有启动新的付费素材。');};
  try{
   await check();
   if(run.phase==='discover'){
    if(run.draining)return stop();const ids=await io.discover(run);await check();run.products=C().ids(ids);if(run.selection.mode==='ids'&&run.products.some(id=>!run.selection.ids.includes(id)))throw Error('F88 发现结果超出指定商品范围。');run.phase='prepare';await save('已保存本轮平台商品范围。');return;
   }
   if(run.phase==='prepare'){
    if(run.draining)return stop();const id=run.products[run.position];if(!id){run.enabled=false;run.status='done';await save('本轮结束，逐品生成与平台结果分别保留。');return;}
    const snapshot=await io.inspect(run,id);await check();if(snapshot.platformId!==id)throw Error('F88 检查商品与目标不一致。');
    const suites=C().planProduct(run.selection,snapshot,run.position);if(run.usedCalls+suites.length>run.selection.maxCalls)throw Error('剩余预算不足该商品整批套数，未生成。');
    if(!suites.length){run.position++;await save('目标商品没有需补套数，跳过。');return;}
    run.suites.push(...suites);run.phase='suites';await save('已固化本品色号、风格、素材编号及可用配额。');return;
   }
   const suite=run.suites[run.suitePosition];if(!suite){run.phase='prepare';run.position++;await save('当前商品各套已处理。');return;}
   const next=async(status,detail)=>{suite.status=status;suite.phase='done';run.suitePosition++;if(run.suitePosition===run.suites.length){run.phase='prepare';run.position++;}await save(detail);};
   if(suite.phase==='preflight'){
    if(run.draining)return stop();await io.preflight(run,suite);await check();suite.phase='generate';await save('费用前再次核对商品、色号、配额及空框。');return;
   }
   if(suite.phase==='generate'){
    if(!suite.generationIntent){
     if(run.draining)return stop();if(run.usedCalls>=run.selection.maxCalls)throw Error('本批调用上限已达。');
     const reference=await io.reference(run,suite);await check();suite.request=C().request(run.selection,suite,reference);suite.generationIntent={id:suite.mediaId,batchId:suite.hostBatchId,at:new Date().toISOString()};run.usedCalls++;await save('先登记原素材编号，再提交一套九宫格生成。');await check();await io.generate(run,suite);return;
    }
    const media=await io.query(run,suite);await check();if(media.id!==suite.mediaId||media.media!=='image'||JSON.stringify(media.productIds)!==JSON.stringify([suite.platformId]))throw Error('原素材编号或商品身份不符。');
    if(media.status==='completed'&&media.available===true){delete suite.request;suite.phase='split';await save('原九宫格母图已由主机验证。');return;}
    if(['failed','submission_unconfirmed','downloaded_unverified','not_completed','missing'].includes(media.status))throw Error('原生成结果未确认，保留编号，不重新生图。');await save('原生成仍在处理，仅查询原编号。');return;
   }
   if(suite.phase==='split'){
    suite.images=await io.split(run,suite);await check();if(suite.images.length!==9||suite.images.some(im=>!im.id||!/^data:image\/png;base64,/.test(im.data)))throw Error('九宫格切图未完整验证。');
    if(run.selection.delivery==='generate')return next('generated','本套AI模拟图已生成，可导出；没有写入平台。');
    suite.phase='deliver';await save('已切出9张；买家秀使用前5张，独立搜推使用9张。');return;
   }
   if(suite.phase==='deliver'||suite.phase==='sync'){
    const syncing=suite.phase==='sync',delivery=syncing?suite.sync:suite.delivery;
    const images=suite.images.slice(0,C().imageCount(delivery.section,syncing));
    if(delivery.phase==='upload'){
     if(delivery.uploadIntent){delivery.upload=await io.recoverUpload(run,suite,delivery,images);await check();}
     else{await io.beforeUpload(run,suite,delivery,images);await check();delivery.uploadIntent={at:new Date().toISOString(),imageIds:images.map(im=>im.id)};await save('持久登记本套上传意图；中断后不盲目复传。');await check();delivery.upload=await io.upload(run,suite,delivery,images);await check();}
     if(!delivery.upload||delivery.upload.platformId!==suite.platformId||delivery.upload.section!==delivery.section||delivery.upload.urls?.length!==images.length)throw Error('平台上传图片与本套范围未完整核验。');
     delivery.phase='publish';await save('本套图片及平台表单已核验。');return;
    }
    if(delivery.phase==='publish'){
     if(delivery.publication){delivery.phase='readback';await save('恢复原提交意图，只回查，不重交。');return;}
     await io.preSubmit(run,suite,delivery);await check();delivery.publication={id:root.crypto.randomUUID(),at:new Date().toISOString()};delivery.phase='readback';await save('持久登记单次平台提交意图。');await check();await io.publish(run,suite,delivery);return;
    }
    const result=await io.readback(run,suite,delivery);await check();if(!validReceipt(suite,delivery,result))throw Error(result?.message||'平台结果没有精确读回本套商品及图片，保留原提交编号。');
    delivery.receipt=result.receipt;delivery.phase='verified';
    if(!syncing&&C().syncAllowed(run.selection,suite)){suite.sync={section:'seeding',phase:'upload',reusedFrom:suite.id};suite.phase='sync';await save('本套买家秀已核验，复用同5图同步搜推，不新增生成。');return;}
    return next('verified',syncing?'买家秀及5图同步均已核验。':'本套平台结果已核验。');
   }
   throw Error('F88 执行阶段无效。');
  }catch(error){run.enabled=false;run.status=error.stopped?'stopped':'blocked';run.error=error.message;await save(error.message);}
 }
 root.FullF88Run={create,scope,advance,validReceipt};if(typeof module==='object')module.exports=root.FullF88Run;
})(globalThis);
