(function(root){
 'use strict';
 // Declarative, independently authored behavior contracts. This module performs no IO.
 const MODULES=Object.freeze(['white','transparent','scene','buyer','mainvideo','fission','outfit','search','searchvideo','trend','selling','incubate','guanghe','follow']);
 const SOURCES=Object.freeze({
  white:'popup.js:2778-2913;content.js:3215-3277,3537-3569',
  scene:'popup.js:2916-3063',buyer:'popup.js:6199-6214',mainvideo:'popup.js:4095-4220',
  fission:'popup.js:6147-6177',outfit:'popup.js:6181-6196',search:'popup.js:2147-2667',
  searchvideo:'popup.js:3066-3149',trend:'popup.js:1570-1575;trend_submit.js:805-840',
  selling:'popup.js:4233-4265;material_tending.js:880-920;xinpin_series.js:242',
  incubate:'popup.js:1590-1595;xinpin_incubate.js:895-900',
  guanghe:'popup.js:3907-4440',follow:'popup.js:4440-4586;follow_ops_util.js:38-46;follow_ops.js:380-411'
 });
 function freeze(value){if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value);}return value;}
 function fail(code,message){const e=new Error(message);e.code=code;throw e;}
 function pick(value,allowed,fallback){if(value===undefined||value===null||value==='')return fallback;if(!allowed.includes(value))fail('INVALID_SELECTION','不支持的选项：'+value);return value;}
 function ids(input){
  if(input===undefined||input===null||input==='')return [];
  const raw=Array.isArray(input)?input:String(input).normalize('NFKC').split(/[\s,，;；、]+/);
  const result=[];
  for(const item of raw){const token=String(item).trim();if(!token)continue;let id=token;
   if(!/^\d{6,}$/.test(id)){try{const u=new URL(token);if(!/^https?:$/.test(u.protocol)||!/(^|\.)(taobao\.com|tmall\.com|1688\.com)$/.test(u.hostname))throw 0;id=u.searchParams.get('id')||u.pathname.match(/\/offer\/(\d+)\.html/)?.[1];}catch{fail('INVALID_ID','商品 ID 或链接无效');}}
   if(!/^\d{6,}$/.test(id||''))fail('INVALID_ID','商品 ID 或链接无效');if(!result.includes(id))result.push(id);
  }return result;
 }
 function positive(value,fallback,max=100){const n=value===undefined?fallback:Number(value);if(!Number.isInteger(n)||n<1||n>max)fail('INVALID_LIMIT','数量须为 1 至 '+max+' 的整数');return n;}
 function date(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value||''))fail('INVALID_DATE','日期须为 YYYY-MM-DD');const d=new Date(value+'T00:00:00Z');if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==value)fail('INVALID_DATE','日期不存在');return value;}
 function range(s){const from=date(s.dateFrom),to=date(s.dateTo||s.dateFrom);if(from>to)fail('INVALID_DATE','开始日期不得晚于结束日期');return {type:'date',dateFrom:from,dateTo:to,expandOnFailure:false};}
 function scope(s,mode){return mode==='ids'?{type:'ids',ids:ids(s.ids),expandOnFailure:false}:{type:'all',missingOnly:true,expandOnFailure:false};}
 function step(id,effect='read',requires=[],success='明确返回并核对目标身份'){return {id,effect,requires,success,unknown:effect==='publish'||effect==='delete'||effect==='generate'?'persist_unknown_and_readback':'halt_without_scope_expansion',retry:effect==='publish'||effect==='delete'||effect==='generate'?'readback_before_retry':'same_scope_only'};}
 const guard=()=>[
  step('verify_shop_and_scope','read',['shopId','scope'],'当前店铺与请求范围一致'),
  step('load_checkpoint','read',['runId'],'读回既有生成、上传、提交记录；已提交及未知不得重复发起'),
  step('acquire_run_lock','local-write',['runId'],'同店铺同流程不存在活跃重复轮次')
 ];
 const conclude=()=>[
  step('aggregate_item_results','local-write',[],'成功/失败/跳过/未知分别统计，轮次结束不代表全部成功'),
  step('persist_checkpoint','local-write',[],'持久保存范围、逐项结果和未确认记录')
 ];
 const submit=kind=>[
  step('check_submission_ledger','read',['shopId','productIdentity'],'若已有提交或未知记录，只回查而不再点击'),
  step('persist_submission_intent','local-write',['idempotencyKey'],'先持久记录意图，后执行一次提交'),
  step('submit_'+kind,'publish',['submissionIntent'],'仅向当前核对目标执行一次提交'),
  step('readback_'+kind,'read',['submissionIntent'],'平台目标 ID、商品集合、内容/槽位结果与请求一致；超时/关框不算成功')
 ];
 function base(module){if(!MODULES.includes(module))fail('UNKNOWN_MODULE','未知模块');return {version:1,module,evidence:{type:'static-package-contract',source:SOURCES[module],runtimeAccepted:false},kind:null,entry:null,choices:[],fields:[],requiredInputs:[],scope:null,permissions:{readShop:false,paidGeneration:'none',platformWrite:[],replaceExisting:false,createProduct:false,executionAuthorized:false},steps:[],skip:[],errors:['wrong_shop','target_identity_conflict','scope_discovery_unconfirmed','duplicate_run','submission_unconfirmed'],readback:{mustMatch:['shopId','productIds'],unknownIsSuccess:false,repeatSubmission:'forbidden_until_verified_absent'},controls:{pause:'at_step_boundary',stop:'stop_new_work_and_drain_existing',forceStop:'persist_inflight_then_stop',resume:'read_checkpoint_before_new_work'}};}
 function menu(c,entry,choices){c.kind='menu';c.entry=entry;c.choices=choices;return freeze(c);}
 function form(c,entry,fields){c.kind='form';c.entry=entry;c.fields=fields;c.requiredInputs=fields.filter(f=>f.required).map(f=>f.name);return freeze(c);}
 function missingIds(c,s,entry,extra=[]){if(!ids(s.ids).length)return form(c,entry,[{name:'ids',required:true,type:'productIds'},...extra]);return null;}
 function run(c,s,actions,options={}){
  c.kind='run';c.entry=options.entry||'automatic';
  c.permissions.readShop=true;c.requiredInputs=['shopId','runId','startConsent',...(options.inputs||[])];
  c.permissions.platformWrite=options.writes||[];c.permissions.paidGeneration=options.paid||'none';
  if(c.scope?.type==='ids')c.requiredInputs.push('ids');
  if(c.scope?.type==='date')c.requiredInputs.push('dateFrom','dateTo');
  if(c.permissions.paidGeneration==='conditional')c.requiredInputs.push('generationPolicy','authorizedCallBudget');
  c.requiredInputs=[...new Set(c.requiredInputs)];
  c.parameters={prompt:typeof s.prompt==='string'?s.prompt:'',source:c.source||null,variant:c.variant||null};
  if(c.variant==='replica'){c.parameters.referenceCount=s.references.length;c.requiredInputs.push('references');}
  // The plan describes effects; caller must still enforce current user authorization.
  c.steps=[...guard(),...actions,...conclude()];return freeze(c);
 }
 function resolve(module,selection={}){
  const s={...selection},c=base(module);
  if(module==='transparent'){
   c.evidence={type:'independently-authored-module',source:'transparent-run.js;background-transparent.js',runtimeAccepted:false};
   const mode=pick(s.mode,['all','ids'],null);if(!mode)return menu(c,'transparent_scope',[{value:'all',label:'全量补缺'},{value:'ids',label:'自定义商品 ID'},{value:'review',label:'重做审核不通过'}]);
   if(mode==='ids'){const empty=missingIds(c,s,'transparent_ids');if(empty)return empty;}
   c.scope=scope(s,mode);c.source='existing_white';c.permissions.replaceExisting=s.reviewRejected===true;c.skip=['not_on_sale','non_physical','missing_white','rejected_white',s.reviewRejected?'pending_or_approved':'existing_transparent'];
   return run(c,s,[step('read_exact_transparent_and_white','read',['scope'],'只读取同商品现有白底图和透明图审核记录'),step('cut_edge_connected_white_locally','local-write',['sourceWhiteMaterialId'],'本地输出真实透明PNG，保留内部白色，不触发付费生图'),step('validate_800_png_alpha','read',['artifactId'],'800×800、小于3MB、透明通道及主体边界检查'),step('lookup_unique_png_before_upload','read',['artifactId'],'复用固定文件名，未知上传不重投'),step('upload_transparent_png','upload',['artifactId']),...submit('transparent_slot')],{entry:'transparent_start',writes:['upload_image',s.reviewRejected?'replace_rejected_transparent_slot':'bind_transparent_empty_slot'],paid:'none',inputs:mode==='ids'?['ids']:[]});
  }
  if(module==='buyer'||module==='outfit'){
   c.kind='web';c.entry='new_tab';c.route=module==='buyer'?'buyer.html':'outfit-workbench';c.routeKind=module==='buyer'?'extension-page':'logical-workspace-key';c.requiredInputs=[];
   c.steps=[step('open_own_'+module+'_workbench','navigation',[],'打开自研对应网页板块，保留既有历史，不调用生成')];return freeze(c);
  }
  if(module==='fission'){
   const empty=missingIds(c,s,'link_form');if(empty)return empty;
   c.kind='web';c.entry='link_form';c.scope={type:'ids',ids:ids(s.ids),expandOnFailure:false};c.route='fission-workbench';c.routeKind='logical-workspace-key';
   c.fields=[{name:'ids',required:true,type:'productIdsOrLinks'}];
   c.steps=[step('validate_kickoff_items','read',['ids'],'只保留指定有效商品'),
    step('open_own_fission_workbench','navigation',['ids'],'携带指定输入进入自研工作台，后续新增/替换另行授权')];
   c.requiredInputs=['ids'];return freeze(c);
  }
  if(module==='white'||module==='scene'){
   const mode=pick(s.mode,['all','ids'],null);
   if(!mode)return menu(c,'run_scope',[{value:'all',label:'全量跑'},{value:'ids',label:'自定义商品 ID'}]);
   if(mode==='ids'){const empty=missingIds(c,s,'id_form');if(empty)return empty;}
   c.scope=scope(s,mode);c.skip=['existing_slot','warehouse_or_off_sale','not_found'];
   c.source=module==='white'?pick(s.source,['ai_generate','image_space_size','detail_main_image','detail_sku_image'],'ai_generate'):pick(s.source,['banana_pro','taobao_ai'],'banana_pro');
   if(module==='white'&&s.reviewRejected===true){c.source='ai_generate';c.permissions.replaceExisting=true;c.skip=['not_explicitly_rejected','pending_or_approved','warehouse_or_off_sale','non_physical_after_sale','same_rejected_source_already_claimed'];return run(c,s,[step('read_official_review_and_reason','read',['scope'],'核对商品ID、失败素材ID、审核时间及明确不通过状态'),step('persist_one_retry_identity','local-write',['originalMaterialId'],'每件一次新生成，未知提交只查原编号'),step('generate_rejection_specific_white','generate',['productReference','rejectionReason'],'完整单主体、无营销贴片，保留商品外观'),step('recheck_same_rejected_material','read',['originalMaterialId'],'提交前再次核对仍是同一失败素材；待审核或通过不得覆盖'),...submit('rejected_white_slot')],{entry:'review_rejected_start',writes:['upload_image','replace_rejected_white_slot'],paid:'conditional',inputs:mode==='ids'?['ids']:[]});}
   return run(c,s,[
    step(mode==='ids'?'search_each_exact_id':'discover_missing_slots','read',['scope'],'每次搜索核对商品 ID；检索失败停止，不改扫全店'),
    step('skip_existing_and_ineligible','read',[],'已有素材及下架商品不生成不覆盖'),
    step('read_product_reference','read',['productIdentity'],'图片来自核对商品及已选来源'),
    step('reuse_or_generate_'+module,c.source==='ai_generate'||c.source==='banana_pro'?'generate':'read',['generationLedger'],'优先复用既有任务；有费用须先检查额度与本批授权'),
    step('validate_generated_asset','read',['assetId'],'素材可解码且商品一致性满足当前策略'),
    step('lookup_existing_upload','read',['assetId'],'优先复用既有上传编号，结果未知不再次上传'),
    step('upload_if_absent','upload',['assetId'],'仅平台明确无该素材时上传'),
    ...submit(module+'_slot')
   ],{entry:mode==='ids'?'id_form_start':'all_start',writes:['upload_image','bind_'+module+'_empty_slot'],paid:c.source==='ai_generate'||c.source==='banana_pro'?'conditional':'none',inputs:mode==='ids'?['ids']:[]});
  }
  if(module==='mainvideo'){
   const empty=missingIds(c,s,'video_batch_form',[{name:'prompt',required:false,type:'text'}]);if(empty)return empty;
   c.scope=scope(s,'ids');c.skip=['off_sale','not_found','already_submitted'];
   return run(c,s,[step('show_seeded_progress','local-write',['ids'],'在后台启动前展示所有输入商品的进度'),
    step('resolve_product_references','read',['ids']),step('reuse_or_generate_video','generate',['generationLedger'],'恢复已提交/已成品任务，禁止重复扣费'),
    step('validate_video','read',['assetId'],'视频可解码且符合目标商品'),step('lookup_existing_upload','read',['assetId']),
    step('upload_video_if_absent','upload',['assetId']),...submit('product_video')],{entry:'video_batch_start',writes:['upload_video','publish_product_video'],paid:'conditional',inputs:['ids']});
  }
  if(module==='trend'||module==='incubate'){
   c.scope={type:'platform_eligible_list',expandOnFailure:false};c.skip=['already_processed','not_eligible'];
   const actions=module==='trend'?[
    step('open_trend_page','navigation'),step('scan_sections_and_trends','read'),
    step('select_eligible_products','read',[],'只选择当前趋势中可提报且未提报商品'),...submit('trend'),
    step('advance_verified_page','navigation',[],'逐页处理；翻页未确认停止该分区；连续失败熔断')
   ]:[step('open_incubation_page','navigation'),step('scan_awaiting_registration','read'),
    step('open_registration_drawer','navigation',['productIdentity']),step('select_date_and_up_to_five_tags','local-write'),
    ...submit('incubation'),step('advance_next_eligible_product','read',[],'报名按钮变查看记录或明确报名结果后继续')];
   return run(c,s,actions,{writes:[module==='trend'?'submit_trend':'register_incubation']});
  }
  if(module==='selling'){
   const variant=pick(s.variant,['selling','series'],null);if(!variant)return menu(c,'selling_kind',[{value:'selling',label:'新品素材卖点'},{value:'series',label:'系列新品内容'}]);
   c.variant=variant;c.scope={type:'platform_eligible_list',expandOnFailure:false};c.skip=variant==='series'?['already_published','unknown_status']:['already_maintained'];
   const actions=variant==='selling'?[step('open_material_tending_page','navigation'),step('scan_pending_selling_points','read'),
    step('trigger_platform_copy_and_wait','platform-action',[],'平台智能生成；不可用时只用已核对标题进行约束补齐'),
    step('fill_validated_short_and_long_points','platform-action'),...submit('selling_points')]:
    [step('open_all_new_products_page','navigation'),step('skip_published_or_ambiguous_rows','read'),
     step('prepare_series_content','platform-action'),...submit('series_content')];
   return run(c,s,actions,{writes:[variant==='selling'?'maintain_selling_points':'publish_series_content']});
  }
  if(module==='search'||module==='searchvideo'){
   const mode=pick(s.mode,module==='search'?['all','ids','date','replica','cleanup']:['all','ids'],'all');
   if(mode==='cleanup')return cleanup(c,s);
   if(mode==='ids'||mode==='replica'){const empty=missingIds(c,s,'id_form',mode==='replica'?[{name:'references',required:true,type:'images'}]:[]);if(empty)return empty;}
   if(mode==='date'&&!s.dateFrom)return form(c,'date_form',[{name:'dateFrom',required:true,type:'date'},{name:'dateTo',required:false,type:'date'}]);
   if(mode==='replica'&&(!Array.isArray(s.references)||!s.references.length))return form(c,'replica_form',[{name:'ids',required:true,type:'productIds'},{name:'references',required:true,type:'images'}]);
   c.scope=mode==='date'?range(s):scope(s,mode==='replica'?'ids':mode);c.variant=mode;c.skip=['full_slots','off_sale','not_found','processed_ledger'];
   return run(c,s,[step('clear_stale_cross_module_scope','local-write',[],'每轮显式保存本模块范围，关闭另一模块/旧复刻标记'),
    ...(mode==='replica'?[step('verify_replica_capability_and_price','read',['references'])]:[]),
    step(mode==='date'?'discover_products_by_listing_date':mode==='all'?'scan_recommendation_products':'search_each_exact_id','read',['scope']),
    step('recover_inflight_before_new_generation','read',['generationLedger']),
    step('read_empty_slots_and_source_policy','read',[],'条数、来源、AI开关沿设置；只有空槽需要素材'),
    step('reuse_or_generate_recommendation','generate',['generationLedger'],'参考图/任务ID绑定商品，当前授权不足则停止新生成'),
    step('validate_asset_and_upload_ledger','read'),step('upload_missing_assets','upload'),...submit(module==='search'?'recommendation_article':'recommendation_video')
   ],{writes:['upload_media',module==='search'?'publish_recommendation_article':'publish_recommendation_video'],paid:'conditional'});
  }
  if(module==='guanghe'){
   const variant=pick(s.variant,['pic','video'],null);if(!variant)return menu(c,'content_kind',[{value:'pic',label:'图文'},{value:'video',label:'视频'}]);c.variant=variant;
   const mode=pick(s.mode,['date','ids'],null);if(!mode)return menu(c,'product_source',[{value:'date',label:'按上架日期'},{value:'ids',label:'按商品 ID'}]);
   if(mode==='ids'){const empty=missingIds(c,s,'id_form');if(empty)return empty;c.scope=scope(s,'ids');}
   else {if(!s.dateFrom)return form(c,'date_form',[{name:'dateFrom',required:true,type:'date'},{name:'dateTo',required:false,type:'date'}]);c.scope=range(s);}
   c.skip=['already_published_today','not_found','not_eligible'];
   return run(c,s,[step('discover_guanghe_products','read',['scope']),step('filter_daily_publication_ledger','read'),
    step('calculate_eligible_budget','read',[],'依据本轮真实价格和授权次数，额度不足不开新任务'),
    step('reuse_or_generate_guanghe_'+variant,'generate',['generationLedger']),step('validate_asset_and_upload_ledger','read'),
    step('upload_missing_assets','upload'),...submit('guanghe_'+variant)],{writes:['upload_media','publish_guanghe_'+variant],paid:'conditional'});
  }
  if(module==='follow'){
   const variant=pick(s.variant,['multi','list'],null);if(!variant)return menu(c,'post_kind',[{value:'multi',label:'多品上新'},{value:'list',label:'清单'}]);
   c.variant=variant;c.groupSize=variant==='multi'?4:3;
   const mode=pick(s.mode,['auto','ids'],null);if(!mode)return form(c,'product_source',[{name:'mode',required:true,type:'autoOrIds'},{name:'maxPosts',required:false,type:'integer'},{name:'ids',required:false,type:'productIds'}]);
   if(mode==='ids'){const empty=missingIds(c,s,'id_form');if(empty)return empty;c.scope=scope(s,'ids');if(c.scope.ids.length<c.groupSize)fail('INSUFFICIENT_GROUP','商品数不足一帖');c.ignoredTail=c.scope.ids.slice(c.scope.ids.length-c.scope.ids.length%c.groupSize);}
   else c.scope={type:'auto_list',tab:variant==='multi'?'上新':'全部商品',maxPosts:positive(s.maxPosts,10,20),expandOnFailure:false};
   c.skip=['already_published_today','not_found','ambiguous_product','platform_requires_modification','incomplete_group'];
   return run(c,s,[step('settle_orphan_publication_as_unknown','local-write',[],'点过发布未结算的旧帖记未知，不当成未发'),
    step('open_follow_'+variant+'_publisher','navigation'),step('select_next_complete_group','platform-action',['scope'],'多品上新每帖4款，清单每帖3款；尾数不发'),
    step('request_platform_copy_inspiration','platform-action'),step('generate_copy_only_if_inspiration_absent','generate',['generationLedger'],'平台灵感优先；AI费用须在当前授权内'),
    ...submit('follow_post'),step('reload_next_post','navigation',[],'先持久记本帖商品和结果，再刷新执行下一帖')],{writes:['publish_follow_post'],paid:'conditional'});
  }
  fail('UNKNOWN_BRANCH','没有对应执行分支');
 }
 function cleanup(c,s){
  const criteria=s.criteria;
  if(!criteria)return form(c,'cleanup_form',[{name:'criteria',required:true,type:'cleanupCriteria'},{name:'dryRun',required:true,type:'boolean'}]);
  const target=pick(criteria.scope,['all','ids','duplicates'],'all');
  if(typeof s.dryRun!=='boolean')fail('DRY_RUN_REQUIRED','清理必须明确演练或实际删除');
  const exposure=Number(criteria.exposure),days=Number(criteria.days);
  if(target!=='duplicates'&&(!Number.isInteger(exposure)||exposure<0||!Number.isInteger(days)||days<0))fail('INVALID_CRITERIA','曝光和天数须为非负整数');
  if(target!=='duplicates'&&criteria.article!==true&&criteria.video!==true)fail('INVALID_CRITERIA','至少选择一种素材类型');
  c.scope=target==='ids'?scope(criteria,'ids'):{type:target,expandOnFailure:false};
  if(target==='ids'&&!c.scope.ids.length)fail('INVALID_ID','自定义清理须填写商品 ID');
  c.variant='cleanup';c.dryRun=s.dryRun;c.criteria={scope:target,exposure:target==='duplicates'?null:exposure,days:target==='duplicates'?null:days,article:criteria.article===true,video:criteria.video===true,includeFeatured:criteria.includeFeatured===true};
  c.skip=['outside_scope','criteria_not_matched','featured_unless_selected'];
  return run(c,s,[step('scan_cleanup_candidates','read',['scope']),step('verify_all_cleanup_conditions','read',[],'逐项核对范围、曝光、天数、类型、精选；重复模式需内容指纹证据'),
   step('persist_cleanup_preview','local-write',[],'保存精确命中列表和依据'),
   ...(s.dryRun?[]:[step('check_deletion_ledger','read'),step('persist_deletion_intent','local-write'),step('delete_matching_materials_once','delete',['deletionIntent'],'仅删除当前明确授权清单'),step('readback_deletion','read',[],'平台明确不存在该素材才能确认，未知不重复删除')])
  ],{entry:s.dryRun?'cleanup_dry_run':'cleanup_start',writes:s.dryRun?[]:['delete_recommendation_materials']});
 }
 const api=freeze({MODULES,SOURCES,resolve,parseIds:ids});
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.FullButtonContracts=api;
})(typeof globalThis==='object'?globalThis:this);

