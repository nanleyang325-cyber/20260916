(function(root){
 const button=document.getElementById('btnOpenLogDetails');if(!button)return;
 button.onclick=async()=>{if(button.disabled)return;button.disabled=true;try{const result=await chrome.runtime.sendMessage({type:'FULL_OPEN_LOG_DETAILS',runId:root.FullPopupUi?.currentRun?.id,view:root.FullWhiteJournalUI?.selected||'progress'});if(!result?.ok)throw Error();button.title='日志详情已在独立窗口打开';}catch{button.title='日志详情未能打开，请重试';}finally{button.disabled=false;}};
})(globalThis);
