(function(root){
 'use strict';
 const pause=ms=>new Promise(r=>setTimeout(r,ms));
 const leases=new Map(),disconnected=e=>/Debugger is not attached to the tab/i.test(String(e?.message||''));
 async function session(target,work,policy={}){
  if(!Number.isInteger(target?.tabId)||!Number.isInteger(target.frameId))throw Error('输入目标缺少本轮标签页和表单归属。');
  const previous=leases.get(target.tabId)||Promise.resolve();let release;const turn=new Promise(r=>release=r),tail=previous.catch(()=>{}).then(()=>turn);leases.set(target.tabId,tail);await previous.catch(()=>{});
  let originalURL;
  try{for(let attempt=0;attempt<2;attempt++){
   const tracker={expectedURL:originalURL,workStarted:false,detached:false};
   try{const result=await sessionAttempt(target,work,tracker);return attempt&&result&&typeof result==='object'&&!Array.isArray(result)?{...result,inputRecovery:{reattachments:attempt,operation:policy.operation||'prepare-session'}}:result;}
   catch(error){
    if(/Another debugger is already attached|already attached to this tab/i.test(String(error.message)))throw Object.assign(Error('浏览器输入连接被其他调试客户端占用；未夺取连接或重复操作，请关闭该客户端后继续原任务。'),{code:'INPUT_SESSION_BUSY'});
    if(error.code==='INPUT_TARGET_CHANGED')throw error;
    if(!disconnected(error)&&!tracker.detached)throw error;
    originalURL||=tracker.url;
    if(attempt===0&&originalURL&&!/user|devtools/i.test(tracker.detachReason||'')&&(!tracker.workStarted||policy.restartSafe===true)){
     const [{result:current}]=await chrome.scripting.executeScript({target:{tabId:target.tabId,frameIds:[target.frameId]},func:()=>location.href});
     if(current!==originalURL)throw Object.assign(Error('原输入标签页或表单地址已改变，未接管其他页面。'),{code:'INPUT_TARGET_CHANGED'});
     if(policy.verifyRecovery)await policy.verifyRecovery();
     continue;
    }
    throw Object.assign(Error('浏览器输入连接已中断；保留原素材与提交记录。继续原任务时，有发布意图的只回查，不重新生成或提交。'),{code:'INPUT_SESSION_INTERRUPTED'});
   }
  }}finally{release();if(leases.get(target.tabId)===tail)leases.delete(target.tabId);}
 }
 async function sessionAttempt(target,work,tracker){
  if(!Number.isInteger(target?.tabId)||!Number.isInteger(target.frameId))throw Error('输入目标缺少本轮标签页和表单归属。');
  const [{result:url}]=await chrome.scripting.executeScript({target:{tabId:target.tabId,frameIds:[target.frameId]},func:()=>location.href});
  tracker.url=url;if(tracker.expectedURL&&tracker.expectedURL!==url)throw Object.assign(Error('原输入标签页或表单地址已改变，未接管其他页面。'),{code:'INPUT_TARGET_CHANGED'});
  const u=new URL(url);if(u.protocol!=='https:'||!/(^|\.)(taobao|tmall)\.com$/.test(u.hostname))throw Error('输入目标不是官方店铺表单。');
  const tab={tabId:target.tabId},contexts=[],tasks=[],sessions=new Set();let childError;
  const send=(scope,method,params={})=>chrome.debugger.sendCommand(scope,method,params);
  async function enable(scope){await send(scope,'Runtime.enable');await send(scope,'Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:false,flatten:true,filter:[{type:'iframe',exclude:false}]});}
  function event(source,method,p){if(source.tabId!==tab.tabId)return;if(method==='Runtime.executionContextCreated'&&p.context?.auxData?.isDefault)contexts.push({scope:{...source},id:p.context.id});if(method==='Runtime.executionContextDestroyed'){const i=contexts.findIndex(c=>c.id===p.executionContextId&&c.scope.sessionId===source.sessionId);if(i>=0)contexts.splice(i,1);}if(method==='Target.attachedToTarget'&&p.targetInfo?.type==='iframe'&&!sessions.has(p.sessionId)){sessions.add(p.sessionId);const scope={tabId:tab.tabId,sessionId:p.sessionId};tasks.push(enable(scope).catch(error=>{childError||=error;}));}}
  chrome.debugger.onEvent.addListener(event);let attached=false,closing=false;
  function detached(source,reason){if(source.tabId===tab.tabId){attached=false;if(!closing){tracker.detached=true;tracker.detachReason=String(reason||'');}}}
  chrome.debugger.onDetach?.addListener(detached);
  try{
   await chrome.debugger.attach(tab,'1.3');attached=true;await send(tab,'Page.bringToFront');await enable(tab);await pause(100);await Promise.all(tasks);if(childError)throw childError;
   const matches=[];
   for(const c of contexts){try{const r=await send(c.scope,'Runtime.evaluate',{contextId:c.id,expression:'location.href',returnByValue:true});if(r.result?.value===url)matches.push(c);}catch{}}
   if(matches.length!==1)throw Error('本轮官方表单的输入上下文不唯一。');const c=matches[0];
   async function call(fn,arg,byValue=true){const r=await send(c.scope,'Runtime.callFunctionOn',{executionContextId:c.id,functionDeclaration:fn.toString(),arguments:[{value:arg}],returnByValue:byValue,awaitPromise:true,userGesture:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description?.split('\n')[0]||'官方表单操作未确认。');return r.result;}
   async function dismissImportantMessage(){
    const results=await chrome.scripting.executeScript({target:{tabId:target.tabId,allFrames:true},func:async()=>{
     if(location.protocol!=='https:'||!/(^|\.)(taobao|tmall)\.com$/.test(location.hostname))return {dismissed:false};
     const visible=e=>!!e?.getClientRects().length&&getComputedStyle(e).visibility!=='hidden',headers=[...document.querySelectorAll('div,span,p,h1,h2,h3')].filter(e=>visible(e)&&e.textContent.trim()==='重要消息');
     const candidates=new Set();for(const header of headers){for(let e=header.parentElement,n=0;e&&e!==document.body&&n<12;n++,e=e.parentElement){const close=[...e.querySelectorAll('.next-icon-close_blod')].filter(visible);if(close.length===1&&e.textContent.includes('预警通知')){candidates.add(close[0]);break;}}}
     if(candidates.size!==1)return {dismissed:false};const close=[...candidates][0];close.click();await new Promise(r=>setTimeout(r,100));
     if(headers.some(visible))throw Error('重要消息提示关闭后仍遮挡页面，原任务保留。');return {dismissed:true};
    }});return results.some(r=>r.result?.dismissed===true);
   }
   async function point(fn,arg,hoverOnly=false,scrollBefore=true,hoverAttempt=0){let object;try{
    const r=await call(fn,arg,false);object=r.objectId;if(!object)throw Error('输入控件未唯一识别。');
    if(scrollBefore)await send(c.scope,'Runtime.callFunctionOn',{objectId:object,functionDeclaration:'function(){this.scrollIntoView({block:"center",inline:"center",behavior:"instant"});}',returnByValue:true});
    let quad,last;
    for(let n=0;n<12;n++){
     await dismissImportantMessage();
     // Hover has not dispatched input yet. A scroll or message dismissal can
     // rebuild the product row, so re-run the caller's same-product selector
     // before measuring. Ordinary clicks/publication are never replayed here.
     if(hoverOnly){const fresh=await call(fn,arg,false);if(!fresh.objectId)throw Error('原商品悬停控件未唯一识别，未打开菜单。');const previous=object;object=fresh.objectId;if(previous!==object)await send(c.scope,'Runtime.releaseObject',{objectId:previous}).catch(()=>{});}
     const hit=await send(c.scope,'Runtime.callFunctionOn',{objectId:object,functionDeclaration:'function(){const r=this.getBoundingClientRect(),x=Math.max(0,r.left)+(Math.min(innerWidth,r.right)-Math.max(0,r.left))/2,y=Math.max(0,r.top)+(Math.min(innerHeight,r.bottom)-Math.max(0,r.top))/2;const e=document.elementFromPoint(x,y);return r.width>0&&r.height>0&&getComputedStyle(this).visibility!=="hidden"&&(e===this||this.contains(e));}',returnByValue:true});
     const q=await send(c.scope,'DOM.getContentQuads',{objectId:object});quad=q.quads?.find(a=>Math.abs((a[2]-a[0])*(a[5]-a[1]))>1);
     if(hit.result?.value&&quad&&last&&quad.every((v,i)=>Math.abs(v-last[i])<.5))break;
     if(n===11){const d=await send(c.scope,'Runtime.callFunctionOn',{objectId:object,functionDeclaration:'function(){const r=this.getBoundingClientRect(),x=Math.max(0,r.left)+(Math.min(innerWidth,r.right)-Math.max(0,r.left))/2,y=Math.max(0,r.top)+(Math.min(innerHeight,r.bottom)-Math.max(0,r.top))/2,e=document.elementFromPoint(x,y);return {viewport:[innerWidth,innerHeight,devicePixelRatio],target:{tag:this.tagName,cls:typeof this.className==="string"?this.className:"",connected:this.isConnected,display:getComputedStyle(this).display,x:r.x,y:r.y,w:r.width,h:r.height},hit:e?{tag:e.tagName,cls:typeof e.className==="string"?e.className:""}:null};}',returnByValue:true});throw Error('输入控件仍在滚动或被遮挡，原任务保留。定位信息：'+JSON.stringify(d.result?.value));}last=quad;await pause(50);
    }
    const x=(quad[0]+quad[2]+quad[4]+quad[6])/4,y=(quad[1]+quad[3]+quad[5]+quad[7])/4;if(x<0||y<0)throw Error('输入控件位于页面外，未点击。');
    if(hoverOnly&&hoverAttempt){
     const outside=await send(c.scope,'Runtime.callFunctionOn',{objectId:object,functionDeclaration:'function(){const r=this.getBoundingClientRect(),row=this.closest("tr,[role=row]")||this.parentElement,candidates=[{x:r.left-4,y:r.top+r.height/2},{x:r.right+4,y:r.top+r.height/2},{x:r.left+r.width/2,y:r.top-4},{x:r.left+r.width/2,y:r.bottom+4}];for(const p of candidates){if(p.x<0||p.y<0||p.x>=innerWidth||p.y>=innerHeight)continue;const hit=document.elementFromPoint(p.x,p.y);if(hit&&!this.contains(hit)&&row?.contains(hit))return p;}return null;}',returnByValue:true});
     if(!outside.result?.value)throw Error('原商品空槽缺少安全的悬停复位位置，未操作其他商品。');
     await send(tab,'Input.dispatchMouseEvent',{type:'mouseMoved',x:outside.result.value.x,y:outside.result.value.y,button:'none',clickCount:0});
    }
    for(const type of (hoverOnly?['mouseMoved']:['mouseMoved','mousePressed','mouseReleased']))await send(tab,'Input.dispatchMouseEvent',{type,x,y,button:type==='mouseMoved'?'none':'left',clickCount:type==='mouseMoved'?0:1});
    if(hoverOnly){
     const hit=await send(c.scope,'Runtime.callFunctionOn',{objectId:object,functionDeclaration:'function(){return this.isConnected&&this.matches(":hover");}',returnByValue:true});
     if(!hit.result?.value){
      if(hoverAttempt>=1)throw Object.assign(Error('原商品空槽悬停未命中；已保留原图片和上传记录，未选择菜单或发布。'),{code:'INPUT_HOVER_NOT_ACKNOWLEDGED'});
      return await point(fn,arg,true,scrollBefore,hoverAttempt+1);
     }
    }
   }finally{if(object)await send(c.scope,'Runtime.releaseObject',{objectId:object}).catch(()=>{});}}
   const click=(fn,arg)=>point(fn,arg),hover=(fn,arg,policy={})=>point(fn,arg,true,true,policy.reset?1:0),clickVisible=(fn,arg)=>point(fn,arg,false,false);
   async function key(key,code,vk,modifiers=0){for(const type of ['keyDown','keyUp'])await send(tab,'Input.dispatchKeyEvent',{type,key,code,windowsVirtualKeyCode:vk,nativeVirtualKeyCode:vk,modifiers});}
   async function text(fn,arg,value){await click(fn,arg);await key('a','KeyA',65,2);await send(tab,'Input.insertText',{text:String(value)});}
   if((await call(function(){return document.visibilityState;})).value==='hidden')throw Object.assign(Error('原任务标签仍处于隐藏状态，未发送输入；请回到原Ego空间后继续。'),{code:'INPUT_TARGET_HIDDEN'});
   tracker.workStarted=true;
   return await work({dismissImportantMessage,call:async(fn,arg)=>(await call(fn,arg)).value,click,clickVisible,hover,key,text,tab,send:(method,params)=>send(tab,method,params),sendFrame:(method,params)=>send(c.scope,method,params)});
  }finally{chrome.debugger.onEvent.removeListener(event);await Promise.allSettled(tasks);closing=true;if(attached)await chrome.debugger.detach(tab).catch(()=>{});chrome.debugger.onDetach?.removeListener(detached);}
 }
 async function searchProduct(target,id,actions){return session(target,async io=>{
  if(!/^\d{6,20}$/.test(id)||!root.FullSearchResultProof)throw Error('指定商品查询校验模块未就绪。');
  const requests=new Map(),pending=[];let latest=null,proof=null,error=null;
  const key=(source,requestId)=>(source.sessionId||'main')+':'+requestId;
  function event(source,method,p){if(source.tabId!==target.tabId)return;
   if(method==='Network.requestWillBeSent'&&root.FullSearchResultProof.requestMatches(p.request,id)){latest=key(source,p.requestId);requests.set(latest,{source:{...source},requestId:p.requestId});proof=null;error=null;}
   const k=key(source,p.requestId);if(!requests.has(k))return;
   if(method==='Network.loadingFailed'&&k===latest)error=Error('指定商品查询网络失败，未按空结果跳过。');
   if(method==='Network.loadingFinished'){const request=requests.get(k);pending.push(chrome.debugger.sendCommand(request.source,'Network.getResponseBody',{requestId:request.requestId}).then(body=>{const result=root.FullSearchResultProof.response(body.base64Encoded?atob(body.body):body.body,id);if(k===latest)proof=result;}).catch(e=>{if(k===latest)error=e;}));}
  }
  chrome.debugger.onEvent.addListener(event);
  try{await io.send('Network.enable',{});await io.sendFrame('Network.enable',{});await actions.trigger();
   for(let n=0;n<80&&!proof&&!error;n++)await pause(200);await Promise.all(pending);
   if(error)throw error;if(!root.FullSearchResultProof.validate(proof,id))throw Error('未取得本次指定商品的成功查询回包，保留任务，不按空结果跳过。');
   return await actions.confirm(proof);
  }finally{chrome.debugger.onEvent.removeListener(event);await io.sendFrame('Network.disable',{}).catch(()=>{});await io.send('Network.disable',{}).catch(()=>{});}
 },{restartSafe:true,operation:'exact-product-read-only-query'});}
 async function openSearchSlot(target,job){return session(target,async io=>{
  const state=await io.call(function(job){const s=FullPlatform.searchSlot(job);return {status:s.status,message:s.message};},job);
  if(state.status!=='ready')return state;
  await io.dismissImportantMessage();
  const scroll=await io.call(function(job){const s=FullPlatform.searchSlot(job);if(s.status!=='ready')throw Error('原商品空槽状态已改变，未滚动表格。');const el=s.opener;el.scrollIntoView({block:'center',inline:'center',behavior:'instant'});const steps=[];for(let e=el.parentElement;e&&e!==document.body;e=e.parentElement){if(e.scrollWidth<=e.clientWidth+1||!/auto|scroll/.test(getComputedStyle(e).overflowX))continue;const before=e.scrollLeft,r=el.getBoundingClientRect(),p=e.getBoundingClientRect(),next=Math.max(0,Math.min(e.scrollWidth-e.clientWidth,before+(r.left+r.right)/2-(p.left+e.clientLeft+e.clientWidth/2)));e.scrollTo({left:next,behavior:'instant'});steps.push({before,after:e.scrollLeft,max:e.scrollWidth-e.clientWidth});}return steps;},job);
  const hoverSlot=(reset=false)=>io.hover(function(job){const s=FullPlatform.searchSlot(job);if(s.status!=='ready')throw Error('原商品空槽状态已改变，未打开菜单。');return s.opener;},job,{reset});await hoverSlot();
  for(let n=0;n<50;n++){
   if(await io.dismissImportantMessage())await hoverSlot();
   if(await io.call(function(job){return !!FullPlatform.searchOption(job);},job)){
    await io.clickVisible(function(job){const s=FullPlatform.searchSlot(job);if(s.status!=='ready')throw Error('原商品空槽状态已改变，未选择菜单。');const option=FullPlatform.searchOption(job);if(!option)throw Error('发图文菜单未唯一就绪。');return option;},job);
    for(let n=0;n<50;n++){if(await io.call(function(job){return FullPlatform.searchSlot(job).status==='prepared';},job))return {status:'prepared',message:'已滚动表格并在原标签页核对搜推表单归属。',horizontalScroll:scroll};await pause(200);}
    throw Error('发图文菜单已选择，但原商品表单未就绪；保留原素材，未重复选择或提交。');
   }
   if(n===10)await hoverSlot(true);
   await pause(200);
  }
  const diagnostic=await io.call(function(job){const s=FullPlatform.searchSlot(job),el=s.opener,r=el?.getBoundingClientRect();return {viewport:[innerWidth,innerHeight,devicePixelRatio],opener:r?{x:r.x,y:r.y,w:r.width,h:r.height,cls:el.className}:null,hover:[...document.querySelectorAll(':hover')].slice(-4).map(e=>({tag:e.tagName,cls:typeof e.className==='string'?e.className:''})),options:[...document.querySelectorAll('[class*="PublishButton_option"],[class*="PublishButtonWidthIcon_option"]')].filter(e=>e.getClientRects().length).map(e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,cls:e.className};})};},job);
  throw Error('发图文菜单未就绪：原图片和上传记录保留。定位信息：'+JSON.stringify(diagnostic));
 },{restartSafe:true,operation:'open-search-form'});}
 async function openUpload(target){return session(target,async io=>{
  const ready=function(){if(!/\/home.htm\/material-center\/mine-material\/sucai-tu$/.test(location.pathname))throw Error('上传目标不是原图片空间。');const inputs=[...document.querySelectorAll('.next-dialog input[type="file"]')].filter(e=>!e.disabled&&e.closest('.next-dialog').getClientRects().length);if(inputs.length>1)throw Error('已打开上传入口不唯一。');return inputs.length===1;};
  if(await io.call(ready))return {opened:true,reused:true};
  let found=false;for(let n=0;n<50;n++){await io.dismissImportantMessage();if(await io.call(ready))return {opened:true,reused:true};const count=await io.call(function(){return [...document.querySelectorAll('button')].filter(e=>e.innerText.trim()==='上传文件'&&!e.disabled&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden').length;});if(count>1)throw Error('图片空间存在多个可见上传按钮，尚未创建上传意图。');if(count===1){found=true;break;}await pause(200);}
  if(!found)throw Error('图片空间上传按钮尚未加载，尚未创建上传意图；保留原素材。');
  await io.click(function(){const a=[...document.querySelectorAll('button')].filter(e=>e.innerText.trim()==='上传文件'&&!e.disabled&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden');if(a.length!==1)throw Error('图片空间可见上传入口已变化，尚未创建上传意图。');return a[0];});
  for(let n=0;n<50;n++){if(await io.call(ready))return {opened:true};await pause(200);}throw Error('图片空间上传面板未就绪，尚未创建上传意图。');
 },{restartSafe:true,operation:'open-upload-panel'});}

 // This function is serialized into the already bound official form frame.
 function formField({job,field}){
  const ids=globalThis.FullPlatform?.inspect(job)?.productIds;
  if(!Array.isArray(job?.productIds)||!job.productIds.length||!Array.isArray(ids)||[...new Set(ids)].sort().join()!==[...new Set(job.productIds)].sort().join())throw Error('正文定位前商品归属未确认。');
  const visible=e=>{if(!e?.getClientRects().length||e.disabled||e.readOnly)return false;for(let p=e;p;p=p.parentElement){const s=getComputedStyle(p);if(p.hidden||p.getAttribute('aria-hidden')==='true'||s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse')return false;}return true;};
  const one=(a,label)=>{if(a.length!==1)throw Error(label+'未唯一就绪（匹配'+a.length+'）；保留原素材。');return a[0];};
  const title=()=>one([...document.querySelectorAll('input[placeholder*="加个标题"],input[placeholder*="添加标题"],input[placeholder*="视频标题"],input[maxlength="20"],input[name="shortTitle"]')].filter(visible),'标题输入框');
  const body=()=>{const rich=[...document.querySelectorAll('.rich-text-content[data-cangjie-content="true"]')].filter(visible);return one(rich.length?rich:[...document.querySelectorAll('textarea')].filter(e=>visible(e)&&e.getAttribute('data-cangjie-dockey')===null),'正文编辑器');};
  if(field==='title')return title();if(field==='body')return body();
  if(field!=='read')throw Error('未知的表单字段。');
  const t=title(),b=body(),clean=s=>String(s||'').replace(/[\uFEFF\u200B]/g,'').trim();return {title:clean(t.value),body:clean(b.tagName==='TEXTAREA'?b.value:b.innerText)};
 }
 async function waitFormEditor(io,job,options={}){
  // The title blur can rebuild Cangjie's renderer. Wait for two equal reads;
  // do not select its keyboard relay textarea or an arbitrary first match.
  const expected=options.expected,fields=expected?Object.keys(expected):null;
  if(fields&&(!fields.length||fields.some(k=>!['title','body'].includes(k)||typeof expected[k]!=='string')))throw Error('编辑器读回目标无效。');
  let previous=null,last,actual;for(let n=0;n<(expected?60:20);n++){
   try{const value=await io.call(formField,{job,field:'read'});actual=value;last=null;const matched=!expected||fields.every(k=>value[k]===expected[k]),key=JSON.stringify(fields?fields.map(k=>value[k]):value);if(matched&&key===previous)return value;previous=matched?key:null;}
   catch(e){last=e;previous=null;if(/商品归属|匹配[2-9]|匹配\d{2,}/.test(e.message))throw e;}
   await pause(100);
  }
  if(last)throw last;
  if(expected&&actual){const diagnostic={};for(const k of fields){if(actual[k]===expected[k])continue;const want=Array.from(expected[k]),got=Array.from(String(actual[k]??''));let first=0;while(first<Math.min(want.length,got.length)&&want[first]===got[first])first++;diagnostic[k]={expectedLength:want.length,actualLength:got.length,firstDifference:first,expectedCodePoint:want[first]?.codePointAt(0)??null,actualCodePoint:got[first]?.codePointAt(0)??null};}const detail=Object.entries(diagnostic).map(([k,d])=>(k==='title'?'标题':'正文')+'预期'+d.expectedLength+'字/实际'+d.actualLength+'字，首个差异位置'+d.firstDifference).join('；');throw Object.assign(Error('真实编辑器内容未精确读回（'+(detail||'内容未持续稳定')+'）；未发布，原素材保留。'),{code:'INPUT_TEXT_MISMATCH',inputDiagnostic:diagnostic});}
  throw Error('正文编辑器未稳定就绪，保留原素材。');
 }
 async function fill(target,job){return session(target,async io=>{
  await waitFormEditor(io,job);
  await io.text(formField,{job,field:'title'},job.title);
  await io.key('Tab','Tab',9);
  await waitFormEditor(io,job,{expected:{title:job.title}});
  await io.text(formField,{job,field:'body'},job.body);
  await io.key('Tab','Tab',9);
  return await waitFormEditor(io,job,{expected:{title:job.title,body:job.body}});
 },{restartSafe:true,operation:'fill-original-form',verifyRecovery:async()=>{
  if(!Array.isArray(job.productIds)||!job.productIds.length)throw Object.assign(Error('重连前未取得原表单商品身份，未重新填表。'),{code:'INPUT_TARGET_CHANGED'});
  const [{result:proof}]=await chrome.scripting.executeScript({target:{tabId:target.tabId,frameIds:[target.frameId]},world:'MAIN',func:job=>({productIds:globalThis.FullPlatform?.inspect(job)?.productIds||[]}),args:[job]});
  if(!Array.isArray(proof?.productIds)||[...new Set(proof.productIds)].sort().join()!==[...new Set(job.productIds)].sort().join())throw Object.assign(Error('重连后的表单关联商品已变化，未重新填表。'),{code:'INPUT_TARGET_CHANGED'});
 }});}
 function publicationInput(raw,job){const ids=new Set(),strings=[];function walk(x,d=0,key=''){if(d>10)return;if(typeof x==='string'){strings.push(x);if(/^(itemId|itemIds|goodsId|goodsIds)$/i.test(key)&&/^\d{6,20}$/.test(x))ids.add(x);for(let n=0,v=x;n<2;n++){try{const parsed=JSON.parse(v);if(parsed!==v){walk(parsed,d+1,key);break;}}catch{}try{v=decodeURIComponent(v);}catch{break;}}}else if(typeof x==='number'&&/^(itemId|itemIds|goodsId|goodsIds)$/i.test(key))ids.add(String(x));else if(Array.isArray(x))for(const v of x)walk(v,d+1,key);else if(x&&typeof x==='object')for(const[k,v]of Object.entries(x))walk(v,d+1,k);}try{const params=new URLSearchParams(raw);const data=params.get('data');if(data)walk(data);else walk(raw);}catch{walk(raw);}const body=strings.join('\n').replace(/\\\//g,'/');return {productIds:[...ids],imagesMatched:job.uploadedAssets.filter(a=>body.includes(a.url)).length,valid:[...ids].sort().join()===job.productIds.slice().sort().join()&&job.uploadedAssets.every(a=>body.includes(a.url))};}
 async function publish(target,job){return session(target,async io=>{
  const current=await io.call(formField,{job,field:'read'});if(current.title!==job.title||current.body!==job.body)throw Error('提交前图文已变化');
  const requests=new Map();let confirmed;
  function event(source,method,p){if(source.tabId!==target.tabId||job.module!=='guanghe')return;if(method==='Network.requestWillBeSent'&&/\/mtop\.taobao\.media\.guang\.pcpublish\.publish\//.test(p.request?.url||'')){const raw=p.request.postData||new URL(p.request.url).search.slice(1);requests.set(p.requestId,publicationInput(raw,job));}if(method==='Network.loadingFinished'&&requests.has(p.requestId))io.send('Network.getResponseBody',{requestId:p.requestId}).then(r=>{const raw=r.base64Encoded?atob(r.body):r.body,v=JSON.parse(raw.slice(raw.indexOf('{'),raw.lastIndexOf('}')+1)),input=requests.get(p.requestId);if(input.valid&&v.ret?.some(s=>String(s).startsWith('SUCCESS::')))confirmed={source:'official-publish-request-and-success-response',productIds:input.productIds,images:input.imagesMatched,success:true};}).catch(()=>{});}
  if(job.module==='guanghe'){chrome.debugger.onEvent.addListener(event);await io.send('Network.enable',{});}
  try{await io.click(function(name){const a=[...document.querySelectorAll('button')].filter(x=>x.getClientRects().length&&!x.disabled&&x.innerText.trim()===name);if(a.length!==1)throw Error('发布确认按钮不唯一');return a[0];},job.module==='guanghe'?'立即发布':'确认');if(job.module==='guanghe')for(let n=0;n<75&&!confirmed;n++)await pause(200);return {status:'submitted_unconfirmed',...(confirmed?{platformPublication:confirmed}:{})};}
  finally{chrome.debugger.onEvent.removeListener(event);if(job.module==='guanghe')await io.send('Network.disable',{}).catch(()=>{});}
 });}
 async function workspaceSearch(target,keyword){return session(target,async io=>{
  const ids=new Set();let payload,error;
  function event(source,method,p){if(source.tabId!==target.tabId)return;
   if(method==='Network.requestWillBeSent'&&/\/mtop\.taobao\.gcm\.content\.admin\.list\//.test(p.request?.url||'')){let value=(p.request.url||'')+(p.request.postData||'');for(let n=0;n<2;n++)try{value=decodeURIComponent(value);}catch{break;}if(value.includes(keyword))ids.add(p.requestId);}
   if(method==='Network.loadingFailed'&&ids.has(p.requestId))error='官方作品查询未完成。';
   if(method==='Network.loadingFinished'&&ids.has(p.requestId))io.send('Network.getResponseBody',{requestId:p.requestId}).then(r=>{const raw=r.base64Encoded?atob(r.body):r.body;payload=JSON.parse(raw.slice(raw.indexOf('{'),raw.lastIndexOf('}')+1));}).catch(()=>{error='官方作品查询回包无法读取。';});
  }
  chrome.debugger.onEvent.addListener(event);
  try{await io.send('Network.enable',{});await io.call(function(keyword){return FullSoutuiWorkspace.trigger(keyword);},keyword);
   for(let n=0;n<100&&!payload&&!error;n++)await pause(200);if(error||!payload?.ret?.some(s=>String(s).startsWith('SUCCESS::')))throw Error(error||'官方作品查询未确认，不能判断为空或发布成功。');
   const totals=[];function scan(x,d=0){if(!x||typeof x!=='object'||d>6)return;for(const[k,v]of Object.entries(x)){if(k==='totalCount'&&/^\d+$/.test(String(v)))totals.push(Number(v));else if(v&&typeof v==='object')scan(v,d+1);}}scan(payload.data);const unique=[...new Set(totals)];if(unique.length!==1)throw Error('作品查询总数未明确。');
   const records=Array.isArray(payload.data?.model?.data)?payload.data.model.data.map(x=>({contentId:String(x.baseInfo?.id||''),title:x.baseInfo?.title||'',body:x.baseInfo?.summary||'',images:(x.baseInfo?.pictures||[]).map(p=>p.url),publishedAt:x.baseInfo?.publishTime,detailUrl:x.baseInfo?.rawDetailUrl||'',topic:x.topicInfo?.topicName||'',editAllowed:x.operateInfo?.edit?.satisfied})):[];
   for(let n=0;n<40;n++){const result=await io.call(function(args){return FullSoutuiWorkspace.read(args.keyword,args.total);},{keyword,total:unique[0]});if(result)return {...result,records};await pause(200);}throw Error('作品列表和查询回包数量未一致。');
  }finally{chrome.debugger.onEvent.removeListener(event);await io.send('Network.disable',{}).catch(()=>{});}
 });}
 async function workspaceEdit(target,id){return session(target,async io=>{await io.click(function(id){return FullSoutuiWorkspace.edit(id);},id);return {opened:true};});}
 function videoPublicationInput(raw,job){const products=new Set(),videos=new Set(),files=new Set(),strings=[];let visited=0;function walk(x,key='',depth=0,video=false){if(depth>16||++visited>12000)return;if(typeof x==='string'){if(key==='fileId')files.add(x);strings.push(x);try{strings.push(decodeURIComponent(x));}catch{}if(/^(?:itemId|itemIds|goodsId|goodsIds)$/i.test(key)&&/^\d{6,20}$/.test(x))products.add(x);if((/^(?:videoId|video_id|videoIds)$/i.test(key)||video&&key==='id')&&/^\d{6,20}$/.test(x))videos.add(x);let value=x;for(let n=0;n<3;n++){try{const parsed=JSON.parse(value);if(parsed!==x){walk(parsed,key,depth+1,video);break;}}catch{}try{const decoded=decodeURIComponent(value);if(decoded===value)break;value=decoded;}catch{break;}}}else if(typeof x==='number')walk(String(x),key,depth+1,video);else if(Array.isArray(x))for(const child of x)walk(child,key,depth+1,video);else if(x&&typeof x==='object')for(const [k,v]of Object.entries(x))walk(v,k,depth+1,video||/^(?:video|videoInfo|videoData)$/.test(k));}const params=new URLSearchParams(raw);walk(params.get('data')||raw);return {valid:products.size===1&&[...products].sort().join()===job.productIds.slice().sort().join()&&(videos.size===1||!!job.directVideoFile?.fileId&&files.size===1&&files.has(job.directVideoFile.fileId))&&strings.includes(job.title),productIds:[...products],videoId:videos.size===1?[...videos][0]:null,fileId:files.size===1?[...files][0]:null};}
 async function publishVideo(target,job){return session(target,async io=>{
  try{await io.call(async function(job){await FullPlatform.execute('verify-video',job);const clean=s=>String(s||'').replace(/[\uFEFF\u200B]/g,'').trim(),title=[...document.querySelectorAll('input[placeholder*="标题"],input[maxlength="20"]')].find(e=>e.getClientRects().length),body=[...document.querySelectorAll('.rich-text-content[data-cangjie-content="true"],textarea')].find(e=>e.getClientRects().length);if(clean(title?.value)!==job.title||clean(body?.matches('textarea')?body.value:body?.innerText)!==job.body)throw Error('提交前视频标题或正文已变化。');FullFlowVideo.declareDirect();},job);}catch(e){return {status:'not_submitted',proof:'pre-submit-check-rejection',actionAttempted:false,message:String(e.message)};}
  const requests=new Map();let confirmed,rejected;
  function event(source,method,p){if(source.tabId!==target.tabId)return;if(method==='Network.requestWillBeSent'&&/\/mtop\.taobao\.(?:media\.guang\.pcpublish|spongebob\.item\.material)\.publish\//i.test(p.request?.url||'')){const raw=p.request.postData||new URL(p.request.url).search.slice(1);requests.set(p.requestId,videoPublicationInput(raw,job));}if(method==='Network.loadingFinished'&&requests.has(p.requestId))chrome.debugger.sendCommand(source,'Network.getResponseBody',{requestId:p.requestId}).then(r=>{const raw=r.base64Encoded?atob(r.body):r.body,v=JSON.parse(raw.slice(raw.indexOf('{'),raw.lastIndexOf('}')+1)),input=requests.get(p.requestId);if(v.ret?.some(s=>String(s).startsWith('SUCCESS::'))&&input.valid&&/^\d{6,}$/.test(String(v.data?.contentId||v.data?.result||input.videoId||'')))confirmed={source:'official-video-publish-request-and-success-response',success:true,productIds:input.productIds,videoId:String(v.data?.contentId||v.data?.result||input.videoId),...(input.fileId?{fileId:input.fileId}:{}),...(v.data?.contentId?{contentId:String(v.data.contentId)}:{})};else if(v.ret&&!v.ret.some(s=>String(s).startsWith('SUCCESS::')))rejected=v.ret.map(String).join('；').replace(/https?:\/\/\S+/g,'[页面地址]').slice(0,240);}).catch(()=>{});}
  chrome.debugger.onEvent.addListener(event);await io.send('Network.enable',{});await io.sendFrame('Network.enable',{});
  try{await io.click(function(){const buttons=[...document.querySelectorAll('button')].filter(e=>e.getClientRects().length&&!e.disabled&&e.innerText.trim()==='确认');if(buttons.length!==1)throw Error('视频确认按钮未唯一就绪。');return buttons[0];});for(let n=0;n<450&&!confirmed&&!rejected;n++)await pause(200);return {status:'submitted_unconfirmed',...(confirmed?{platformPublication:confirmed}:{}),...(rejected?{error:'平台明确拒绝：'+rejected}:{})};}
  finally{chrome.debugger.onEvent.removeListener(event);await io.sendFrame('Network.disable',{}).catch(()=>{});await io.send('Network.disable',{}).catch(()=>{});}
 });}
 root.FullSoutuiInput={formField,waitFormEditor,session,searchProduct,openSearchSlot,openUpload,fill,publish,publishVideo,workspaceSearch,workspaceEdit,publicationInput,videoPublicationInput};
})(globalThis);
