(function(root){
 'use strict';
 function cancel(run,at=new Date().toISOString()){
  if(!run)throw Error('原任务不存在，请刷新任务记录。');
  if(run.status==='done'||run.phase==='done')throw Error('任务已完成，无需取消。');
  if(run.cancellation)return run;
  run.cancellation={at,reason:'user-request',previousStatus:run.status,recordsPreserved:true,inFlightRequestsNotRecalled:true};
  run.enabled=false;run.draining=false;run.status='stopped';
  if(run.trend)run.trend.controlRevision=Number(run.trend.controlRevision||0)+1;
  run.events||=[];run.events.push({at,phase:run.phase,position:run.position,message:'用户取消任务：停止后续执行，原素材、已用额度和提交记录保留；已发出的请求不会撤回。'});
  return run;
 }
 function restart(run,confirmed){
  if(!confirmed||!run?.cancellation)throw Error('请确认重新开始已取消的原任务。');
  run.cancellationHistory||=[];run.cancellationHistory.push({...run.cancellation,restartedAt:new Date().toISOString()});delete run.cancellation;
  run.events||=[];run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,message:'用户确认重新开始原任务：复用原素材、编号和提交记录，保留已用额度与原上限。'});return run;
 }
 root.FullTaskCancel={cancel,restart};
 if(!root.chrome?.runtime?.onMessage)return;
 chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(sender.id!==chrome.runtime.id||message.type!=='FULL_FLOW_CANCEL')return false;
  if(typeof message.runId!=='string'||!/^[a-f\d]{8}(?:-[a-f\d]{4}){3}-[a-f\d]{12}$/i.test(message.runId)){reply({ok:false,error:'任务编号无效。'});return false;}
  (async()=>{
   await FullStateStore.update('material-flow-runs-v1',runs=>{cancel(runs?.find(r=>r.id===message.runId));return runs;});
   // Do not wait for the worker's execution lock: enabled=false is the existing live-operation guard.
   for(const prefix of ['full-flow:','full-trend:'])await chrome.alarms.clear(prefix+message.runId);
   const entryGate=typeof controlReleaseIdleEgoPause==='function'?await executionGate(controlReleaseIdleEgoPause):null;
   return {ok:true,runId:message.runId,cancelled:true,recordsPreserved:true,inFlightRequestsNotRecalled:true,entryGate};
  })().then(reply,error=>reply({ok:false,error:error.message}));return true;
 });
})(globalThis);
