(function(root){
 'use strict';
 const RATIOS=['1:1','3:4','4:3','9:16','16:9'];
 function create(input){
  const prompt=String(input.prompt||'').trim();if(!prompt||prompt.length>5800)throw Error('请填写 1 至 5800 字的创作提示词。');
  if(!RATIOS.includes(input.ratio))throw Error('请选择图片比例。');if(!['yes','no'].includes(input.palette))throw Error('请明确这次是否使用南乐杨-1号色调。');
  if(!Array.isArray(input.references)||input.references.length>2||input.references.some(data=>typeof data!=='string'||!/^data:image\/(png|jpeg|webp);base64,/.test(data)))throw Error('最多添加 2 张有效参考图，也可不添加。');
  const request={id:root.crypto.randomUUID(),module:'freegen',media:'image',model:'nano-banana-pro',productIds:[],prompt:prompt+'\n输出一张独立完整图片，不输出九宫格或拼图。'+(input.palette==='yes'?'环境采用奶油白、自然浅木色和浅灰布艺；保留参考商品自身颜色。':'保留参考主体原色，环境使用自然色彩。'),ratio:input.ratio,palette:input.palette,references:[...input.references],consent:true};
  return {id:request.id,name:prompt.slice(0,40),source:'自研自由生图 · GrsAI',request,status:'draft',createdAt:new Date().toISOString(),available:false};
 }
 function apply(task,result){
  if(result.id!==task.id||result.module!=='freegen'||result.media!=='image'||!Array.isArray(result.productIds)||result.productIds.length)throw Error('返回任务身份或来源不一致，保留原编号，未替换结果。');
  if(typeof result.status!=='string')throw Error('主机未返回任务状态。');task.status=result.status;task.available=result.status==='completed'&&result.available===true;task.sha256=result.sha256||null;task.mediaInfo=result.mediaInfo||null;task.error=result.error||'';task.updatedAt=new Date().toISOString();
 }
 async function submit(task,io){
  if(task.status!=='draft')throw Error('本任务已有提交记录，只能查询原编号。');task.status='submitting';await io.save();
  try{apply(task,await io.api('/api/media',{method:'POST',body:JSON.stringify(task.request)}));}
  catch(error){task.status=[400,403,413,503].includes(error.status)?'rejected':'submission_unconfirmed';task.error=error.message;throw error;}
  finally{await io.save();}
 }
 async function query(task,io){
  if(task.status==='draft')return;const result=await io.api('/api/media/'+task.id);apply(task,result);await io.save();
  // Resume only queries a provider task already recorded by the host; this endpoint cannot create a new paid task.
  if(task.status==='pending'){apply(task,await io.api('/api/media/'+task.id+'/resume',{method:'POST',body:'{}'}));await io.save();}
 }
 const api={RATIOS,create,apply,submit,query};root.FreegenCore=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
