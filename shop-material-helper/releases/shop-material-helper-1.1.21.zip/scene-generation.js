(function(root){
 'use strict';
 const LIMIT=3,same=(a,b)=>JSON.stringify(a)===JSON.stringify(b),done=g=>g.status==='completed'&&g.available===true;
 function enabled(run){return run.module==='scene'&&['banana_pro','ai_generate'].includes(run.selection?.source||'banana_pro');}
 function excluded(item){return /差价|运费/.test(item.title||'');}
 async function advance(run,item,io){
  io={...io};for(const name of ['prepare','planGeneration','queryGeneration','submitGeneration']){const fn=io[name];if(fn)io[name]=async(...args)=>{try{return await fn(...args);}catch(error){if(args[1]?.id)error.failureItemId=args[1].id;throw error;}};}
  await io.check();
  const max=Number(run.selection.maxCalls);if(!Number.isInteger(max)||max<0||!Number.isInteger(run.usedCalls)||run.usedCalls<0)throw Error('原场景图调用预算无效。');
  const remainingItems=run.items.slice(run.position),selected=[];
  const skip=async i=>{i.phase='done';i.status='skipped';i.detail='标题含差价或运费，跳过素材生成与回填。';await io.save(i.detail);};
  // Include durable old intents first, even after a restart or a drain request.
  for(const i of remainingItems)if(i.phase==='generate'&&i.generations?.some(g=>g.intent&&!done(g)))selected.push(i);
  if(selected.length>LIMIT)throw Error('已有场景图并发超过三件，保留原编号等待核对。');
  let reserved=selected.reduce((n,i)=>n+i.generations.filter(g=>!g.intent&&!done(g)).length,0);
  if(!run.draining)for(const i of remainingItems){
   if(selected.includes(i)||!['prepare','generate'].includes(i.phase))continue;
   if(selected.length>=LIMIT)break;
   if(excluded(i)&&!i.generations?.some(g=>g.intent)){await skip(i);continue;}
   if(i.generations?.every(done)){i.phase=excluded(i)?'done':'attach';if(excluded(i)){i.status='skipped';i.detail='标题含差价或运费；保留已生成文件，跳过回填。';}continue;}
   if(run.usedCalls+reserved>=max)break;
   await io.check();if(run.draining)break;
   if(i.phase==='prepare'){
    const prepared=await io.prepare(run,i);await io.check();
    if(prepared?.status==='ineligible'){i.phase='done';i.status='skipped';i.detail=prepared.message;await io.save(i.detail);continue;}
    if(!same(prepared?.productIds,i.productIds)||prepared.needsGeneration!==true)throw Object.assign(Error('并发场景图预检未确认同商品生成条件。'),{failureItemId:i.id});
    i.prepared=prepared;i.phase='generate';await io.save('已逐件核对场景图商品与空槽。');
   }
   if(excluded(i)){await skip(i);continue;}
   if(io.generationEligibility&&(!i.generations||i.generations.some(g=>!g.intent&&!done(g)))){const outcome=await io.generationEligibility(run,i);await io.check();if(outcome?.status==='ineligible'){i.skipReason=outcome.skipReason;i.status='skipped';i.phase='done';i.detail=outcome.message;await io.save(i.detail);continue;}}
   if(!i.generations){
    await io.check();if(run.draining)break;
    const plan=await io.planGeneration(run,i);await io.check();
    if(plan?.length!==1||!same(plan[0].productIds,i.productIds)||plan[0].media!=='image'||!plan[0].id||plan[0].intent)throw Object.assign(Error('场景图计划须为同商品一张独立原素材。'),{failureItemId:i.id});
    i.generations=plan;await io.save('已保存场景图唯一素材编号。');
   }
   reserved+=i.generations.filter(g=>!g.intent&&!done(g)).length;selected.push(i);
  }
  const entries=selected.flatMap(i=>(i.generations||[]).map(g=>({i,g})));
  const ids=entries.map(({g})=>g.id);
  if(entries.length>LIMIT||new Set(ids).size!==ids.length||entries.some(({i,g})=>!same(g.productIds,i.productIds)||g.media!=='image'))throw Error('场景图并发编号、商品或数量不符。');
  const waiting=entries.filter(({g})=>g.intent&&!done(g));
  const polled=await Promise.allSettled(waiting.map(async({i,g})=>{
   const result=await io.queryGeneration(run,i,g);
   if(result.id!==g.id||!same(result.productIds,i.productIds))throw Object.assign(Error('并发场景图回查编号或商品不符。'),{failureItemId:i.id});
   if(done(result))Object.assign(g,result);
   else if(['failed','violation','submission_unconfirmed','downloaded_unverified','not_completed','missing'].includes(result.status)){g.status=result.status;g.error=result.error||result.message||'通道未返回可用图片';throw Object.assign(Error('原场景图结果未确认（'+result.status+'）：'+g.error+'；保留编号，不重复生成。'),{failureItemId:i.id});}
   else {g.status=result.status||'pending';g.error=result.error||result.message||'';g.downloadOrigin=result.downloadOrigin||null;}
  }));
  await io.save('已回查原场景图并发任务。');await io.check();
  const failure=polled.find(r=>r.status==='rejected');if(failure)throw failure.reason;
  const submissions=[];let interrupted;
  try{for(const {i,g} of entries){
   if(g.intent||done(g)||run.draining||excluded(i))continue;
   await io.check();if(run.draining)break;
   if(run.usedCalls>=max)throw Error('本轮场景图调用上限已用完，未新增请求。');
   g.intent={id:g.id,at:new Date().toISOString()};g.status='pending';run.usedCalls++;
   run.usedCallsByType||={image:0,video:0,text:0};run.usedCallsByType.image=(run.usedCallsByType.image||0)+1;
   await io.save('已登记场景图第'+run.usedCalls+'次请求；最多三件同时生成。');await io.check();if(run.draining)break;
   submissions.push(Promise.resolve().then(()=>io.submitGeneration(run,i,g)).then(()=>({ok:true}),error=>({ok:false,error})));
  }}catch(error){interrupted=error;}
  const results=await Promise.all(submissions);await io.save('本轮场景图并发提交 '+submissions.length+' 件，后续按原编号回查。');
  if(interrupted)throw interrupted;await io.check();const rejected=results.find(r=>!r.ok);if(rejected)throw rejected.error;
  for(const i of selected)if(i.generations.every(done)){if(excluded(i))await skip(i);else i.phase='attach';}
  if(run.draining){run.enabled=false;run.status=entries.some(({g})=>g.intent&&!done(g))?'draining':'drained';if(run.status==='draining')run.enabled=true;}
  if(!run.draining&&!selected.length&&item.phase==='generate'&&run.usedCalls>=max)throw Error('本轮场景图调用上限已用完，未新增请求。');
  await io.save('场景图并发生成状态已保存；回填逐件核对商品。');
 }
 const api={LIMIT,enabled,excluded,advance};root.FullSceneGeneration=api;if(typeof module==='object')module.exports=api;
})(globalThis);
