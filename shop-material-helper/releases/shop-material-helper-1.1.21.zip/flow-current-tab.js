(function(root){
 'use strict';
 const material=url=>{try{const u=new URL(url);return u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname==='/home.htm/material-center/material-management';}catch{return false;}};
 function allowed(url,referencePid){try{const u=new URL(url);if(u.protocol!=='https:')return false;if(['sell.publish.tmall.com','item.upload.taobao.com'].includes(u.hostname)){const id=u.searchParams.get('id')||u.searchParams.get('itemId');return (u.hostname==='sell.publish.tmall.com'?u.pathname==='/tmall/publish.htm':u.pathname==='/sell/v2/publish.htm')&&/^\d{6,20}$/.test(id||'')&&(u.searchParams.get('__material_video_reference')==='1'||id===referencePid);}if(['qn.taobao.com','myseller.taobao.com'].includes(u.hostname))return ['/home.htm/material-center/material-management','/home.htm/material-center/mine-material/sucai-tu','/home.htm/content-center/list'].includes(u.pathname);if(u.hostname==='creator.guanghe.taobao.com')return /^\/page\/(?:workspace\/tb|pubNew\/(?:pic|video))\/?$/.test(u.pathname);return ['item.taobao.com','detail.tmall.com'].includes(u.hostname)&&u.pathname==='/item.htm'&&/^\d{6,20}$/.test(u.searchParams.get('id')||'');}catch{return false;}}
 function same(a,b){try{const x=new URL(a),y=new URL(b);if(material(a)&&material(b))return (x.searchParams.get('tab')||'')===(y.searchParams.get('tab')||'');return x.origin===y.origin&&x.pathname===y.pathname&&x.search===y.search;}catch{return false;}}
 async function claim(run){const tabs=await root.chrome.tabs.query({active:true,currentWindow:true});if(tabs.length!==1||!Number.isInteger(tabs[0].id)||!Number.isInteger(tabs[0].windowId)||!material(tabs[0].pendingUrl||tabs[0].url))throw Error('请在当前店铺素材页启动搜推；不会另开页面或接管其他窗口。');run.workTab={tabId:tabs[0].id,windowId:tabs[0].windowId};run.tabId=tabs[0].id;run.windowId=tabs[0].windowId;return tabs[0];}
 async function get(run){const binding=run.workTab;if(!binding)throw Error('搜推原标签页绑定缺失，未另开页面。');let tab;try{tab=await root.chrome.tabs.get(binding.tabId);}catch{throw Error('原搜推标签页已关闭，保留原任务，不另开页面。');}if(tab.windowId!==binding.windowId)throw Error('原搜推标签页已移到其他窗口，未接管。');if(!allowed(tab.pendingUrl||tab.url,run.videoReferenceCollection?.productId))throw Error('原搜推标签页已转到其他用途，未导航或另开页面。');return tab;}
 // Only an explicit continue confirmation may replace a stale browser binding.
 async function recover(run){
  let tab;const previous=run.workTab?structuredClone(run.workTab):null,id=previous?.tabId??run.tabId;
  if(Number.isInteger(id))try{tab=await root.chrome.tabs.get(id);}catch{}
  if(tab&&!allowed(tab.pendingUrl||tab.url,run.videoReferenceCollection?.productId))tab=null; // Leave a repurposed external page untouched.
  if(!tab){
   const tabs=await root.chrome.tabs.query({active:true,currentWindow:true});if(tabs.length!==1||!Number.isInteger(tabs[0].id)||!Number.isInteger(tabs[0].windowId))throw Error('当前店铺标签页未唯一确认，请切到店铺素材页后继续。');tab=tabs[0];
   if(!allowed(tab.pendingUrl||tab.url,run.videoReferenceCollection?.productId)){
    let home=tab.url==='about:blank';try{const u=new URL(tab.url);home||=u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname.replace(/\/$/,'')==='/home.htm/QnworkbenchHome';}catch{}
    const bootstrap=typeof root.chrome.runtime?.getURL==='function'&&tab.url?.startsWith(root.chrome.runtime.getURL('data-connect.html'));
    if(!home&&!bootstrap)throw Error('请在当前店铺素材页继续原任务；不会接管外部网站或另开页面。');
    tab=await root.chrome.tabs.update(tab.id,{url:'https://qn.taobao.com/home.htm/material-center/material-management',active:true});
   }
  }
  if(!Number.isInteger(tab.windowId))throw Error('原任务当前窗口未确认。');
  await root.chrome.tabs.update(tab.id,{active:true});
  run.workTab={tabId:tab.id,windowId:tab.windowId};run.tabId=tab.id;run.windowId=tab.windowId;
  for(const item of run.items||[])for(const child of item.syncRuns||[])if(child.status!=='done')inherit(run,child);
  if(!previous||previous.tabId!==tab.id||previous.windowId!==tab.windowId){run.events||=[];run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail:'继续原任务：已复用现有店铺标签页，原图片与提交记录保留。'});}
  return tab;
 }
 async function open(run,url,reload=false){
  if(!run.workTab)await claim(run);if(!allowed(url))throw Error('搜推目标地址不属于已支持的官方页面，未导航。');let tab=await get(run);run.tabId=run.workTab.tabId;run.windowId=run.workTab.windowId;
  if(!same(tab.pendingUrl||tab.url,url))tab=await root.chrome.tabs.update(tab.id,{url});else if(reload)await root.chrome.tabs.reload(tab.id);
  for(let n=0;n<180;n++){
   tab=await get(run);
   if(!tab.pendingUrl&&same(tab.url,url)){
    if(tab.status==='complete')return tab;
    // DOM readiness belongs to the requested document, not slow unrelated subresources.
    try{const [probe]=await root.chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},func:()=>({url:location.href,readyState:document.readyState})});if(same(probe?.result?.url,url)&&['interactive','complete'].includes(probe?.result?.readyState))return tab;}catch(error){if(!/context|navigation|frame|cannot access|No tab/i.test(error.message))throw error;}
   }else if(!tab.pendingUrl&&tab.status==='complete')throw Error('原搜推标签页未到达目标地址，保留原任务。');
   await new Promise(r=>setTimeout(r,250));
  }
  throw Error('原搜推标签页加载超时；未创建替代页面。');
 }
 function inherit(parent,child){if(parent.workTab){child.workTab=structuredClone(parent.workTab);child.tabId=parent.workTab.tabId;child.windowId=parent.workTab.windowId;}return child;}
 async function collection(run){const tab=await get(run),returnURL=tab.pendingUrl||tab.url;return {open:url=>open(run,url),finish:()=>open(run,returnURL)};}
 root.FullCurrentTab={claim,get,recover,open,inherit,collection,allowed};if(typeof module==='object')module.exports=root.FullCurrentTab;
})(globalThis);
