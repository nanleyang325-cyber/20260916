(function(root){
 'use strict';
 function install(adapter){
  const fail=e=>adapter.notice(e?.message||String(e));
  function openScope(initial='ids',review=false){
   if(adapter.hasActive()||adapter.hasDialog())return;
   const box=adapter.mount('<h3>透明图 · '+(review?'重做审核不通过':'补缺')+'</h3>'+
    '<p class="scm-sub">使用同商品已有白底图本地抠图，上传透明 PNG，不重新付费生图。缺少白底图、下架及非实物链接跳过。'+(review?'仅替换仍明确审核不通过的透明图；待审核和已通过不覆盖。':'只补空槽，已有透明图不覆盖。')+'</p>'+
    '<label style="display:block;margin:8px 0;font-size:12px;"><input type="radio" name="transparent-scope" value="ids" '+(initial==='ids'?'checked':'')+'> 仅指定商品 ID</label>'+
    '<label style="display:block;margin:8px 0;font-size:12px;"><input type="radio" name="transparent-scope" value="all" '+(initial==='all'?'checked':'')+'> '+(review?'全店审核不通过商品':'全店待补充商品')+'</label>'+
    '<textarea id="transparent-ids" aria-label="透明图商品ID" placeholder="每行一个商品ID，或用逗号分隔"></textarea><div class="scm-count" id="transparent-count"></div>'+
    '<div class="scm-actions"><button type="button" class="scm-btn scm-cancel tp-cancel">取消</button><button type="button" class="scm-btn scm-start tp-start" disabled>开始补透明图</button></div>');
   const input=box.modal.querySelector('#transparent-ids'),count=box.modal.querySelector('#transparent-count'),submit=box.modal.querySelector('.tp-start'),cancel=box.modal.querySelector('.tp-cancel'),choices=[...box.modal.querySelectorAll('[name="transparent-scope"]')],key=review?'transparent:reviewIds':'transparent:ids';
   let busy=false,touched=false,saving=Promise.resolve();const mode=()=>choices.find(r=>r.checked).value;
   const refresh=()=>{const ids=adapter.parse(input.value),only=mode()==='ids';input.hidden=!only;input.style.display=only?'':'none';count.textContent=only?'识别到 '+ids.length+' 个商品ID':'范围：'+(review?'全店在售且透明图审核不通过的商品':'全店待补充透明图的商品，扫描完成后再处理');submit.textContent=only?(review?'开始指定ID重做':'开始补透明图'):(review?'开始全店重做':'开始全量补缺');submit.disabled=busy||only&&!ids.length;};
   const persist=()=>adapter.saveDraft({[key]:input.value});
   const controls=disabled=>{input.disabled=cancel.disabled=disabled;choices.forEach(r=>r.disabled=disabled);refresh();};
   input.oninput=()=>{touched=true;refresh();saving=persist();saving.catch(fail);};choices.forEach(r=>r.onchange=refresh);
   const close=async()=>{if(busy)return;busy=true;controls(true);try{await saving.catch(()=>{});await persist();box.remove();}catch(e){fail(e);}finally{busy=false;controls(false);}};
   cancel.onclick=close;box.bg.onclick=e=>{if(e.target===box.bg)close();};
   adapter.readDrafts().then(d=>{if(!touched&&!input.value){input.value=d?.[key]||'';refresh();}}).catch(fail);
   submit.onclick=async()=>{const scope=mode(),ids=adapter.parse(input.value);if(busy||scope==='ids'&&!ids.length)return;busy=true;controls(true);try{await saving.catch(()=>{});await persist();await adapter.start('transparent',{mode:scope,ids:scope==='ids'?ids:[],reviewRejected:review,source:'existing_white'});box.remove();}catch(e){fail(e);}finally{busy=false;controls(false);}};
   refresh();setTimeout(()=>{if(input.isConnected&&mode()==='ids')input.focus();},50);
  }
  function open(){
   if(adapter.hasActive()||adapter.hasDialog())return;
   const box=adapter.mount('<h3>透明图 · 选择运行方式</h3><p class="scm-sub">已有白底图 → 本地抠图 → 透明 PNG → 上传回填</p><div class="scm-actions" style="flex-direction:column;gap:8px;align-items:stretch;">'+
    '<button type="button" class="scm-btn scm-start scm-pick tp-menu-all" style="width:100%;"><span class="scm-pick-t">全量补缺</span><span class="scm-pick-s">完整扫描后补充透明图空槽</span></button>'+
    '<button type="button" class="scm-btn scm-start scm-pick tp-menu-ids" style="width:100%;"><span class="scm-pick-t">自定义商品 ID</span><span class="scm-pick-s">只处理指定商品，不扩大范围</span></button>'+
    '<button type="button" class="scm-btn scm-start scm-pick tp-menu-review" style="width:100%;"><span class="scm-pick-t">重做审核不通过</span><span class="scm-pick-s">复用白底图重新抠图，先选择范围</span></button><button type="button" class="scm-btn scm-cancel tp-cancel">取消</button></div>');
   for(const[selector,scope,review]of[['.tp-menu-all','all',false],['.tp-menu-ids','ids',false],['.tp-menu-review','ids',true]])box.modal.querySelector(selector).onclick=()=>{box.remove();openScope(scope,review);};
   box.modal.querySelector('.tp-cancel').onclick=()=>box.remove();box.bg.onclick=e=>{if(e.target===box.bg)box.remove();};
  }
  return {open,openScope};
 }
 root.FullTransparentUI={install};
})(globalThis);
