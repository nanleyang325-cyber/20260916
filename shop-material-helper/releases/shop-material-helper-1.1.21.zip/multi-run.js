(function(root){
 'use strict';
 const MODULES=['white','scene','mainvideo','searchvideo','search','trend','selling','incubate','guanghe','follow'];
 const QUOTA_MODULES=['white','scene','mainvideo','searchvideo','search'];
 const clone=value=>structuredClone(value);
 function quota(value){if(value===''||value==null)return null;const n=Number(value);if(!Number.isInteger(n)||n<1||n>9999)throw Error('商品数量上限须为 1 至 9999，或留空不限。');return n;}
 function scope(run){return JSON.stringify({entries:run.entries,maxCalls:run.maxCalls,totalQuota:run.totalQuota,runAt:run.runAt,dailyTime:run.dailyTime});}
 function nextDaily(time,now=Date.now()){if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('每日执行时间无效。');const next=new Date(now),[h,m]=time.split(':').map(Number);next.setHours(h,m,0,0);if(next.getTime()<=now)next.setDate(next.getDate()+1);return next.getTime();}
 function create(entries,options={}){
  if(options.startConsent!==true)throw Error('请确认模块顺序、范围、费用上限及运行时间。');
  if(!Array.isArray(entries)||!entries.length||entries.length>MODULES.length)throw Error('请选择至少一个可自动执行模块。');
  const seen=new Set(),frozen=entries.map(entry=>{if(!MODULES.includes(entry.module)||seen.has(entry.module))throw Error('模块不存在、重复或须使用独立网页工作台。');seen.add(entry.module);const selection=clone(entry.selection||{});if(selection.mode==='cleanup')throw Error('素材删除不纳入无人值守多任务。');if(!['all','ids','date','replica'].includes(selection.mode))throw Error('多任务商品选择方式无效。');if(selection.mode==='date'&&(!/^\d{4}-\d{2}-\d{2}$/.test(selection.dateFrom||'')||!/^\d{4}-\d{2}-\d{2}$/.test(selection.dateTo||'')||selection.dateFrom>selection.dateTo))throw Error('请明确有效的固定上架日期范围。');return {module:entry.module,selection:{...selection,startConsent:true,autoPublish:true},maxProducts:QUOTA_MODULES.includes(entry.module)?quota(entry.maxProducts):null};});
  const maxCalls=Number(options.maxCalls);if(!Number.isInteger(maxCalls)||maxCalls<1||maxCalls>100)throw Error('整轮生成次数上限须为 1 至 100。');
  const now=options.now??Date.now(),dailyTime=options.dailyTime||'';if(dailyTime&&!options.dailyConsent)throw Error('每天自动执行会每天重新产生费用，须单独确认。');
  const runAt=dailyTime?nextDaily(dailyTime,now):Number(options.runAt||now);if(!Number.isFinite(runAt)||runAt<now-60000)throw Error('运行时间已经过去。');
  const run={id:crypto.randomUUID(),entries:frozen,maxCalls,totalQuota:quota(options.totalQuota),dailyTime,runAt,nextAt:runAt,enabled:true,status:runAt>now?'scheduled':'running',position:0,childIds:[],currentChildId:null,usedCalls:0,usedProducts:0,cycle:1,history:[],events:[],createdAt:new Date(now).toISOString()};run.consentScope=scope(run);return run;
 }
 function completedProducts(child){return new Set((child.items||[]).filter(item=>['verified','preview'].includes(item.status)).flatMap(item=>item.productIds||[])).size;}
 async function advance(run,io){
  if(!run.enabled)return;
  const now=io.now?.()??Date.now(),save=async detail=>{run.events.push({at:new Date(now).toISOString(),position:run.position,detail});await io.save(run);};
  try{
   if(run.consentScope!==scope(run))throw Error('多任务顺序、范围、预算或时间已变化，须重新确认。');
   if(run.nextAt>now)return;
   if(run.status==='waiting_daily'){run.cycle++;run.position=0;run.childIds=[];run.currentChildId=null;run.usedCalls=0;run.usedProducts=0;run.status='running';await save('开始已确认的每日新一轮；本轮预算重新计数。');return;}
   if(run.currentChildId){
    const child=await io.child(run.currentChildId);if(!child)throw Error('原子流程记录缺失，禁止重建以免重复扣费。');
    if(child.multiRunId!==run.id||child.multiPosition!==run.position||child.multiCycle!==run.cycle)throw Error('原子流程与多任务登记不符。');
    const calls=Number(child.usedCalls||0);if(!Number.isInteger(calls)||calls<0||run.usedCalls+calls>run.maxCalls)throw Error('原子流程生成次数记录超过本轮预算，已停止。');
    if(child.status==='done'&&!child.enabled){run.entryResults||={};run.entryResults[run.position]={module:child.module,childId:child.id,status:child.completionReport?.outcome==='completed'?'generated':'failed',detail:child.completionReport?'子模块已结算：'+JSON.stringify(child.completionReport.counts):'子模块结束，具体结果见原任务',completionReport:child.completionReport};run.usedCalls+=calls;if(QUOTA_MODULES.includes(child.module))run.usedProducts+=completedProducts(child);run.position++;run.currentChildId=null;if(run.status==='draining'){run.enabled=false;run.status='stopped';await save('当前已付费任务完成收尾，后续模块未启动。');}else await save('当前模块结束，按原顺序进入下一模块。');return;}
    if(!child.enabled){
     if(root.FullTaskFailures&&!child.cancellation&&!['paused','stopped','drained'].includes(child.status)){
      run.entryResults||={};run.entryResults[run.position]={module:child.module,childId:child.id,status:'failed',detail:root.FullTaskFailures.clean(child.error||'子模块未核验完成'),completionReport:root.FullTaskFailures.report(child,child.kind==='trend'?'trend':'flow')};run.usedCalls+=calls;run.position++;run.currentChildId=null;await save('子模块卡点及原编号已记录，继续原顺序下一模块。');return;
     }
     run.enabled=false;run.status=['paused','stopped','drained'].includes(child.status)?'stopped':'blocked';run.error=child.error||(['stopped','drained'].includes(child.status)?'当前模块已停止，原编号保留。':'当前模块结果未确认，后续模块不启动。');await save(run.error);return;
    }
    await io.tick(child.id);return;
   }
   if(run.status==='draining'){run.enabled=false;run.status='stopped';await save('当前没有需要收尾的子流程，后续模块未启动。');return;}
   if(run.position>=run.entries.length||run.totalQuota&&run.usedProducts>=run.totalQuota){const reason=run.position>=run.entries.length?'本轮所有模块已结束。':'达到整轮商品上限，未轮到的模块本轮不再执行。';run.history.push({cycle:run.cycle,childIds:[...run.childIds],usedCalls:run.usedCalls,usedProducts:run.usedProducts,endedAt:new Date(now).toISOString()});if(run.dailyTime){run.status='waiting_daily';run.nextAt=nextDaily(run.dailyTime,now);await save(reason+' 等待下一次已确认的每日执行。');}else{run.enabled=false;run.status='done';await save(reason);}return;}
   const entry=run.entries[run.position],remaining=run.maxCalls-run.usedCalls,selection={...clone(entry.selection),maxCalls:Math.min(Number(entry.selection.maxCalls)||run.maxCalls,remaining)};
   if(QUOTA_MODULES.includes(entry.module)){const remainingProducts=run.totalQuota?run.totalQuota-run.usedProducts:null,limits=[entry.maxProducts,remainingProducts].filter(n=>n!==null);if(limits.length)selection.maxProducts=Math.min(...limits);}
   const child=await io.create(entry.module,selection,{parentId:run.id,position:run.position,cycle:run.cycle});
   if(!child?.id)throw Error('子流程未确认登记成功。');run.currentChildId=child.id;if(!run.childIds.includes(child.id))run.childIds.push(child.id);run.status='running';await save('已登记下一个模块及其固定范围、剩余预算；尚未重复创建。');
  }catch(error){run.enabled=false;run.status='blocked';run.error=error.message;await save(error.message);}
 }
 const api={MODULES,QUOTA_MODULES,quota,scope,nextDaily,create,advance,completedProducts};root.FullMultiRun=api;if(typeof module==='object')module.exports=api;
})(globalThis);
