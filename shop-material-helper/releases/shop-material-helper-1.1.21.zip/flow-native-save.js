(function(root){
 'use strict';
 if(root.FullWhiteNativeSave)return;
 let active=null;
 function imageURL(value){try{const u=new URL(value);if(u.protocol==='https:'&&/(^|\.)alicdn\.com$/.test(u.hostname)&&!u.username&&!u.password&&![...u.searchParams.keys()].some(key=>/token|secret|credential|auth|signature|(^|_)key$/i.test(key)))return u.href;}catch{}return null;}
 function endpoint(value){try{const u=new URL(String(value),location.href);return u.protocol==='https:'&&u.hostname==='sale.taobao.com'&&u.pathname==='/dpss/yinhe/form/save.do';}catch{return false;}}
 function fields(body,pid){try{
  const params=typeof FormData!=='undefined'&&body instanceof FormData?body:body instanceof URLSearchParams?body:typeof body==='string'?new URLSearchParams(body):null;if(!params)return null;
  if(params.getAll('domainId').length!==1||params.get('domainId')!==pid||params.getAll('bizId').length!==1||params.get('bizId')!=='3'||params.getAll('postFormDatas').length!==1)return null;
  for(const [key,value]of [['domainType','1001'],['bizType','22'],['itemId',pid]])if(params.has(key)&&params.get(key)!==value)return null;
  const forms=JSON.parse(params.get('postFormDatas')),form=forms?.[0]?.postFormData;if(!Array.isArray(forms)||forms.length!==1||!form||Object.keys(form).length!==1||!Object.prototype.hasOwnProperty.call(form,'itemWhiteImg'))return null;
  return imageURL(form.itemWhiteImg);
 }catch{return null;}}
 function owned(pid,itemId){if(!active||active.pid!==pid||active.itemId!==itemId)throw Error('白底图保存观察归属不符。');return active;}
 function install(pid,itemId){
  if(!/^\d{6,}$/.test(pid)||typeof itemId!=='string'||!itemId)throw Error('白底图保存观察缺少明确商品与原任务。');if(active)throw Error('已有白底图保存观察，未重复挂钩或点击。');
  const state={pid,itemId,records:[],closed:false,lastAt:Date.now(),restores:[],listeners:[]};active=state;
  const record=body=>{if(state.closed)return null;const imageUrl=fields(body,pid);if(!imageUrl)return null;const result={imageUrl,at:new Date().toISOString(),done:false,confirmed:false};state.records.push(result);state.lastAt=Date.now();return result;};
  const complete=(result,status,response)=>{if(!result||state.closed)return;result.done=true;result.confirmed=status>=200&&status<300&&response?.success===true;state.lastAt=Date.now();};
  try{
   const originalFetch=root.fetch;
   if(typeof originalFetch==='function'){
    function wrapped(input,init){
     const method=String(init?.method||input?.method||'GET').toUpperCase(),target=method==='POST'&&endpoint(typeof input==='string'||input instanceof URL?input:input?.url);let candidate=null;
     if(target){if(init&&Object.prototype.hasOwnProperty.call(init,'body'))candidate=Promise.resolve(record(init.body));else if(input?.clone)try{candidate=input.clone().text().then(record,()=>null);}catch{}}
     let response;try{response=originalFetch.apply(this,arguments);}catch(error){if(candidate)candidate.then(r=>complete(r,0,null));throw error;}
     if(!candidate)return response;
     Promise.resolve(response).then(async value=>{const r=await candidate;try{complete(r,value.status,await value.clone().json());}catch{complete(r,value.status,null);}},async()=>complete(await candidate,0,null));return response;
    }
    root.fetch=wrapped;state.restores.push(()=>{if(root.fetch===wrapped)root.fetch=originalFetch;});
   }
   const proto=root.XMLHttpRequest?.prototype;if(proto){const originalOpen=proto.open,originalSend=proto.send,targets=new WeakMap();
    function opened(method,url){targets.set(this,String(method).toUpperCase()==='POST'&&endpoint(url));return originalOpen.apply(this,arguments);}
    function sent(body){const r=targets.get(this)?record(body):null;if(r){const xhr=this,done=()=>{let value;try{value=xhr.responseType==='json'?xhr.response:JSON.parse(xhr.responseText);}catch{}complete(r,xhr.status,value);};this.addEventListener('loadend',done,{once:true});state.listeners.push([this,done]);}return originalSend.apply(this,arguments);}
    proto.open=opened;proto.send=sent;state.restores.push(()=>{if(proto.open===opened)proto.open=originalOpen;if(proto.send===sent)proto.send=originalSend;});
   }
   if(!state.restores.length)throw Error('白底图保存观察入口不可用。');return {armed:true,productId:pid,itemId};
  }catch(error){restore(pid,itemId);throw error;}
 }
 function restore(pid,itemId){if(!active)return {restored:true};const state=owned(pid,itemId);state.closed=true;for(const [xhr,listener]of state.listeners)xhr.removeEventListener('loadend',listener);for(const restoreHook of state.restores.reverse())restoreHook();active=null;return {restored:true};}
 async function wait(pid,itemId,options={}){const state=owned(pid,itemId),timeout=Math.min(30000,Math.max(0,Number(options.timeoutMs??30000))),quiet=Math.min(1000,Math.max(0,Number(options.quietMs??500))),start=Date.now();
  try{while(true){
   if(state.records.length>1)return {status:'submitted_unconfirmed',platformSaveConfirmed:false,message:'检测到多个同商品白底保存请求，未认定为唯一保存。'};
   const r=state.records[0];if(r?.done&&Date.now()-state.lastAt>=quiet){if(r.confirmed)return {status:'submitted_unconfirmed',platformSaveConfirmed:true,source:'owned-native-editor-save-request',productId:pid,itemId,imageUrl:r.imageUrl,at:r.at,saveRequestCount:1};return {status:'submitted_unconfirmed',platformSaveConfirmed:false,message:'平台白底保存响应未明确成功，只能回查原记录。'};}
   if(Date.now()-start>=timeout)return {status:'submitted_unconfirmed',platformSaveConfirmed:false,message:'未取得唯一白底保存回执，保留原提交意图。'};
   await new Promise(resolve=>setTimeout(resolve,100));
  }}finally{if(active===state)restore(pid,itemId);}
 }
 root.FullWhiteNativeSave={install,wait,restore};
})(globalThis);
