'use strict';
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(!['FULL_WHITE_RETRY_CLAIM','FULL_WHITE_RETRY_IMPORT','FULL_WHITE_RETRY_DECIDE'].includes(message.type))return false;
 if(sender.id!==chrome.runtime.id||!['popup.html','log-details.html'].some(p=>sender.url?.split(/[?#]/)[0]===chrome.runtime.getURL(p)))return false;
 executionGate(async()=>{
  const all=await flowRuns(),run=all.find(r=>r.id===message.runId),item=FullWhiteRetry.candidate(run),token=FullWhiteRetry.token(item);
  if(!item||message.generationId!==token)throw Error('原审核记录已变化，请刷新日志；未新增生成。');
  if(message.type==='FULL_WHITE_RETRY_CLAIM'){
   if(item.retryDecision?.generationId===token||all.some(r=>r.enabled||r.status==='paused'))return {offer:false};let offer=false;
   await FullStateStore.update('white-review-retry-prompts-v1',old=>{const state=old||{},key=run.id+':'+token,now=Date.now();if(state[key]?.until>now)return state;for(const k of Object.keys(state))if(state[k].until<now)delete state[k];state[key]={owner:message.owner,until:now+120000};offer=true;return state;});return {offer};
  }
  if(message.type==='FULL_WHITE_RETRY_IMPORT'){
   const artifact=await reviewAsset(message.data);
   if([...(item.reviewAttempts||[]),item].some(a=>a.retryImportedReference?.sha256===artifact.sha256))throw Error('这张导入图已在此前重做中使用，请选择其他素材图。');
   const assetKey=crypto.randomUUID();await reviewWrite(REVIEW_ASSET+assetKey,{...artifact,productId:item.productIds[0],runId:run.id,previousGenerationId:token,fileName:String(message.fileName||'导入素材图').split(/[\\/]/).at(-1).slice(0,100)});
   return {assetKey,sha256:artifact.sha256,preview:artifact.reference};
  }
  if(!['continue','import','stop'].includes(message.choice))throw Error('请选择是否继续采集。');
  if(message.choice==='stop'){await FullStateStore.update(FLOW_KEY,runs=>{const current=runs.find(r=>r.id===run.id),target=FullWhiteRetry.candidate(current);if(FullWhiteRetry.token(target)!==token)return runs;target.retryDecision={generationId:token,choice:'stop',at:new Date().toISOString()};current.events.push({at:new Date().toISOString(),productId:target.productIds[0],detail:'用户暂不继续采集：保留本次审核不通过记录，未新增生成或替换。'});return runs;});return {cancelled:true};}
  let imported=null;
  if(message.choice==='import'){
   if(message.identityConfirmed!==true||typeof message.assetKey!=='string'||!/^[a-f0-9-]{36}$/.test(message.assetKey))throw Error('请先导入图片，并确认属于当前商品。');
   const a=await reviewRead(REVIEW_ASSET+message.assetKey);
   if(!a||a.productId!==item.productIds[0]||a.runId!==run.id||a.previousGenerationId!==token||[...(item.reviewAttempts||[]),item].some(i=>i.retryImportedReference?.sha256===a.sha256))throw Error('导入图片未绑定当前原任务，或已经使用，请重新选择。');
   imported={assetKey:message.assetKey,sha256:a.sha256,previousGenerationId:token,fileName:a.fileName};
  }
  await reviewIdle();if(!FullFlowRun.matchesConsent(run))throw Error('原白底图执行范围已变化。');
  try{await FullCurrentTab.get(run);}catch{await FullCurrentTab.recover(run);}const snapshot=await flowWhiteReviewSnapshot(run,item.productIds[0]);
  FullWhiteRetry.restart(run,item,snapshot,token);
  if(imported){item.retryImportedReference=imported;item.detail='用户确认使用导入素材图作为本次重做参考，未再次自动采图。';run.events.at(-1).detail='用户确认导入素材图：已绑定商品 '+item.productIds[0]+' 及原任务；本次以导入图为参考，最多新增一次生成，仍在原标签页执行。';}
  await flowSave(run);await chrome.alarms.create('full-flow:'+run.id,{when:Date.now()+100,periodInMinutes:.5});return {runId:run.id,continued:true};
 }).then(result=>{reply({ok:true,...result});if(result.continued)flowTick(result.runId).catch(()=>{});}).catch(e=>reply({ok:false,error:e.message}));return true;
});
