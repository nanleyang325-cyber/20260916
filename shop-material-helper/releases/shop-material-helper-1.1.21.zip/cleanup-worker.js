'use strict';
async function cleanupOpen(run,url,reload=false){
 const allowed=u=>typeof u==='string'&&u.startsWith('https://qn.taobao.com/home.htm/material-center/');let tab;
 if(Number.isInteger(run.tabId)){try{tab=await chrome.tabs.get(run.tabId);}catch{throw Error('原清理工作标签页已关闭，请恢复原页；未另开标签页。');}if(!allowed(tab.url)||run.cleanupWindowId!==undefined&&tab.windowId!==run.cleanupWindowId)throw Error('原清理工作页已转作其他用途，未接管或新开页面。');}
 else {const tabs=await chrome.tabs.query({currentWindow:true}),eligible=tabs.filter(t=>allowed(t.url));tab=eligible.find(t=>t.active)||eligible[0];if(!tab)tab=await chrome.tabs.create({url,active:true});run.tabId=tab.id;run.cleanupWindowId=tab.windowId;await flowSave(run);}
 if(tab.url!==url)await chrome.tabs.update(tab.id,{url});else if(reload)await chrome.tabs.reload(tab.id);
 for(let n=0;n<40;n++){tab=await chrome.tabs.get(run.tabId);if(tab.status==='complete'){await queueDelay(300);return tab;}await queueDelay(300);}throw Error('原清理工作页加载超时，未新开标签页。');
}
async function cleanupPictureCall(run,action,...args){
 const tab=await cleanupOpen(run,'https://qn.taobao.com/home.htm/material-center/mine-material/sucai-tu');
 await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',files:['cleanup-pictures.js']});
 const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:async(action,args)=>{try{return await FullCleanupPictures[action](...args);}catch{return {error:'图片空间查询或操作未确认'};}},args:[action,args]});if(result?.error)throw Error(result.error);return result;
}
async function cleanupPictureIndex(run){
 if(run.cleanupPictureIndex)return;
 const wanted=new Set(run.items.flatMap(i=>i.candidate?.pictureUrls||[])),records=[];let complete=false;
 for(let page=1;page<=100&&wanted.size;page++){if(!await flowLive(run))throw Error('已停止图片空间读取');const r=await cleanupPictureCall(run,'list',page);for(const p of r.records)if(wanted.has(p.url)){records.push(p);wanted.delete(p.url);}if(r.empty){complete=true;break;}await queueDelay(100);}
 run.cleanupPictureIndex={records,complete,unmatched:[...wanted]};await flowSave(run);
}
async function cleanupPictures(run,item){
 if(item.receipt?.status!=='已删除'||run.selection.pictureCleanup!=='unreferenced-only')throw Error('素材未确认删除，不清理图片');
 FullCleanupDirect.ids(run,item);item.pictureCleanup||={results:[]};const state=item.pictureCleanup,urls=item.candidate.pictureUrls||[];
 const save=async(detail)=>{FullCleanupDirect.event(run,'素材 '+item.candidate.contentId+' · '+detail);await flowSave(run);};
 if(!urls.length){state.summary='关联图片保留：未取得完整关联图片地址';if(!state.noImagesLogged){state.noImagesLogged=true;await save(state.summary);}return;}
 try{await cleanupPictureIndex(run);}catch(e){if(!await flowLive(run))throw e;state.summary='关联图片保留：图片空间索引未确认';await save(state.summary);return;}
 for(const url of urls){
  if(!await flowLive(run))throw Error('已停止后续图片清理');
  let result=state.results.find(r=>r.url===url);if(result&&['deleted','retained'].includes(result.status))continue;
  const matches=run.cleanupPictureIndex.records.filter(p=>p.url===url),p=matches[0];
  if(!result){result={url,status:'pending'};state.results.push(result);}
  if(matches.length!==1){Object.assign(result,{status:'retained',reason:'未唯一匹配图片空间文件'});await save('图片保留：'+url+'；'+result.reason);continue;}
  result.id=p.id;result.name=p.name;
  try{
   if(!result.intent){const proof=await cleanupPictureCall(run,'inspect',p);if(!proof.safe){Object.assign(result,{status:'retained',reason:proof.reason});await save('图片 '+p.id+' 保留：'+proof.reason);continue;}if(!await flowLive(run))throw Error('已停止图片删除');result.intent={at:new Date().toISOString(),id:p.id};await save('图片 '+p.id+' 已确认无引用，登记一次删除请求');if(!await flowLive(run))throw Error('已停止图片删除');const sent=await cleanupPictureCall(run,'remove',p);if(sent.status==='retained'){Object.assign(result,sent);await save('图片 '+p.id+' 保留：'+sent.reason);continue;}}
   Object.assign(result,await cleanupPictureCall(run,'verify',p));await save('图片 '+p.id+' '+(result.status==='deleted'?'已删除':'待确认')+'：'+result.reason);
   if(result.status==='unknown')throw Error(result.reason);
  }catch(e){if(result.intent){result.status='unknown';result.reason='图片删除结果未确认，继续原任务时仅回查';await save('图片 '+p.id+' 待确认：'+result.reason);throw Error(result.reason);}Object.assign(result,{status:'retained',reason:'图片引用查询未确认'});await save('图片 '+p.id+' 保留：'+result.reason);}
 }
 state.summary='图片已删除 '+state.results.filter(r=>r.status==='deleted').length+'、保留 '+state.results.filter(r=>r.status==='retained').length+'；原因见逐条日志';await save(state.summary);
}
