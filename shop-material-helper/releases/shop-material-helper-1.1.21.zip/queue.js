(function(root){
 'use strict';
 async function run(queue,io){
  if(!queue.enabled||queue.done)return;
  while(queue.position<queue.jobs.length){
   if(!queue.enabled)return;
   const entry=queue.jobs[queue.position],job=await io.job(entry.id);
   if(!job||root.FullAutomation.scope(job)!==entry.scope){queue.enabled=false;queue.error='商品或素材范围变化，队列停止。';await io.save(queue);return;}
   queue.phase='working';await io.save(queue);
   if(!queue.enabled)return;
   try{const result=await io.run(job);entry.status=result.status;entry.receipt=result.receipt;entry.taskOutcome=root.FullTaskFailures?.outcome(result);if(result.status!=='verified'){queue.enabled=false;queue.phase='needs_review';queue.error=result.error||result.detail||'当前任务未核验通过。';await io.save(queue);return;}}
   catch(error){entry.taskOutcome=root.FullTaskFailures?.outcome(job);queue.enabled=false;queue.phase='needs_review';queue.error=error.message;await io.save(queue);return;}
   queue.position++;queue.phase='ready';await io.save(queue);
  }
  queue.done=true;queue.enabled=false;queue.phase='done';await io.save(queue);
 }
 root.FullQueue={run};if(typeof module!=='undefined')module.exports=root.FullQueue;
})(globalThis);
