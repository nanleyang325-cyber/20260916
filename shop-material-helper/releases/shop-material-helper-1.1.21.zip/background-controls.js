'use strict';
importScripts('idle-ego-pause.js');
async function controlReleaseIdleEgoPause(){return FullIdleEgoPause.release({read:keys=>chrome.storage.local.get(keys),update:(key,fn)=>FullStateStore.update(key,fn),runtime:()=>({queueBusy,studioBusy:studioBusy.size})});}

const GLOBAL_CONTROL_KEY='material-global-control-v1',PROCESS_RECORD_KEY='material-processing-records-v1';
const CONTROL_RUN_KEYS=['material-auto-runs-v1','material-flow-runs-v1','material-multi-runs-v1','material-studio-publish-batches-v1','material-f88-runs-v1','material-kmt-runs-v1'];
function controlTouchWhite(run){if(run.kind==='trend'&&run.trend)run.trend.controlRevision=(run.trend.controlRevision||0)+1;if(run.module==='white')run.whiteControlRevision=(Number.isSafeInteger(run.whiteControlRevision)&&run.whiteControlRevision>=0?run.whiteControlRevision:0)+1;}
async function controlHost(action){try{const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/media-batches/control"),{method:'POST',headers:{'X-Material-Client':'full-v1','Content-Type':'application/json'},body:JSON.stringify({action}),signal:AbortSignal.timeout(5000)});if(!response.ok)return {ok:false,note:'主机批次暂停状态未确认。'};return {ok:true,...await response.json()};}catch{return {ok:false,note:'插件服务未就绪；扩展控制已记录，主机队列状态待核对。'};}}
async function controlStudioIds(){const tasks=(await chrome.storage.local.get('material-studio-requests-v1'))['material-studio-requests-v1']||[];return [...new Set([...studioBusy,...tasks.filter(t=>!t.parentId&&['queued','running','waiting_text','submitting','submitted_unconfirmed'].includes(t.status)).map(t=>t.requestId)])];}
async function controlPause(policy={}){
 const previous=(await chrome.storage.local.get(GLOBAL_CONTROL_KEY))[GLOBAL_CONTROL_KEY];if(previous?.paused)return previous;
 const snapshot=previous?.draining?{...previous,paused:true,draining:false,stopping:false}:{paused:true,at:new Date().toISOString(),runs:{},states:{},queues:[],studio:await controlStudioIds()};
 await FullStateStore.update(GLOBAL_CONTROL_KEY,()=>snapshot);
 for(const key of CONTROL_RUN_KEYS)await FullStateStore.update(key,runs=>{if(!runs)return;const active=runs.filter(run=>run.enabled||snapshot.runs[key]?.includes(run.id||run.batchId)&&['drained','stopped'].includes(run.status));snapshot.runs[key]=[...new Set([...(snapshot.runs[key]||[]),...active.map(run=>run.id||run.batchId)])];snapshot.states[key]||={};for(const run of active){snapshot.states[key][run.id||run.batchId]||={status:run.status,draining:!!run.draining};run.enabled=false;run.status='paused';controlTouchWhite(run);}return runs;});
 await FullStateStore.update(QUEUE_KEY,state=>{if(!state)return;snapshot.queues=[...new Set([...snapshot.queues,...(state.backgroundQueues||[]).filter(q=>q.enabled).map(q=>q.id)])];for(const queue of state.backgroundQueues||[])queue.enabled=false;for(const job of state.jobs||[])if(job.backgroundQueueLocked)job.stopRequested=true;return state;});
 for(const job of queueJobs.values())job.stopRequested=true;
 snapshot.host=policy.localOnly?{ok:false,localOnly:true}:await controlHost('pause');await FullStateStore.update(GLOBAL_CONTROL_KEY,()=>snapshot);return snapshot;
}
async function controlResume(){
 if(queueBusy||studioBusy.size)throw Error('正在等待已开始的动作停止，请稍后继续；未新建任务。');const snapshot=(await chrome.storage.local.get(GLOBAL_CONTROL_KEY))[GLOBAL_CONTROL_KEY];if(!snapshot?.paused)return {paused:false};
 // Validate every immutable scope before changing any enabled flag.
 for(const key of CONTROL_RUN_KEYS){const runs=(await chrome.storage.local.get(key))[key]||[];for(const run of runs)if(snapshot.runs[key]?.includes(run.id||run.batchId)&&run.status==='paused'){if(key==='material-flow-runs-v1'&&(run.module==='white'?!FullFlowRun.matchesConsent(run):run.consentScope!==FullFlowRun.scope(run))||key==='material-auto-runs-v1'&&run.consentScope!==FullAutoRun.scope(run)||key==='material-multi-runs-v1'&&run.consentScope!==FullMultiRun.scope(run)||key==='material-f88-runs-v1'&&run.consentScope!==FullF88Run.scope(run)||key==='material-kmt-runs-v1'&&run.consentScope!==FullKmtCore.scope(run))throw Error('原范围发生变化，未恢复任何任务。');}}
 await FullStateStore.update(GLOBAL_CONTROL_KEY,value=>({...value,paused:false,draining:false,stopping:false,resumedAt:new Date().toISOString()}));
 for(const key of CONTROL_RUN_KEYS)await FullStateStore.update(key,runs=>{if(!runs)return;for(const run of runs)if(snapshot.runs[key]?.includes(run.id||run.batchId)&&run.status==='paused'){const original=snapshot.states?.[key]?.[run.id||run.batchId];run.enabled=true;run.status=original?.status||'running';run.error='';run.draining=original?.draining||false;controlTouchWhite(run);}return runs;});
 await FullStateStore.update(QUEUE_KEY,state=>{if(!state)return;for(const queue of state.backgroundQueues||[])if(snapshot.queues.includes(queue.id)&&!queue.done)queue.enabled=true;return state;});
 for(const id of snapshot.runs['material-auto-runs-v1']||[])await chrome.alarms.create('auto-run:'+id,{when:Date.now()+100,periodInMinutes:.5});
 const flows=await flowRuns();for(const id of snapshot.runs['material-flow-runs-v1']||[]){const run=flows.find(r=>r.id===id);if(run?.enabled&&!run.multiRunId)await chrome.alarms.create('full-flow:'+id,{when:Date.now()+100,periodInMinutes:.5});}
 for(const id of snapshot.runs['material-multi-runs-v1']||[])await chrome.alarms.create('full-multi:'+id,{when:Date.now()+100,periodInMinutes:.5});
 for(const id of snapshot.runs['material-studio-publish-batches-v1']||[])await chrome.alarms.create('studio-publish-batch:'+id,{when:Date.now()+100,periodInMinutes:.5});
 for(const id of snapshot.queues||[])await chrome.alarms.create('full-run:'+id,{when:Date.now()+100,periodInMinutes:.5});
 for(const id of snapshot.studio||[]){await chrome.alarms.create('studio-request:'+id,{when:Date.now()+100,periodInMinutes:.5});studioTick(id).catch(()=>{});}
 for(const id of snapshot.runs['material-f88-runs-v1']||[])await chrome.alarms.create('full-f88:'+id,{when:Date.now()+100,periodInMinutes:.5});
 for(const id of snapshot.runs['material-kmt-runs-v1']||[])await chrome.alarms.create('full-kmt:'+id,{when:Date.now()+100,periodInMinutes:.5});
 const host=snapshot.host?.localOnly?{ok:false,localOnly:true}:await controlHost('resume');return {paused:false,host};
}
async function controlDrain(){
 const previous=(await chrome.storage.local.get(GLOBAL_CONTROL_KEY))[GLOBAL_CONTROL_KEY];if(previous?.draining||previous?.paused)return previous;
 const snapshot={paused:false,draining:true,stopping:true,at:new Date().toISOString(),runs:{},states:{},queues:[],studio:await controlStudioIds()};
 // Persist the entry gate first. Already accepted work keeps its original ID.
 await FullStateStore.update(GLOBAL_CONTROL_KEY,()=>snapshot);
 for(const key of CONTROL_RUN_KEYS)await FullStateStore.update(key,runs=>{if(!runs)return;const active=runs.filter(run=>run.enabled);snapshot.runs[key]=active.map(run=>run.id||run.batchId);snapshot.states[key]=Object.fromEntries(active.map(run=>[run.id||run.batchId,{status:run.status,draining:!!run.draining}]));for(const run of active){run.draining=true;if(run.kind==='trend'){run.enabled=false;run.status='drained';}else if(key==='material-multi-runs-v1'&&!run.currentChildId){run.enabled=false;run.status='drained';}else run.status='draining';controlTouchWhite(run);}return runs;});
 await FullStateStore.update(QUEUE_KEY,state=>{if(!state)return;snapshot.queues=[...new Set([...snapshot.queues,...(state.backgroundQueues||[]).filter(q=>q.enabled).map(q=>q.id)])];for(const queue of state.backgroundQueues||[])queue.enabled=false;return state;});
 snapshot.host=await controlHost('drain');await FullStateStore.update(GLOBAL_CONTROL_KEY,()=>snapshot);
 await chrome.alarms.create('global-drain-watch',{when:Date.now()+100,periodInMinutes:.5});return controlDrainWatch();
}
async function controlDrainWatch(){
 const snapshot=(await chrome.storage.local.get(GLOBAL_CONTROL_KEY))[GLOBAL_CONTROL_KEY];if(!snapshot?.draining)return snapshot||{paused:false,stopping:false};
 const tasks=(await chrome.storage.local.get('material-studio-requests-v1'))['material-studio-requests-v1']||[];let active=!!queueBusy||studioBusy.size>0||tasks.some(task=>snapshot.studio?.includes(task.requestId)&&['queued','running','waiting_text','submitting','submitted_unconfirmed'].includes(task.status));for(const key of CONTROL_RUN_KEYS){const runs=(await chrome.storage.local.get(key))[key]||[];active||=runs.some(run=>run.enabled&&snapshot.runs[key]?.includes(run.id||run.batchId));}
 if(snapshot.host?.ok){const host=await controlHost('status');if(host.ok)active||=host.active===true;else snapshot.host=host;}
 if(active)return snapshot;
 for(const key of CONTROL_RUN_KEYS)await FullStateStore.update(key,runs=>{if(!runs)return;for(const run of runs)if(snapshot.runs[key]?.includes(run.id||run.batchId)&&['drained','stopped'].includes(run.status)){run.status='paused';run.enabled=false;controlTouchWhite(run);}return runs;});
 snapshot.draining=false;snapshot.stopping=false;snapshot.paused=true;snapshot.drainedAt=new Date().toISOString();await FullStateStore.update(GLOBAL_CONTROL_KEY,()=>snapshot);if(chrome.alarms.clear)await chrome.alarms.clear('global-drain-watch');return snapshot;
}
function processingKey(run,at=Date.now(),kind){
 const variant=run.module==='selling'?(run.selection?.variant==='series'?'series':'material'):run.module==='guanghe'?(run.selection?.variant==='video'?'video':'pic'):run.module==='follow'?(run.selection?.variant==='multi'?'multi':'list'):null;
 if(!variant)return run.module;
 const key=run.module+':'+variant;
 return kind!=='blacklist'&&['follow','guanghe'].includes(run.module)?key+':'+new Date(at).toLocaleDateString('sv-SE',{timeZone:'Asia/Shanghai'}):key;
}
async function trackProcessing(run){if(run.selection?.mode==='cleanup')return;await FullStateStore.update(PROCESS_RECORD_KEY,previous=>{const records=previous||{processed:{},skipped:{},blacklist:{},resets:[]};records.seen||={};for(const item of run.items||[]){const kind=item.status==='verified'?'processed':item.status==='skipped'?'skipped':item.blacklisted?'blacklist':null;if(!kind)continue;const event=[run.id,item.id||item.productIds.join(','),kind].join(':');if(records.seen[event])continue;records.seen[event]=true;const key=processingKey(run,item.publication?.at||run.createdAt||Date.now(),kind),values=new Set(records[kind][key]||[]);for(const id of item.productIds||[])values.add(id);records[kind][key]=[...values];}return records;});}
async function filterProcessing(run,targets){const records=(await chrome.storage.local.get(PROCESS_RECORD_KEY))[PROCESS_RECORD_KEY];if(!records)return targets;const key=processingKey(run),explicitWhite=run.module==='white'&&['ids','custom'].includes(run.selection?.mode),recheck=run.selection?.mode==='cleanup'||explicitWhite||['selling','incubate','trend','follow','guanghe'].includes(run.module),excluded=new Set([...(run.selection?.mode==='cleanup'||run.module==='trend'||explicitWhite?[]:records.processed?.[key]||[]),...(!recheck?records.skipped?.[key]||[]:[]),...(records.blacklist?.[processingKey(run,Date.now(),'blacklist')]||[]),...(records.blacklist?.[run.module]||[])]);const blacklisted=new Set([...(records.blacklist?.[processingKey(run,Date.now(),'blacklist')]||[]),...(records.blacklist?.[run.module]||[])]);return targets.filter(target=>{const recheckSearchSlots=run.module==='search'&&run.selection?.mode!=='cleanup'&&Number.isInteger(target.emptySlots)&&target.emptySlots>0;return !target.productIds.some(id=>blacklisted.has(id)||excluded.has(id)&&!recheckSearchSlots);});}
const originalFlowSave=flowSave;flowSave=async run=>{await originalFlowSave(run);await trackProcessing(run);};
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id)return false;
 if(['FULL_GLOBAL_PAUSE','FULL_GLOBAL_RESUME','FULL_GLOBAL_DRAIN','FULL_GLOBAL_FORCE'].includes(message.type)){executionGate(()=>message.type==='FULL_GLOBAL_RESUME'?controlResume():message.type==='FULL_GLOBAL_DRAIN'?controlDrain():controlPause()).then(result=>reply({ok:true,...result,stopping:result.stopping===true}),error=>reply({ok:false,error:error.message}));return true;}
 if(message.type==='FULL_EGO_RELEASE_SPACE'){executionGate(()=>controlPause({localOnly:true})).then(result=>reply({ok:true,...result}),error=>reply({ok:false,error:error.message}));return true;}
 if(message.type==='FULL_GLOBAL_STATUS'){chrome.storage.local.get(GLOBAL_CONTROL_KEY).then(value=>reply({ok:true,...value[GLOBAL_CONTROL_KEY]}));return true;}
 if(message.type==='FULL_RECORDS_STATUS'){chrome.storage.local.get(PROCESS_RECORD_KEY).then(value=>reply({ok:true,records:value[PROCESS_RECORD_KEY]||{processed:{},skipped:{},blacklist:{}}}));return true;}
 if(message.type==='FULL_RESET_RECORDS'){
  executionGate(async()=>{if(message.consent!==true||!['processed','skipped','blacklist'].some(key=>message[key]===true))throw Error('请选择并确认要重置的记录类别。');if(typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||queueBusy||(await flowRuns()).some(r=>r.enabled)||(await multiRuns()).some(r=>r.enabled)||(await autoRuns()).some(r=>r.enabled)||await studioBatchConflict()||(await queueState())?.backgroundQueues?.some(q=>q.enabled))throw Error('请先暂停或停止正在执行的任务，再重置记录。');let reset;await FullStateStore.update(PROCESS_RECORD_KEY,previous=>{const records=previous||{processed:{},skipped:{},blacklist:{},resets:[]};reset={at:new Date().toISOString(),categories:[],before:{}};for(const key of ['processed','skipped','blacklist'])if(message[key]===true){reset.categories.push(key);reset.before[key]=records[key];records[key]={};}records.resets||=[];records.resets.push(reset);return records;});reply({ok:true,categories:reset.categories,message:'已重置所选处理记录；费用、上传和提交意图完整保留。'});}).catch(error=>reply({ok:false,error:error.message}));return true;
 }
 return false;
});
if(chrome.alarms.onAlarm)chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='global-drain-watch')executionGate(controlDrainWatch).catch(()=>{});});
