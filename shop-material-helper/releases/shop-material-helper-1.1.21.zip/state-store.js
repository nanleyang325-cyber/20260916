(function(root){
 'use strict';
 const pending=new Map(),clone=value=>value===undefined?undefined:structuredClone(value);
 const conflict=()=>{throw new Error('任务身份或已提交范围冲突，保留原记录，请回查。');};
 const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 const identity=job=>JSON.stringify([job.id,job.module,[...(job.productIds||[])].sort()]);
 const submitted=job=>!!(job.publication||job.automation?.uploadIntent||Object.keys(job.batchUploadIntents||{}).length||job.sceneUpload);
 function keepRecord(stored,incoming,fields){
  if(!stored)return clone(incoming);if(!incoming)return clone(stored);
  for(const field of fields)if(stored[field]!=null&&incoming[field]!=null&&!same(stored[field],incoming[field]))conflict();
  const merged={...clone(stored),...clone(incoming)};
  for(const [key,value] of Object.entries(stored))if(merged[key]==null)merged[key]=clone(value);
  return merged;
 }
 function mergeJob(stored,incoming){
  if(!stored)return clone(incoming);if(!incoming)return clone(stored);
  if(identity(stored)!==identity(incoming))conflict();
  if(submitted(stored)&&(!same((stored.assets||[]).map(a=>a.id),(incoming.assets||[]).map(a=>a.id))||!!stored.replaceExisting!==!!incoming.replaceExisting))conflict();
  const merged={...clone(stored),...clone(incoming)};
  merged.publication=keepRecord(stored.publication,incoming.publication,['key','imageUrl','contentId','submittedAt']);
  merged.sceneUpload=keepRecord(stored.sceneUpload,incoming.sceneUpload,['url','pictureId','fileName','name']);
  if(stored.automation||incoming.automation){
   merged.automation={...clone(stored.automation||{}),...clone(incoming.automation||{})};
   merged.automation.uploadIntent=keepRecord(stored.automation?.uploadIntent,incoming.automation?.uploadIntent,['fileName','at']);
  }
  if(stored.batchUploadIntents||incoming.batchUploadIntents){
   merged.batchUploadIntents=clone(stored.batchUploadIntents||{});
   for(const [key,value] of Object.entries(incoming.batchUploadIntents||{}))merged.batchUploadIntents[key]=keepRecord(merged.batchUploadIntents[key],value,['at','id']);
  }
  // A snapshot without the durable intent is stale; keep the outcome associated with it.
  // A caller carrying the same intent may still publish a fresh manual readback result.
  const staleIntent=!!stored.publication&&!incoming.publication||!!stored.automation?.uploadIntent&&!incoming.automation?.uploadIntent;
  if(staleIntent||stored.status==='verified')for(const field of ['status','error','receipt','automationConsent'])if(stored[field]!==undefined)merged[field]=clone(stored[field]);
  if(staleIntent&&stored.automation)merged.automation={...clone(stored.automation),uploadIntent:merged.automation?.uploadIntent};
  if(stored.receipt&&!merged.receipt)merged.receipt=clone(stored.receipt);
  return merged;
 }
 function mergePanelState(latest,local){
  if(!latest)return clone(local);
  const merged={...clone(latest),...clone(local)},localJobs=new Map((local.jobs||[]).map(job=>[job.id,job]));
  merged.jobs=(latest.jobs||[]).map(job=>{const incoming=localJobs.get(job.id);localJobs.delete(job.id);return job.backgroundQueueLocked?clone(job):mergeJob(job,incoming);});
  for(const job of localJobs.values())merged.jobs.push(clone(job));
  if(Object.hasOwn(latest,'backgroundQueues'))merged.backgroundQueues=clone(latest.backgroundQueues);
  if(Object.hasOwn(latest,'scheduleDue'))merged.scheduleDue=clone(latest.scheduleDue);
  else delete merged.scheduleDue;
  return merged;
 }
 async function update(key,transform){
  const operation=async()=>{
   const previous=(await root.chrome.storage.local.get(key))[key],next=await transform(clone(previous));
   if(next===undefined)return previous;
   await root.chrome.storage.local.set({[key]:next});return clone(next);
  };
  if(root.navigator?.locks?.request)return root.navigator.locks.request('material-state:'+key,{mode:'exclusive'},operation);
  // Test/legacy fallback serializes this JS context only; it is not cross-context locking.
  const before=pending.get(key)||Promise.resolve(),current=before.catch(()=>{}).then(operation);pending.set(key,current);
  try{return await current;}finally{if(pending.get(key)===current)pending.delete(key);}
 }
 root.FullStateStore={update,mergeJob,mergePanelState};if(typeof module!=='undefined')module.exports=root.FullStateStore;
})(globalThis);
