(function (root) {
  const visible = el => !!el && el.getClientRects().length > 0;
  const disabled = el => !!el.closest('[disabled],[aria-disabled="true"]') || /disabled|disable/i.test(String(el.className || '') + ' ' + String(el.parentElement?.className || ''));
  function controls(container, direction, includeDisabled = false) {
    const names = direction === 'next' ? /next|right|下一页|下页|后一页/i : /prev|previous|left|上一页|上页|前一页/i;
    const arrows = direction === 'next' ? ['>', '›', '»', '→'] : ['<', '‹', '«', '←'];
    const matches = [];
    for (const el of container.querySelectorAll('button,a,[role="button"],i,svg,span')) {
      const text = el.textContent.trim();
      const classes = (el.getAttribute('class') || '').split(/\s+/).map(value => value.replace(/^next-/, '')).join(' ');
      const labels = [el.getAttribute('aria-label'), el.getAttribute('title'), el.getAttribute('data-action'), classes].filter(Boolean).join(' ');
      if (!names.test(labels) && !arrows.includes(text) && !(text.length < 8 && names.test(text))) continue;
      const target = el.closest('button,a,[role="button"]') || el;
      if (!container.contains(target) || !visible(target) || (!includeDisabled && disabled(target))) continue;
      if (!matches.includes(target)) matches.push(target);
    }
    return matches;
  }
  function locate(doc) {
    const candidates = [];
    for (const el of doc.querySelectorAll('span,div,p,li')) {
      if (!visible(el)) continue;
      const match = el.textContent.trim().match(/^(\d+)\s*\/\s*(\d+)$/);
      if (!match || el.textContent.length > 18) continue;
      let container = el.parentElement;
      for (let depth = 0; container && depth < 5; depth++, container = container.parentElement) {
        const text = container.innerText || container.textContent;
        if (text.length > 400) break;
        if (!controls(container, 'next', true).length || !controls(container, 'previous', true).length) continue;
        const expected = text.match(/共\s*(\d+)\s*(?:件|个|款)\s*商品/);
        const cls = String(container.className || '');
        const score = (expected ? 10 : 0) + (/pagination|pager/i.test(cls) ? 3 : 0);
        candidates.push({ container, current: Number(match[1]), total: Number(match[2]), expected: expected ? Number(expected[1]) : null, score });
        break;
      }
    }
    candidates.sort((a,b) => b.score - a.score);
    const first = candidates[0];
    if (!first || first.current < 1 || first.total < first.current || first.total > 500) throw new Error('未能识别商品列表分页。请打开“出售中”的商品列表。');
    if (candidates.some(c => c.score === first.score && (c.current !== first.current || c.total !== first.total))) throw new Error('页面有多个不同的分页入口，无法确定商品分页，已停止。');
    return first;
  }
  function info(doc) {
    const page = locate(doc);
    const bodyText = doc.body?.innerText || '';
    const expected = page.expected ?? (Number(bodyText.match(/共\s*(\d+)\s*(?:件|个|款)\s*商品/)?.[1] || 0) || null);
    return { current: page.current, total: page.total, expected };
  }
  function move(doc, direction) {
    const page = locate(doc);
    if ((direction === 'previous' && page.current === 1) || (direction === 'next' && page.current === page.total)) return false;
    const button = controls(page.container, direction)[0];
    if (!button) throw new Error(`无法找到可用的${direction === 'next' ? '下一页' : '上一页'}按钮，已停止。`);
    button.click(); return true;
  }
  root.MaterialPager = { info, move };
})(globalThis);
