'use strict';
const SOUTUI_WORKSPACE='https://creator.guanghe.taobao.com/page/workspace/tb';
async function soutuiInject(target){await chrome.scripting.executeScript({target:{tabId:target.tabId,frameIds:[target.frameId]},world:'MAIN',files:['soutui-form.js']});}
async function soutuiEval(target,action,arg){const allowed=['bind','openPictures','select','declaration','options','verify','pictureState'];if(!allowed.includes(action))throw Error('未知的搜推表单操作。');const [{result}]=await chrome.scripting.executeScript({target:{tabId:target.tabId,frameIds:[target.frameId]},world:'MAIN',func:async(action,arg)=>{try{const api=action==='select'?FullSoutuiPicker:FullSoutuiForm;return {ok:true,value:await api[action](arg)};}catch(e){return {ok:false,error:e.message};}},args:[action,arg??null]});if(result?.ok!==true)throw Error(result?.error||'搜推表单操作未返回确认，保留原任务。');return result.value;}
async function soutuiReference(run,item,persist=true){
 const source=await fetchReference({url:item.mainImage});const data=source.reference;if(!/^data:image\/(png|jpeg|webp);base64,/.test(data||''))throw Error('同商品原图格式未确认。');const bytes=Uint8Array.from(atob(data.split(',')[1]),c=>c.charCodeAt(0)),bitmap=await createImageBitmap(new Blob([bytes]));
 const reject=(code,message,details={})=>{item.referenceValidationFailure={code,productIds:[...item.productIds],url:item.mainImage,width:bitmap.width,height:bitmap.height,at:new Date().toISOString(),...details};throw Object.assign(Error(message),{code});};
 try{if(bitmap.width<720||bitmap.height<720)reject('SOUTUI_REFERENCE_TOO_SMALL','商品原图不足720像素，未用缩略占位图生成。');const canvas=new OffscreenCanvas(64,64),ctx=canvas.getContext('2d');ctx.drawImage(bitmap,0,0,64,64);const pixels=ctx.getImageData(0,0,64,64).data;let sum=0,sq=0,nonWhite=0;for(let n=0;n<pixels.length;n+=4){const v=(pixels[n]+pixels[n+1]+pixels[n+2])/3;sum+=v;sq+=v*v;if(v<248)nonWhite++;}const variance=sq/4096-(sum/4096)**2;if(variance<30||nonWhite/4096<.01)reject('SOUTUI_REFERENCE_EMPTY','商品原图为空白或信息不足，未生成。',{variance,nonWhiteRatio:nonWhite/4096});delete item.referenceValidationFailure;item.referenceProof={source:'same-product-record.mainImg',width:bitmap.width,height:bitmap.height,variance,nonWhiteRatio:nonWhite/4096};if(persist)await flowSave(run);return source;}finally{bitmap.close();}
}
async function soutuiExtraReference(run,item,g){
 // Scene guides contain other switch models. Use the same-product primary image only.
 if(g.sceneCategory==='switch'){const sceneIndex=Number(g.sceneIndex);if(!Number.isInteger(sceneIndex)||sceneIndex<0||sceneIndex>26)throw Error('场景参考序号无效。');return null;}
 if(g.sceneCategory==='electricCurtain'&&g.viewIndex>0){const anchor=item.generations?.[0];if(anchor?.status!=='completed')throw Error('同套整体场景尚未完成，未开始中景或局部图。');return (await flowMedia('/'+anchor.id+'/data')).data;}
 return null;
}
async function soutuiAttach(run,item,uploaded){
 const isSearch=run.module==='search';
 const copy=FullSoutuiScenes.copy(run,item,!isSearch),job={id:item.id,module:run.module,productIds:[...item.productIds],title:copy.title,body:copy.body,uploadedAssets:uploaded,batchPrefix:item.prepared.batchPrefix||FullSoutuiScenes.batchPrefix(run,item)};
 // Read the baseline before entering the editor: same-tab navigation would discard a filled form.
 if(!isSearch&&run.workTab&&!item.prepared.publicationBaseline){Object.assign(item.prepared,job);item.prepared.publicationBaseline=await soutuiWorkspace(run,item,true);await flowSave(run);}
 await flowPosition(run,item);let target=await flowFrame(run,isSearch?'rows':'form');await flowInject(target);
 const noteInputRecovery=async result=>{if(!result?.inputRecovery)return;item.inputRecoveries||=[];item.inputRecoveries.push({at:new Date().toISOString(),...result.inputRecovery});run.events||=[];run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail:'浏览器输入连接短暂中断，已在原标签页核对商品后重连并继续（'+result.inputRecovery.operation+'）；未重新生成或重复发布。'});await flowSave(run);};if(isSearch){const opened=await FullSoutuiInput.openSearchSlot(target,job);await noteInputRecovery(opened);if(opened.status!=='prepared')throw Error(opened.message||'没有明确空槽。');}
 const form=await flowFrame(run,'form');await flowInject(form);await soutuiInject(form);
 if(isSearch)await flowEval(form,async job=>{try{return await FullPlatform.execute('bind-products',job);}catch(e){return {flowError:e.message};}},[job]);else await soutuiEval(form,'bind',job.productIds[0]);
 await noteInputRecovery(await FullSoutuiInput.fill(form,job));
 const existing=!isSearch?await soutuiEval(form,'pictureState',job):null;
 if(existing?.state!=='complete'){
 await soutuiEval(form,'openPictures');
 const picker=await flowFrame(run,'picker');await chrome.scripting.executeScript({target:{tabId:picker.tabId,frameIds:[picker.frameId]},world:'MAIN',files:['soutui-picker.js']});await soutuiEval(picker,'select',job);
 }
 for(let n=0;n<50;n++){const result=await flowEval(form,async job=>{try{return await FullPlatform.execute('verify-pictures',job);}catch(e){return {pending:true,message:e.message};}},[job]);if(!result.pending)break;if(n===49)throw Error(result.message);await queueDelay(200);}
 item.prepared={...item.prepared,...job,sceneCategory:copy.sceneCategory};item.prepared.creatorDeclaration=await soutuiDeclaration(form,job.module);
 if(!isSearch&&copy.sceneCategory!=='other')item.prepared.platformOptions=await soutuiEval(form,'options');
 if(isSearch)await flowContentBaseline(run,item,form);await flowSave(run);return {ok:true};
}
async function soutuiDeclaration(form,module){
 const settings=module==='guanghe'?(await chrome.storage?.local?.get('material-feature-settings-v1'))?.['material-feature-settings-v1']:null;
 return soutuiEval(form,'declaration',{required:module==='guanghe',module,choice:module==='guanghe'&&(settings?.guangheDeclaration==null||settings.guangheDeclaration==='none')?'none':'manual'});
}
function soutuiContentMatches(record,item){
 const p=item.prepared,clean=s=>String(s||'').replace(/[\uFEFF\u200B]/g,'').trim();
 return clean(record.title)===p.title&&clean(record.body)===p.body&&record.images?.length===p.uploadedAssets.length&&record.images.every((u,i)=>u===p.uploadedAssets[i].url||u.startsWith(p.uploadedAssets[i].url+'_')||u.startsWith(p.uploadedAssets[i].url+'?'));
}
function soutuiPublicationBaseline(search,item){
 if(!Number.isInteger(search.total)||search.total<0||!Array.isArray(search.records)||search.records.length!==search.total||search.records.some(r=>!/^\d+$/.test(r.contentId))||new Set(search.records.map(r=>r.contentId)).size!==search.total)throw Error('光合发布前作品基线未完整，未提交。');
 if(search.records.some(r=>soutuiContentMatches(r,item)))throw Error('光合已有相同标题、正文和原图片的作品，未重复发布。');
 return search;
}
function soutuiPublishedCandidate(search,item){
 const baseline=item.prepared.publicationBaseline;
 if(!baseline||!Number.isInteger(baseline.total)||baseline.total<0||baseline.total>0&&(!Array.isArray(baseline.records)||baseline.records.length!==baseline.total))throw Error('光合原发布基线不完整，保留原提交记录。');
 const prior=new Set((baseline.records||[]).map(r=>r.contentId)),records=search.records||[];
 const candidates=records.filter(r=>!prior.has(r.contentId)&&/^\d+$/.test(r.contentId)&&soutuiContentMatches(r,item));
 if(candidates.length!==1)return null;const record=candidates[0],id=record.contentId,rows=(search.rows||[]).filter(row=>new RegExp('ID\\s*[:：]\\s*'+id+'(?:\\D|$)').test(row));
 if(rows.length!==1)return null;const row=rows[0],date=row.match(/(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})/),publishedAt=date?Date.parse(date[1]+'T'+date[2]+'+08:00'):NaN;
 if(!Number.isFinite(publishedAt)||!Number.isFinite(Date.parse(item.publication?.at))||publishedAt<Date.parse(item.publication.at)-10000)return null;
 return {record,id,row,publishedAt};
}
async function soutuiWorkspace(run,item,baseline=false){
 const tab=run.workTab?await flowOpen(run,SOUTUI_WORKSPACE):await chrome.tabs.create({url:SOUTUI_WORKSPACE,active:false});item.workspaceTabId=tab.id;await flowSave(run);let target;
 for(let n=0;n<60;n++){try{const frames=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:()=>({ready:location.hostname==='creator.guanghe.taobao.com'&&location.pathname==='/page/workspace/tb'&&document.readyState==='complete'&&!!document.querySelector('input[placeholder*="作品ID"]')})});const found=frames.filter(f=>f.result?.ready);if(found.length===1){target={tabId:tab.id,frameId:found[0].frameId};break;}}catch(error){if(!/context.*destroy|navigation|frame.*removed|frame.*not.*found/i.test(error.message))throw error;}await queueDelay(250);}
 if(!target)throw Error('官方光合作品管理页未就绪，请本人登录后继续原任务。');await chrome.scripting.executeScript({target:{tabId:target.tabId,frameIds:[target.frameId]},world:'MAIN',files:['soutui-workspace.js']});const search=await FullSoutuiInput.workspaceSearch(target,item.prepared.title);
 if(baseline)return soutuiPublicationBaseline(search,item);
 const candidate=soutuiPublishedCandidate(search,item);if(!candidate)return {status:'submitted_unconfirmed',message:'未唯一核对本次新作品的编号、发布时间与原内容，保留原提交记录。'};
 const {record,id,row,publishedAt}=candidate;
 item.prepared.savedContent={contentId:id,title:record.title,body:record.body,images:record.images,checkedAt:search.at};
 const publication=item.submitResult?.platformPublication,prior=item.prepared.persistedForm;
 if(publication?.success===true&&publication.productIds?.join()===item.productIds.join()&&publication.images===record.images.length||prior?.productIds?.join()===item.productIds.join()&&prior.images?.length===record.images.length&&prior.images.every((u,i)=>u.startsWith(item.prepared.uploadedAssets[i].url))){await flowSave(run);return {status:'verified',receipt:{source:'platform-readback',contentId:id,productIds:[...item.productIds],publishedAt,status:/公域审核通过/.test(row)?'公域审核通过':/公域审核中/.test(row)?'公域审核中':'已发布（审核状态以平台为准）',imageCount:record.images.length,storedContentVerified:true,productBindingProof:publication?.success?'official-publish-request-and-success-response':'prior-independent-saved-form-readback'}};}
 if(run.workTab){await flowSave(run);return {status:'submitted_unconfirmed',message:'原作品已找到，但商品绑定证据不足；保留原提交编号，未另开编辑页或重复发布。'};}
 const before=new Set((await chrome.tabs.query({})).map(t=>t.id));await FullSoutuiInput.workspaceEdit(target,id);let edit;
 for(let n=0;n<40;n++){const tabs=await chrome.tabs.query({});const matches=tabs.filter(t=>!before.has(t.id)&&t.openerTabId===tab.id);if(matches.length===1){edit=matches[0];break;}if(matches.length>1)throw Error('保存后回查出现多个编辑页。');const current=await chrome.tabs.get(tab.id);if(current.url!==SOUTUI_WORKSPACE){edit=current;break;}await queueDelay(250);}
 if(!edit)throw Error('保存后的光合编辑页未唯一打开。');const oldTab=run.tabId;run.tabId=edit.id;
 try{const form=await flowFrame(run,'form',edit);await soutuiInject(form);let persisted;for(let n=0;n<40;n++){try{persisted=await soutuiEval(form,'verify',item.prepared);break;}catch(e){if(n===39)throw e;await queueDelay(250);}}item.prepared.persistedForm=persisted;await flowSave(run);return {status:'verified',receipt:{source:'platform-readback',contentId:id,productIds:[...item.productIds],publishedAt,status:/公域审核通过/.test(row)?'公域审核通过':/公域审核中/.test(row)?'公域审核中':'已发布（审核状态以平台为准）',imageCount:persisted.images.length,storedFormVerified:true}};}finally{run.tabId=oldTab;}
}

// Apply an already generated, explicitly reviewed image to an untouched pending article.
// No generation, upload, publication, budget increase, or automatic resume occurs here.
function soutuiReplaceReviewedImage(run,message,replacement,original){
 const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
 if(message.confirmed!==true||message.visualConfirmed!==true||run.enabled||!['blocked','stopped','paused'].includes(run.status)||run.module!=='search'||!FullFlowRun.matchesConsent(run)||!uuid.test(message.oldGenerationId||'')||!uuid.test(message.replacementId||'')||message.oldGenerationId===message.replacementId)throw Error('替换须明确确认外观，且原搜推任务已暂停、授权范围未变。');
 const matches=run.items.flatMap((item,itemIndex)=>(item.generations||[]).map((g,generationIndex)=>({item,itemIndex,g,generationIndex}))).filter(x=>x.g.id===message.oldGenerationId);
 if(matches.length!==1)throw Error('原图片编号不唯一，未替换。');
 const {item,itemIndex,g,generationIndex}=matches[0];
 if(itemIndex<run.position||!['prepare','generate','attach'].includes(item.phase)||item.publication||item.receipt||Object.keys(item.uploadIntents||{}).length||item.prepared?.uploadedAssets?.length||item.videoUploadIntent||item.nativeIntent||g.media!=='image'||!g.intent)throw Error('该篇已有上传或发布记录，须在平台原内容编辑；保留全部原记录。');
 if(run.items.some(i=>(i.generations||[]).some(x=>x.id===message.replacementId))||(run.imageCorrections||[]).some(x=>x.replacementId===message.replacementId))throw Error('替换图已使用，未重复接入。');
 const ids=JSON.stringify(item.productIds);
 for(const [media,id]of [[replacement,message.replacementId],[original,message.oldGenerationId]])if(media?.id!==id||media.media!=='image'||media.status!=='completed'||media.available!==true||JSON.stringify(media.productIds)!==ids||!/^[a-f\d]{64}$/i.test(media.sha256||''))throw Error('原图和替换图均须从服务端确认同商品、已完成及文件哈希。');
 const at=new Date().toISOString(),next={...structuredClone(g),id:replacement.id,status:'completed',available:true,sha256:replacement.sha256,mediaInfo:structuredClone(replacement.mediaInfo),model:replacement.model,intent:{id:replacement.id,at,source:'existing-reviewed-replacement'},externalGeneration:true};
 delete next.prompt;delete next.referenceUrl;
 run.imageCorrections||=[];run.imageCorrections.push({at,originalGenerationId:g.id,replacementId:replacement.id,original:structuredClone(g),replacementSHA256:replacement.sha256,productIds:[...item.productIds],visualConfirmed:true,chargedNewCalls:0,originalUsedCalls:run.usedCalls,originalConsentScope:run.consentScope});
 item.generations[generationIndex]=next;
 run.events||=[];run.events.push({at,phase:run.phase,position:run.position,detail:'已接入同商品已完成且确认外观的替换图；旧图记录保留，未生图、上传、发布或恢复任务。'});
 return {replaced:true,itemIndex,generationIndex,oldGenerationId:g.id,replacementId:replacement.id,newPaidCalls:0,enabled:run.enabled};
}
