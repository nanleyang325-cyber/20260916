(function(root){
 'use strict';
 const valid=url=>{try{const parsed=new URL(url.startsWith('//')?'https:'+url:url);if(parsed.protocol!=='https:'||!/(^|\.)alicdn\.com$/.test(parsed.hostname))return null;parsed.pathname=parsed.pathname.replace(/_\d+x\d+[^/]*\.(?:jpe?g|png|webp)$/i,'');return parsed.href;}catch{return null;}};
 function rowFor(doc,pid){const rows=[...doc.querySelectorAll('.next-table-row,[role="row"],[data-item-id],[data-product-id]')].filter(row=>{const direct=row.getAttribute('data-item-id')||row.getAttribute('data-product-id');const id=row.querySelector('[class*="ItemInfoCell_productIdNumber"]')?.textContent.trim();if((direct===pid||id===pid)&&[direct,id].filter(Boolean).some(value=>value!==pid))throw Object.assign(new Error('商品行身份字段冲突。'),{code:'PRODUCT_CONFLICT'});return (direct||id)===pid;});if(rows.length!==1)throw Object.assign(new Error('目标商品行未唯一定位。'),{code:rows.length?'PRODUCT_CONFLICT':'PRODUCT_NOT_FOUND'});return rows[0];}
 function inspect(doc,pid,module){
  const row=rowFor(doc,pid),status=(row.querySelector('[class*="ItemInfoCell_statusTagWrapper"],[data-sale-status]')?.textContent||'').replace(/\s/g,'');
  const saleState=/下架|仓库/.test(status)?'off_sale':/^(?:出售中|新品)+$/.test(status)?'on_sale':'unknown';
  const col=module==='white'?'3':'5',cell=row.querySelector(`[data-next-table-col="${col}"]`),occupied=!!cell?.querySelector('img[src]'),empty=!!cell?.querySelector('.material-image-item-placeholder-container');
  const image=row.querySelector('[class*="ItemInfoCell"] img,[data-product-cover]'),url=valid(image?.getAttribute('src')||'');
  return {productId:pid,title:row.querySelector('[class*="ItemInfoCell_productTitle"],[data-product-title]')?.textContent.trim()||pid,saleState,slotState:occupied?'occupied':empty?'empty':'unknown',mainImage:url,source:'official-material-search',checkedAt:new Date().toISOString()};
 }
 function whiteFilter(){const control=document.querySelector('#bizAndBasicStatus');if(!control)return null;const container=control.closest('.next-select, .next-cascader-select')||control;if(!container.getClientRects().length)return null;const label=(container.querySelector('.next-select-values')?.textContent||container.textContent||'').replace(/\s/g,''),value=String(control.value||'').replace(/\s/g,''),empty=t=>/^(?:全部|全部素材|素材状态|请选择)$/.test(t);return {control,container,clean:(empty(label)||label==='素材类型与状态')&&(!value||empty(value))};}
 async function clearWhiteFilter(input){let filter=whiteFilter();if(!filter)throw new Error('白底图素材筛选状态无法确认，未开始检索。');const form=input.closest('form'),reset=form?.contains(filter.control)?[...form.querySelectorAll('button')].filter(b=>b.getClientRects().length&&!b.disabled&&b.textContent.trim()==='重置'):[];if(reset.length>1)throw new Error('白底图筛选重置入口不唯一。');if(reset.length===1)reset[0].click();else if(!filter.clean){const clear=filter.container.querySelector('.next-select-clear, [aria-label="清除"]');if(!clear?.getClientRects().length)throw new Error('白底图残留素材筛选无法清除，未开始检索。');clear.click();}for(let n=0;n<20;n++){filter=whiteFilter();if(filter?.clean)return;await new Promise(r=>setTimeout(r,250));}throw new Error('白底图素材筛选未确认清空，未开始检索。');}
 // The global help search rotates hints containing 商品; it is not a product filter.
 function productSearchInputs(doc){return [...doc.querySelectorAll('input')].filter(input=>input.getClientRects().length&&!input.disabled&&!['password','hidden','checkbox'].includes(input.type)&&[input.placeholder,input.getAttribute('aria-label')].some(label=>/^(?:商品ID[\/／]名称)$/i.test(String(label||'').replace(/\s/g,''))));}
 async function search(pid,module,options={}){
  if(!/^\d{6,}$/.test(pid)||!['white','scene'].includes(module))throw new Error('商品检索参数无效。');
  const inputs=productSearchInputs(document);
  if(inputs.length!==1)throw new Error('未识别唯一商品搜索框，请打开基础素材商品列表。');
  if(module==='white'&&options.clearWhiteFilter){await clearWhiteFilter(inputs[0]);return search(pid,module,{verifyWhiteFilter:true});}
  const input=inputs[0];Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,pid);input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  // Let the controlled input commit before Enter reads the search component state.
  await new Promise(resolve=>setTimeout(resolve,0));
  const committed=productSearchInputs(document);if(!input.isConnected||committed.length!==1||committed[0]!==input||input.value!==pid)throw new Error('检索条件已被修改，停止避免处理错商品。');
  // The current Field filter queries automatically after its debounce. Enter
  // races that update and restores the previous filter during rapid searches.
  const automatic=input.id==='itemIdOrName'&&input.closest('[data-meta="Field"]');
  if(!automatic){input.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,bubbles:true}));input.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,bubbles:true}));}
  for(let n=0;n<12;n++){await new Promise(resolve=>setTimeout(resolve,500));if(module==='white'&&options.verifyWhiteFilter&&!whiteFilter()?.clean)throw new Error('检索期间白底图素材筛选已变化，停止避免漏查。');const current=productSearchInputs(document);if(current.length!==1||current[0].value!==pid)throw new Error('检索条件已被修改，停止避免处理错商品。');try{return inspect(document,pid,module);}catch(error){if(error.code!=='PRODUCT_NOT_FOUND')throw error;}}
  throw Object.assign(new Error('按指定 ID 搜索未命中，不回退扫描全店。'),{code:'PRODUCT_NOT_FOUND'});
 }
 function skuImages(doc,pid,url){
  const current=new URL(url);if(current.searchParams.get('id')!==pid||!/(^|\.)(tmall|taobao)\.com$/.test(current.hostname))throw new Error('详情页商品身份不匹配。');
  for(const script of doc.querySelectorAll('script:not([src])')){const text=script.textContent;try{const payload=JSON.parse(text),identities=[payload.itemId,payload.item?.itemId,payload.data?.item?.itemId,payload.skuBase?.itemId].filter(value=>value!=null).map(String);if(identities.some(id=>id!==pid))throw new Error('SSR 商品身份不匹配。');}catch(error){if(error.message==='SSR 商品身份不匹配。')throw error;}let start=text.indexOf('"props"');if(start<0)continue;start=text.indexOf('[',start);if(start<0)continue;let depth=0,quoted=false,escaped=false;
   for(let i=start;i<text.length;i++){const c=text[i];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;continue;}if(c==='"'){quoted=true;continue;}if(c==='[')depth++;if(c===']'&&--depth===0){try{const props=JSON.parse(text.slice(start,i+1)),values=props[0]?.values;if(!Array.isArray(values))break;const filtered=values.filter(v=>typeof v.name==='string'&&!/价保|补贴|赠|送|活动|优惠|满减|现货|秒杀|特价/.test(v.name)&&typeof v.image==='string').map(v=>valid(v.image)).filter(Boolean);return filtered.filter(u=>filtered.filter(other=>other===u).length===1);}catch{break;}}}
  }return [];
 }
 // Read only product-owned SSR objects. Never collect recommendation cards or
 // page-wide images: sharing a CDN does not establish product identity.
 function objectFields(text,key){
  const found=[],pattern=new RegExp('"'+key+'"\\s*:\\s*\\{','g');let match;
  while((match=pattern.exec(text))){const start=text.indexOf('{',match.index);let depth=0,quoted=false,escaped=false;
   for(let n=start;n<text.length;n++){const c=text[n];if(quoted){if(escaped)escaped=false;else if(c==='\\')escaped=true;else if(c==='"')quoted=false;continue;}if(c==='"'){quoted=true;continue;}if(c==='{')depth++;if(c==='}'&&--depth===0){try{found.push(JSON.parse(text.slice(start,n+1)));}catch{}pattern.lastIndex=n+1;break;}}
  }return found;
 }
 function whiteSources(doc,pid,url){
  const current=new URL(url);if(!['detail.tmall.com','item.taobao.com'].includes(current.hostname)||current.protocol!=='https:'||current.searchParams.get('id')!==pid)throw Error('详情页商品身份不匹配。');
  const scripts=[...doc.querySelectorAll('script:not([src])')].map(s=>s.textContent||''),records=[];
  for(const text of scripts)for(const item of objectFields(text,'item'))if(String(item.itemId)===pid)records.push({item,text});
  if(!records.length)throw Object.assign(Error('未取得同商品详情数据，未采用推荐商品图片。'),{code:'WHITE_REFERENCE_UNAVAILABLE'});
  const record=records.find(r=>Array.isArray(r.item.images))||records[0],item=record.item,sku=objectFields(record.text,'skuBase')[0]||{},values=(sku.props?.[0]?.values||[]).filter(v=>typeof v.name==='string'&&!/价保|补贴|赠|送|活动|优惠|满减|现货|秒杀|特价/.test(v.name));
  const unique=xs=>[...new Set(xs.map(u=>typeof u==='string'?valid(u):null).filter(Boolean))];
  const skuEntries=values.map(v=>({name:v.name,url:valid(typeof v.image==='string'?v.image:'')})).filter(v=>v.url),main=unique(Array.isArray(item.images)?item.images:[]).slice(0,20);
  let descriptionUrl=null;try{const u=new URL(item.pcADescUrl,current.origin);if(u.protocol==='https:'&&u.hostname==='market.m.taobao.com'&&u.pathname==='/app/detail-project/desc/index.html'&&u.searchParams.get('id')===pid)descriptionUrl=u.href;}catch{}
  return {productId:pid,title:typeof item.title==='string'?item.title:'',skuCount:values.length,sku:skuEntries,main,detail:[],targetSku:values.at(-1)?.name||'',descriptionUrl};
 }
 function descriptionImages(html){
  if(typeof html!=='string'||html.length>8*1024*1024)return [];
  const doc=new DOMParser().parseFromString(html,'text/html'),urls=[];
  for(const img of doc.querySelectorAll('img'))for(const key of ['data-ks-lazyload','data-src','data-original','src']){const raw=img.getAttribute(key),u=raw&&valid(raw);if(u&&!urls.includes(u)){urls.push(u);break;}}
  return urls.slice(0,100);
 }
 async function collectWhiteSources(doc,pid,url,options={}){
  const result=whiteSources(doc,pid,url);result.descriptionState=result.descriptionUrl?'unavailable':'not_linked';
  const imageIdentity=raw=>{try{const u=new URL(raw);return u.hostname.toLowerCase()+u.pathname.replace(/(\.(?:jpe?g|png|webp))(?:_[^/]*)$/i,'$1');}catch{return null;}},excluded=new Set((options.excludeUrls||[]).map(imageIdentity));
  if(options.primaryFirst&&result.main.some(u=>!excluded.has(imageIdentity(u)))){result.descriptionState='not_needed_main_available';delete result.descriptionUrl;return result;}
  if(result.descriptionUrl&&root.lib?.mtop?.request){
   try{const response=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('详情正文读取超时。')),12000),ok=v=>{clearTimeout(timer);resolve(v);},fail=()=>{clearTimeout(timer);reject(Error('详情正文接口未返回成功。'));};const pending=root.lib.mtop.request({api:'mtop.taobao.detail.getdesc',v:'7.0',data:{id:pid,detail_v:'3.3.0'},type:'GET',dataType:'json',ttid:'2019@taobao_h5_9.9.9',timeout:10000,success:ok,failure:fail});if(pending?.then)pending.then(ok,fail);});
    if(!response?.ret?.some(v=>/^SUCCESS(?:::|$)/.test(v)))throw Error('详情正文接口未返回成功。');
    if(response.data?.itemId!=null&&String(response.data.itemId)!==pid)throw Error('详情正文商品身份不匹配。');
    result.detail=descriptionImages(response.data?.pcDescContent);result.descriptionState=result.detail.length?'collected':'empty';
   }catch(error){if(/身份/.test(error.message))throw error;result.descriptionState='unavailable';}
  }
  // A rendered description is already bound to the verified product page.
  if(!result.detail.length){const urls=[];for(const scope of doc.querySelectorAll('#description #J_DivItemDesc, #J_DivItemDesc, [data-component="itemDesc"], [class*="descV8-container"]'))for(const img of scope.querySelectorAll('img')){const u=valid(img.getAttribute('data-ks-lazyload')||img.getAttribute('data-src')||img.getAttribute('src')||'');if(u&&!urls.includes(u))urls.push(u);}if(urls.length){result.detail=urls.slice(0,100);result.descriptionState='rendered';}}
  delete result.descriptionUrl;return result;
 }
 root.FullProductProbe={inspect,search,skuImages,whiteSources,descriptionImages,collectWhiteSources};if(typeof module!=='undefined')module.exports=root.FullProductProbe;
})(globalThis);
