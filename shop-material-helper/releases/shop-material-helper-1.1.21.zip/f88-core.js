(function(root){
 'use strict';
 const STYLES={buyer:['model','product','buyer_model'],seeding:['model','buyer_model']};
 const URLS={products:'https://myseller.taobao.com/home.htm/quality-pulse/product-management',decoration:'https://myseller.taobao.com/home.htm/quality-pulse/express-product-decoration'};
 const pid=value=>/^\d{6,}$/.test(String(value||''));
 const integer=(value,min,max,label)=>{const n=Number(value);if(!Number.isInteger(n)||n<min||n>max)throw Error(label+'须为 '+min+' 至 '+max+' 的整数。');return n;};
 function ids(value){const entries=Array.isArray(value)?value:String(value||'').split(/[\s,，;；]+/).filter(Boolean);if(entries.some(v=>!pid(v)))throw Error('F88 使用平台商品 ID，请输入至少6位完整数字。');return [...new Set(entries.map(String))];}
 function imageURL(value){const u=new URL(value, 'https://img.alicdn.com');if(u.protocol!=='https:'||!/(^|\.)alicdn\.com$/.test(u.hostname)||u.username||u.password)throw Error('色号原图地址未确认。');u.pathname=u.pathname.replace(/_\d+x\d+[^/]*\.(?:jpe?g|png|webp)$/i,'');return u.href;}
 function styles(value,section){const allowed=STYLES[section],selected=allowed.filter(k=>(Array.isArray(value)?value:[value]).includes(k));return selected.length?selected:['model'];}
 function settings(input={}){
  const section=input.section==='seeding'?'seeding':'buyer',mode=input.mode==='all'?'all':'ids',productIds=ids(input.ids||[]);
  if(mode==='ids'&&!productIds.length)throw Error('请填写平台商品 ID。');
  const plans={};for(const [id,plan]of Object.entries(input.plans||{})){if(!pid(id)||!plan||Array.isArray(plan)||typeof plan!=='object')throw Error('逐品风格计划无效。');const values={};let total=0;for(const key of Object.keys(plan)){if(!STYLES[section].includes(key))throw Error('本板块不支持该风格计划：'+key);values[key]=integer(plan[key],0,9,'风格套数');total+=values[key];}if(total>9)throw Error('每品风格计划总数不能超过9套。');plans[id]=values;}
  if(!['yes','no'].includes(input.palette))throw Error('请确认本批环境色彩。');
  return {enabled:input.enabled===true,section,mode,ids:productIds,styles:styles(input.styles,section),count:integer(input.count??(section==='buyer'?5:3),1,9,'套数'),plans,
   syncSeeding:input.syncSeeding!==false,syncProduct:input.syncProduct===true,delivery:input.delivery==='generate'?'generate':'platform',palette:input.palette,
   maxCalls:integer(input.maxCalls??20,1,100,'生成调用上限'),ratio:['1:1','3:4'].includes(input.ratio)?input.ratio:'3:4',consent:input.consent===true,platformConsent:input.platformConsent===true};
 }
 function parseSkcs(response,id){
  if(!pid(id)||!response?.ret?.some(v=>/^SUCCESS(?:::|$)/.test(v)))throw Error('F88 色号查询未明确成功。');
  const outer=response.data||{},payload=Array.isArray(outer.content)?outer:outer.data;
  if(!Array.isArray(payload?.content))throw Error('F88 色号响应结构未确认。');
  const keys=['taoItemId','shopTaoItemId','platformItemId','itemId'];
  const matches=payload.content.filter(p=>keys.some(key=>String(p?.[key]??'')===id));if(matches.length!==1)throw Error('F88 色号响应商品身份不唯一。');
  const item=matches[0];if(keys.some(key=>item[key]!=null&&String(item[key])!==id))throw Error('F88 色号响应身份字段冲突。');
  if(!Array.isArray(item.skcList)||!item.skcList.length)throw Error('目标商品没有明确色号原图。');
  const skcs=item.skcList.map(s=>{if(!pid(s?.id)||typeof s.propertyValueName!=='string'||!s.propertyValueName.trim()||!s.imageUrl)throw Error('色号编号、名称或原图缺失。');return {id:String(s.id),name:s.propertyValueName.trim(),url:imageURL(s.imageUrl)};});
  if(new Set(skcs.map(s=>s.id)).size!==skcs.length)throw Error('商品色号编号重复。');return skcs;
 }
 function styleList(selection,product,index){const plan=selection.plans[product.platformId];let list=[];if(plan)for(const key of STYLES[selection.section])for(let n=0;n<(plan[key]||0);n++)list.push(key);if(!plan)list=Array.from({length:selection.count},(_,i)=>selection.styles[(i+(selection.section==='seeding'?index:0))%selection.styles.length]);return selection.section==='buyer'&&product.skcs.length===1?list.slice(0,3):list;}
 function planProduct(selection,product,index=0){
  if(!pid(product?.platformId)||!Array.isArray(product.skcs)||!product.skcs.length)throw Error('平台商品身份与色号尚未核验。');
  if(selection.mode==='ids'&&!selection.ids.includes(product.platformId))throw Error('平台商品不在本轮指定范围内。');
  if(product.skcs.some(s=>!pid(s.id)||!s.name||imageURL(s.url)!==s.url))throw Error('原色号图记录无效。');
  let list=styleList(selection,product,index),capacity;
  if(selection.section==='buyer'){
   if(!Number.isInteger(product.quota)||product.quota<0||!Number.isInteger(product.emptySlots)||product.emptySlots<0)throw Error('F88 剩余配额或空实穿框未明确，未生成。');
   capacity=Math.min(product.quota,product.emptySlots);
  }else{
   if(!Number.isInteger(product.existing)||product.existing<0||product.canCreate!==true)throw Error('搜推素材数量或创建入口未明确，未生成。');
   capacity=Math.max(0,list.length-product.existing);
  }
  // Only generate suites the confirmed destination can use; no paid surplus suites.
  list=list.slice(selection.section==='seeding'?product.existing:0).slice(0,capacity);
  if(!list.length)return [];
  if(selection.delivery==='platform'&&product.contract?.ready!==true)throw Error(product.contract?.reason||'平台表单契约未确认，未调用生成。');
  const usedOrders=new Set();
  return list.map((style,suiteIndex)=>{
   let skc=product.skcs[suiteIndex%product.skcs.length],orderId=null;
   if(selection.section==='buyer'&&selection.delivery==='platform'){
    const order=(product.orders||[]).find(o=>!usedOrders.has(o.id)&&product.skcs.some(s=>s.name===o.color));if(!order)throw Error('没有已核验的同色可用订单，未调用生成。');
    skc=product.skcs.find(s=>s.name===order.color);orderId=order.id;usedOrders.add(order.id);
   }
   const id=root.crypto.randomUUID();return {id,mediaId:root.crypto.randomUUID(),hostBatchId:root.crypto.randomUUID(),platformId:product.platformId,title:product.title||'',skc:{...skc},style,suiteIndex,orderId,phase:'preflight',status:'pending',images:[],delivery:{section:selection.section,phase:'upload'}};
  });
 }
 function prompt(selection,suite){const kind={model:'成年模特自然展示服装',buyer_model:'成年普通人物在日常场景自然展示服装',product:'只拍摄商品，不出现人物'}[suite.style];return '生成明确为AI模拟的服装商品展示图，不模拟真实用户评价。严格保持参考色号“'+suite.skc.name+'”的商品颜色、版型、材质、数量与标识。'+kind+'。输出规则3行3列九宫格，每格独立构图，等宽等高，无边框、无留白、无文字。九张为同一色号与同一人物，不增加未见过的背面、标签、功能、认证或购买体验。商品标题仅作识别：'+suite.title+'。';}
 function request(selection,suite,reference){if(!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(reference||''))throw Error('色号原图尚未成功读取。');return {id:suite.mediaId,module:'buyer',media:'image',model:'nano-banana-pro',productIds:[suite.platformId],prompt:prompt(selection,suite),ratio:selection.ratio,palette:selection.palette,references:[reference],consent:true};}
 function copy(suite,section){const title=Array.from(suite.title||'商品展示').slice(0,20).join(''),body='AI模拟商品展示，供查看款式与配色。'+(suite.title||'')+'；色号：'+suite.skc.name+'。图片不代表真实购买或试穿体验。';return {title,body:Array.from(body).slice(0,section==='buyer'?500:1000).join('')};}
 function syncAllowed(selection,suite){return selection.section==='buyer'&&selection.syncSeeding&&(suite.style!=='product'||selection.syncProduct);}
 function imageCount(section,sync=false){return section==='buyer'||sync?5:9;}
 const api={STYLES,URLS,ids,pid,imageURL,styles,settings,parseSkcs,styleList,planProduct,prompt,request,copy,syncAllowed,imageCount};root.FullF88Core=api;if(typeof module==='object')module.exports=api;
})(globalThis);
