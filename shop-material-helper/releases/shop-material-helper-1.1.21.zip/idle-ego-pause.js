(function(root){
 'use strict';
 const GLOBAL='material-global-control-v1',QUEUES='full-helper-v1',STUDIO='material-studio-requests-v1';
 const RUNS=['material-auto-runs-v1','material-flow-runs-v1','material-multi-runs-v1','material-studio-publish-batches-v1','material-f88-runs-v1','material-kmt-runs-v1'];
 const keys=[GLOBAL,...RUNS,QUEUES,STUDIO];
 function inspect(data,runtime){
  const snapshot=data[GLOBAL];
  if(!snapshot?.paused)return {releasable:false,reason:'not-paused'};
  if(snapshot.host?.localOnly!==true)return {releasable:false,reason:'independent-global-pause'};
  if(snapshot.draining||snapshot.stopping||runtime.queueBusy||runtime.studioBusy)return {releasable:false,reason:'operation-still-settling'};
  for(const key of RUNS){
   const runs=data[key]||[];if(!Array.isArray(runs))return {releasable:false,reason:'run-state-unverified'};
   if(runs.some(r=>r.enabled||r.status==='paused'&&!r.cancellation))return {releasable:false,reason:'other-task-held'};
   for(const id of snapshot.runs?.[key]||[]){const run=runs.find(r=>(r.id||r.batchId)===id);if(!run||!run.cancellation&&!['done','completed','verified'].includes(run.status))return {releasable:false,reason:'original-pause-held'};}
  }
  const queues=data[QUEUES]?.backgroundQueues||[],studio=data[STUDIO]||[];
  if(!Array.isArray(queues)||!Array.isArray(studio))return {releasable:false,reason:'queue-state-unverified'};
  if(queues.some(q=>q.enabled))return {releasable:false,reason:'other-queue-active'};
  for(const id of snapshot.queues||[]){const queue=queues.find(q=>q.id===id);if(!queue||!queue.done)return {releasable:false,reason:'original-queue-held'};}
  if(studio.some(t=>['queued','running','waiting_text','submitting','submitted_unconfirmed'].includes(t.status)))return {releasable:false,reason:'studio-request-unsettled'};
  for(const id of snapshot.studio||[]){const task=studio.find(t=>t.requestId===id);if(!task||!['verified','prepared','stopped','cancelled'].includes(task.status))return {releasable:false,reason:'original-studio-held'};}
  return {releasable:true,reason:'idle-local-ego-pause'};
 }
 async function release(io){
  const data=await io.read(keys),check=inspect(data,io.runtime());if(!check.releasable)return {...check,released:false};
  const expected=JSON.stringify(data[GLOBAL]);let released=false;
  await io.update(GLOBAL,current=>{if(JSON.stringify(current)!==expected)return current;released=true;return {...current,paused:false,draining:false,stopping:false,gateReleasedAt:new Date().toISOString(),gateReleaseReason:'idle-ego-space-release',originalTasksNotResumed:true};});
  return {...check,released,originalTasksNotResumed:true};
 }
 root.FullIdleEgoPause={inspect,release,keys};
})(globalThis);
