(function(root){
 'use strict';
 function readCreatorDeclaration(required=false){const labels=[...document.querySelectorAll('label')].filter(l=>l.getClientRects().length>0&&/^(?:含AI生成内容|内容无需(?:标注|注明)|含虚构演绎内容|含个人观点|含医疗建议|含金融投资建议)$/.test(l.textContent.trim()));const chosen=labels.filter(l=>l.querySelector('input:checked')||l.getAttribute('aria-checked')==='true');if(chosen.length>1)throw Error('内容声明不唯一，请本人核对。');if((required||labels.some(l=>l.closest('[aria-required="true"],.next-form-item-required,.ant-form-item-required')||l.querySelector('input[required]')))&&!chosen.length)throw Error('平台要求内容声明，请本人选择后继续；插件不自动勾选，素材保留。');return chosen.length?chosen[0].textContent.trim():null;}
 const visible=el=>!!el&&el.getClientRects().length>0&&getComputedStyle(el).visibility!=='hidden';
 const controls=scope=>[...scope.querySelectorAll('button,a,[role="button"]')].filter(el=>visible(el)&&!el.disabled&&el.getAttribute('aria-disabled')!=='true');
 function oneButton(scope,names){const found=controls(scope).filter(el=>names.includes(el.textContent.trim()));if(found.length!==1)throw Error('操作入口不唯一：'+names.join('/'));return found[0];}
 function value(input,text){if(!input)throw Error('平台输入字段未识别。');const type=input.tagName==='TEXTAREA'?HTMLTextAreaElement:HTMLInputElement;Object.getOwnPropertyDescriptor(type.prototype,'value').set.call(input,text);for(const event of ['input','change','blur','focusout'])input.dispatchEvent(new Event(event,{bubbles:true}));if(input.value!==text)throw Error('输入字段读回不一致。');}
 const same=(a,b)=>JSON.stringify([...new Set(a)].sort())===JSON.stringify([...new Set(b)].sort());
 function pids(scope){const set=new Set();for(const el of scope.querySelectorAll('[data-item-id],[data-product-id],a[href]')){const raw=el.dataset.itemId||el.dataset.productId;if(/^\d{6,}$/.test(raw||''))set.add(raw);if(el.href)try{const u=new URL(el.href);if(/(^|\.)(taobao|tmall)\.com$/.test(u.hostname)&&/^\d{6,}$/.test(u.searchParams.get('id')||''))set.add(u.searchParams.get('id'));}catch{}}for(const m of scope.innerText.matchAll(/(?:商品\s*ID|宝贝\s*ID)\s*[:：]?\s*(\d{6,})/g))set.add(m[1]);return [...set];}
 function images(scope){return [...scope.querySelectorAll('img')].map(img=>img.src).filter(url=>/^https:\/\/(?:[^/]+\.)?alicdn\.com\//.test(url));}
 const urlMatches=(actual,expected)=>actual===expected||actual.startsWith(expected+'_')||actual.startsWith(expected+'?');
 function selectedImages(task){const scope=task.kind==='fission'?document.querySelector('#struct-mainImagesGroup'):document.querySelector('.next-upload-list,.next-picture-uploader-list,[data-upload-list]')||document.querySelector('.next-picture-uploader')?.parentElement;if(!scope)throw Error('主图区域未识别。');return [...scope.querySelectorAll('img')].filter(visible).map(img=>img.src).filter(url=>/^https:\/\/(?:[^/]+\.)?alicdn\.com\//.test(url));}
 function seedFields(task){
  if(!same(pids(document.body),[task.productId]))throw Error('种草关联商品与目标不一致。');
  const title=document.querySelector('input[placeholder*="标题"]')?.value,body=document.querySelector('textarea')?.value??document.querySelector('[contenteditable="true"]')?.textContent;
  if(title!==(task.title||'商品生活场景')||body!==(task.body||'AI辅助创作，商品信息以商品详情页为准。'))throw Error('种草标题或正文读回变化，未发布。');
  const labels=[...document.querySelectorAll('label')].filter(el=>visible(el)&&/^内容无需(?:标注|注明)$/.test(el.textContent.trim()));
  readCreatorDeclaration(true);
 }
 function identity(task){if(task.kind!=='fission')return;const u=new URL(location.href),id=u.searchParams.get('st_dist_src_id')||u.searchParams.get('itemId');if(!/(^|\.)(taobao|tmall)\.com$/.test(u.hostname)||id!==task.productId||task.mode==='new'&&u.searchParams.get('copyItem')!=='true')throw Error('商品编辑页与目标商品/新增模式不符。');}
 async function execute(action,task,arg){
  if(action==='source'||action==='source-title'){
   const u=new URL(location.href),pid=u.searchParams.get('id')||u.pathname.match(/\/offer\/(\d+)\.html/)?.[1];if(pid!==task.productId)throw Error('来源页商品身份不符。');
   const titles=[...document.querySelectorAll('h1,[class*="ItemHeader--mainTitle"],[class*="Title--title"],.tb-main-title')].map(el=>el.textContent.trim()).filter(Boolean);const title=titles[0]||document.title;
   if(action==='source-title'){if(!titles[0])throw Error('未读取到目标商品的明确标题，未生成商品文案。');return {productId:pid,title:titles[0]};}
   const gallery=[...document.querySelectorAll('[class*="PicGallery"],[class*="gallery"],#J_UlThumb,.tb-gallery')];if(!gallery.length)throw Error('来源商品主图区域未识别，未从推荐区取图。');
   const urls=[...new Set(gallery.flatMap(images))];if(!urls.length)throw Error('来源商品主图未加载。');return {productId:pid,title,images:urls.slice(0,10).map((url,i)=>({id:pid+'-'+i,url}))};
  }
  if(action==='ready'){const picker=!!document.querySelector('input[placeholder*="图片名称"],input[placeholder*="图片名"],input[placeholder*="文件名"]');return {picker,editor:!!document.querySelector('#struct-mainImagesGroup'),seed:!!document.querySelector('input[placeholder*="标题"]')&&!!document.querySelector('textarea,[contenteditable="true"]')};}
  if(action==='fission-read-fields'){identity(task);const titles=[...document.querySelectorAll('.sell-component-tbtitle input:not([type="checkbox"]):not([disabled])')].filter(visible),styles=[...document.querySelectorAll('.sell-catProp-item-input input[maxlength="128"]')].filter(el=>visible(el)&&!el.closest('#struct-sku,.next-dialog,[role="dialog"]'));if(titles.length!==1||task.changeStyle&&styles.length!==1)throw Error('保存后标题或款号字段不唯一。');return {ok:true,title:titles[0].value,style:styles[0]?.value};}
  if(action==='fission-fields'){
   identity({...task,kind:'fission'});if(task.mode==='replace'&&(task.changeStyle||task.optimizedTitle))throw Error('替换原链接不修改标题或款号。');if(!/^[a-zA-Z0-9_-]{8,100}$/.test(task.requestId||''))throw Error('缺少稳定发布编号，未修改字段。');
   const key='material-fission-fields:'+task.requestId,priorRaw=sessionStorage.getItem(key);let intent=priorRaw?JSON.parse(priorRaw):null;
   if(intent&&intent.productId!==task.productId)throw Error('字段修改意图与商品身份不一致。');
   const titleFields=[...document.querySelectorAll('.sell-component-tbtitle input:not([type="checkbox"]):not([disabled])')].filter(visible);if(task.optimizedTitle&&titleFields.length!==1)throw Error('商品标题字段未唯一识别。');
   const titleField=titleFields.length===1?titleFields[0]:null,originalTitle=intent?.originalTitle||titleField?.value||'';
   const proposed=task.optimizedTitle==null?originalTitle:String(task.optimizedTitle).trim();if(task.optimizedTitle&&(!proposed||proposed.length>(Number(titleField.maxLength)>0?Number(titleField.maxLength):60)))throw Error('优化后的商品标题为空或超长。');
   // 原扩展 push_pusher.js KH_INPUT_SEL 使用此基础属性货号框；排除 SKU 整表和任意 SKU 行。
   const styleFields=[...document.querySelectorAll('.sell-catProp-item-input input[maxlength="128"]')].filter(el=>visible(el)&&!el.closest('#struct-sku,[id*="sku"],[class*="sku-table"],.next-dialog,[role="dialog"]'));
   if(task.changeStyle&&styleFields.length!==1)throw Error('基础信息货号字段未唯一识别，未修改 SKU 货号。');
   const style=styleFields[0],styleBefore=intent?.styleBefore||style?.value?.trim()||'';
   if(intent?.stage==='awaiting-reload'){
    if(style?.value?.trim()!==intent.styleAfter)throw Error('改款号后的页面尚未读回目标款号，请人工核对；不会再次改号。');
    if(task.optimizedTitle)value(titleField,proposed);intent.stage='complete';sessionStorage.setItem(key,JSON.stringify(intent));return {ok:true,originalTitle,newTitle:titleField?.value||originalTitle,styleBefore:intent.styleBefore,styleAfter:intent.styleAfter};
   }
   if(intent?.stage==='complete'){
    if(task.changeStyle&&style?.value?.trim()!==intent.styleAfter)throw Error('既有款号修改记录与当前页面不一致。');if(task.optimizedTitle&&titleField?.value!==intent.newTitle)throw Error('既有标题修改记录与当前页面不一致。');return {ok:true,...intent};
   }
   if(!intent){let styleAfter=styleBefore;if(task.changeStyle){if(!styleBefore)throw Error('源款号为空，未编造新款号。');if(!root.chrome?.storage?.local)throw Error('款号编号存储不可用，未改号。');const now=new Date(),date=String(now.getFullYear())+String(now.getMonth()+1).padStart(2,'0')+String(now.getDate()).padStart(2,'0'),base=styleBefore.replace(/-\d{4}-\d+$/,'').trim(),counterKey=base+'|'+date,stored=await chrome.storage.local.get('materialStyleSequences'),table=stored.materialStyleSequences||{},seq=Number(table[counterKey]||0)+1;table[counterKey]=seq;await chrome.storage.local.set({materialStyleSequences:table});const suffix='-'+date.slice(4)+'-'+seq;styleAfter=base.slice(0,128-suffix.length)+suffix;}intent={productId:task.productId,originalTitle,newTitle:proposed,styleBefore,styleAfter,stage:'prepared'};sessionStorage.setItem(key,JSON.stringify(intent));}
   if(task.changeStyle&&(style.readOnly||style.disabled)){
    const switchers=[...document.querySelectorAll('button.switch-cate-btn')].filter(visible);if(switchers.length!==1)throw Error('只读款号需切换类目弹窗，但入口不唯一。');
    const sourceBrands=[...document.querySelectorAll('.sell-component-item-prop-item-ui')].filter(row=>/^品牌/.test(row.innerText.trim())).map(row=>{const el=row.querySelector('.next-select-trigger,input');return String(el?.value||el?.textContent||'').trim();}).filter(text=>text&&text!=='请选择');if(sourceBrands.length!==1)throw Error('原品牌字段缺失或不唯一，未切换类目。');
    const wait=async test=>{for(let i=0;i<25;i++){const result=test();if(result)return result;await new Promise(resolve=>setTimeout(resolve,120));}throw Error('平台弹窗尚未就绪，未继续修改。');};switchers[0].click();const dialog=await wait(()=>{const found=[...document.querySelectorAll('.next-dialog,[role="dialog"]')].filter(visible);if(found.length>1)throw Error('类目弹窗不唯一');return found[0];});
    const brand=dialog.querySelector('.sell-catProp-item-select');if(!brand)throw Error('类目弹窗品牌字段未识别');brand.click();const options=await wait(()=>{const found=[...document.querySelectorAll('.next-overlay-wrapper.opened .info-content')].filter(visible);return found.length?found:null;});const match=options.filter(el=>el.textContent.trim()===sourceBrands[0]);const pick=match.length===1?match[0]:null;if(!pick)throw Error('授权品牌不唯一或与原品牌不匹配，未选其他品牌');pick.click();await wait(()=>brand.textContent.trim()&&brand.textContent.trim()!=='请选择');
    const fields=[...dialog.querySelectorAll('input[maxlength="128"]')].filter(el=>visible(el)&&!el.disabled&&!el.readOnly);if(fields.length!==1)throw Error('类目弹窗货号字段不唯一');value(fields[0],intent.styleAfter);const confirm=await wait(()=>{const list=controls(dialog).filter(el=>el.textContent.trim()==='确定');if(list.length>1)throw Error('类目确认按钮不唯一');return list[0];});intent.stage='awaiting-reload';sessionStorage.setItem(key,JSON.stringify(intent));confirm.click();return {ok:true,requiresReload:true,originalTitle,newTitle:proposed,styleBefore,styleAfter:intent.styleAfter};
   }
   if(task.changeStyle)value(style,intent.styleAfter);if(task.optimizedTitle)value(titleField,proposed);intent.stage='complete';sessionStorage.setItem(key,JSON.stringify(intent));return {ok:true,originalTitle,newTitle:titleField?.value||originalTitle,styleBefore,styleAfter:intent.styleAfter};
  }
  if(action==='product-search'){const fields=[...document.querySelectorAll('input')].filter(el=>visible(el)&&/商品ID|宝贝名称|商品名称|宝贝ID/.test(el.placeholder));if(fields.length!==1)throw Error('出售中商品搜索入口不唯一。');value(fields[0],task.productId);oneButton(fields[0].closest('form')||document.body,['搜索','查询']).click();return {ok:true};}
  if(action==='fission-route'){const rows=[...document.querySelectorAll('tr,[role="row"],.next-table-row')].filter(el=>visible(el)&&same(pids(el),[task.productId]));if(rows.length!==1)throw Error('未在出售中精确找到目标商品。');const anchors=[...rows[0].querySelectorAll('a[href]')].filter(a=>/sell\.publish\.tmall\.com\/tmall\/publish\.htm/.test(a.href));const edit=anchors.find(a=>{const u=new URL(a.href);return u.searchParams.get('itemId')===task.productId;});if(!edit)throw Error('目标商品官方编辑链接未识别。');const u=new URL(edit.href);if(task.mode==='new'){u.searchParams.set('copyItem','true');u.searchParams.set('st_dist_src_id',task.productId);}return {ok:true,url:u.href};}
  if(action==='picker-search'){const candidates=[...document.querySelectorAll('input')].filter(el=>visible(el)&&/图片名|图片名称|文件名/.test(el.placeholder));if(candidates.length!==1)throw Error('图片空间搜索入口不唯一。');value(candidates[0],arg.name);oneButton(candidates[0].closest('form,.next-search')||document.body,['搜索','查询']).click();return {ok:true};}
  if(action==='picker-empty'){const checked=[...document.querySelectorAll('input[type="checkbox"]:checked')].filter(el=>visible(el)||visible(el.parentElement));if(checked.length)throw Error('图片选择器存在未确认的预选图片，请先清空；未带入其他图片。');return {ok:true};}
  if(action==='picker-select'){
   const candidates=[...document.querySelectorAll('[title],tr,[role="row"],.image-item,.picture-item,[class*="imageItem"],[class*="pic-item"]')].filter(el=>visible(el)&&(el.getAttribute('title')===arg.name||el.innerText.trim()===arg.name||el.innerText.split('\n').some(text=>text.trim()===arg.name))&&images(el).some(url=>urlMatches(url,arg.url))).sort((a,b)=>a.innerText.length-b.innerText.length);
   const leaves=candidates.filter(el=>!candidates.some(other=>other!==el&&el.contains(other)));if(leaves.length!==1)throw Error('未找到唯一文件名及地址一致的图片。');const candidate=leaves[0];const check=candidate.querySelector('input[type="checkbox"],input[type="radio"]');if(check){if(!check.checked)check.click();await new Promise(resolve=>setTimeout(resolve,80));if(!check.checked)throw Error('图片选择状态未读回。');}else{candidate.click();await new Promise(resolve=>setTimeout(resolve,80));if(candidate.getAttribute('aria-selected')!=='true'&&!/(?:^|[\s_-])(?:selected|checked)(?:[\s_-]|$)/.test(candidate.className))throw Error('图片选中状态未确认。');}return {ok:true};
  }
  if(action==='picker-confirm'){oneButton(document.body,['确定','确认','使用选中图片']).click();return {ok:true};}
  if(action==='open-images'){
   identity(task);const scope=task.kind==='fission'?document.querySelector('#struct-mainImagesGroup'):document.querySelector('.next-picture-uploader')||document.body;if(!scope)throw Error('上传区域未识别。');
   const choices=controls(scope).filter(el=>['替换','上传图片','点击上传图片','添加图片'].includes(el.textContent.trim()));if(choices.length)choices[0].click();else if(scope.matches('.next-picture-uploader'))scope.click();else throw Error('图片上传入口未识别。');return {ok:true};
  }
  if(action==='verify-images'){identity(task);const urls=selectedImages(task);if(!task.uploads.every(record=>urls.some(url=>urlMatches(url,record.url))))throw Error('主图/种草图片地址尚未全部精确回填。');if(task.kind!=='fission'){const remaining=[...urls];for(const record of task.uploads){const i=remaining.findIndex(url=>urlMatches(url,record.url));if(i<0)throw Error('种草图片数量或地址不一致。');remaining.splice(i,1);}if(remaining.length)throw Error('种草表单包含未确认的额外图片，未发布。');}return {ok:true,urls};}
  if(action==='seed-associate'){
   const scope=document.body;if(same(pids(scope),[task.productId]))return {ok:true};oneButton(scope,['添加商品']).click();return {ok:true};
  }
  if(action==='seed-search'){const fields=[...document.querySelectorAll('input')].filter(el=>visible(el)&&/商品关键词|商品ID/.test(el.placeholder));if(fields.length!==1)throw Error('种草商品搜索字段未唯一识别。');value(fields[0],task.productId);oneButton(fields[0].closest('.next-dialog,.next-drawer')||document.body,['搜索','查询']).click();return {ok:true};}
  if(action==='seed-select'){const rows=[...document.querySelectorAll('tr,[role="row"],[data-item-id],.item-card')].filter(el=>visible(el)&&same(pids(el),[task.productId]));if(rows.length!==1)throw Error('种草搜索结果不唯一。');const input=rows[0].querySelector('input[type="checkbox"],input[type="radio"]');if(!input)throw Error('目标商品选择控件未识别。');if(!input.checked)input.click();oneButton(document.body,['确定','确认']).click();return {ok:true};}
  if(action==='seed-fill'){
   if(!same(pids(document.body),[task.productId]))throw Error('种草关联商品与目标不一致。');value(document.querySelector('input[placeholder*="标题"]'),task.title||'商品生活场景');const body=document.querySelector('textarea');if(body)value(body,task.body||'AI辅助创作，商品信息以商品详情页为准。');else{const editor=document.querySelector('[contenteditable="true"]');if(!editor)throw Error('种草正文编辑框未识别。');editor.textContent=task.body||'AI辅助创作，商品信息以商品详情页为准。';editor.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:editor.textContent}));}
   readCreatorDeclaration(true);seedFields(task);return {ok:true};
  }
  if(action==='submit'){
   identity(task);await execute('verify-images',task);
   if(task.kind!=='fission')seedFields(task);
   const button=oneButton(document.body,task.kind==='fission'?['提交']:['发布内容']);button.click();return {status:'submitted_unconfirmed',documentTimeOrigin:performance.timeOrigin};
  }
  if(action==='confirm-seed'){const dialogs=[...document.querySelectorAll('.next-dialog,[role="dialog"]')].filter(visible);if(!dialogs.length)return {ok:true,confirmation:false};if(dialogs.length!==1)throw Error('发布确认弹窗不唯一。');oneButton(dialogs[0],['确认发布','确定','确认']).click();return {ok:true,confirmation:true};}
  if(action==='receipt'){
   if(task.publication?.documentTimeOrigin===performance.timeOrigin)return {status:'submitted_unconfirmed'};
   const cards=[...document.querySelectorAll('[data-content-id],[data-item-id],tr,[role="row"]')].filter(el=>visible(el));
   const matches=cards.filter(el=>same(pids(el),[task.productId])&&task.uploads.every(record=>images(el).some(url=>urlMatches(url,record.url)))&&/已发布|审核中|审核通过|出售中/.test(el.innerText));
   if(matches.length!==1)return {status:'submitted_unconfirmed'};const card=matches[0],id=card.getAttribute('data-content-id')||card.getAttribute('data-item-id');if(!/^\d{6,}$/.test(id||''))return {status:'submitted_unconfirmed'};
   return {status:'verified',receipt:{source:'platform-readback',contentId:id,productIds:[task.productId],imageUrls:task.uploads.map(u=>u.url),status:card.innerText.match(/已发布|审核中|审核通过|出售中/)[0]}};
  }
  throw Error('未知工作台平台动作。');
 }
 root.FullStudioPage={execute};
})(globalThis);
