(function(root){
 'use strict';
 const FIELD='sc_item_img_800_800_scene';
 function publicImageURL(value){try{const url=new URL(value);if(url.protocol==='https:'&&/(^|\.)alicdn\.com$/.test(url.hostname)&&!url.username&&!url.password)return url.href;}catch{}return null;}
 function nativeSaveProof(job,pid,url){const saved=job.nativeSaveReceipt,legacy=job.nativeResultSource==='owned-native-editor-save-request';return job.module==='white'&&!!job.id&&!!job.nativeIntent&&job.publication?.productIds?.length===1&&job.publication.productIds[0]===pid&&saved?.platformSaveConfirmed===true&&saved.imageUrl===url&&(saved.source==='owned-native-editor-save-request'||legacy)&&(saved.saveRequestCount===1||legacy&&saved.saveRequestCount===undefined)&&(saved.productId===undefined||saved.productId===pid)&&(saved.itemId===undefined||saved.itemId===job.id);}
 function reviewSaveProof(job,pid,url){const saved=job.reviewSaveResult,proof=saved?.reviewSaveReceipt,publication=job.publication,original=job.reviewOriginal;if(job.module!=='white'||job.reviewRetry!==true||!job.id||publication?.productIds?.length!==1||publication.productIds[0]!==pid||!publication.id||original?.productId!==pid||original.review?.code!=='4'||original.review?.name!=='审核不通过'||!original.materialId)return false;if(proof)return proof.platformSaveConfirmed===true&&proof.saveRequestCount===1&&proof.productId===pid&&proof.imageUrl===url&&proof.oldMaterialId===original.materialId&&proof.publicationId===publication.id;return saved?.ok===true&&saved.status==='submitted_unconfirmed'&&saved.message==='已保存，后台素材记录尚未匹配。';}
 function sceneSaveProof(job,pid,url){const saved=job.sceneSaveResult,proof=saved?.sceneSaveReceipt;if(job.module!=='scene'||!job.id||!job.publication?.id||job.publication.productIds?.length!==1||job.publication.productIds[0]!==pid||job.sceneUpload?.url!==url||!job.sceneUpload.pictureId)return false;if(proof)return proof.platformSaveConfirmed===true&&proof.saveRequestCount===1&&proof.productId===pid&&proof.imageUrl===url&&proof.itemId===job.id&&proof.publicationId===job.publication.id;return saved?.ok===true&&saved.status==='submitted_unconfirmed'&&saved.message==='已保存，后台素材记录尚未匹配。';}
 async function imageHash(url){const safe=publicImageURL(url);if(!safe)throw Error('白底图字节核验URL不在官方图片域。');const response=await fetch(safe,{credentials:'omit',cache:'no-store',redirect:'error',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('白底图字节读取未确认。');const bytes=await response.arrayBuffer();if(!bytes.byteLength)throw Error('白底图字节为空。');return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');}
 function extract(response,pid,field=FIELD,bizId='5'){
  if(response?.success!==true||!Array.isArray(response.data?.list))throw new Error('平台素材回包结构未识别。');
  const matched=response.data.list.filter(row=>[row.itemId,row.domainInfo?.itemId,row.domainInfo?.domainId,row.domainInfo?.info?.itemId,row.head?.itemId].some(id=>String(id)===pid));
  if(matched.length!==1)throw new Error('目标商品素材记录不唯一。');
  const row=matched[0], identifiers=[row.itemId,row.domainInfo?.itemId,row.domainInfo?.domainId,row.domainInfo?.info?.itemId,row.head?.itemId].filter(id=>id!=null).map(String);
  if(identifiers.some(id=>id!==pid))throw new Error('素材回包商品ID冲突。');
  const matches=[];
  for(const material of row.material||[])for(const form of material.formVOList||[])for(const item of form.form?.items||[]){
   if(item.name!==field)continue;
   const props=item.componentProps||{};
   for(const object of [form,props])for(const [key,value] of Object.entries({domainId:pid,domainType:'1001',bizId,bizType:'22'}))if(String(object[key])!==value)throw new Error('平台素材字段身份不符。');
   if(!/^\d+$/.test(String(form.templateId||'')))throw new Error('缺少有效平台模板ID。');
   const hasValue=Object.prototype.hasOwnProperty.call(item,'defaultValue');
   if(hasValue&&(!item.defaultValue||typeof item.defaultValue!=='object'||typeof item.defaultValue.picUrl!=='string'))throw new Error('素材图片值结构未确认，不能当空槽。');
   let pictureUrl=hasValue?item.defaultValue.picUrl:'';
   if(pictureUrl){const parsed=new URL(pictureUrl.startsWith('//')?'https:'+pictureUrl:pictureUrl);if(parsed.protocol!=='https:'||!/(^|\.)alicdn\.com$/.test(parsed.hostname))throw new Error('素材槽图片地址未确认。');pictureUrl=parsed.href;}
   if(!pictureUrl&&['materialId','materialStatus','auditTime','expectVersion'].some(key=>Object.prototype.hasOwnProperty.call(props,key)))throw new Error('素材槽仍有历史或审核记录，不能当明确空槽。');
   matches.push({productId:pid,templateId:String(form.templateId),url:pictureUrl,materialId:props.materialId?String(props.materialId):null,materialStatus:String(props.materialStatus??''),field});
  }
  if(matches.length!==1)throw new Error('场景图字段不唯一或缺失。');return matches[0];
 }
 function extractReview(response,pid){
  const scene=extract(response,pid,'itemWhiteImg','3'),row=response.data.list.find(r=>[r.itemId,r.domainInfo?.domainId,r.domainInfo?.info?.itemId].some(id=>String(id)===pid)),fields=[];
  for(const m of row.material||[])for(const f of m.formVOList||[])for(const i of f.form?.items||[])if(i.name==='itemWhiteImg')fields.push(i.componentProps);
  if(fields.length!==1)throw Error('官方白底审核字段不唯一。');const p=fields[0],info=row.domainInfo?.info||{},sale=String(info.itemStatusName||'');
  return {...scene,title:String(info.itemName||info.itemTitle||info.title||row.head?.title||''),saleState:/出售中|在售/.test(sale)?'on_sale':/下架|仓库/.test(sale)?'off_sale':'unknown',review:{code:String(p.materialStatus??''),name:String(p.materialStatusName||''),reason:String(p.materialRejectReason||'').slice(0,500),auditTime:p.auditTime?String(p.auditTime):''}};
 }
 function assertReviewReplacement(expected,current){
  const valid=s=>s?.saleState==='on_sale'&&s.review?.code==='4'&&s.review?.name==='审核不通过'&&!!s.materialId&&!!s.url;
  if(!valid(expected)||!valid(current)||['productId','materialId','url'].some(k=>expected[k]!==current[k])||expected.review.auditTime!==current.review.auditTime)throw Error('原失败素材或审核状态已变化，禁止替换。');
 }
 function extractTransparent(response,pid){
  if(response?.success!==true||!Array.isArray(response.data?.list))throw Error('平台透明图回包结构未识别。');
  const matched=response.data.list.filter(r=>[r.itemId,r.domainInfo?.domainId,r.domainInfo?.info?.itemId].some(id=>String(id)===pid));if(matched.length!==1)throw Error('透明图商品记录不唯一。');
  const record=matched[0],identifiers=[record.itemId,record.domainInfo?.domainId,record.domainInfo?.info?.itemId].filter(id=>id!=null).map(String);if(identifiers.some(id=>id!==pid))throw Error('透明图商品身份冲突。');
  const saleLabel=String(record.domainInfo?.info?.itemStatusName||''),saleState=/下架|仓库|不在售|非在售/.test(saleLabel)?'off_sale':/^(出售中|在售)/.test(saleLabel)?'on_sale':'unknown';
  if(!(record.material||[]).some(m=>(m.formVOList||[]).some(f=>(f.form?.items||[]).some(i=>i.name==='sc_item_img_800_800_transparent'))))return {productId:pid,supported:false,title:String(record.domainInfo?.info?.itemName||''),saleState,url:'',materialId:null,whiteSource:{},review:{}};
  const scene=extract(response,pid,'sc_item_img_800_800_transparent','4'),white=extractReview(response,pid),row=response.data.list.find(r=>[r.itemId,r.domainInfo?.domainId,r.domainInfo?.info?.itemId].some(id=>String(id)===pid));
  const fields=[];for(const m of row.material||[])for(const f of m.formVOList||[])for(const item of f.form?.items||[])if(item.name==='sc_item_img_800_800_transparent')fields.push(item.componentProps);
  if(fields.length!==1)throw Error('官方透明图字段不唯一。');const p=fields[0];
  if(String(p.width)!=='800'||String(p.height)!=='800'||p.fileSuffix!=='png'||p.transparentCheck!==true)throw Error('当前透明图规格未确认。');
  return {...scene,supported:true,title:white.title,saleState,review:{code:String(p.materialStatus??''),name:String(p.materialStatusName||''),reason:String(p.materialRejectReason||'').slice(0,500),auditTime:p.auditTime?String(p.auditTime):''},whiteSource:{productId:pid,materialId:white.materialId,url:white.url,review:white.review},requirements:{width:800,height:800,format:'png',maxBytes:3*1024*1024}};
 }
 function assertTransparentTarget(expected,current,replace){
  if(!expected||!current||current.supported===false||!/^\d+$/.test(current.templateId||'')||['productId','templateId','url'].some(k=>expected[k]!==current[k])||(expected.materialId??null)!==(current.materialId??null)||expected.review?.auditTime!==current.review?.auditTime||expected.whiteSource?.materialId!==current.whiteSource?.materialId||expected.whiteSource?.url!==current.whiteSource?.url||current.saleState!=='on_sale'||!current.whiteSource?.url||!current.whiteSource?.materialId)throw Error('原透明素材或白底图已变化，未替换。');
  if(replace){if(expected.review?.code!=='4'||expected.review?.name!=='审核不通过'||current.review?.code!=='4'||current.review?.name!=='审核不通过'||!current.materialId)throw Error('仅允许替换仍明确审核不通过的原透明图。');}
  else if(current.url||current.materialId)throw Error('透明图槽已有内容，普通补缺不覆盖。');
 }
 function transparentSaveProof(job,pid,url){const proof=job.transparentSaveResult?.transparentSaveReceipt;return job.module==='transparent'&&!!job.id&&proof?.platformSaveConfirmed===true&&proof.saveRequestCount===1&&proof.productId===pid&&proof.imageUrl===url&&proof.publicationId===job.publication?.id&&proof.sourceMaterialId===job.transparentOriginal?.whiteSource?.materialId&&job.publication?.productIds?.join()===pid;}
 async function reviewPage(pageNumber){
  if(!Number.isInteger(pageNumber)||pageNumber<1)throw Error('审核分页页码无效。');
  const token=document.cookie.match(/(?:^|;\s*)_tb_token_=([^;]*)/)?.[1];if(!token)throw Error('平台登录未就绪。');
  const u=new URL('https://sale.taobao.com/dpss/yinhe/list/query.do');for(const [k,v]of Object.entries({code:'sellerMaterialDataListV2',useNewForm:'true',sceneId:'23',productionConfigId:'45',currentPage:String(pageNumber),pageSize:'10',_tb_token_:token}))u.searchParams.set(k,v);
  const response=await fetch(u.href,{credentials:'include',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('审核分页查询未确认。');const data=await response.json(),d=data.data;
  if(data.success!==true||!Array.isArray(d?.list)||!Number.isSafeInteger(Number(d.total))||Number(d.total)<0||Number(d.currentPage)!==pageNumber||!Number.isSafeInteger(Number(d.pageSize))||Number(d.pageSize)<1)throw Error('官方审核分页结构未确认。');
  const scenes=d.list.map(row=>{const ids=[row.itemId,row.domainInfo?.domainId,row.domainInfo?.info?.itemId].filter(x=>x!=null).map(String);if(!ids.length||new Set(ids).size!==1)throw Error('审核分页商品身份冲突。');return extractReview(data,ids[0]);});
  return {scenes,total:Number(d.total),pageSize:Number(d.pageSize),number:pageNumber,totalPages:Math.max(1,Math.ceil(Number(d.total)/Number(d.pageSize)))};
 }
 async function transparentPage(pageNumber){
  if(!Number.isInteger(pageNumber)||pageNumber<1)throw Error('透明图分页页码无效。');const token=document.cookie.match(/(?:^|;\s*)_tb_token_=([^;]*)/)?.[1];if(!token)throw Error('平台登录未就绪。');
  const u=new URL('https://sale.taobao.com/dpss/yinhe/list/query.do');for(const[k,v]of Object.entries({code:'sellerMaterialDataListV2',useNewForm:'true',sceneId:'23',productionConfigId:'45',currentPage:String(pageNumber),pageSize:'10',_tb_token_:token}))u.searchParams.set(k,v);
  const response=await fetch(u.href,{credentials:'include',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('透明图分页查询未确认。');const data=await response.json(),d=data.data;
  if(data.success!==true||!Array.isArray(d?.list)||!Number.isSafeInteger(Number(d.total))||Number(d.total)<0||Number(d.currentPage)!==pageNumber||!Number.isSafeInteger(Number(d.pageSize))||Number(d.pageSize)<1)throw Error('官方透明图分页结构未确认。');
  const scenes=d.list.map(row=>{const ids=[row.itemId,row.domainInfo?.domainId,row.domainInfo?.info?.itemId].filter(x=>x!=null).map(String);if(!ids.length||new Set(ids).size!==1)throw Error('透明图分页商品身份冲突。');return extractTransparent(data,ids[0]);});
  return {scenes,total:Number(d.total),pageSize:Number(d.pageSize),number:pageNumber,totalPages:Math.max(1,Math.ceil(Number(d.total)/Number(d.pageSize)))};
 }

 async function request(job,action,fileName){
  const pid=job.productIds?.[0];if(job.productIds?.length!==1||!/^\d{6,}$/.test(pid))throw new Error('场景绑定需要一个明确商品ID。');
  const field=job.module==='white'?'itemWhiteImg':job.module==='transparent'?'sc_item_img_800_800_transparent':FIELD,bizId=job.module==='white'?'3':job.module==='transparent'?'4':'5';
  // CSRF只在平台页面内存中使用，不回传、不写日志、不保存在任务中。
  const token=document.cookie.match(/(?:^|;\s*)_tb_token_=([^;]*)/)?.[1];if(action!=='lookup'&&!token)throw Object.assign(new Error('平台登录或CSRF状态未就绪。'),{code:'PLATFORM_LOGIN_UNAVAILABLE'});
  async function query(review=false){const u=new URL('https://sale.taobao.com/dpss/yinhe/list/query.do');for(const [key,value]of Object.entries({code:'sellerMaterialDataListV2',useNewForm:'true',sceneId:'23',productionConfigId:'45',currentPage:'1',itemIdOrName:pid,_tb_token_:token}))u.searchParams.set(key,value);const response=await fetch(u.href,{credentials:'include',signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('平台素材查询失败。');const payload=await response.json();if(job.module==='transparent'&&payload.success===true&&Array.isArray(payload.data?.list)&&payload.data.list.length===0)return {productId:pid,saleState:'not_found',notFoundConfirmed:true};return job.module==='transparent'?extractTransparent(payload,pid):review?extractReview(payload,pid):extract(payload,pid,field,bizId);}
  if(action==='readTransparent'){if(job.module!=='transparent')throw Error('透明图读取模块不符。');return {ok:true,status:'prepared',scene:await query()};}
  if(action==='readReview')return {ok:true,status:'prepared',scene:await query(true)};
  if(action==='read')return {ok:true,status:'prepared',scene:await query()};
  if(action==='verify'){const scene=await query(job.reviewRetry===true),expected=job.sceneUpload?.url;let hash;
   if(!scene.materialId)return {ok:true,status:'submitted_unconfirmed',scene,message:'官方素材ID未确认，继续回查。'};
   if(scene.url!==expected){if(!publicImageURL(expected)||!publicImageURL(scene.url)||!(nativeSaveProof(job,pid,expected)||sceneSaveProof(job,pid,expected)||reviewSaveProof(job,pid,expected)&&scene.materialId!==job.reviewOriginal.materialId||transparentSaveProof(job,pid,expected)&&scene.materialId!==job.transparentOriginal.materialId))return {ok:true,status:'submitted_unconfirmed',scene,message:'素材槽URL不匹配且没有同商品单次保存证明，继续回查。'};
    try{const hashes=await Promise.all([imageHash(expected),imageHash(scene.url)]);if(hashes[0]!==hashes[1])return {ok:true,status:'submitted_unconfirmed',scene,message:'官方改写URL与原素材字节不同，未验收。'};hash=hashes[0];}catch{return {ok:true,status:'submitted_unconfirmed',scene,message:'保存已确认，但官方改写图片的字节读取未确认。'};}
   }
   return {ok:true,status:'verified',scene,...(job.reviewRetry||job.module==='transparent'?{review:scene.review}:{}),receipt:{source:'platform-readback',contentId:scene.materialId,productIds:[pid],status:scene.materialStatus||'已绑定',url:'https://sale.taobao.com/dpss/yinhe/list/query.do',imageUrl:scene.url,...(hash?{imageMatch:'sha256',imageSha256:hash}:{})}};
  }
  if(!root.lib?.mtop?.request)throw Object.assign(new Error('图片空间查询组件未就绪，请先打开官方图片空间。'),{code:'LOOKUP_COMPONENT_UNAVAILABLE'});
  const response=await new Promise((resolve,reject)=>{const signal=AbortSignal.timeout(15000),timeout=()=>reject(Object.assign(Error('图片空间查询超时；请完成平台验证后继续原任务。'),{code:'PICTURE_QUERY_TIMEOUT',saveNotAttempted:action==='bind'}));signal.addEventListener('abort',timeout,{once:true});Promise.resolve().then(()=>root.lib.mtop.request({api:'mtop.taobao.picturecenter.console.file.query',v:'1.0',type:'GET',dataType:'json',data:{page:1,deleted:0,orderBy:'0',status:0,ignoreCat:1,clientType:0,type:1,catId:'0'}})).then(value=>{signal.removeEventListener('abort',timeout);resolve(value);},error=>{signal.removeEventListener('abort',timeout);reject(error);});});
  const pictures=[];let recovered=false;const proof=job.uploadProof,allowTruncated=action==='lookup'&&['search','scene'].includes(job.module)&&proof?.originalName===fileName&&/^[a-f0-9]{32}$/.test(proof.md5||'');function scan(value){if(!value||typeof value!=='object')return;if(value.fullUrl){if(Object.values(value).some(v=>v===fileName))pictures.push(value);else if(allowTruncated&&typeof value.name==='string'&&value.name.endsWith('.png')&&value.name.length<fileName.length&&fileName.startsWith(value.name.slice(0,-4))&&String(value.md5||'').toLowerCase()===proof.md5){pictures.push(value);recovered=true;}}for(const child of Object.values(value))if(child&&typeof child==='object')scan(child);}scan(response.data);
  if(!pictures.length)throw Object.assign(new Error('图片空间尚未查到本批唯一文件名。'),{code:'PICTURE_NOT_FOUND'});
  if(pictures.length!==1||['scene','transparent'].includes(job.module)&&pictures[0].pixel!=='800x800')throw Object.assign(new Error('图片记录重复或800×800尺寸不符。'),{code:'PICTURE_RECORD_CONFLICT'});
  const picture=pictures[0];const url=new URL(picture.fullUrl.startsWith('//')?'https:'+picture.fullUrl:picture.fullUrl);if(url.protocol!=='https:'||!/(^|\.)alicdn\.com$/.test(url.hostname))throw new Error('平台图片地址无效。');
  if(action==='lookup')return {ok:true,status:'uploaded',sceneUpload:{name:recovered?picture.name:fileName,url:url.href,pictureId:String(picture.pictureId||''),...(recovered?{originalName:fileName,contentMatch:'official-original-file-md5'}:{})}};
  if(action!=='bind'||!job.publicationConsent||job.sceneUpload?.url!==url.href)throw new Error('场景绑定未确认或上传记录不符。');
  if(job.module==='transparent'&&(!job.publication?.id||job.publication.productIds?.join()!==pid))throw Error('透明图缺少同商品单次提交意图。');
  const before=await query(job.reviewRetry===true);if(job.module==='transparent')assertTransparentTarget(job.transparentOriginal,before,job.replaceExisting===true);if(job.reviewRetry===true)assertReviewReplacement(job.reviewOriginal,before);if(before.url&&!job.replaceExisting)throw new Error('该素材槽已有图片，需明确选择允许替换后才能保存。');const form=new URLSearchParams({bizId,bizType:'22',domainType:'1001',operatorType:'1',domainId:pid,_tb_token_:token,postFormDatas:JSON.stringify([{templateId:Number(before.templateId),postFormData:{[field]:url.href}}])});
  const saved=await fetch('https://sale.taobao.com/dpss/yinhe/form/save.do',{method:'POST',credentials:'include',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:form,signal:AbortSignal.timeout(20000)});
  if(!saved.ok)return {ok:true,status:'submitted_unconfirmed',message:'场景保存HTTP结果不明，只能回查，不重交。'};
  let result;try{result=await saved.json();}catch{return {ok:true,status:'submitted_unconfirmed',message:'保存回包未识别，只能回查。'};}
  if(result.success!==true)return {ok:true,status:'submitted_unconfirmed',message:result.success===false?'平台明确返回未成功，保留响应分类；不自动重交。':'平台未明确确认保存，请回查。',saveOutcome:result.success===false?'rejected':'unknown'};
  const sceneSaveReceipt=job.module==='scene'?{platformSaveConfirmed:true,saveRequestCount:1,productId:pid,imageUrl:url.href,itemId:job.id,publicationId:job.publication?.id}:undefined;
  const reviewSaveReceipt=job.reviewRetry?{platformSaveConfirmed:true,saveRequestCount:1,productId:pid,imageUrl:url.href,oldMaterialId:before.materialId,publicationId:job.publication?.id}:undefined;
  const transparentSaveReceipt=job.module==='transparent'?{platformSaveConfirmed:true,saveRequestCount:1,productId:pid,imageUrl:url.href,oldMaterialId:before.materialId,sourceMaterialId:before.whiteSource.materialId,publicationId:job.publication?.id}:undefined;
  const scene=await query(job.reviewRetry===true);if(scene.url!==url.href||!scene.materialId)return {ok:true,status:'submitted_unconfirmed',message:'已保存，后台素材记录尚未匹配。',...(reviewSaveReceipt?{reviewSaveReceipt}:{}),...(sceneSaveReceipt?{sceneSaveReceipt}:{}),...(transparentSaveReceipt?{transparentSaveReceipt}:{})};
  return {ok:true,status:'verified',...(job.reviewRetry?{review:scene.review,reviewSaveReceipt}:{}),...(sceneSaveReceipt?{sceneSaveReceipt}:{}),...(transparentSaveReceipt?{transparentSaveReceipt,review:scene.review}:{}),receipt:{source:'platform-readback',contentId:scene.materialId,productIds:[pid],status:scene.materialStatus||'已绑定',imageUrl:scene.url}};
 }
 root.FullScene={extract,extractReview,assertReviewReplacement,reviewPage,extractTransparent,assertTransparentTarget,transparentPage,request};if(typeof module!=='undefined')module.exports=root.FullScene;
})(globalThis);
