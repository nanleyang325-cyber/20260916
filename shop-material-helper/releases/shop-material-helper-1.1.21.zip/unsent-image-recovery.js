(function(root){
 'use strict';
 function plan(run,m,history){
  if(m.confirm!==true||!run||run.id!==m.runId||run.module!=='search'||run.status!=='done'||run.enabled||run.cancellation||run.generationOnlyRecovery||!run.selection?.startConsent||run.selection.executionBoundary?.paidGeneration!==true)throw Error('原任务与新增付费生图确认不符。');
  const ids=m.assetIds,gs=run.items.flatMap(i=>i.generations||[]);
  if(!Array.isArray(ids)||!ids.length||ids.length>9||new Set(ids).size!==ids.length||gs.length!==ids.length||gs.some(g=>!ids.includes(g.id)||!g.intent)||Number(run.selection.maxCalls)<ids.length)throw Error('原编号或预算范围不符。');
  if(run.items.some(i=>i.productIds?.join()!==m.productId||!i.failureSkipped||i.failure?.phase!=='generate'||!i.failure.reason.includes('(409)')||i.publication||i.receipt||i.prepared?.uploadedAssets?.length||Object.keys(i.uploadIntents||{}).length||i.syncRuns?.length))throw Error('存在非暂停卡点、其他商品或已上传/提交记录，不能按未发送恢复。');
  if(history.some(j=>ids.includes(j.id)))throw Error('本机已登记原编号，必须查询原请求，不得重新提交。');
  if(run.usedCalls!==ids.length||gs.some(g=>g.status!=='pending'))throw Error('原意图状态未确认，保留记录。');
  return {assetIds:[...ids],productId:m.productId,originalIntentCount:run.usedCalls,providerRequestsBefore:0,generationOnly:true};
 }
 function apply(run,p){
  const at=new Date().toISOString();run.generationOnlyRecovery={...p,at};
  for(const item of run.items){item.failureHistory||=[];item.failureHistory.push(structuredClone(item.failure));delete item.failure;delete item.failureSkipped;item.phase='generate';item.status='pending';for(const g of item.generations){g.unsubmittedIntents||=[];g.unsubmittedIntents.push({intent:structuredClone(g.intent),reason:'本地暂停拒绝，已核本机无任务登记，未调用服务商',at});delete g.intent;g.status='draft';delete g.error;}}
  run.usedCalls=0;run.usedCallsByType={...(run.usedCallsByType||{}),image:0};run.position=0;run.phase='items';run.enabled=false;run.status='paused';run.error='';run.draining=false;
  run.events.push({at,phase:'items',position:0,detail:'用户明确批准原'+p.assetIds.length+'个编号继续生图；旧计数为本地意图，服务商请求0，已归档未发送意图。仅放行这些编号，店铺写入关闭。'});return run;
 }
 root.UnsentImageRecovery={plan,apply};if(typeof module==='object')module.exports=root.UnsentImageRecovery;
 if(!root.chrome?.runtime?.onMessage)return;
 chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(m.type!=='FULL_RECOVER_UNSENT_IMAGES')return;
  if(sender.id!==chrome.runtime.id||sender.url!==chrome.runtime.getURL('api-settings.html')){reply({ok:false,error:'恢复入口不符'});return;}
  executionGate(async()=>{
   const runs=await flowRuns(),run=runs.find(r=>r.id===m.runId);
   if(flowBusy||queueBusy||runs.some(r=>r.enabled)||(await autoRuns()).some(r=>r.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled)||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||typeof studioBatchConflict==='function'&&await studioBatchConflict()||typeof studioBusy!=='undefined'&&studioBusy.size||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled))throw Error('其他队列仍在执行，未恢复。');
   if(!run||!FullFlowRun.matchesConsent(run))throw Error('原范围已变化。');
   const control=await chrome.storage.local.get(['independent-ai-control-v1','material-global-control-v1']);
   if(!control['independent-ai-control-v1']?.paused||control['material-global-control-v1']?.paused||control['material-global-control-v1']?.draining)throw Error('暂停来源不符，未解除其他控制。');
   const history=await(await fetch(chrome.runtime.getURL('local-api/api/history'))).json();
   if(!Array.isArray(history.jobs))throw Error('本机任务登记未核实');const p=plan(run,m,history.jobs);
   const key='unsent-images-before-recovery:'+run.id;if((await chrome.storage.local.get(key))[key])throw Error('原恢复备份已存在，先查状态。');
   await chrome.storage.local.set({[key]:structuredClone(run)});
   await FullStateStore.update('material-flow-runs-v1',current=>{const latest=current.find(r=>r.id===run.id);if(JSON.stringify(latest)!==JSON.stringify(run))throw Error('原任务已经改变');apply(latest,p);return current;});
   // Keep global new requests paused; only the explicit original UUIDs are allowed.
   await chrome.storage.local.set({'independent-ai-control-v1':{...control['independent-ai-control-v1'],paused:true,allowedIds:p.assetIds,allowedRunId:run.id,allowedAt:new Date().toISOString()}});
   reply({ok:true,runId:run.id,status:'prepared',images:p.assetIds.length,providerRequestsBefore:0,generationOnly:true});
  }).catch(e=>reply({ok:false,error:e.message}));return true;
 });
})(globalThis);
