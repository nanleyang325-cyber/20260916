(function(root){
 'use strict';
 const Q=root.MaterialFeaturedQuality||(typeof require==='function'?require('./featured-quality.js'):null);
 const enabled=(run,item)=>run.module==='search'&&run.selection?.mode!=='cleanup'&&Array.isArray(item.generations)&&item.generations.length>0&&item.generations.every(g=>g.media==='image');
 function validate(run,item,images,index){
  if(!enabled(run,item))return null;
  if(item.productIds?.length!==1||images.length!==item.generations.length||new Set(images.map(i=>i.id)).size!==images.length)throw Error('本地检查：商品或图片数量不符');
  for(let n=0;n<images.length;n++){const im=images[n],g=item.generations[n];if(im.id!==g.id||!/^[a-f0-9]{64}$/.test(im.sha256||''))throw Error('本地检查：图片编号或文件指纹不符');const errors=Q.technical(im,g.ratio||'3:4');if(errors.length)throw Error('本地检查：'+errors.join('；'));}
  if(new Set(images.map(i=>i.sha256)).size!==images.length)throw Error('本地检查：本组存在完全相同的重复图');
  const ids=new Set(images.map(i=>i.id));if(index.some(i=>!ids.has(i.id)&&images.some(c=>c.sha256===i.sha256)))throw Error('本地检查：与本机同商品其他成图完全相同');
  const uploaded=item.prepared?.uploadedAssets;if(uploaded?.length&&JSON.stringify(uploaded.map(a=>a.sourceAssetId))!==JSON.stringify(images.map(i=>i.id)))throw Error('本地检查：上传素材编号与原图不符');
  return {source:'local-file-check',status:'passed',images:images.map(({id,sha256,width,height})=>({id,sha256,width,height})),comparedLocalImages:index.length,modelCalls:0};
 }
 const api={enabled,validate};root.MaterialLocalQuality=api;if(typeof module==='object')module.exports=api;
})(globalThis);
