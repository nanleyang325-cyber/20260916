(function(root){'use strict';
 const endpoint='/h5/mtop.taobao.feeds.material.item.list/1.0/';
 function requestMatches(request,id){try{const u=new URL(request.url);if(u.protocol!=='https:'||!/(^|\.)taobao\.com$/.test(u.hostname)||u.pathname!==endpoint)return false;const p=new URLSearchParams(request.postData||u.search),data=JSON.parse(p.get('data')),condition=typeof data.condition==='string'?JSON.parse(data.condition):data.condition;return String(data.pageNo)==='1'&&Array.isArray(condition?.itemIds)&&Object.keys(condition).length===1&&condition.itemIds.length===1&&String(condition.itemIds[0])===id;}catch{return false;}}
 function response(raw,id){let data;try{if(typeof raw!=='string'||raw.length>2*1024*1024)throw Error();data=JSON.parse(raw.slice(raw.indexOf('{'),raw.lastIndexOf('}')+1));}catch{throw Error('指定商品查询回包无法解析，未按空结果跳过。');}
  const model=data.data?.model;if(!data.ret?.some(s=>String(s).startsWith('SUCCESS::'))||data.data.fail!==false||!model||!Array.isArray(model.data))throw Error('指定商品查询未成功，未按空结果跳过。');
  if(!['string','number'].includes(typeof model.totalCount)||!/^\d+$/.test(String(model.totalCount)))throw Error('指定商品查询总数无效，保留原任务。');const total=Number(model.totalCount),ids=model.data.map(r=>String(r.itemId||''));if(!Number.isInteger(total)||total<0||total!==ids.length||model.hasNext!==false)throw Error('指定商品查询数量不完整，保留原任务。');
  if(total>1||ids.some(v=>v!==id))throw Error('指定商品查询结果不唯一或商品身份不符，保留原任务。');
  return {source:'official-material-list-response',queryProductId:id,responsePageIndex:String(model.pageIndex??''),totalCount:total,productIds:ids,found:total===1};
 }
 function validate(proof,id){return proof?.source==='official-material-list-response'&&proof.queryProductId===id&&Number.isInteger(proof.totalCount)&&Array.isArray(proof.productIds)&&(proof.totalCount===0&&proof.productIds.length===0&&proof.found===false||proof.totalCount===1&&proof.productIds.length===1&&proof.productIds[0]===id&&proof.found===true);}
 root.FullSearchResultProof={requestMatches,response,validate};if(typeof module==='object')module.exports=root.FullSearchResultProof;
})(globalThis);
