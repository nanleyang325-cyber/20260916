(function(root){
 'use strict';
 const home='https://qn.taobao.com/home.htm/material-center/material-management';
 function isMaterial(url){try{const u=new URL(url);return u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname==='/home.htm/material-center/material-management';}catch{return false;}}
 async function open(options={}){
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!Number.isInteger(tab?.id))throw Error('未找到当前店铺标签页，请重新打开店铺素材助手。');
  // Chrome withholds internal-page URLs without the broad tabs permission.
  // Existing debugger metadata can identify only this current tab without
  // attaching a debugger, navigating another tab, or requesting new permissions.
  if(options.whiteEntry===true&&!tab.url&&chrome.debugger?.getTargets){
   const matches=(await chrome.debugger.getTargets()).filter(t=>t.type==='page'&&t.tabId===tab.id);
   if(matches.length===1&&typeof matches[0].url==='string')tab.url=matches[0].url;
  }
  if(isMaterial(tab.url)&&(!tab.pendingUrl||isMaterial(tab.pendingUrl)))return {tabId:tab.id,reused:true};
  let replace=tab.url==='about:blank';try{const u=new URL(tab.url);replace||=u.protocol==='https:'&&/(^|\.)(taobao|tmall|1688|qianniu)\.com$/.test(u.hostname);replace||=options.whiteEntry===true&&u.protocol==='chrome:'&&['history','newtab','new-tab-page'].includes(u.hostname);}catch{}
  if(options.reuseCurrent===true){const bootstrap=tab.url?.startsWith(chrome.runtime.getURL('data-connect.html'));if(!replace&&!bootstrap){const opened=await chrome.tabs.create({windowId:tab.windowId,url:home,active:true});return {tabId:opened.id,reused:false};}const result=await chrome.tabs.update(tab.id,{url:home,active:true});return {tabId:result.id,reused:true};}
  const result=replace?await chrome.tabs.update(tab.id,{url:home,active:true}):await chrome.tabs.create({windowId:tab.windowId,url:home,active:true});
  return {tabId:result.id,reused:false};
 }
 root.FullMaterialEntry={open};
 if(typeof module==='object')module.exports=root.FullMaterialEntry;
})(globalThis);
