(function(root){
 'use strict';
 // Evidence: original v5.4.175 push_pusher.js 435-523 and background.js 9221+.
 // Must execute in MAIN world: the official source-import CKEditor and __SELL_STATE__ live there.
 const EDITOR='.sell-component-lite-decoration-editor',MODULE='[class*="wrapper_module_index_label"]',PREFIX='material-studio-detail:';
 const visible=el=>!!el&&el.getClientRects().length>0&&getComputedStyle(el).visibility!=='hidden';
 const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 async function until(check,ms){const end=Date.now()+ms;do{const value=check();if(value)return value;if(Date.now()>=end)break;await wait(120);}while(true);return null;}
 const failure=(reason,error)=>({ok:false,status:'blocked',reason,error:error||reason});
 function identity(task,applying){const url=new URL(location.href);if(url.protocol!=='https:'||url.hostname!=='sell.publish.tmall.com'||url.pathname!=='/tmall/publish.htm'||!/^\d{6,}$/.test(task.productId||'')||url.searchParams.get('itemId')!==task.productId)throw Error('商品发布页与目标商品身份不符。');if(applying&&(task.mode!=='new'||url.searchParams.get('copyItem')!=='true'||url.searchParams.has('st_dist_src_id')&&url.searchParams.get('st_dist_src_id')!==task.productId))throw Error('同步详情只能在已核对的新增商品克隆页操作。');}
 function imageUrl(raw){try{const url=new URL(String(raw));if(!['https:','http:'].includes(url.protocol)||url.username||url.password||!/(^|\.)alicdn\.com$/.test(url.hostname))return null;return url.href;}catch{return null;}}
 function canonical(raw){const url=imageUrl(raw);if(!url)return '';const parsed=new URL(url);return parsed.origin+parsed.pathname.replace(/(\.(?:jpg|jpeg|png|webp))[_.].*$/i,'$1');}
 function editor(){const list=[...document.querySelectorAll(EDITOR)].filter(visible);if(list.length!==1)throw Error('图文详情编辑器缺失或不唯一。');return list[0];}
 function snapshot(){const el=editor(),ready=/拖动模块可以调整顺序/.test(el.innerText||''),modules=el.querySelectorAll(MODULE).length,urls=[...new Set([...el.querySelectorAll('img[src]')].map(img=>imageUrl(img.src)).filter(Boolean))];return {ready,modules,urls};}
 function mainUrls(task){const state=root.__SELL_STATE__;if(!state?.getState)throw Error('平台主图字段不可读，未从缩略图猜测来源。');const value=state.getState().getComponentValue('mainImagesGroup'),list=Array.isArray(value?.images)?value.images:Array.isArray(value)?value:null;if(!list||!list.length||list.length>50)throw Error('平台主图字段为空或异常。');const urls=list.map(item=>imageUrl(item?.url));if(urls.some(url=>!url))throw Error('平台主图未全部使用图片空间 alicdn 地址。');const uploads=(task.uploads||[]).map(record=>imageUrl(record.url));if(!uploads.length||uploads.some(url=>!url)||uploads.length!==urls.length||urls.some((url,index)=>canonical(url)!==canonical(uploads[index])))throw Error('平台主图字段与本次已上传图片不一致。');return urls;}
 const matches=(snap,urls)=>{const expected=new Set(urls.map(canonical)),actual=new Set(snap.urls.map(canonical));return snap.ready&&snap.modules>0&&expected.size>0&&expected.size===actual.size&&[...expected].every(url=>url&&actual.has(url));};
 function html(urls){return urls.map(url=>'<p><img src="'+url.replace(/&/g,'&amp;').replace(/"/g,'%22')+'" style="max-width:100%"/></p>').join('');}
 function key(task){if(!/^[a-zA-Z0-9_-]{8,100}$/.test(task.requestId||''))throw Error('缺少稳定详情同步编号。');return PREFIX+task.requestId;}
 function stored(task){const raw=sessionStorage.getItem(key(task));return raw?JSON.parse(raw):null;}
 function save(task,intent){sessionStorage.setItem(key(task),JSON.stringify(intent));}
 function applied(task,urls,snap,extra={}){return {ok:true,status:'applied',requestId:task.requestId,urls,modules:snap.modules,source:'main-field-alicdn',...extra};}
 function skipped(task,snap,reason){return {ok:true,status:'skipped',requestId:task.requestId,reason,modules:snap.modules,urls:snap.urls,retainedExisting:true};}
 function readback(task,result){const snap=snapshot();if(!snap.ready)return failure('editor_not_ready','图文详情编辑器尚未就绪。');if(!result)return failure('missing_detail_result','没有原详情同步结果，仅允许人工核对。');if(result.status==='applied'){if(!matches(snap,result.urls||[]))return failure('detail_readback_mismatch','详情模块数量或实际图片地址未与本次图片一致。');return {ok:true,status:'verified',detailStatus:'applied',modules:snap.modules,urls:result.urls,readOnly:true};}if(result.status==='skipped'){if(result.reason==='disabled'||result.reason==='replace_mode_preserves_existing')return {ok:true,status:'skipped',reason:result.reason,readOnly:true};if(result.reason!=='existing_detail_preserved'||snap.modules!==result.modules||(result.urls||[]).some(url=>!snap.urls.some(actual=>canonical(actual)===canonical(url))))return failure('preserved_detail_changed','原有详情保留记录与当前页面不一致。');return {ok:true,status:'verified',detailStatus:'skipped',reason:'existing_detail_preserved',modules:snap.modules,urls:result.urls||[],retainedExisting:true,readOnly:true};}return failure('invalid_detail_result','原详情同步结果状态无效。');}
 function recover(task){const intent=stored(task),snap=snapshot();if(!snap.ready)return failure('editor_not_ready','图文详情编辑器尚未就绪。');if(intent&&intent.productId!==task.productId)return failure('detail_intent_identity','原详情意图与商品身份不一致。');if(intent?.decision==='skip_existing'){const result=skipped(task,intent.baseline,'existing_detail_preserved'),check=readback(task,result);return check.ok?{...result,recovered:true,readOnly:true}:check;}const urls=intent?.urls||mainUrls(task);if(matches(snap,urls))return applied(task,urls,snap,{recovered:true,readOnly:true,importClicks:intent?.clicks||0});return failure('detail_import_unconfirmed','详情导入尚未读回预期模块和图片；仅回查，未再次点击导入。');}
 function uniqueText(text,selector='button,div,span,a'){const candidates=[...document.querySelectorAll(selector)].filter(el=>visible(el)&&!el.disabled&&el.getAttribute('aria-disabled')!=='true'&&el.textContent.trim()===text),leaves=candidates.filter(el=>!candidates.some(other=>other!==el&&el.contains(other)));if(leaves.length!==1)throw Error(text+'入口缺失或不唯一。');return leaves[0];}
 async function execute(action,task){try{
  identity(task,action==='apply'&&task.mode==='new');
  if(action==='inspect'){const snap=snapshot();return {ok:true,...snap,readOnly:true};}
  if(action==='verify')return readback(task,task.detailResult);
  if(action==='recover')return recover(task);
  if(action!=='apply')return failure('unknown_action','未知详情动作。');
  if(!task.syncDetail)return skipped(task,{modules:0,urls:[]},'disabled');
  if(task.mode!=='new')return skipped(task,snapshot(),'replace_mode_preserves_existing');
  const ready=await until(()=>{try{const snap=snapshot();return snap.ready?snap:null;}catch{return null;}},6000);if(!ready)return failure('editor_not_ready','详情编辑器未显示就绪标志，不能将未渲染误判为空。');
  const prior=stored(task);if(prior)return recover(task);
  if(ready.modules>0){save(task,{productId:task.productId,decision:'skip_existing',baseline:ready,stage:'complete'});return skipped(task,ready,'existing_detail_preserved');}
  const urls=mainUrls(task),intent={productId:task.productId,urls,baseline:ready,stage:'prepared',clicks:0};save(task,intent);
  uniqueText('源码导入').click();intent.stage='source_opened';save(task,intent);
  const ck=await until(()=>root.CKEDITOR?.instances?.['source-import'],15000);if(!ck)return failure('source_editor_missing','官方源码导入编辑器未就绪。');
  identity(task,true);if(snapshot().modules>0)return failure('detail_became_nonempty','打开导入期间出现已有详情，未覆盖。');
  let callbackReady=false;const source=html(urls);try{ck.setData(source,{callback:()=>{callbackReady=true;}});}catch{ck.setData(source);}const dataReady=await until(()=>{try{return callbackReady||urls.every(url=>String(ck.getData()||'').includes(url.replace(/&/g,'&amp;'))||String(ck.getData()||'').includes(url));}catch{return callbackReady;}},5000);if(!dataReady)return failure('source_data_unconfirmed','源码未读回预期图片，未点击导入。');intent.stage='source_data_set';save(task,intent);
  for(let attempt=0;attempt<3;attempt++){
   identity(task,true);const before=snapshot();if(before.modules>0){if(matches(before,urls)){intent.stage='complete';save(task,intent);return applied(task,urls,before,{importClicks:intent.clicks});}return failure('detail_became_nonempty','详情已有不同内容，未覆盖或清除。');}
   mainUrls(task);const button=uniqueText('导入','button.next-btn-primary.next-dialog-btn');intent.clicks++;intent.stage='import_clicked';save(task,intent);button.click();
   const changed=await until(()=>snapshot().modules!==before.modules,attempt===0?6000:10000);
   if(changed){const verified=await until(()=>{const snap=snapshot();return matches(snap,urls)?snap:null;},5000);if(!verified)return failure('detail_import_mismatch','导入后的详情数量或图片地址不符，未继续点击。');intent.stage='complete';save(task,intent);return applied(task,urls,verified,{importClicks:intent.clicks});}
  }
  return failure('detail_import_unconfirmed','有界导入未产生已核对模块，保留原意图，仅允许回查。');
 }catch(error){return failure('detail_adapter_error',error.message||'详情适配未完成。');}}
 root.FullStudioDetail={execute};
})(globalThis);
