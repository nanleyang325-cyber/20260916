(function(root){
 'use strict';
 const Q=root.MaterialFeaturedQuality||(typeof require==='function'?require('./featured-quality.js'):null);
 const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 function create(io){
  const hash=value=>io.hash(JSON.stringify(value));
  async function save(run,message){run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail:message});await io.save(run);}
  function product(run,item){if(item.productIds?.length!==1)throw Error('审图需要唯一商品');run.featuredReviews||={};return run.featuredReviews[item.productIds[0]]||= {productId:item.productIds[0],calls:0,groups:{}};}
  async function audit(run,item,state,kind,inputs,context){
   const pid=item.productIds[0],p=product(run,item),signature=await hash({pid,kind,inputs:inputs.map(i=>[i.label,i.role,i.sha256]),context});
   if(state.signature&&state.signature!==signature)throw Error('审图范围或图片已变化，保留原回执，不重审或放行。');
   if(!state.id){
    if(run.draining||!await io.live(run))throw Error('已停止新增审图。');
    if(p.calls>=Q.limit(run))throw Error('本商品审图次数已达到确认上限。');
    Object.assign(state,{id:io.uuid(),signature,kind,status:'registered',at:new Date().toISOString(),inputs:inputs.map(({label,role,sha256,id})=>({label,role,sha256,id}))});p.calls++;
    run.reviewCalls=(run.reviewCalls||0)+1;run.usedCallsByType||={image:0,video:0,text:0};run.usedCallsByType.review=(run.usedCallsByType.review||0)+1;
    await save(run,'已登记唯一'+(kind==='reference'?'参考图':'成图')+'审查编号；不自动重试或重新生图。');
    if(!await io.live(run)||run.draining)throw Error('已停止，审图登记保留；未发送新的审图。');
    await io.submit({id:state.id,module:'featured-review',media:'text',model:Q.MODEL,productIds:[pid],auditKind:kind,auditSignature:signature,maxOutputTokens:Q.MAX_OUTPUT,reviewInputs:inputs.map(({label,role,sha256,data})=>({label,role,sha256,data})),prompt:Q.prompt(kind,pid,signature,context),consent:true});
    return false;
   }
   if(state.status==='passed')return true;
   if(state.status==='blocked')throw Error('自动审图未通过：'+(state.reason||'无法确认图片质量')+'；保留全部原图，不上传发布。');
   const result=await io.query(state.id);
   if(result.id!==state.id||!same(result.productIds,[pid]))throw Error('原审图编号或商品回查不符。');
   if(result.status==='completed'){
    if(result.review?.signature!==signature||result.review?.productId!==pid||result.review?.kind!==kind)throw Error('审图回执不匹配，未放行。');
    state.review=result.review;state.usage=result.reviewUsage||null;state.status=result.review.pass===true?'passed':'blocked';
    state.reason=[...(result.review.issues||[]),...(result.review.images||[]).flatMap(i=>i.issues||[])].join('；').slice(0,1200)||'存在未通过或无法确认的检查项';
    await save(run,state.status==='passed'?'自动审图通过（模型意见，不等于平台精选）；继续原任务。':'自动审图未通过；原素材保留，未上传发布。');
    if(state.status==='blocked')throw Error('自动审图未通过：'+state.reason);
    return true;
   }
   if(['failed','rejected','submission_unconfirmed','missing'].includes(result.status))throw Error('原审图结果未确认（'+result.status+'）；保留编号，不重复付费。');
   return false;
  }
  async function reference(run,item){
   if(!Q.active(run))return true;const p=product(run,item);
   if(p.sourceURL&&p.sourceURL!==item.mainImage)throw Error('本商品参考图已变化，未沿用旧审图。');
   if(!p.snapshot){const snapshot=await io.capture(run,item);if(!snapshot.references?.length)throw Error('参考图缺失');p.sourceURL=item.mainImage;p.snapshot='featured:'+run.id+':'+p.productId;await io.put(p.snapshot,snapshot);p.coverage=snapshot.coverage;await save(run,'已保存本商品参考与可读取历史图片，审图仅覆盖记录范围。');}
   const snapshot=await io.get(p.snapshot);if(!snapshot)throw Error('原审图图片快照缺失，未重新采集或付费。');
   p.reference||={};const context={title:item.title||'',facts:run.selection.facts||''};
   const ok=await audit(run,item,p.reference,'reference',snapshot.references.map((i,n)=>({...i,label:'R'+n,role:'reference'})),context);
   if(ok){item.reviewedReference={signature:p.reference.signature,visibleFacts:p.reference.review.visibleFacts,supportedActions:p.reference.review.supportedActions};}
   return ok;
  }
  async function references(run,item){
   const p=product(run,item);if(p.reference?.status!=='passed'||p.sourceURL!==item.mainImage)throw Error('参考审图未通过，禁止生图。');
   const s=await io.get(p.snapshot);if(!s)throw Error('参考快照缺失');
   return p.reference.review.selectedReferences.map(label=>s.references[Number(label.slice(1))]?.original).map(data=>{if(!data)throw Error('已审核参考图缺失');return data;});
  }
  async function images(run,item){
   if(!Q.active(run))return true;const p=product(run,item);if(p.reference?.status!=='passed')throw Error('参考审查未通过');
   const candidates=await io.candidates(run,item),copy=io.copy(run,item);if(candidates.length!==3)throw Error('成图审查须为三张原图');
   const state=p.groups[item.id]||= {},snapshot=await io.get(p.snapshot);if(!snapshot)throw Error('原审图快照缺失');
   for(const image of candidates){const errors=Q.technical(image,item.generations.find(g=>g.id===image.id)?.ratio);if(errors.length)throw Error(errors.join('；')+'；原图保留，未上传。');}
   let reviewSet;
   if(!state.comparisonKey){
    const local=await io.otherImages(run,item),others=[...snapshot.references,...snapshot.history,...local.filter(o=>!candidates.some(c=>c.id===o.id))];
    const matches=candidates.map(c=>({id:c.id,matches:Q.compare(c,[...others,...candidates.filter(x=>x.id!==c.id)]).slice(0,8)}));
    state.localComparison={at:new Date().toISOString(),compared:others.length,checks:matches};
    if(matches.some(c=>c.matches.some(m=>m.exact))) {state.localComparison.blocked=true;await save(run,'检测到字节完全相同的重复图，保留原图；未审图、上传或发布。');throw Error('与参考、历史素材或本批其他图片完全相同，未发布。');}
    const scored=others.map(o=>({o,d:Math.min(...candidates.map(c=>Q.distance(c.fingerprint,o.fingerprint).hamming))})).sort((a,b)=>a.d-b.d);
    const selected=p.reference.review.selectedReferences.map(l=>({...snapshot.references[Number(l.slice(1))],label:l,role:'reference'}));
    const historical=[...new Map(scored.map(({o})=>[o.sha256,o])).values()].filter(o=>!selected.some(r=>r.sha256===o.sha256)).slice(0,6);
    reviewSet=[...selected,...candidates.map((c,n)=>({...c,label:'C'+n,role:'candidate'})),...historical.map((h,n)=>({...h,label:'H'+n,role:'history'}))];
    reviewSet=reviewSet.map(({original,...image})=>image);
    state.comparisonKey='featured-group:'+run.id+':'+item.id;await io.put(state.comparisonKey,reviewSet);await save(run,'本地重复检查完成；语义相似与结构检查交给视觉模型。');
   }else reviewSet=await io.get(state.comparisonKey);
   if(!reviewSet)throw Error('原成图对比快照缺失，未重审。');
   if(!same(reviewSet.filter(i=>i.role==='candidate').map(i=>[i.id,i.sha256]),candidates.map(i=>[i.id,i.sha256])))throw Error('成图已经变化，旧审图不可放行。');
   const context={title:copy.title,body:copy.body,referenceSignature:p.reference.signature,candidates:reviewSet.filter(i=>i.role==='candidate').map(({label,sha256})=>({label,sha256}))};
   return audit(run,item,state,'images',reviewSet,context);
  }
  async function guard(run,item){
   if(!Q.active(run))return;
   const p=product(run,item),state=p.groups[item.id];if(state?.status!=='passed'||p.reference?.status!=='passed')throw Error('图片尚未通过自动审查，不能上传或发布。');
   const candidates=await io.candidates(run,item),copy=io.copy(run,item),inputs=await io.get(state.comparisonKey);
   if(!inputs||!same(inputs.filter(i=>i.role==='candidate').map(i=>[i.id,i.sha256]),candidates.map(i=>[i.id,i.sha256])))throw Error('成图指纹已变化，不能沿用旧审图。');
   const context={title:copy.title,body:copy.body,referenceSignature:p.reference.signature,candidates:inputs.filter(i=>i.role==='candidate').map(({label,sha256})=>({label,sha256}))};
   const signature=await hash({pid:p.productId,kind:'images',inputs:inputs.map(i=>[i.label,i.role,i.sha256]),context});if(signature!==state.signature||state.review?.signature!==signature)throw Error('图片或文案与审核记录不一致，未发布。');
   if(item.prepared?.uploadedAssets?.length&&(!same(item.prepared.uploadedAssets.map(a=>a.sourceAssetId),candidates.map(c=>c.id))||item.prepared.title!==copy.title||item.prepared.body!==copy.body))throw Error('待发布图片来源或文案与审图范围不符。');
  }
  return {reference,references,images,guard};
 }
 root.MaterialFeaturedWorkflow={create};if(typeof module==='object')module.exports=root.MaterialFeaturedWorkflow;
})(globalThis);
