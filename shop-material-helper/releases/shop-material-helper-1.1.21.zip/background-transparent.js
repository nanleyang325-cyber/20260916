'use strict';
async function transparentHost(route='',data){
 const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/transparent")+route,{method:data?'POST':'GET',headers:{'Content-Type':'application/json','X-Material-Client':'full-v1'},...(data?{body:JSON.stringify(data)}:{}),signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw Error('原透明图任务未确认，请保留原编号检查主机。');return response.json();
}
function transparentPageURL(value){try{const u=new URL(value);return u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname==='/home.htm/material-center/material-management'&&!u.searchParams.get('tab');}catch{return false;}}
async function transparentClaimTab(run){const tabs=await chrome.tabs.query({active:true,currentWindow:true});if(tabs.length!==1||!transparentPageURL(tabs[0].url))throw Error('请先切回素材中心基础素材页，再启动透明图。');run.tabId=tabs[0].id;run.windowId=tabs[0].windowId;return tabs[0];}
async function transparentWorkTab(run){let tab;try{tab=await chrome.tabs.get(run.tabId);}catch{throw Error('原透明图工作标签页已关闭；未接管其他页面。');}if(tab.windowId!==run.windowId||!transparentPageURL(tab.url))throw Error('原透明图工作页已变化，未导航或操作其他页面。');if(tab.status!=='complete')throw Error('原素材页面尚未加载完成。');return tab;}
async function transparentScene(run,job,action,fileName,tab){
 const signal=AbortSignal.timeout(30000),expired=()=>Object.assign(Error('透明图工作页调用超时；原素材和进度已保留，请回到原素材页后继续。'),{code:'TRANSPARENT_PAGE_TIMEOUT'});
 const result=await new Promise((resolve,reject)=>{const timeout=()=>reject(expired());signal.addEventListener('abort',timeout,{once:true});(async()=>{
 const target=tab||await transparentWorkTab(run);if(signal.aborted)throw expired();await chrome.scripting.executeScript({target:{tabId:target.id,frameIds:[0]},world:'MAIN',files:['scene.js']});
 // A late injection must not start an operation after the caller has timed out.
 if(signal.aborted)throw expired();
 const[{result}]=await chrome.scripting.executeScript({target:{tabId:target.id,frameIds:[0]},world:'MAIN',func:async(job,action,fileName)=>{try{return action==='transparentPage'?{ok:true,page:await FullScene.transparentPage(job.page)}:await FullScene.request(job,action,fileName);}catch(e){return {ok:false,error:e.message,code:e.code||null,saveNotAttempted:e.saveNotAttempted===true};}},args:[job,action,fileName||'']});
 return result;
 })().then(value=>{signal.removeEventListener('abort',timeout);resolve(value);},error=>{signal.removeEventListener('abort',timeout);reject(error);});});
 if(!result?.ok)throw Object.assign(Error(result?.error||'透明图平台读取未确认。'),{code:result?.code,saveNotAttempted:result?.saveNotAttempted===true});return result;
}
async function transparentInspect(run,pid){return(await transparentScene(run,{module:'transparent',productIds:[pid]},'readTransparent')).scene;}
async function transparentDiscover(run){
 const ids=FullButtonContracts.parseIds(run.selection.ids);if(ids.length){const targets=[];for(const pid of ids){if(!await flowLive(run))throw Error('透明图扫描已暂停。');targets.push({productIds:[pid],discovered:await transparentInspect(run,pid)});}run.transparentScanSummary={requested:ids.length,complete:true,source:'official-transparent-fields'};await flowSave(run);return targets;}
 let page=1,total=null;const targets=await FullWhiteScan.collect(run,{label:'待处理透明图',pendingText:'尚未开始抠图或上传。',isLive:flowLive,prepare:async()=>{page=1;},restore:async n=>{page=n;},page:async()=>{const p=(await transparentScene(run,{page},'transparentPage')).page;if(total===null)total=p.total;else if(total!==p.total)throw Error('透明图扫描期间商品总数变化，未将部分结果当全量。');return {page:{number:p.number,totalPages:p.totalPages,hasNext:p.number<p.totalPages,signature:p.scenes.map(s=>[s.productId,s.materialId,s.review.code,s.review.auditTime,s.whiteSource.materialId].join(':')).join('|')||'empty-confirmed',emptyConfirmed:p.total===0},targets:p.scenes.filter(s=>run.selection.reviewRejected?s.review.code==='4'&&s.review.name==='审核不通过':!s.url&&!s.materialId).map(s=>({productIds:[s.productId],discovered:s}))};},next:async()=>({number:++page}),save:flowSave});
 run.transparentScanSummary={total,targets:targets.length,complete:true,source:'official-transparent-fields'};await flowSave(run);return targets;
}
async function transparentClaimed(run,s){return(await flowRuns()).some(r=>r.id!==run.id&&r.module==='transparent'&&r.selection.reviewRejected&&r.items?.some(i=>FullTransparentRun.targetKey(i.original)===FullTransparentRun.targetKey(s)&&i.publication));}
async function transparentReuse(run,item){
 const runs=await flowRuns();for(const prior of runs.slice().reverse())for(const old of(prior.items||[]).slice().reverse())if(prior.module==='transparent'&&old.cutout?.status==='completed'&&old.cutout.available===true&&FullTransparentRun.sourceKey(old.original)===FullTransparentRun.sourceKey(item.original)){const current=await transparentHost('/'+old.cutout.id);if(current.status==='completed'&&current.available===true&&current.productIds?.join()===item.productIds.join()&&current.sourceUrl===item.original.whiteSource.url&&current.sourceMaterialId===item.original.whiteSource.materialId)return {...old.cutout,...current,reusedFrom:{runId:prior.id,itemId:old.id}};}return null;
}
async function transparentDerive(run,item){if(!await flowLive(run))return;const s=item.original.whiteSource;return transparentHost('',{id:item.cutout.id,productIds:item.productIds,sourceMaterialId:s.materialId,sourceUrl:s.url,consent:true});}
async function transparentAttach(run,item){
 FullTransparentRun.guard(run,'upload');if(item.uploaded)return;
 const name='tp-'+item.cutout.id+'.png',job={id:item.id,module:'transparent',productIds:item.productIds},space=await autoOpen(FullCore.URLS.space);item.returnUploadTabId=space.id;item.returnUploadURL=space.url;let found;
 try{found=await transparentScene(run,job,'lookup',name,space);}catch(e){if(e.code!=='PICTURE_NOT_FOUND')throw e;}
 if(!found){
  if(item.uploadIntents?.[name])throw Error('原透明 PNG 已有上传意图但尚未回查，禁止重复上传。');
  const file=await transparentHost('/'+item.cutout.id+'/data');if(file.name!==name||file.sha256!==item.cutout.output.sha256||file.productIds?.join()!==item.productIds.join()||file.sourceMaterialId!==item.original.whiteSource.materialId||file.sourceSha256!==item.cutout.sourceSha256||file.width!==800||file.height!==800||file.format!=='png'||!file.data?.startsWith('data:image/png;base64,'))throw Error('原透明 PNG 身份、来源或校验不符，未上传。');
  await chrome.tabs.update(space.id,{active:true});const inspected=await queuePlatform(space.id,job,'inspect');if(!inspected.ok)throw Error(inspected.error);if(!inspected.fileInputs){const opened=await queuePlatform(space.id,job,'open-upload');if(!opened.ok)throw Error(opened.error);}
  item.uploadIntents||={};item.uploadIntents[name]={at:new Date().toISOString(),assetId:item.cutout.id,sha256:file.sha256,productIds:[...item.productIds]};await flowSave(run);if(!await flowLive(run))return;
  const sent=await queuePlatform(space.id,job,'upload',[file]);if(!sent.ok)throw Error(sent.error);
  for(let n=0;n<20;n++){if(!await flowLive(run))return;await queueDelay(1000);try{found=await transparentScene(run,job,'lookup',name,space);break;}catch(e){if(e.code!=='PICTURE_NOT_FOUND')throw e;}}
 }
 if(!found?.sceneUpload)throw Error('原透明 PNG 上传结果尚未确认。');item.uploaded=found.sceneUpload;await flowSave(run);
}
function transparentJob(run,item){return {id:item.id,module:'transparent',productIds:item.productIds,sceneUpload:item.uploaded,transparentOriginal:item.original,transparentSaveResult:item.submitResult,publicationConsent:true,publication:item.publication,replaceExisting:run.selection.reviewRejected===true};}
async function transparentPublish(run,item){const space=await autoOpen(FullCore.URLS.space);return transparentScene(run,transparentJob(run,item),'bind',item.uploaded.name,space);}
async function transparentReadback(run,item){
 const result=await transparentScene(run,transparentJob(run,item),'verify');if(!FullFlowRun.validReceipt(item,result))return result;
 if(item.original.materialId&&result.receipt.contentId===item.original.materialId)return {status:'submitted_unconfirmed',message:'透明图仍为原失败素材编号，未确认替换。'};
 const file=await fetchReference({url:result.receipt.imageUrl});if(!file.reference.startsWith('data:image/png;base64,'))return {status:'submitted_unconfirmed',message:'平台返回的透明图不是 PNG，未验收。'};
 const bytes=Uint8Array.from(atob(file.reference.split(',')[1]),c=>c.charCodeAt(0));if(bytes.length<33||bytes[0]!==137||bytes[1]!==80||bytes[2]!==78||bytes[3]!==71||bytes[24]!==8||bytes[25]!==6)return {status:'submitted_unconfirmed',message:'平台透明 PNG 通道未确认，未验收。'};
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');
 if(hash!==item.cutout.output.sha256){
  const source=await transparentHost('/'+item.cutout.id+'/data');if(source.sha256!==item.cutout.output.sha256||source.sourceSha256!==item.cutout.sourceSha256||source.sourceMaterialId!==item.original.whiteSource.materialId||source.productIds?.join()!==item.productIds.join()||!source.data?.startsWith('data:image/png;base64,'))throw Error('原透明 PNG 身份未确认，不接受平台压缩结果。');
  const original=Uint8Array.from(atob(source.data.split(',')[1]),c=>c.charCodeAt(0)),sourceHash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',original)),n=>n.toString(16).padStart(2,'0')).join('');if(sourceHash!==item.cutout.output.sha256)throw Error('原透明 PNG 字节校验不符。');
  result.receipt.pixelCheck=await FullTransparentPng.comparePng(original,bytes);result.receipt.imageSourceSha256=sourceHash;result.receipt.imageMatch='platform_png_optimized';
 }
 result.receipt.imageSha256=hash;result.receipt.alphaVerified=true;return result;
}
function transparentWorker(){return {save:async run=>{await flowSave(run);if(run.status==='done')await chrome.tabs.update(run.tabId,{active:true}).catch(()=>{});},isLive:flowLive,discover:transparentDiscover,inspect:transparentInspect,claimed:transparentClaimed,reuse:transparentReuse,derive:transparentDerive,queryCutout:(_run,item)=>transparentHost('/'+item.cutout.id),attach:transparentAttach,publish:transparentPublish,readback:transparentReadback};}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id||message.type!=='FULL_TRANSPARENT_CONTROL')return false;
 executionGate(async()=>{
  const before=(await flowRuns()).find(r=>r.id===message.runId);if(!before||before.module!=='transparent')throw Error('原透明图任务未找到。');
  if(before.cancellation&&message.action!=='stop')throw Error('该任务已取消，原素材和记录保留。');const resumes=['resume','drain'].includes(message.action)||message.action==='pause'&&(message.paused===false||message.paused===undefined&&before.status==='paused');
  if(resumes){if(await executionPaused()||(await flowRuns()).some(r=>r.enabled&&r.id!==before.id)||typeof autoRuns==='function'&&(await autoRuns()).some(r=>r.enabled)||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled)||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||typeof studioBatchConflict==='function'&&await studioBatchConflict()||(await queueState())?.backgroundQueues?.some(q=>q.enabled))throw Error('其他任务或全局暂停仍在生效。');if(!FullFlowRun.matchesConsent(before))throw Error('透明图原执行范围已变化。');}
  await FullStateStore.update(FLOW_KEY,runs=>{const run=runs?.find(r=>r.id===message.runId);if(!run)throw Error('原透明图任务已变化。');FullTransparentRun.change(run,message.action,message.paused);return runs;});
  const run=(await flowRuns()).find(r=>r.id===message.runId);if(run.enabled)await chrome.alarms.create('full-flow:'+run.id,{when:Date.now()+100,periodInMinutes:.5});else await chrome.alarms.clear('full-flow:'+run.id);reply({ok:true});if(run.enabled)flowTick(run.id).catch(()=>{});
 }).catch(e=>reply({ok:false,error:e.message}));return true;
});
