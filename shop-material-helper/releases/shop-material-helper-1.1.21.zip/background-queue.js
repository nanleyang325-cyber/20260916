'use strict';
importScripts('workflows.js','automation.js','queue.js');
const QUEUE_KEY='full-helper-v1',queueJobs=new Map();let queueBusy=false;
let executionRegistration=Promise.resolve();
async function executionGate(action){const previous=executionRegistration;let release;executionRegistration=new Promise(resolve=>release=resolve);await previous;try{return await action();}finally{release();}}
async function executionPaused(includeDrain=true){const state=(await chrome.storage.local.get('material-global-control-v1'))['material-global-control-v1'];return state?.paused===true||includeDrain&&state?.draining===true;}
async function additionalExecutionActive(){return typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||await executionPaused()||typeof flowRuns==='function'&&(await flowRuns()).some(run=>run.enabled)||typeof multiRuns==='function'&&(await multiRuns()).some(run=>run.enabled)||typeof studioBatchConflict==='function'&&await studioBatchConflict();}
const queueDelay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function queueState(){return (await chrome.storage.local.get(QUEUE_KEY))[QUEUE_KEY];}
async function updateQueuedJob(job){await FullStateStore.update(QUEUE_KEY,state=>{const index=state?.jobs.findIndex(j=>j.id===job.id);if(index==null||index<0)throw new Error('队列任务已移除。');Object.assign(job,FullStateStore.mergeJob(state.jobs[index],job));state.jobs[index]=job;return state;});}
async function updateQueue(queue){await FullStateStore.update(QUEUE_KEY,state=>{state.backgroundQueues||=[];const index=state.backgroundQueues.findIndex(q=>q.id===queue.id);if(index<0)state.backgroundQueues.push(queue);else{if(state.backgroundQueues[index].enabled===false)queue.enabled=false;globalThis.FullTaskFailures?.save(queue,'queue',state.backgroundQueues[index]);state.backgroundQueues[index]=queue;}return state;});}
async function queueScene(tabId,job,action,fileName){
 await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',files:['scene.js']});
 const [{result}]=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',func:async(job,action,fileName)=>{try{return await FullScene.request(job,action,fileName);}catch(error){return {ok:false,code:['PICTURE_NOT_FOUND','LOOKUP_COMPONENT_UNAVAILABLE','PLATFORM_LOGIN_UNAVAILABLE','PICTURE_RECORD_CONFLICT'].includes(error.code)?error.code:'SCENE_OPERATION_UNCONFIRMED',error:'后台素材操作未确认，请检查登录、文件和商品身份。'};}},args:[job,action,fileName||'']});return result;
}
async function queuePlatform(tabId,job,action,assets=[]){
 await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},files:['platform.js']});
 const [{result}]=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},func:async(job,action,assets)=>{try{return {ok:true,...await FullPlatform.execute(action,job,assets)};}catch(error){return {ok:false,error:error.message,executed:false};}},args:[job,action,assets]});return result;
}
async function runQueuedJob(job){
 job.backgroundQueueLocked=true;job.stopRequested=false;queueJobs.set(job.id,job);await updateQueuedJob(job);let tabId;
 const open=async()=>{const existing=(await chrome.tabs.query({url:FullCore.URLS.space})).at(-1);const tab=existing||await chrome.tabs.create({url:FullCore.URLS.space,active:false});tabId=tab.id;await queueDelay(2000);};
 const scene=(action,name)=>queueScene(tabId,job,action,name);
 try{return await FullAutomation.run(job,{
  save:updateQueuedJob,verify:FullCore.verifyReceipt,delay:queueDelay,openSpace:open,
  lookup:async(_job,name)=>{for(let n=0;n<6;n++){const result=await scene('lookup',name);if(result.code!=='LOOKUP_COMPONENT_UNAVAILABLE')return result;await queueDelay(1000);}return {ok:false,code:'LOOKUP_COMPONENT_UNAVAILABLE',error:'图片空间未就绪，请完成登录。'};},
  asset:async(id,isScene)=>{const response=await fetch(`${chrome.runtime.getURL("local-api")}/api/media/${id}/${isScene?'data-scene':'data'}`,{signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('原素材下载验证未就绪。');return response.json();},
  openUpload:()=>queuePlatform(tabId,job,'open-upload'),upload:(_job,assets)=>queuePlatform(tabId,job,'upload',assets),
  readSlot:()=>scene('read'),bind:(_job,name)=>scene('bind',name),readback:async()=>{await open();return scene('verify');}
 });}finally{job.backgroundQueueLocked=false;queueJobs.delete(job.id);await updateQueuedJob(job);}
}
async function queueTick(id){
 if(queueBusy)return;queueBusy=true;let queue;
 try{const state=await queueState();queue=state?.backgroundQueues?.find(q=>q.id===id);if(!queue?.enabled||queue.done||Date.now()<queue.runAt)return;await FullQueue.run(queue,{job:async id=>(await queueState()).jobs.find(j=>j.id===id),run:runQueuedJob,save:updateQueue});}finally{queueBusy=false;if(queue&&!queue.enabled)await chrome.alarms.clear('full-run:'+id);}
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id)return false;
 if(message.type==='FULL_QUEUE_START'){
  executionGate(async()=>{
   if(queueBusy||await additionalExecutionActive())throw new Error('已有后台队列或多任务运行中。');if(typeof autoRuns==='function'&&(await autoRuns()).some(run=>run.enabled))throw new Error('已有自动补图运行，请先停止。');
   if(!Array.isArray(message.jobIds)||!message.jobIds.length||new Set(message.jobIds).size!==message.jobIds.length)throw new Error('请选择不重复的任务。');
   let queue;await FullStateStore.update(QUEUE_KEY,state=>{if(!state)throw new Error('任务记录不存在。');if(state.backgroundQueues?.some(q=>q.enabled))throw new Error('已有待执行队列，请先停止。');
   const entries=message.jobIds.map(id=>{const job=state.jobs.find(j=>j.id===id);if(!job)throw new Error('任务不存在。');FullAutomation.approve(job);return {id,scope:FullAutomation.scope(job)};});
   const runAt=message.runAt||Date.now()+1000;if(!Number.isFinite(runAt)||runAt<Date.now()-1000)throw new Error('运行时间无效。');
   queue={id:crypto.randomUUID(),jobs:entries,position:0,phase:'ready',enabled:true,done:false,runAt,createdAt:new Date().toISOString()};state.backgroundQueues||=[];state.backgroundQueues.push(queue);return state;});
   await chrome.alarms.create('full-run:'+queue.id,{when:queue.runAt,periodInMinutes:0.5});reply({ok:true,queueId:queue.id});
  }).catch(error=>reply({ok:false,error:error.message}));return true;
 }
 if(message.type==='FULL_QUEUE_STOP'){
  (async()=>{for(const job of queueJobs.values())job.stopRequested=true;const names=[];await FullStateStore.update(QUEUE_KEY,state=>{if(!state)return;for(const queue of state.backgroundQueues||[]){queue.enabled=false;names.push('full-run:'+queue.id);}for(const job of state.jobs||[])if(job.backgroundQueueLocked)job.stopRequested=true;return state;});for(const name of names)await chrome.alarms.clear(name);reply({ok:true});})().catch(()=>reply({ok:false,error:'停止请求未确认，请检查队列。'}));return true;
 }
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name.startsWith('full-run:'))queueTick(alarm.name.slice(9)).catch(()=>{});});
