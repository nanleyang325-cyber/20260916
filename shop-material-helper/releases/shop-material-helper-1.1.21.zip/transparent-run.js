(function(root){
 'use strict';
 const physical=s=>!!s?.title&&s.saleState==='on_sale'&&!/售后.*链接|换货专拍|补差.*链接|运费.*专拍|单.?拍.?不.?发.?货/.test(s.title);
 const sourceKey=s=>[s?.productId,s?.whiteSource?.materialId,s?.whiteSource?.url].join('|');
 const targetKey=s=>[s?.productId,s?.materialId||'',s?.url||'',s?.review?.auditTime||''].join('|');
 function eligible(s,rejected=false){
  if(!s||s.saleState==='not_found'||!/^\d{6,}$/.test(s.productId||''))return {eligible:false,reason:'not_found',message:'指定商品未唯一命中，不扩大到其他商品。'};
  if(s.supported===false)return {eligible:false,reason:'unsupported',message:'平台未提供该商品的透明图字段，跳过，不当作空槽。'};
  if(s.saleState!=='on_sale')return {eligible:false,reason:s.saleState==='off_sale'?'off_sale':'sale_unknown',message:s.saleState==='off_sale'?'商品非在售，跳过透明图。':'商品在售状态未确认，跳过透明图。'};
  if(!physical(s))return {eligible:false,reason:'non_physical',message:'非实物售后或补差链接，不适用透明图。'};
  if(!s.whiteSource?.materialId||!s.whiteSource?.url)return {eligible:false,reason:'white_missing',message:'缺少该商品已有白底图，跳过；透明图不会触发重新生图。'};
  if(s.whiteSource.review?.code==='4')return {eligible:false,reason:'white_rejected',message:'来源白底图审核不通过，先修正白底图，不沿用不合格来源。'};
  if(rejected){if(!s.url||!s.materialId||s.review?.code!=='4'||s.review?.name!=='审核不通过')return {eligible:false,reason:'not_rejected',message:'透明图并非明确审核不通过；待审核和已通过均不覆盖。'};}
  else if(s.url||s.materialId)return {eligible:false,reason:'occupied',message:'已有透明图，普通补缺跳过；审核不通过请选重做入口。'};
  return {eligible:true};
 }
 function same(a,b,rejected){return eligible(b,rejected).eligible&&sourceKey(a)===sourceKey(b)&&targetKey(a)===targetKey(b)&&a?.templateId===b?.templateId;}
 function selection(input={}){return {...structuredClone(input),source:'existing_white',mode:input.mode==='custom'?'ids':input.mode,palette:'no',count:1,ratio:'1:1',maxCalls:0,reviewRejected:input.reviewRejected===true,executionBoundary:{paidGeneration:false,storeWrite:input.executionBoundary?.storeWrite===true}};}
 function create(input){return root.FullFlowRun.create('transparent',selection(input));}
 function guard(run,action){if(run.selection?.executionBoundary?.paidGeneration!==false)throw Error('透明图不允许付费生图。');if(['upload','publish'].includes(action)&&run.selection?.executionBoundary?.storeWrite!==true)throw Object.assign(Error('本轮禁止店铺写入，已停在透明图'+(action==='upload'?'上传':'回填')+'之前。'),{boundaryBlocked:true,action});}
 function revision(run){return Number.isSafeInteger(run?.transparentControlRevision)?run.transparentControlRevision:0;}
 function mergeControl(run,canonical){if(!canonical)return run;const copy=k=>{if(Object.prototype.hasOwnProperty.call(canonical,k))run[k]=structuredClone(canonical[k]);else delete run[k];};if(revision(canonical)>revision(run)){for(const k of ['enabled','status','draining','transparentPause','error'])copy(k);run.transparentControlRevision=revision(canonical);}else if(revision(canonical)===revision(run)){if(canonical.enabled===false)for(const k of ['enabled','status','error'])copy(k);if(canonical.draining)run.draining=true;}return run;}
 function change(run,action,paused){
  if(run.module!=='transparent'||run.status==='done')throw Error('透明图原任务不存在或已结束。');
  if(action==='pause'){const value=typeof paused==='boolean'?paused:run.status!=='paused';if(value){if(!run.enabled&&run.status!=='paused')throw Error('该透明图任务未在运行。');run.transparentPause={draining:!!run.draining};run.enabled=false;run.status='paused';}else{if(run.status!=='paused')return run;run.enabled=true;run.draining=!!run.transparentPause?.draining;run.status=run.draining?'draining':'running';delete run.transparentPause;}}
  else if(action==='stop'){run.enabled=false;run.status='stopped';delete run.transparentPause;}
  else if(action==='drain'){run.enabled=true;run.draining=true;run.status='draining';delete run.transparentPause;}
  else if(action==='resume'){run.enabled=true;run.draining=false;run.status='running';run.error='';delete run.transparentPause;}
  else throw Error('未知透明图控制。');run.transparentControlRevision=revision(run)+1;return run;
 }
 async function advance(run,io){
  if(!run.enabled)return;
  const save=async detail=>{run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail});await io.save(run);};
  const live=async()=>run.enabled&&(!io.isLive||await io.isLive(run));
  const next=async(status,detail)=>{const item=run.items[run.position];item.status=status;item.phase='done';item.detail=detail;run.position++;await save(detail);};
  const check=async item=>{const current=await io.inspect(run,item.productIds[0]);if(!same(item.original,current,run.selection.reviewRejected))throw Error('透明图目标或来源白底图已变化，保留现有 PNG，不自动覆盖。');return current;};
  try{
   if(!await live())return;if(!root.FullFlowRun.matchesConsent(run))throw Error('透明图执行范围已变化。');guard(run,'read');
   if(run.phase==='discover'){
    if(run.draining){run.enabled=false;run.status='drained';await save('透明图已收尾停止，未启动新商品。');return;}
    const targets=await io.discover(run);if(!await live())return;const requested=root.FullButtonContracts.parseIds(run.selection.ids),seen=new Set();if(!Array.isArray(targets)||targets.some(t=>t.productIds?.length!==1||!/^\d{6,}$/.test(t.productIds[0])||requested.length&&!requested.includes(t.productIds[0])))throw Error('透明图发现结果超出原商品范围。');
    run.items=targets.filter(t=>{if(seen.has(t.productIds[0]))return false;seen.add(t.productIds[0]);return true;}).map(t=>({...t,id:crypto.randomUUID(),phase:'prepare',status:'pending'}));run.phase='items';await save('透明图商品集合已保存；使用已有白底图，不创建付费生成任务。');return;
   }
   const item=run.items[run.position];if(!item){run.enabled=false;run.status='done';await save('透明图本轮结束；上传回填与平台审核分开记录，无新增生图调用。');return;}
   if(run.draining&&item.phase==='prepare'){run.enabled=false;run.status='drained';await save('已收尾停止，不开始下一商品的抠图或上传。');return;}
   if(item.phase==='prepare'){
    const current=await io.inspect(run,item.productIds[0]);if(!await live())return;const decision=eligible(current,run.selection.reviewRejected);item.eligibility={at:new Date().toISOString(),reason:decision.reason||'eligible'};if(!decision.eligible)return next('skipped',decision.message);
    if(run.selection.reviewRejected&&await io.claimed?.(run,current))return next('skipped','同一失败透明素材已有处理意图，请回查原任务。');
    item.original=current;item.title=current.title;const reused=await io.reuse?.(run,item);item.cutout=reused||{id:crypto.randomUUID(),status:'planned'};item.phase='cutout';await save(reused?'复用该商品同一白底图已完成的透明 PNG 原编号。':'已核对来源白底图、透明槽位和在售状态；保存唯一抠图编号。');return;
   }
   if(item.phase==='cutout'){
    await check(item);if(!await live())return;
    if(!item.cutout.intent){item.cutout.intent={at:new Date().toISOString(),productIds:[...item.productIds],sourceMaterialId:item.original.whiteSource.materialId};item.cutout.status='pending';await save('持久登记本地抠图意图；不调用 GrsAI，不改变原白底图。');if(!await live())return;await io.derive(run,item);return;}
    const result=await io.queryCutout(run,item);if(!await live())return;if(result.id!==item.cutout.id||result.productIds?.join()!==item.productIds.join()||result.sourceMaterialId!==item.original.whiteSource.materialId||result.sourceUrl!==item.original.whiteSource.url)throw Error('透明 PNG 原编号或来源商品不符。');
    if(result.status==='failed')return next('failed','本地抠图未通过检查：'+String(result.error||'未知结果')+'；不上传、不重新生图。');
    if(result.status!=='completed'||result.available!==true){await save('只查询原抠图任务，尚未上传。');return;}
    if(result.output?.width!==800||result.output?.height!==800||result.output?.format!=='png'||!/^[a-f0-9]{64}$/i.test(result.output?.sha256||''))throw Error('透明 PNG 尺寸、格式或校验值未确认。');
    item.cutout={...item.cutout,...result};item.phase='attach';await save('透明 PNG 已验证为800×800，具有真实透明通道，保留内部白色商品。');return;
   }
   if(item.phase==='attach'){await check(item);if(!await live())return;guard(run,'upload');await io.attach(run,item);if(!await live())return;item.phase='publish';await save('已按唯一 PNG 文件名上传并回查；尚未替换商品槽位。');return;}
   if(item.phase==='publish'){
    if(item.publication&&item.publishPreparationFailure?.publicationId!==item.publication.id){item.phase='readback';await save('已有透明图提交意图，仅回查，不再次提交。');return;}
    await check(item);if(!await live())return;guard(run,'publish');if(!item.publication)item.publication={id:crypto.randomUUID(),at:new Date().toISOString(),productIds:[...item.productIds]};delete item.publishPreparationFailure;item.phase='readback';await save('持久登记透明图单次回填意图。');if(!await live())return;item.submitResult=await io.publish(run,item);await save('透明图回填动作已返回，等待独立读取商品素材及 PNG 字节。');return;
   }
   if(item.phase==='readback'){
    const result=await io.readback(run,item);if(!await live())return;
    if(root.FullFlowRun.validReceipt(item,result)&&(result.receipt.imageSha256===item.cutout.output.sha256||root.FullTransparentPng?.matchesReceipt(result.receipt,item.cutout.output.sha256))){item.receipt=result.receipt;item.reviewOutcome=result.review||null;return next('verified','透明图已回填并核对商品、素材编号和 PNG；当前审核：'+(result.review?.name||'待平台确认')+'。');}
    item.readbackAttempts=(item.readbackAttempts||0)+1;if(item.readbackAttempts<3){await save('透明图提交后尚未唯一回查，只读取原结果，不重交。');return;}
    throw Error(result?.message||'透明图回填结果未确认，继续原任务只回查，不再次提交。');
   }
   throw Error('未知透明图执行阶段。');
  }catch(e){run.enabled=false;run.status=e.boundaryBlocked?'boundary_blocked':'pending_review';run.error=e.message;const item=run.items[run.position];if(item){if(e.code==='PICTURE_QUERY_TIMEOUT'&&e.saveNotAttempted===true&&item.publication&&!item.submitResult&&item.phase==='readback'){item.publishPreparationFailure={at:new Date().toISOString(),publicationId:item.publication.id,saveNotAttempted:true,code:e.code};item.phase='publish';}item.status=item.publication&&!item.publishPreparationFailure?'submitted_unconfirmed':'blocked';item.detail=e.message;}await save('透明图暂停：'+e.message);}
 }
 function snapshot(run){
  if(run?.module!=='transparent')return null;const rows=(run.items||[]).map(item=>{const phase=item.status==='verified'?'done':item.status==='failed'?'failed':item.status==='skipped'?'skip':['blocked','submitted_unconfirmed'].includes(item.status)?'unknown':item.publication||Object.keys(item.uploadIntents||{}).length?'filling':item.cutout?.available?'generated':item.cutout?.intent?'generating':'wait';return {pid:item.productIds[0],phase,status:phase,label:{done:'✅已回填',failed:'⛔失败',skip:'⏭跳过',unknown:'待确认',filling:'回填中',generated:'待上传',generating:'抠图中',wait:'等待'}[phase],note:root.FullWhiteJournal?.clean(item.detail||'')||item.detail||'',costText:'本地抠图 · 无生图调用',step:'透明图',downloadUrl:item.cutout?.available===true&&/^[a-f0-9-]{36}$/i.test(item.cutout.id)?(chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/transparent/")+item.cutout.id+'/file':null,executionPhase:item.phase,updatedAt:run.events?.at(-1)?.at||run.createdAt};});const counts={total:rows.length,done:0,failed:0,skip:0,unknown:0,boundary:0,wait:0,generating:0,generated:0,filling:0};for(const row of rows)counts[row.phase]++;return {id:run.id,module:'transparent',startedAt:run.createdAt,updatedAt:run.events?.at(-1)?.at||run.createdAt,status:run.status,mode:['ids','custom'].includes(run.selection.mode)?'ids':'all',source:'existing_white',discoveryComplete:run.phase!=='discover',rows,counts};
 }
 root.FullTransparentRun={physical,eligible,sourceKey,targetKey,same,selection,create,guard,mergeControl,change,advance,snapshot};if(typeof module==='object')module.exports=root.FullTransparentRun;
})(globalThis);
