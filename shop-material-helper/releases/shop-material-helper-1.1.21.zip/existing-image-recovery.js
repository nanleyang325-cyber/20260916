(function(root){
 'use strict';
 function plan(run,request){
  if(request.confirm!==true||run?.id!==request.runId||run.module!=='search'||run.enabled||run.status!=='done'||run.cancellation)throw Error('原结束任务或明确的原图恢复确认不符。');
  const ids=request.assetIds;
  if(!Array.isArray(ids)||!ids.length||new Set(ids).size!==ids.length||ids.length>27)throw Error('原图编号清单无效。');
  if(request.publishGenerated===true){
   const prior=run.generationOnlyRecovery,items=run.items,gs=items.flatMap(i=>i.generations||[]);
   if(!prior||run.existingAssetsOnly||prior.productId!==request.productId||run.usedCalls!==ids.length||prior.assetIds.length!==ids.length||prior.assetIds.some(id=>!ids.includes(id))||gs.length!==ids.length||items.some(i=>i.productIds?.join()!==request.productId||i.status!=='generated'||i.phase!=='done'||i.publication||i.receipt||i.publishIntent||i.publishAttempted||i.syncRuns?.length||Object.keys(i.uploadIntents||{}).length||i.prepared?.uploadedAssets?.length)||gs.some(g=>!ids.includes(g.id)||g.status!=='completed'||g.available!==true))throw Error('原六图生成完成范围、未发布状态或商品归属不符。');
   return {itemIds:items.map(i=>i.id),assetIds:[...ids],originalAssetIds:[...ids],productId:request.productId,usedCalls:run.usedCalls,publishGenerated:true};
  }
  const retry=!!run.existingAssetsOnly,originalIds=run.existingAssetsOnly?.originalAssetIds||run.existingAssetsOnly?.assetIds;
  if(retry&&(request.retryBeforeSubmit!==true||ids.some(id=>!originalIds?.includes(id))||run.usedCalls!==run.existingAssetsOnly.usedCalls))throw Error('再次接续须匹配原图限定范围及明确确认。');
  const items=run.items.filter(i=>i.generations?.some(g=>ids.includes(g.id)));
  if(!items.length||items.flatMap(i=>i.generations).length!==ids.length||items.some(i=>!i.failureSkipped||i.failure?.phase!=='attach'||!(i.failure.reason.includes('正文编辑器')||retry&&i.failureHistory?.some(f=>f.reason.includes('正文编辑器'))&&/原搜推标签页加载超时|图片搜索未稳定/.test(i.failure.reason))||i.publication||i.receipt||i.publishIntent||i.publishAttempted||i.syncRuns?.length||i.generations.some(g=>!ids.includes(g.id)||g.status!=='completed')))throw Error('恢复范围包含未完成、已提交或非正文卡点条目。');
  const products=[...new Set(items.flatMap(i=>i.productIds))];if(products.length!==1||products[0]!==request.productId)throw Error('原商品归属不符。');
  return {itemIds:items.map(i=>i.id),assetIds:[...ids],originalAssetIds:[...(originalIds||ids)],productId:products[0],usedCalls:run.usedCalls};
 }
 function apply(run,p){
  const at=new Date().toISOString(),attempt=(run.existingAssetsOnly?.attempt||0)+1;run.existingAssetsOnly={...p,at,attempt};
  if(p.publishGenerated){run.generatedPublicationAuthorization={at,previousConsentScope:run.consentScope,previousBoundary:structuredClone(run.selection.executionBoundary),completedGenerationRecovery:structuredClone(run.generationOnlyRecovery),assetIds:[...p.assetIds]};delete run.generationOnlyRecovery;run.selection.executionBoundary={...run.selection.executionBoundary,paidGeneration:false,storeWrite:true};run.selection.autoPublish=true;run.consentScope=root.FullFlowRun.scope(run);}
  for(const item of run.items)if(p.itemIds.includes(item.id)){item.failureHistory||=[];if(item.failure)item.failureHistory.push(structuredClone(item.failure));delete item.failure;delete item.failureSkipped;item.phase='attach';item.status='pending';item.detail='用户确认仅恢复已有原图的上传发布，不新增生成。';}
  run.position=run.items.findIndex(i=>p.itemIds.includes(i.id));run.phase='items';run.status='paused';run.enabled=false;run.error='';run.draining=false;
  run.events.push({at,phase:'items',position:run.position,detail:'仅恢复原图 '+p.assetIds.length+' 张；保留原上传意图、旧失败记录和生图计数，其他条目仍跳过。'});return run;
 }
 root.ExistingImageRecovery={plan,apply};if(typeof module==='object')module.exports=root.ExistingImageRecovery;
 if(!root.chrome?.runtime?.onMessage)return;
 chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if(m.type!=='INDEPENDENT_RECOVER_EXISTING_IMAGES')return;
  if(sender.id!==chrome.runtime.id||!sender.url?.startsWith(chrome.runtime.getURL('api-settings.html'))){reply({ok:false,error:'恢复入口不符。'});return;}
  executionGate(async()=>{
   const runs=await flowRuns(),run=runs.find(r=>r.id===m.runId);
   if(flowBusy||queueBusy||runs.some(r=>r.enabled)||(await autoRuns()).some(r=>r.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled)||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||typeof studioBatchConflict==='function'&&await studioBatchConflict()||typeof studioBusy!=='undefined'&&studioBusy.size||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled))throw Error('已有运行中的任务，未修改恢复记录。');
   if(!run||!FullFlowRun.matchesConsent(run))throw Error('原任务不存在或授权范围已变化。');
   // ExistingAssetsOnly guards this run's IDs, stages and generation count.
   // Do not require or alter the user's global AI pause for an upload-only continuation.
   const p=plan(run,m);
   for(const id of p.assetIds){const a=await flowMedia('/'+id);if(a.id!==id||a.status!=='completed'||a.available!==true||a.productIds?.join()!==p.productId||!m.hashes?.[id]||a.sha256!==m.hashes[id])throw Error('原图编号、商品或哈希未确认：'+id);}
   // Completed-generation publication may follow an explicitly requested browser-space change.
   // Preparation sends no store request; normal confirmed resume must recover/validate the tab.
   if(!p.publishGenerated)await FullCurrentTab.get(run);
   const key='existing-images-before-recovery:'+run.id+(run.existingAssetsOnly?':after-'+Date.parse(run.existingAssetsOnly.at):'');if((await chrome.storage.local.get(key))[key])throw Error('原恢复备份已存在，先核回执，不覆盖或重复恢复。');
   await chrome.storage.local.set({[key]:structuredClone(run)});
   await FullStateStore.update('material-flow-runs-v1',current=>{const latest=current.find(r=>r.id===m.runId);if(JSON.stringify(latest)!==JSON.stringify(run))throw Error('准备期间任务改变，未恢复。');apply(latest,p);return current;});
   reply({ok:true,status:'prepared',runId:run.id,images:p.assetIds.length,items:p.itemIds.length,generationCalls:run.usedCalls});
  }).catch(e=>reply({ok:false,error:e.message}));return true;
 });
})(globalThis);
