(function(root){
 'use strict';
 const rules=[
  ['cutout',/抠图痕迹|摳圖痕跡|抠图残留|摳圖殘留/,'修正抠图边缘','优先采集轮廓清晰、未受抠图损伤的同商品主图，主图不足再采集详情图、最后SKU图。仅清理商品轮廓外的白边、黑边、光晕、毛刺及背景残留，背景为纯白RGB(255,255,255)；保留商品真实轮廓、接口、线缆、结构、文字标识和透明部件，不以涂抹或虚构细节修补损坏的商品。','边缘连续自然，无白边、黑边、光晕或背景残留；商品真实结构和标识完整。'],
  ['human',/人体|肢体|手指|人物|模特|人台|身体/,'包含人体或肢体','改用没有人物、手、手指或身体部位遮挡的同商品SKU原图。清除商品外部的人体、模特或人台；不补画被遮挡的商品。商品自身真实印刷的图标与文字保持原样，不擅自篡改。','没有人物、手、手指或身体部位；商品自身图案与结构保持一致。'],
  ['cropped',/不完整|裁切|截断|缺失|完整性/,'商品主体不完整','改用完整展示同款同规格商品的原图；保持原机位和比例，补足画布留白，不补画原图缺失的商品结构。','整件商品及必要线缆、接口均完整，没有截断。'],
  ['multiple',/多个|重复|多主体|拼图|拼接/,'存在多个或重复主体','先确认单件商品与其不可分割部件。仅去掉重复展示的另一角度或另一件商品；保留同一商品的全部结构件和必要配件；若为多键面板，多个按键不是多件商品。','仅展示一件完整商品，按键、接口及必要部件数量与所选原图一致。'],
  ['marketing',/牛皮癣|文字|水印|营销|贴片|促销|二维码/,'存在营销文字或贴片','仅清除商品外部叠加的促销文字、贴片、水印、价格、二维码及装饰边框；保留商品上真实印刷或刻印的品牌、图标、按键文字和屏幕。','外加营销内容已清除，商品自身文字、图标及屏幕未被改写。'],
  ['background',/背景|非白|纯白|阴影|杂物/,'背景不合要求','仅替换商品外部背景为纯白RGB(255,255,255)，清除背景杂物及外部阴影；保留商品内部结构、原有反光、纹理与真实材质层次。','背景为纯白，商品边缘无残留和缺损，内部白色结构及材质细节保留。'],
  ['blur',/模糊|清晰|分辨率|像素|锯齿/,'清晰度不足','优先重新采集清晰原图；保留原始图案和文字，不凭空锐化、改字或重画细节。仅对清晰参考图做背景清理。','主体、边缘、按键图标清楚，未凭空增加细节。'],
  ['mismatch',/不一致|不符|不匹配|实物|商品无关/,'图片与商品不一致','重新核对商品及规格，选用完全对应的商品原图。保持颜色、按键数量、接口位置、品牌和比例，不使用同系列其他型号。','与目标商品及选定规格一致。']
 ];
 function plan(snapshot,custom=''){
  const reason=String(snapshot?.review?.reason||'').trim();
  if(!reason)throw Error('平台未返回具体拒绝原因，请先查清原因；未生成。');
  const found=rules.filter(r=>r[1].test(reason));
  if(!found.length&&!String(custom).trim())throw Object.assign(Error('该拒绝原因尚无对应修改规则，请填写本次修正方案后再生成。'),{code:'WHITE_REVIEW_RULE_UNSUPPORTED'});
  return {reason,fixes:[...found.map(r=>({id:r[0],title:r[2],edit:r[3],check:r[4]})),...(custom.trim()?[{id:'custom',title:'补充修正',edit:custom.trim(),check:'逐项核对补充修正要求。'}]:[])]};
 }
 function prompt(snapshot,custom='',previous=[]){
  const p=plan(snapshot,custom);
  const core=root.FullCore||(typeof require==='function'?require('./workflows.js'):null);
  if(!core?.whitePrompt)throw Error('统一白底图提示词未加载，未生成。');
  return core.whitePrompt({title:String(snapshot.title||''),reason:p.reason,fixes:p.fixes.map(f=>f.edit),previous:previous.slice(-3).map(v=>String(v.reason||v))})+'\n输出前复核：'+p.fixes.map(f=>f.check).join('；');
 }
 function unresolved(item){return !!(item.publication&&item.status!=='verified'||item.uploadIntents&&item.status!=='verified'||item.generations?.some(g=>g.intent&&!['completed','failed'].includes(g.status)));}
 function claimed(runs,snapshot,runId,spec,key){
  return runs.some(r=>r.id!==runId&&r.items?.some(i=>{
   if(key(i.reviewOriginal)!==key(snapshot)||!i.generations?.some(g=>g.intent)&&!i.publication)return false;
   if(!spec?.newRound)return true;
   return r.enabled===true||unresolved(i)||!['verified','failed','skipped'].includes(i.status);
  }));
 }
 const api={plan,prompt,claimed,unresolved};root.FullReviewRework=api;if(typeof module==='object')module.exports=api;
})(globalThis);
