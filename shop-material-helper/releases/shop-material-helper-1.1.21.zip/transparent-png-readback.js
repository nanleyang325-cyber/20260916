(function(root){
 'use strict';
 const width=800,height=800,length=width*height*4;
 function compareRgba(source,target){
  if(!source||!target||source.length!==length||target.length!==length)throw Error('透明图像素尺寸不符。');
  let visible=0,clear=0,opaque=0,squared=0,absolute=0,maxDelta=0,weightedSquared=0,weightedAbsolute=0,weightedMax=0;
  const bias=[0,0,0],tiles=Array.from({length:2500},()=>({count:0,squared:0,absolute:0}));
  // CDN PNG optimization can quantize saturated edges. Check their visible error,
  // local 16px regions and systematic color bias, while requiring exact alpha.
  for(let i=0;i<length;i+=4){const alpha=source[i+3];if(alpha!==target[i+3])throw Error('平台透明通道与原 PNG 不同。');if(!alpha){clear++;continue;}visible++;if(alpha===255)opaque++;const pixel=i/4,tile=tiles[Math.floor(pixel/width/16)*50+Math.floor(pixel%width/16)];tile.count++;for(let c=0;c<3;c++){const delta=target[i+c]-source[i+c],d=Math.abs(delta),weighted=delta*alpha/255; squared+=d*d;absolute+=d;maxDelta=Math.max(maxDelta,d);weightedSquared+=weighted*weighted;weightedAbsolute+=Math.abs(weighted);weightedMax=Math.max(weightedMax,Math.abs(weighted));bias[c]+=weighted;tile.squared+=weighted*weighted;tile.absolute+=Math.abs(weighted);}}
  if(clear<6400||clear>633600||opaque<3200||[0,799,639200,639999].some(i=>source[i*4+3]!==0))throw Error('平台图未通过真实透明背景检查。');
  const rms=Math.sqrt(squared/(visible*3)),meanAbsolute=absolute/(visible*3);
  const proof={width,height,alphaExact:true,transparentPixels:clear,opaquePixels:opaque,rms,meanAbsolute,maxDelta,policy:'platform-quantization-v2',weightedRms:Math.sqrt(weightedSquared/(visible*3)),weightedMean:weightedAbsolute/(visible*3),weightedMax,colorBias:Math.max(...bias.map(n=>Math.abs(n/visible))),maxTileRms:Math.max(0,...tiles.filter(t=>t.count>=16).map(t=>Math.sqrt(t.squared/(t.count*3)))),maxTileMean:Math.max(0,...tiles.filter(t=>t.count>=16).map(t=>t.absolute/(t.count*3)))};
  if(!validColor(proof))throw Error('平台图片颜色变化超出压缩容差，保留待核验。');
  return proof;
 }
 function bounded(n,max){return Number.isFinite(n)&&n>=0&&n<=max;}
 function validColor(p){return p?.policy==='platform-quantization-v2'?bounded(p.rms,8)&&bounded(p.meanAbsolute,4)&&bounded(p.maxDelta,255)&&bounded(p.weightedRms,5)&&bounded(p.weightedMean,3)&&bounded(p.weightedMax,96)&&bounded(p.colorBias,1.5)&&bounded(p.maxTileRms,14)&&bounded(p.maxTileMean,10):!p?.policy&&bounded(p?.rms,2)&&bounded(p?.meanAbsolute,1)&&bounded(p?.maxDelta,32);}
 async function decode(bytes){
  const bitmap=await createImageBitmap(new Blob([bytes],{type:'image/png'}),{colorSpaceConversion:'none',premultiplyAlpha:'none'});
  try{if(bitmap.width!==width||bitmap.height!==height)throw Error('平台 PNG 不是800×800。');const canvas=new OffscreenCanvas(width,height),ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(bitmap,0,0);return ctx.getImageData(0,0,width,height).data;}finally{bitmap.close();}
 }
 async function comparePng(source,target){return compareRgba(await decode(source),await decode(target));}
 function matchesReceipt(receipt,sourceHash){
  if(receipt?.imageSha256===sourceHash)return true;
  const p=receipt?.pixelCheck;
  return receipt?.imageSourceSha256===sourceHash&&/^[a-f0-9]{64}$/.test(receipt.imageSha256||'')&&receipt.imageMatch==='platform_png_optimized'&&p?.width===width&&p.height===height&&p.alphaExact===true&&p.transparentPixels>=6400&&p.transparentPixels<=633600&&p.opaquePixels>=3200&&validColor(p);
 }
 const api={compareRgba,comparePng,matchesReceipt};root.FullTransparentPng=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
