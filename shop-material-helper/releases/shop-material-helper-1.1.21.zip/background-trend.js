'use strict';
const TREND_URL='https://myseller.taobao.com/home.htm/trend-product-operation/home';
const trendDelay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function trendRoute(url){try{const u=new URL(url);return u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname==='/home.htm/trend-product-operation/home';}catch{return false;}}
function trendEntry(url){try{const u=new URL(url);return trendRoute(url)||u.protocol==='https:'&&['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)&&u.pathname==='/home.htm/material-center/material-management';}catch{return false;}}
async function trendTab(run){let tab;try{tab=await chrome.tabs.get(run.workTab.tabId);}catch{throw Error('原趋势标签页已关闭；请从现有店铺页继续原任务。');}if(tab.windowId!==run.workTab.windowId||!trendRoute(tab.pendingUrl||tab.url))throw Error('原趋势标签页用途或窗口已变化，原任务保留。');return tab;}
async function trendOpen(tab){
 if(!trendEntry(tab.pendingUrl||tab.url))throw Error('请在当前店铺素材页或趋势页启动，不会接管其他页面。');
 if(!trendRoute(tab.pendingUrl||tab.url)){
  const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},func:()=>({draft:!![...document.querySelectorAll('[role="dialog"],.next-dialog,.next-drawer,iframe')].find(e=>e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0&&(/发布|上传|添加标题|内容描述/.test(e.innerText||'')||/publish/i.test(e.src||'')))})});
  if(result?.draft)throw Error('当前页有发布或上传表单，请先完成或关闭；未刷新、未覆盖草稿。');
  await chrome.tabs.update(tab.id,{url:TREND_URL});
 }
 for(let n=0;n<100;n++){
  const current=await chrome.tabs.get(tab.id);if(current.windowId!==tab.windowId)throw Error('原窗口已变化。');
  if(!current.pendingUrl&&trendRoute(current.url))try{const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:()=>!!window.QN_WORKBENCH_CFG?.shopInfo?.shopId&&typeof window.lib?.mtop?.request==='function'});if(result)return current;}catch{}
  await trendDelay(300);
 }
 throw Error('原趋势页尚未就绪，未新开页面或提交。');
}
async function trendCall(run,method,input={}){
 const tab=await trendTab(run),target={tabId:tab.id,frameIds:[0]};
 await chrome.scripting.executeScript({target,world:'MAIN',files:['trend-platform.js']});
 const [{result}]=await chrome.scripting.executeScript({target,world:'MAIN',func:async(method,input)=>{try{return {ok:true,data:await FullTrendPlatform[method](input)};}catch(e){return {ok:false,error:e.message,code:e.code};}},args:[method,{...input,shopId:run.trend.scope.shopId}]});
 await trendTab(run);
 if(!result?.ok)throw Object.assign(Error(result?.error||'趋势平台读取未确认。'),{code:result?.code||'TREND_READ_UNKNOWN'});
 return result.data;
}
async function trendIdentify(tab){await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',files:['trend-platform.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:()=>{try{return {ok:true,...FullTrendPlatform.identify()};}catch(e){return {ok:false,error:e.message};}}});if(!result?.ok)throw Error(result?.error||'店铺身份未取得。');return result;}
async function trendCurrentCategory(run){
 const tab=await trendTab(run);const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:()=>{
  const selected=[...document.querySelectorAll('[role="tab"][aria-selected="true"],.next-tabs-tab.active')].filter(e=>e.getBoundingClientRect().width>0).map(e=>e.innerText.trim());
  let key=selected.includes('市场趋势')?'market':selected.includes('平台缺货')?(selected.includes('同款稀缺')?'scarce':selected.includes('相似款稀缺')?'similar':null):null;
  if(!key)return {error:'当前分类未确认；请选市场趋势、相似款稀缺或同款稀缺。'};
  const moduleType={market:'1',similar:'3',scarce:'4'}[key],allowed=['opportunityTitle','trendTopicId','cateIds','cateLevel1Ids','cateLevel2Ids','benefitLabels','recLabels','minSuggestPrice','maxSuggestPrice','orderBy','orderType'];
  let filters=null;for(const p of performance.getEntriesByType('resource').filter(p=>/mtop.alibaba.spo.opportunity.list.query/.test(p.name)).reverse())try{const data=JSON.parse(new URL(p.name).searchParams.get('data'));if(String(data.moduleType)!==moduleType)continue;filters=Object.fromEntries(Object.entries(data).filter(([k])=>allowed.includes(k)));break;}catch{}
  if(filters===null)return {error:'当前趋势列表和筛选条件尚未确认，请等待列表加载完成后重试；未扩大执行范围。'};
  return {key,filters};
 }});if(result?.error||!result?.key)throw Error(result?.error||'当前分类未确认。');return result;
}
function trendFlat(run,intent){return {id:intent.id,at:intent.createdAt,...intent.scope,productIds:intent.productIds,pageKey:intent.pageKey,candidatePageNo:Number(intent.pageKey),opportunityTitle:run.trend.opportunity?.title};}
function trendIO(){return {
 scanSections:async run=>{const current=run.selection.trendStartKey?{key:run.selection.trendStartKey,filters:run.selection.trendFilters}:await trendCurrentCategory(run),p=await trendCall(run,'permissions');const sections=p.sections.filter(s=>s.enabled).map(s=>({key:s.key,active:s.key===current.key}));if(!sections.some(s=>s.active))throw Error('当前分类没有平台提报权限，未扩大执行范围。');return {status:'ready',scope:run.trend.scope,sections,activeKey:current.key,filters:current.filters};},
 nextOpportunity:async(run,ctx)=>{
  const cursor=ctx.cursor||{pageNo:1,remaining:[]},scope={...run.trend.scope,sectionKey:ctx.sectionKey};let pageNo=cursor.pageNo,remaining=cursor.remaining||[],hasNext=cursor.hasNext;
  if(!remaining.length){if(cursor.hasNext===false)return {status:'end',scope};if(cursor.hasNext===true)pageNo++;const p=await trendCall(run,'opportunities',{sectionKey:ctx.sectionKey,pageNo,filters:run.selection.trendStartKey===ctx.sectionKey?run.selection.trendFilters||{}:{}});remaining=p.records.map(r=>({activityId:r.activityId,opportunityType:r.opportunityType,title:r.opportunityTitle}));hasNext=p.hasNext;if(!remaining.length){if(!p.emptyConfirmed)throw Error('趋势页为空但总数或结束状态未确认。');return {status:'end',scope};}}
  const opportunity=remaining.shift(),nextCursor=remaining.length||hasNext?{pageNo,remaining,hasNext}:null;
  return {status:'ready',scope,opportunity,nextCursor};
 },
 readPage:async(run,ctx)=>{const section=run.trend.sections[run.trend.sectionIndex],pageNo=Number(ctx.cursor||1),p=await trendCall(run,'candidates',{...ctx,pageNo,...(section.key==='similar'?{itemTitle:run.trend.opportunity.title}:{})});return {status:p.emptyConfirmed?'empty':'ready',scope:{...ctx,cursor:undefined},pageKey:String(pageNo),items:p.records.map(r=>({productId:r.itemId,eligible:r.eligible,reason:r.skipReason==='already_reported'?'平台已提报或审核中':r.skipReason==='no_report_operation'?'平台未提供可提报操作':''})),nextCursor:p.hasNext?pageNo+1:null};},
 submitBatch:async(run,intent)=>{
  // Recheck the frozen candidates on the original page before any write.
  const section=run.trend.sections[run.trend.sectionIndex],p=await trendCall(run,'candidates',{...intent.scope,pageNo:Number(intent.pageKey),...(section.key==='similar'?{itemTitle:run.trend.opportunity.title}:{})});
  if(!intent.productIds.every(id=>p.records.filter(r=>r.itemId===id&&r.eligible).length===1))return {status:'not_submitted',code:'CANDIDATE_CHANGED',intentId:intent.id,scope:intent.scope,productIds:intent.productIds,dispatchNeverStarted:true,proofOrigin:'candidate-preflight-v2',error:'本批商品资格或页集合已变化，未提交；重新读取当前活动。'};
  const tab=await trendTab(run),target={tabId:tab.id,frameIds:[0]};await chrome.scripting.executeScript({target,world:'MAIN',files:['trend-platform.js']});
  // Serialize only dispatch with the control gate. The SDK promise is retained
  // in the page so pause/stop never waits for its network response.
  await executionGate(async()=>{
   const live=(await flowRuns()).find(r=>r.id===run.id);if(!live?.enabled||live.draining||live.trend.controlRevision!==run.trend.controlRevision||typeof executionPaused==='function'&&await executionPaused())throw Error('已暂停或停止，本批未继续提交。');await trendTab(run);
   const [{result}]=await chrome.scripting.executeScript({target,world:'MAIN',func:input=>{FullTrendPlatform.identify(input.shopId);globalThis.FullTrendDispatch||={};const key=input.runId+':'+input.id,signature=JSON.stringify([input.shopId,input.tabId,input.windowId,input.sectionKey,input.activityId,input.opportunityType,[...input.productIds].sort()]);if(globalThis.FullTrendDispatch[key]){if(globalThis.FullTrendDispatch[key].signature!==signature)throw Error('原提交范围不一致。');return {started:true,existing:true};}const slot={at:Date.now(),pending:true,signature};globalThis.FullTrendDispatch[key]=slot;FullTrendPlatform.report(input).then(answer=>{slot.answer=answer;slot.pending=false;},error=>{slot.answer={status:'unknown',message:String(error.message)};slot.pending=false;});return {started:true};},args:[{...trendFlat(run,intent),runId:run.id}]});if(!result?.started)throw Error('原批次发送尚未确认。');
  });
  return {status:'submitted',intentId:intent.id,scope:intent.scope,productIds:intent.productIds};
 },
 readbackBatch:async(run,intent)=>{
  const end=Date.now()+25000;let answer;
  do{
   const tab=await trendTab(run),[{result:dispatch}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[0]},world:'MAIN',func:id=>globalThis.FullTrendDispatch?.[id]?.answer||null,args:[run.id+':'+intent.id]});
   if(dispatch?.status==='rejected')return {status:'rejected',intentId:intent.id,scope:intent.scope,productIds:intent.productIds,error:dispatch.message,receipt:{api:dispatch.api,platformStatus:dispatch.message}};
   answer=await trendCall(run,'readback',trendFlat(run,intent));if(answer.status==='verified'){
    const r=answer.receipt,expected=intent.scope,ids=x=>Array.isArray(x)?[...x].map(String).sort().join('|'):'';
    if(r?.source!=='platform-readback'||r.api!=='mtop.alibaba.spo.opportunity.report.item.list.query'||String(r.shopId)!==String(expected.shopId)||String(r.activityId)!==String(expected.activityId)||String(r.opportunityType)!==String(expected.opportunityType)||ids(r.productIds)!==ids(intent.productIds)||!Array.isArray(r.records)||r.records.length!==intent.productIds.length||!intent.productIds.every(id=>r.records.filter(row=>String(row.itemId)===id&&String(row.opportunityId)===String(expected.activityId)&&String(row.opportunityType)===String(expected.opportunityType)&&typeof row.reportStatusName==='string'&&row.reportStatusName).length===1))throw Error('官方回查与原店铺、活动或完整商品集合不符，未记为成功。');
    const platformStatus=[...new Set(r.records.map(row=>row.reportStatusName))].join('、');return {status:'confirmed',intentId:intent.id,scope:intent.scope,productIds:intent.productIds,receipt:{...r,platformStatus,checkedVia:{tabId:tab.id,windowId:tab.windowId,shopId:run.trend.scope.shopId,at:new Date().toISOString()}}};
   }
   const live=(await flowRuns()).find(r=>r.id===run.id);if(!live?.enabled||Date.now()>=end)break;await trendDelay(1500);
  }while(true);
  return {status:'unknown',code:'TREND_READBACK_PENDING',error:answer?.message||'原批次尚未回查明确，保留原提交；继续时只查不重提。'};
 }
};}
async function trendSave(run){await FullStateStore.update(FLOW_KEY,runs=>{runs||=[];const index=runs.findIndex(r=>r.id===run.id);if(index<0)runs.push(structuredClone(run));else{const current=runs[index];if(current.trend?.controlRevision>run.trend.controlRevision){run.trend.controlRevision=current.trend.controlRevision;run.enabled=current.enabled;run.status=current.status;run.error=current.error;}if(current.cancellation){run.cancellation=structuredClone(current.cancellation);run.enabled=false;run.draining=false;run.status='stopped';}globalThis.FullTaskFailures?.save(run,'trend',current);runs[index]=structuredClone(run);}return runs;});}
const trendRunner=FullTrendRun.createRunner({load:async id=>(await flowRuns()).find(r=>r.id===id),save:trendSave,io:trendIO()});
async function trendCheckIdle(except){if(typeof executionPaused==='function'&&await executionPaused())throw Error('已全局暂停，请先恢复。');if((await flowRuns()).some(r=>r.id!==except&&(r.enabled||r.status==='paused'))||queueBusy||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||typeof studioBatchConflict==='function'&&await studioBatchConflict()||typeof studioBusy!=='undefined'&&studioBusy.size||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled)||(await autoRuns()).some(r=>r.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled))throw Error('已有执行或待执行任务，请先暂停或停止。');}
async function flowTrendStart(selection){
 if(selection?.startConsent!==true||selection.executionBoundary?.storeWrite!==true)throw Error('趋势提报需要明确的店铺提报操作确认。');
 await trendCheckIdle();let [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab||!Number.isInteger(tab.id))throw Error('当前店铺标签页未确认。');tab=await trendOpen(tab);const shop=await trendIdentify(tab);
 const old=[...(await flowRuns())].reverse().find(r=>r.kind==='trend'&&r.status!=='done'&&r.trend.scope.shopId===shop.shopId);
 if(old)throw Object.assign(Error('当前店铺有未完成趋势原任务，是否继续执行？'),{code:'ORIGINAL_TASK_EXISTS',runId:old.id});
 const run=FullTrendRun.create({selection:{...selection,shopId:shop.shopId,shopName:shop.shopName,mode:'all',maxCalls:0,paidGeneration:false,executionBoundary:{paidGeneration:false,storeWrite:true}},workTab:{tabId:tab.id,windowId:tab.windowId}}),current=await trendCurrentCategory(run);
 run.selection.trendStartKey=current.key;run.selection.trendFilters=current.filters;run.consentScope=FullFlowRun.scope(run);run.events.push({at:run.createdAt,phase:'sections',detail:'免费趋势提报已启动；复用当前标签页，不调用生图或视频接口。'});await trendSave(run);await chrome.alarms.create('full-trend:'+run.id,{when:Date.now()+100,periodInMinutes:.5});flowTrendTick(run.id).catch(()=>{});return {ok:true,runId:run.id};
}
async function flowTrendControl(id,action,confirmed,restartCancelled=false){
 let run=(await flowRuns()).find(r=>r.id===id);if(run?.kind!=='trend')throw Error('不是可恢复的趋势原任务。');
 if(run.cancellation&&action!=='stop'&&!(action==='resume'&&confirmed&&restartCancelled))throw Error('该任务已取消，请确认重新开始原任务。');if(action==='resume'){
  await trendCheckIdle(id);if(!FullFlowRun.matchesConsent(run))throw Error('原趋势执行范围已变化，未继续。');
  let tab;try{tab=await trendTab(run);}catch{if(!confirmed)throw Error('原标签页已变化，请确认继续原任务。');[tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab||!trendEntry(tab.pendingUrl||tab.url))throw Error('请在已有店铺素材页继续；不会另开页面。');tab=await trendOpen(tab);}
  const shop=await trendIdentify(tab);if(shop.shopId!==run.trend.scope.shopId)throw Error('当前店铺与原任务不一致，未继续。');
  if(tab.id!==run.workTab.tabId||tab.windowId!==run.workTab.windowId){run.bindingHistory||=[];run.bindingHistory.push({at:new Date().toISOString(),previous:run.workTab,current:{tabId:tab.id,windowId:tab.windowId},shopId:shop.shopId,reason:'explicit-resume-same-shop'});run.trend.originalScope||=structuredClone(run.trend.scope);const previousScope=structuredClone(run.trend.scope);run.workTab={tabId:tab.id,windowId:tab.windowId};run.trend.scope={...run.trend.scope,tabId:tab.id,windowId:tab.windowId};for(const key of ['processedActivities','processedProducts']){const aliases=run.trend[key].filter(s=>s.startsWith(JSON.stringify([previousScope.shopId,previousScope.tabId,previousScope.windowId]).slice(0,-1))).map(s=>s.replace(JSON.stringify([previousScope.shopId,previousScope.tabId,previousScope.windowId]).slice(0,-1),JSON.stringify([run.trend.scope.shopId,tab.id,tab.windowId]).slice(0,-1)));run.trend[key]=[...new Set([...run.trend[key],...aliases])];}await trendSave(run);}
 }
 if(run.cancellation&&action==='resume'&&confirmed&&restartCancelled)await FullStateStore.update(FLOW_KEY,runs=>{FullTaskCancel.restart(runs.find(r=>r.id===id),true);return runs;});run=await trendRunner.control(id,action);if(!run.enabled)await chrome.alarms.clear('full-trend:'+id);else{await chrome.alarms.create('full-trend:'+id,{when:Date.now()+100,periodInMinutes:.5});flowTrendTick(id).catch(()=>{});}return {ok:true,runId:id};
}
async function flowTrendTick(id){
 if(flowBusy||queueBusy||trendRunner.isBusy(id))return;flowBusy=true;queueBusy=true;
 try{for(let n=0;n<12;n++){const run=(await flowRuns()).find(r=>r.id===id);if(!run?.enabled)return;const next=await trendRunner.step(id);if(!next?.enabled)return;await trendDelay(180);}}
 finally{flowBusy=false;queueBusy=false;const run=(await flowRuns()).find(r=>r.id===id);if(run?.enabled)chrome.alarms.create('full-trend:'+id,{when:Date.now()+150,periodInMinutes:.5}).catch(()=>{});else await chrome.alarms.clear('full-trend:'+id);}
}
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name.startsWith('full-trend:'))flowTrendTick(alarm.name.slice(11)).catch(()=>{});});
chrome.runtime.onStartup.addListener(()=>{flowRuns().then(runs=>Promise.all(runs.filter(r=>r.kind==='trend'&&r.enabled).map(r=>chrome.alarms.create('full-trend:'+r.id,{when:Date.now()+1000,periodInMinutes:.5})))).catch(()=>{});});
