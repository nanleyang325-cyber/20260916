(function(root){
 'use strict';
 const restartButton=document.getElementById('btnRestartCancelled');const button=document.getElementById('btnCancelTask');if(!button)return;
 const ui=()=>root.FullLogDetailsUI||root.FullPopupUi;const supported=run=>!!run&&(!run.logFamily||['flow','trend'].includes(run.logFamily));const resumable=run=>supported(run)&&!run.enabled&&(!!run.cancellation||['stopped','blocked','budget_exhausted','recovery_exhausted'].includes(run.status));let pending=false;
 root.FullRecoveryUi={plan:async run=>{if(!(run.items||[]).some(i=>i.generations?.some(g=>['failed','violation'].includes(g.status))))return null;const response=await chrome.runtime.sendMessage({type:'FULL_FLOW_RECOVERY_PLAN',runId:run.id});if(!response?.ok)throw Error(response?.error||'原失败素材恢复范围未确认。');return response.plan;},summary:plan=>plan?.recoveries?.length?'已有'+plan.completedImages+'张成图；仅恢复'+plan.recoveries.length+'张明确的能力失败，最多新增'+plan.maxAdditionalRequests+'次调用'+(plan.localQuotaRemoved?'，按实际调用计费。':'，累计不超过原'+plan.maxCalls+'次。'):''};

 function render(){const run=ui()?.currentRun;button.hidden=!supported(run)||run.status==='done'||run.phase==='done';button.disabled=pending||!!run?.cancellation;button.textContent=run?.cancellation?'已取消':'取消任务';if(restartButton){restartButton.hidden=!resumable(run);restartButton.disabled=pending;restartButton.textContent=run?.cancellation?'重新开始':'继续原任务';}}
 button.onclick=async()=>{
  const run=ui()?.currentRun;if(pending||!supported(run)||run.cancellation)return;
  if(!root.confirm('取消当前任务 '+String(run.id).slice(0,8)+'？\n停止后续执行，保留已生成素材、已用额度和提交记录；已发出的生成或发布请求不会撤回。'))return;
  const id=run.id;pending=true;render();
  try{const result=await chrome.runtime.sendMessage({type:'FULL_FLOW_CANCEL',runId:id});if(!result?.ok)throw Error(result?.error||'取消结果尚未确认，请查看原任务状态。');root.FullPopupUi?.notice('已取消任务，原素材与记录保留');}
  catch(error){root.alert(error.message);}finally{pending=false;render();}
 };
 if(restartButton)restartButton.onclick=async()=>{
  const run=ui()?.currentRun;if(pending||!resumable(run))return;pending=true;render();
  try{const plan=await root.FullRecoveryUi.plan(run);if(!root.confirm('重新开始原任务 '+String(run.id).slice(0,8)+'？\n'+(run.module==='search'?'复用原素材与记录，按原商品和篇数执行，不设本地生成次数上限；实际生成按服务商计费。':'复用原素材与记录，原额度上限不清零。')+'\n'+root.FullRecoveryUi.summary(plan)))return;
   const result=await chrome.runtime.sendMessage({type:'FULL_FLOW_RESUME',runId:run.id,confirmResume:true,restartCancelled:!!run.cancellation,...(plan?.recoveries?.length?{recoverCapabilities:true,recoveryPlanSHA256:plan.planSHA256}:{})});if(!result?.ok)throw Error(result?.error||'重新开始未确认，请保留原记录。');root.FullPopupUi?.notice('已重新开始原任务，保留原素材与用量记录');
  }catch(error){root.alert(error.message);}finally{pending=false;render();}
 };
 root.addEventListener('material-run-state',render);Promise.resolve(ui()?.ready).then(render,render);
})(globalThis);
