(function(root){
 'use strict';
 const supported=['white','scene'];
 function scope(job){return JSON.stringify({id:job.id,module:job.module,productIds:job.productIds,assets:job.assets.map(a=>a.id),replaceExisting:!!job.replaceExisting});}
 function approve(job){
  if(!supported.includes(job.module))throw new Error('当前自动绑定仅支持白底图和场景图。');
  if(job.productIds.length!==1||!/^\d{6,}$/.test(job.productIds[0]))throw new Error('自动绑定需要一个明确商品。');
  if(job.assets.length!==1||job.assets[0].status!=='completed')throw new Error('需先完成一张素材并下载验证。');
  if(!job.reviewedAssets)throw new Error('请先审看并确认这张素材与目标商品一致。');
  job.automationConsent={scope:scope(job),approvedAt:new Date().toISOString()};
 }
 function approveRun(job,run){
  if(!root.FullAutoRun||run.consentScope!==root.FullAutoRun.scope(run)||!run.autoPublish||job.autoRunId!==run.id||!run.ids.includes(job.productIds[0])||job.productIds.length!==1||!supported.includes(job.module)||job.module!==run.module||job.assets.length!==1||job.assets[0].status!=='completed'||job.replaceExisting)throw new Error('自动补图授权范围不匹配。');
  // Explicit start-button authorization does not claim a human reviewed generated output.
  job.automationConsent={scope:scope(job),approvedAt:new Date().toISOString(),kind:'start-button',runId:run.id,generatedPublicationAllowed:true};
 }
 async function run(job,io){
  const startConsent=job.automationConsent?.kind==='start-button'&&job.automationConsent.runId===job.autoRunId&&job.automationConsent.generatedPublicationAllowed===true;
  if(!supported.includes(job.module)||job.automationConsent?.scope!==scope(job)||!job.reviewedAssets&&!startConsent)throw new Error('自动执行范围未确认或已改变，请重新审看确认。');
  if(job.assets.length!==1||job.assets[0].status!=='completed')throw new Error('素材尚未生成完成。');
  const fileName=`material-${job.assets[0].id}${job.module==='scene'?'-scene-800':''}.png`;
  let state=job.automation||(job.automation={step:'ready',events:[]});
  const save=async(step,detail)=>{state.step=step;state.events.push({time:new Date().toISOString(),step,detail});job.automation=state;await io.save(job);state=job.automation;};
  const check=()=>{if(job.stopRequested)throw Object.assign(new Error('已停止后续动作；已提交操作只能回查。'),{stopped:true});};
  const take=result=>{if(!result?.ok)throw Object.assign(new Error(result?.error||'平台动作未确认。'),{executed:result?.executed});return result;};
  const finish=async result=>{
   job.error='';state.lastReadback={status:result.status,message:result.message||'',scene:result.scene||null};
   if(result.status==='verified'&&io.verify(job,result.receipt)&&result.receipt.imageUrl===job.sceneUpload?.url){job.receipt=result.receipt;job.status='verified';await save('verified','素材URL、内容ID及商品身份已回查');return result;}
   job.status='submitted_unconfirmed';await save('readback',result.message||'后台尚未确认，后续仅回查');return {...result,status:'submitted_unconfirmed',receipt:undefined,message:result.message||'回执未通过商品与图片核对，仅保留待回查状态。'};
  };
  try{
   check();
   // 任何已留下的保存意图（包括崩溃后恢复）均只查询，绝不重新保存。
   if(job.publication){await save('readback','恢复已有提交，禁止重交');return await finish(take(await io.readback(job)));}
   await save('space','打开图片空间并查找原上传');await io.openSpace(job);check();
   let uploaded=await io.lookup(job,fileName);
   if(!uploaded?.ok){
    if(uploaded?.code!=='PICTURE_NOT_FOUND')throw new Error(uploaded?.error||'图片空间查询未确认，未上传文件。');
    if(state.uploadIntent){job.status='unknown';await save('upload_unknown','既有上传意图尚未回查，禁止重复上传');return {ok:true,status:'unknown'};}
    const asset=await io.asset(job.assets[0].id,job.module==='scene');check();
    await io.openUpload(job);state.uploadIntent={fileName,at:new Date().toISOString()};await save('uploading','已登记上传意图');
    check();take(await io.upload(job,[asset]));
    for(let n=0;n<20;n++){check();await io.delay(1500);uploaded=await io.lookup(job,fileName);if(uploaded?.ok)break;if(uploaded?.code!=='PICTURE_NOT_FOUND')throw new Error(uploaded?.error||'上传回查未确认。');}
    if(!uploaded?.ok){job.status='unknown';await save('upload_unknown','尚未查到本次唯一文件名，停止写入');return {ok:true,status:'unknown'};}
   }
   job.sceneUpload=uploaded.sceneUpload;job.status='uploaded';await save('uploaded','已精确查回唯一上传文件');check();
   // 先读取现有槽并检查替换权限，再登记一次性保存意图。
   const before=take(await io.readSlot(job));state.beforeSlot=before.scene;job.automation=state;await io.save(job);state=job.automation;
   if(before.scene.url&&!job.replaceExisting)throw new Error('目标素材槽已有图片，未允许替换，停止保存。');
   check();job.publicationConsent=true;job.publication={key:job.id+':'+job.module+':'+job.productIds[0],submittedAt:new Date().toISOString(),imageUrl:job.sceneUpload.url};job.status='submitting';await save('binding','已登记单次绑定意图');
   check();return await finish(take(await io.bind(job,fileName)));
  }catch(error){
   job.error=error.message;job.status=error.stopped?'stopped':job.publication?'unknown':'failed';
   await save(error.stopped?'stopped':'blocked',error.message);throw error;
  }
 }
 root.FullAutomation={supported,scope,approve,approveRun,run};if(typeof module!=='undefined')module.exports=root.FullAutomation;
})(globalThis);
