/* Browser port of the existing edge-connected-white-v1 algorithm. No model/API. */
(function(root){'use strict';
 const N=800,COUNT=N*N;
 const bad=code=>{throw Error(code);};
 const white=(p,i)=>p[i+3]===255&&Math.min(p[i],p[i+1],p[i+2])>=248&&Math.max(p[i],p[i+1],p[i+2])-Math.min(p[i],p[i+1],p[i+2])<=8;
 function check(p,w,h){if(w!==N||h!==N||p.length!==COUNT*4)bad('WHITE_SOURCE_MUST_BE_800');}
 function padding(p,w=N,h=N){check(p,w,h);const edges=[0,0,0,0];for(let n=0;n<N;n++){if(white(p,n*4))edges[0]++;if(white(p,((N-1)*N+n)*4))edges[1]++;if(white(p,n*N*4))edges[2]++;if(white(p,(n*N+N-1)*4))edges[3]++;}const min=Math.min(...edges);return edges.filter(v=>v>=784).length>=3&&min>=400&&min<800&&[0,799,639200,639999].every(i=>white(p,i*4));}
 function round(x){const f=Math.floor(x),d=x-f;return d===.5?f+(f%2):Math.round(x);}
 function verify(p,w=N,h=N){check(p,w,h);let clear=0,opaque=0,partial=0,left=N,top=N,right=-1,bottom=-1;for(let i=0;i<COUNT;i++){const a=p[i*4+3];if(!a)clear++;else{if(a===255)opaque++;else partial++;const x=i%N,y=Math.floor(i/N);left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);}}if(clear<6400||clear>633600||opaque<3200||left<2||top<2||right>797||bottom>797||[0,799,639200,639999].some(i=>p[i*4+3]!==0))bad('CUTOUT_SUBJECT_OR_ALPHA_UNCONFIRMED');return {width:N,height:N,format:'png',transparentPixels:clear,opaquePixels:opaque,partialPixels:partial,bounds:{left,top,right,bottom}};}
 function cut(input,w=N,h=N){check(input,w,h);const p=new Uint8ClampedArray(input),candidate=new Uint8Array(COUNT);let already=0;
  for(let i=0;i<COUNT;i++){const at=i*4,min=Math.min(p[at],p[at+1],p[at+2]),max=Math.max(p[at],p[at+1],p[at+2]);if(!p[at+3])already++;candidate[i]=p[at+3]<16||min>=248&&max-min<=8?1:0;}
  const existingAlpha=already>=6400&&[0,799,639200,639999].every(i=>p[i*4+3]===0);
  if(!existingAlpha){let edge=0,total=0;for(let x=0;x<N;x++){edge+=candidate[x]+candidate[639200+x];total+=2;}for(let y=1;y<799;y++){edge+=candidate[y*N]+candidate[y*N+799];total+=2;}if(edge<total*.98||[0,799,639200,639999].some(i=>!candidate[i]))bad('WHITE_BACKGROUND_NOT_CONFIRMED');
   const clear=new Uint8Array(COUNT),queue=new Int32Array(COUNT);let head=0,tail=0;const push=i=>{if(candidate[i]&&!clear[i]){clear[i]=1;queue[tail++]=i;}};
   for(let x=0;x<N;x++){push(x);push(639200+x);}for(let y=1;y<799;y++){push(y*N);push(y*N+799);}
   while(head<tail){const i=queue[head++],x=i%N,y=Math.floor(i/N);if(x)push(i-1);if(x<799)push(i+1);if(y)push(i-N);if(y<799)push(i+N);}
   for(let i=0;i<COUNT;i++)if(clear[i])p[i*4+3]=0;
   const before=new Uint8ClampedArray(p);
   for(let y=1;y<799;y++)for(let x=1;x<799;x++){const i=y*N+x,at=i*4;if(clear[i]||!(clear[i-1]||clear[i+1]||clear[i-N]||clear[i+N]))continue;if(Math.min(before[at],before[at+1],before[at+2])<220)continue;let best=-1,bestMin=256;
    for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const xx=x+dx,yy=y+dy;if(xx<1||xx>798||yy<1||yy>798)continue;const j=yy*N+xx;if(clear[j]||clear[j-1]||clear[j+1]||clear[j-N]||clear[j+N])continue;const q=j*4,m=Math.min(before[q],before[q+1],before[q+2]);if(m>=180&&m<bestMin){best=j;bestMin=m;}}
    if(best<0||bestMin>=246)continue;let num=0,den=0;for(let c=0;c<3;c++){const d=255-before[best*4+c];num+=(255-before[at+c])*d;den+=d*d;}if(den<64)continue;const alpha=Math.max(.05,Math.min(1,num/den));if(alpha>.98)continue;for(let c=0;c<3;c++)p[at+c]=Math.max(0,Math.min(255,round((before[at+c]-255*(1-alpha))/alpha)));p[at+3]=round(alpha*255);
   }
  }
  return {pixels:p,info:{...verify(p),algorithm:'edge-connected-white-v1',existingAlpha}};
 }
 const api={cut,padding,verify};root.MaterialCutout=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
