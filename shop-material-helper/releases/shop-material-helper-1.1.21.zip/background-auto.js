'use strict';
importScripts('auto-run.js');
const AUTO_KEY='material-auto-runs-v1',autoBusy=new Set();
async function autoRuns(){return (await chrome.storage.local.get(AUTO_KEY))[AUTO_KEY]||[];}
async function autoSave(run){await FullStateStore.update(AUTO_KEY,previous=>{const runs=previous||[];const canonical=runs.find(r=>r.id===run.id);if(canonical?.enabled===false){run.enabled=false;run.status=canonical.status;}globalThis.FullTaskFailures?.save(run,'auto',runs.find(r=>r.id===run.id));const stored=structuredClone(run);for(const item of stored.items)if(item.reference)delete item.reference.data;const index=runs.findIndex(r=>r.id===run.id);if(index>=0){if(runs[index].draining)run.draining=stored.draining=true;if(runs[index].enabled===false&&run.enabled){run.enabled=false;run.status=runs[index].status;stored.status=run.status;}stored.enabled=run.enabled;runs[index]=stored;}else runs.push(stored);return runs;});}
async function autoSaveJob(job){await FullStateStore.update(QUEUE_KEY,previous=>{const state=previous||{products:[],jobs:[],schedules:[]},index=state.jobs.findIndex(j=>j.id===job.id);if(index<0)state.jobs.push(job);else{Object.assign(job,FullStateStore.mergeJob(state.jobs[index],job));state.jobs[index]=job;}return state;});}
async function autoOpen(url){let tab=(await chrome.tabs.query({url})).at(-1);if(!tab)tab=await chrome.tabs.create({url,active:false});for(let n=0;n<15;n++){const current=await chrome.tabs.get(tab.id);if(current.status==='complete')return current;await queueDelay(400);}throw new Error('后台页面未加载完成，请完成店铺登录后继续。');}
async function autoPreflight(run,item){
 const tab=await autoOpen(FullCore.URLS.material);let frames=[];
 for(let n=0;n<20;n++){const candidates=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:()=>({ready:!!document.querySelector('.next-table,.next-table-row')&&[...document.querySelectorAll('input')].some(i=>/商品|\bID\b/i.test(i.placeholder||''))})});frames=candidates.filter(frame=>frame.result?.ready);if(frames.length)break;await queueDelay(400);}
 if(frames.length!==1)throw new Error('未识别唯一基础素材商品列表，请打开并登录该页面。');
 await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[frames[0].frameId]},files:['product-probe.js']});
 const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id,frameIds:[frames[0].frameId]},func:async(pid,module,options)=>{try{return {ok:true,...await FullProductProbe.search(pid,module,options)};}catch(error){return {ok:false,error:error.message,code:error.code==='PRODUCT_NOT_FOUND'?'PRODUCT_NOT_FOUND':'PRODUCT_LOOKUP_BLOCKED'};}},args:[item.productId,run.module,{clearWhiteFilter:run.module==='white'&&['ids','custom'].includes(run.selection?.mode)}]});
 if(!result?.ok){if(result?.code==='PRODUCT_NOT_FOUND')return {productId:item.productId,saleState:'not_found',slotState:'unknown'};throw new Error(result?.error||'目标商品只读检查未完成。');}
 if(run.saleOnly!==true&&result.saleState==='on_sale'&&result.slotState==='empty'){
  const space=await autoOpen(FullCore.URLS.space),job={module:run.module,productIds:[item.productId]},checked=await queueScene(space.id,job,'read');
  if(!checked.ok)throw new Error(checked.error||'官方素材槽状态未确认。');if(checked.scene.url)result.slotState='occupied';
 }
 return result;
}
async function autoReference(run,item){
 let referenceUrl,source='main-first';
 if(run.module==='white'){
  const url='https://detail.tmall.com/item.htm?id='+item.productId,existed=(await chrome.tabs.query({url})).length>0,tab=await autoOpen(url);
  try{await chrome.scripting.executeScript({target:{tabId:tab.id},files:['product-probe.js']});const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:pid=>{try{return FullProductProbe.skuImages(document,pid,location.href);}catch{return [];}},args:[item.productId]});if(result?.length){referenceUrl=result.at(-1);source='sku-last';}}catch{}finally{if(!existed){const current=await chrome.tabs.get(tab.id);if(!current.active)await chrome.tabs.remove(tab.id);}}
 }
 referenceUrl||=item.product.mainImage;if(!referenceUrl)throw new Error('未取得同商品 SKU 图或主图，未调用生成。');
 const file=await fetchReference({url:referenceUrl});return {productId:item.productId,data:file.reference,url:referenceUrl,source};
}
async function autoCheckLive(run){const current=(await autoRuns()).find(value=>value.id===run.id);if(!current?.enabled)throw new Error('已停止后续动作，保留原记录。');}
async function autoTick(id){
 if(autoBusy.size||queueBusy)return;autoBusy.add(id);queueBusy=true;
 try{
  const run=(await autoRuns()).find(r=>r.id===id);if(!run?.enabled)return;if(run.module==='white'){run.enabled=false;run.status='boundary_blocked';run.error='本轮禁止付费生成与店铺写入；旧白底自动入口已停止，保留全部原记录。';run.boundaryBlocked={action:'legacyAuto',stage:run.items?.[run.position]?.phase||run.phase||'legacy',at:new Date().toISOString()};await autoSave(run);await chrome.alarms.clear('auto-run:'+run.id);return;}
  const io={save:autoSave,saveJob:autoSaveJob,preflight:autoPreflight,reference:autoReference,loadJob:async id=>(await queueState())?.jobs.find(job=>job.id===id),
   createJob:async(run,item)=>{const {jobs}=FullCore.plan([{id:item.productId,title:item.product.title,images:[]}],{module:run.module,ids:item.productId,palette:run.palette,count:1,maxCalls:1});const job=jobs[0];job.autoRunId=run.id;job.backgroundQueueLocked=true;await autoSaveJob(job);return job;},
   submit:async(run,item)=>{const job=item.job,asset=job.assets[0];asset.status='submitting';job.status='generating';await autoSaveJob(job);const reference=item.reference.data||(await fetchReference({url:item.reference.url})).reference;await autoCheckLive(run);const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/media"),{method:'POST',headers:{'Content-Type':'application/json','X-Material-Client':'full-v1'},body:JSON.stringify({id:asset.id,module:run.module,media:'image',model:'nano-banana-pro',productIds:[item.productId],prompt:job.prompt,ratio:job.ratio,palette:run.palette,references:[reference],consent:true}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('生成提交未确认，保留原编号，只查询。');},
   query:async(run,item)=>{const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/media/")+item.job.assets[0].id,{signal:AbortSignal.timeout(20000)});if(!response.ok)throw new Error('原生成编号查询未确认，未重复提交。');const result=await response.json();if(result.id!==item.job.assets[0].id||result.media!=='image'||result.productIds?.length!==1||result.productIds[0]!==item.productId)throw new Error('原素材与商品身份不一致。');return result;},
   publish:async(run,item)=>{const job=item.job;FullAutomation.approveRun(job,run);await autoSaveJob(job);await autoCheckLive(run);return runQueuedJob(job);}
  };
  // Several cheap steps may progress now; polling yields to the next alarm.
  for(let n=0;n<6&&run.enabled;n++){const before=run.items[run.position]?.phase;await FullAutoRun.advance(run,io);const after=run.items[run.position]?.phase;if(after==='poll'||before==='poll'&&after==='poll')break;}
  if(!run.enabled){await chrome.alarms.clear('auto-run:'+run.id);for(const item of run.items)if(item.job){item.job.backgroundQueueLocked=false;await autoSaveJob(item.job);}}
 }finally{queueBusy=false;autoBusy.delete(id);}
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id)return false;
 if(message.type==='FULL_AUTO_START'){
  executionGate(async()=>{if(message.module==='white')throw Error('旧白底自动入口已关闭；请使用白底图专用入口，本轮禁止付费生成与店铺写入。');if((await autoRuns()).some(run=>run.enabled)||queueBusy||await additionalExecutionActive()||(await queueState())?.backgroundQueues?.some(queue=>queue.enabled))throw new Error('已有自动流程或后台队列运行，请先停止。');const run=FullAutoRun.create(message.module,message.selection);const pending=(await autoRuns()).find(previous=>previous.module===run.module&&previous.items.some(item=>run.ids.includes(item.productId)&&item.submissionIntent&&!['verified','skipped','generated'].includes(item.status)));if(pending)throw new Error('同商品已有原生成或提交记录待处理，请在任务页继续 / 回查原任务，未新建生图。');await autoSave(run);await chrome.alarms.create('auto-run:'+run.id,{when:Date.now()+100,periodInMinutes:.5});reply({ok:true,runId:run.id});autoTick(run.id).catch(()=>{});}).catch(error=>reply({ok:false,error:error.message}));return true;
 }
 if(['FULL_AUTO_STOP','FULL_AUTO_RESUME'].includes(message.type)){
  executionGate(async()=>{if(message.type==='FULL_AUTO_RESUME'&&(queueBusy||await additionalExecutionActive()||(await queueState())?.backgroundQueues?.some(queue=>queue.enabled)))throw new Error('已有执行或待执行后台队列，请先停止。');await FullStateStore.update(AUTO_KEY,previous=>{const runs=previous||[],run=runs.find(r=>r.id===message.runId);if(!run)throw new Error('自动任务不存在。');if(message.type==='FULL_AUTO_RESUME'&&run.module==='white')throw Error('本轮禁止恢复旧白底自动执行；原编号和历史记录保持不变。');if(message.type==='FULL_AUTO_STOP'){run.enabled=false;run.status='stopped';for(const item of run.items){const job=queueJobs.get(item.job?.id);if(job)job.stopRequested=true;}}else{if(runs.some(r=>r.enabled&&r.id!==run.id))throw new Error('请等待当前执行结束。');if(run.consentScope!==FullAutoRun.scope(run))throw new Error('原范围已变化，不能继续。');run.enabled=true;run.status='running';run.error='';}return runs;});if(message.type==='FULL_AUTO_STOP')await chrome.alarms.clear('auto-run:'+message.runId);else await chrome.alarms.create('auto-run:'+message.runId,{when:Date.now()+100,periodInMinutes:.5});reply({ok:true});}).catch(error=>reply({ok:false,error:error.message}));return true;
 }
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name.startsWith('auto-run:'))autoTick(alarm.name.slice(9)).catch(()=>{});});
