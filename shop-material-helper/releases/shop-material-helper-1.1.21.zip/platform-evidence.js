(function(){
 'use strict';
 function identifiers(element,name){
  const found=new Set(),seen=new WeakSet();let visited=0;
  function visit(value,depth){if(!value||typeof value!=='object'||depth>6||seen.has(value)||visited++>400)return;seen.add(value);
   for(const [key,descriptor]of Object.entries(Object.getOwnPropertyDescriptors(value))){if(!('value'in descriptor)||/token|cookie|secret|authorization|password|apiKey/i.test(key))continue;const child=descriptor.value;if(key===name&&/^\d{6,}$/.test(String(child)))found.add(String(child));else if(child&&typeof child==='object')visit(child,depth+1);}
  }
  for(const key of Object.keys(element)){if(key.startsWith('__reactProps$'))visit(element[key],0);if(key.startsWith('__reactFiber$'))visit(element[key]?.memoizedProps,0);}
  return found;
 }
 for(const list of document.querySelectorAll('[class*="VideoMaterial_videoList"]'))for(const child of list.children){const ids=identifiers(child,'contentId');if(ids.size===1)child.setAttribute('data-full-content-id',[...ids][0]);else child.removeAttribute('data-full-content-id');}
 for(const row of document.querySelectorAll('tr,.next-table-row,.next-drawer,.next-dialog,[role="dialog"]')){const ids=identifiers(row,'itemId');if(ids.size===1)row.setAttribute('data-full-product-id',[...ids][0]);else row.removeAttribute('data-full-product-id');}
})();
