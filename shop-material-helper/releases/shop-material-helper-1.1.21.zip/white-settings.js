(function(root){
'use strict';
const key='material-feature-settings-v1',extension=!!root.chrome?.runtime?.id;
const read=async()=>extension?(await root.chrome.storage.local.get(key))[key]||{}:JSON.parse(root.localStorage.getItem(key)||'{}');
async function init(){
 let current=await read();
 const adapter={
  settings:()=>current,
  async saveSettings(patch){
   if(extension)await root.FullStateStore.update(key,previous=>({...previous,...patch}));
   else{const save=async()=>{const latest=await read();root.localStorage.setItem(key,JSON.stringify({...latest,...patch}));};if(root.navigator?.locks?.request)await root.navigator.locks.request('material-state:'+key,{mode:'exclusive'},save);else await save();}
   const saved=await read();
   if(Object.entries(patch).some(([field,value])=>JSON.stringify(saved[field])!==JSON.stringify(value)))throw Error('设置保存后读回不一致，请核对后重试。');
   current=saved;
  },
  closeSettings:()=>root.location.assign('panel.html')
 };
 root.FullWhiteUI.install(adapter,document.querySelector('#run-mode'),root.FullRunModes.SORTS,()=>[],{standalone:true}).openSettings();
}
init().catch(error=>{const status=document.querySelector('#settings-loading');if(status){status.setAttribute('role','alert');status.textContent='白底图设置读取失败：'+error.message;}});
})(globalThis);
