'use strict';
async function studioBatchTick(batchId){
 if(studioBatchBusy.size||queueBusy)return;studioBatchBusy.add(batchId);let batch;
 try{batch=(await studioBatchRuns()).find(value=>value.batchId===batchId);if(!batch?.enabled)return;const item=batch.items[batch.position];if(!item){batch.status='completed';batch.enabled=false;await studioBatchSave(batch);return;}
  let task=((await chrome.storage.local.get(STUDIO_KEY))[STUDIO_KEY]||[]).find(value=>value.requestId===item.requestId);
  if(!task&&batch.draining){batch.enabled=false;batch.status='drained';await studioBatchSave(batch);return;}
  if(!task){task=await executionGate(()=>studioRegister(batch.requests[batch.position],batch.batchId));}
  else studioLive.set(task.requestId,batch.requests[batch.position]);
  if(task.status!=='verified')await studioTick(task.requestId);
  task=((await chrome.storage.local.get(STUDIO_KEY))[STUDIO_KEY]||[]).find(value=>value.requestId===item.requestId);item.status=task.status;item.error=task.error||'';item.taskOutcome=globalThis.FullTaskFailures?.outcome(task);if(task.receipt)item.receipt=task.receipt;
  if(task.status==='verified'){batch.requests[batch.position].images=[];batch.position++;batch.error='';if(batch.position===batch.items.length){batch.status='completed';batch.enabled=false;}else if(batch.draining){batch.status='drained';batch.enabled=false;}}
  else if(task.status==='submitted_unconfirmed'){item.queries=(item.queries||0)+1;if(item.queries>=10){batch.enabled=false;batch.status='submitted_unconfirmed';batch.error='原组发布未确认，后续组暂停；继续时先回查原组。';}}
  else if(['blocked','prepared','failed','stopped'].includes(task.status)){batch.status='blocked';batch.enabled=false;batch.error=task.error||'当前组未核验，未派发后续组。';}
  await studioBatchSave(batch);
 }catch(error){if(batch){batch.status='blocked';batch.enabled=false;batch.error=error.message;await studioBatchSave(batch);}}finally{studioBatchBusy.delete(batchId);if(batch&&!batch.enabled)await chrome.alarms.clear('studio-publish-batch:'+batchId);}
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(sender.id!==chrome.runtime.id)return false;
 if(message.type==='FULL_STUDIO_PUBLISH_BATCH'){
  executionGate(async()=>{
   if(!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(message.batchId||'')||!Array.isArray(message.requests)||!message.requests.length||message.requests.length>100||new Set(message.requests.map(r=>r.requestId)).size!==message.requests.length)throw Error('批量发布须有唯一编号和1至100个独立请求。');
   if(JSON.stringify(message.requests).length>48*1024*1024)throw Error('本批图片超过48MB，请减少组数后分别确认。');
   for(const r of message.requests)if(!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(r.requestId||'')||r.module!=='fission'||!['new','replace'].includes(r.mode)||r.consent!==true||!/^\d{6,}$/.test(r.productId||'')||!Array.isArray(r.images)||!r.images.length||r.images.length>9||new Set(r.images.map(im=>im.id)).size!==r.images.length||r.images.some(im=>!im.id||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(im.data||'')||im.data.length>8*1024*1024))throw Error('某组商品、图片或新增/替换授权无效，整批未登记。');
   const fingerprint=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(message.requests))))].map(n=>n.toString(16).padStart(2,'0')).join('');
   const previous=(await studioBatchRuns()).find(value=>value.batchId===message.batchId);if(previous){if(previous.fingerprint!==fingerprint)throw Error('原批次范围、图片或选项已变化，未重复派单。');reply(studioBatchPublic(previous));return;}
   if(queueBusy||await additionalExecutionActive()||(await autoRuns()).some(r=>r.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled))throw Error('已有自动任务或发布批次，请先完成或停止。');
   const batch={batchId:message.batchId,fingerprint,requests:message.requests.map(r=>({...r,type:'FULL_STUDIO_PUBLISH'})),items:message.requests.map(r=>({requestId:r.requestId,status:'draft'})),position:0,status:'running',enabled:true,createdAt:new Date().toISOString()};await studioBatchSave(batch);await chrome.alarms.create('studio-publish-batch:'+batch.batchId,{when:Date.now()+100,periodInMinutes:.5});reply(studioBatchPublic(batch));
  }).catch(error=>reply({ok:false,error:error.message}));return true;
 }
 if(message.type==='FULL_STUDIO_PUBLISH_BATCH_STATUS'){
  studioBatchRuns().then(batches=>{const batch=batches.find(value=>value.batchId===message.batchId);reply(batch?studioBatchPublic(batch):{ok:false,error:'未找到原发布批次。'});}).catch(error=>reply({ok:false,error:error.message}));return true;
 }
 if(['FULL_STUDIO_PUBLISH_BATCH_STOP','FULL_STUDIO_PUBLISH_BATCH_RESUME'].includes(message.type)){
  executionGate(async()=>{const resume=message.type.endsWith('_RESUME');if(resume&&(queueBusy||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||await studioBatchConflict(message.batchId)||(await flowRuns()).some(r=>r.enabled)||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled)||(await autoRuns()).some(r=>r.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled)))throw Error('已有其他任务，未恢复发布。');let result;await FullStateStore.update(STUDIO_BATCH_KEY,batches=>{const batch=batches?.find(value=>value.batchId===message.batchId);if(!batch)throw Error('原发布批次不存在。');if(batch.status==='completed'){result=batch;return batches;}batch.enabled=resume;batch.status=resume?'running':'stopped';batch.error='';if(resume&&batch.items[batch.position])batch.items[batch.position].queries=0;result=batch;return batches;});if(result.enabled)await chrome.alarms.create('studio-publish-batch:'+result.batchId,{when:Date.now()+100,periodInMinutes:.5});else await chrome.alarms.clear('studio-publish-batch:'+result.batchId);reply(studioBatchPublic(result));}).catch(error=>reply({ok:false,error:error.message}));return true;
 }
 return false;
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name.startsWith('studio-publish-batch:'))studioBatchTick(alarm.name.slice(21)).catch(()=>{});});
