(function(root){
 'use strict';
 const supported=['white','scene'];
 function scope(run){return JSON.stringify({module:run.module,ids:run.ids,maxCalls:run.maxCalls,palette:run.palette,autoPublish:run.autoPublish});}
 function create(module,selection){
  if(!supported.includes(module))throw new Error('此模块的自动执行链路尚未接通。');
  const ids=root.FullCore.ids(selection.ids.join('\n')),maxCalls=Number(selection.maxCalls);
  if(!Number.isInteger(maxCalls)||maxCalls<1||maxCalls>100||!['yes','no'].includes(selection.palette)||selection.startConsent!==true)throw new Error('请核对本批次数上限、色调和执行范围。');
  const run={id:crypto.randomUUID(),module,ids,maxCalls,palette:selection.palette,autoPublish:selection.autoPublish===true,usedCalls:0,position:0,status:'running',enabled:true,items:ids.map(productId=>({productId,phase:'preflight',status:'pending'})),events:[],createdAt:new Date().toISOString()};run.consentScope=scope(run);return run;
 }
 async function advance(run,io){
  if(!run.enabled||run.status==='done')return;
  if(run.consentScope!==scope(run)){run.enabled=false;run.status='blocked';run.error='范围或执行设置已改变，请重新开始。';await io.save(run);return;}
  const item=run.items[run.position];if(!item){run.status='done';run.enabled=false;await io.save(run);return;}
  if(run.draining&&['preflight','reference','generate'].includes(item.phase)&&!item.submissionIntent){run.status='drained';run.enabled=false;await io.save(run);return;}
  const record=async(phase,detail)=>{item.phase=phase;run.events.push({time:new Date().toISOString(),productId:item.productId,phase,detail});await io.save(run);};
  const next=async(status,detail)=>{item.status=status;item.detail=detail;run.position++;await record('done',detail);if(run.position===run.items.length){run.enabled=false;run.status='done';await io.save(run);}};
  try{
   if(item.phase==='preflight'){
    const found=await io.preflight(run,item);if(!run.enabled)return;
    if(found.productId!==item.productId)throw new Error('商品检索结果与输入 ID 不一致。');
    if(found.saleState==='not_found')return await next('skipped','按指定 ID 搜索未命中，跳过，不扫描全店。');
    if(found.saleState==='off_sale')return await next('skipped','商品已下架或在仓库，跳过。');
    if(found.saleState!=='on_sale')throw new Error('未确认商品在售状态，尚未生成。');
    if(found.slotState==='occupied')return await next('skipped','已有对应图片，跳过，不覆盖。');
    if(found.slotState!=='empty')throw new Error('未确认明确空槽，尚未生成。');
    item.product=found;await record('reference','目标在售且槽位明确为空。');return;
   }
   if(item.phase==='reference'){
    const reference=await io.reference(run,item);if(!run.enabled)return;
    if(reference.productId!==item.productId||!reference.data?.startsWith('data:image/'))throw new Error('参考图未明确属于目标商品。');
    item.reference=reference;item.job=await io.createJob(run,item);await record('generate','已取得同商品参考图并登记原任务编号。');return;
   }
   if(item.phase==='generate'){
    if(item.submissionIntent){await record('poll','恢复原任务，只查询，不重复生成。');return;}
    if(run.usedCalls>=run.maxCalls)throw new Error('本批生成次数已达上限，后续未生成。');
    item.submissionIntent={id:item.job.assets[0].id,at:new Date().toISOString()};run.usedCalls++;await record('poll','已登记单次生图意图。');
    if(!run.enabled)return;await io.submit(run,item);return;
   }
   if(item.phase==='poll'){
    const result=await io.query(run,item);if(!run.enabled)return;
    if(result.status==='completed'&&result.available){item.job.assets[0]={...item.job.assets[0],...result};item.job.status='generated';await io.saveJob(item.job);await record('recheck','原素材已下载验证，回查目标状态。');return;}
    if(['failed','submission_unconfirmed','not_completed','downloaded_unverified'].includes(result.status))throw new Error('生成状态为 '+result.status+'，只保留原编号，不重新提交。');
    item.status='generating';await io.save(run);return;
   }
   if(item.phase==='recheck'){
    const found=await io.preflight(run,item);if(!run.enabled)return;
    if(found.productId!==item.productId||found.saleState!=='on_sale')throw new Error('生成后商品在售状态变化，保留素材，不写入。');
    if(found.slotState==='occupied')return await next('skipped','生成期间该槽已有图片，保留素材，不覆盖。');
    if(found.slotState!=='empty')throw new Error('生成后空槽状态未确认，保留素材，不写入。');
    if(!run.autoPublish)return await next('generated','素材已生成，按本批设置等待人工审看。');
    await record('publish','开始自动上传并补空槽。');return;
   }
   if(item.phase==='publish'){
    if(item.publishAttempted&&!io.loadJob)throw new Error('恢复发布必须先读取权威任务记录，未重复提交。');
    if(io.loadJob){
     const durable=await io.loadJob(item.job.id);
     if(!durable||durable.id!==item.job.id||durable.module!==run.module||durable.productIds?.length!==1||durable.productIds[0]!==item.productId||JSON.stringify(durable.assets?.map(asset=>asset.id))!==JSON.stringify(item.job.assets.map(asset=>asset.id)))throw new Error('权威任务记录缺失或范围冲突，未重复提交。');
     item.job=durable;
    }
    item.publishAttempted=true;await record('publish','已读取权威上传与提交意图，恢复时只回查原记录。');if(!run.enabled)return;
    const result=await io.publish(run,item);if(!run.enabled)return;
    if(result.status!=='verified')throw new Error('上传或绑定结果尚未核验，后续暂停，只回查原记录。');
    if(result.receipt)item.receipt=structuredClone(result.receipt);await next('verified','图片已绑定，商品、素材 URL 和内容编号回查通过。');
   }
  }catch(error){run.status='blocked';run.enabled=false;run.error=error.message;item.status='blocked';item.detail=error.message;await io.save(run);}
 }
 root.FullAutoRun={supported,scope,create,advance};if(typeof module!=='undefined')module.exports=root.FullAutoRun;
})(globalThis);
