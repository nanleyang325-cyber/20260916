(function(root){
 'use strict';
 async function collect(run,io){
  const scan=run.whiteScan||(run.whiteScan={version:1,complete:false,pages:[],targets:[],currentPage:1});
  const live=async()=>{if(run.enabled===false||io.isLive&&!await io.isLive(run))throw Object.assign(Error('全量扫描已暂停；保留已读页和商品，不开始生成。'),{stopped:true});};
  if(scan.complete)return structuredClone(scan.targets);
  await live();
  if(scan.pages.length){await io.restore(scan.currentPage);}else await io.prepare();
  await live();
  while(true){
   const result=await io.page();await live();const p=result?.page;
   if(!p||!Number.isInteger(p.number)||p.number<1||typeof p.hasNext!=='boolean'||!Array.isArray(result.targets))throw Error('全量分页信息未确认，未将部分商品当成全量。');
   if(p.totalPages!==null&&p.totalPages!==undefined&&(!Number.isInteger(p.totalPages)||p.totalPages<p.number))throw Error('全量分页总页数无效。');
   if(result.targets.some(t=>t.productIds?.length!==1||!/^\d{6,}$/.test(t.productIds[0])))throw Error('全量扫描商品身份不明确。');
   if(scan.pages.some(x=>x.number!==p.number&&x.signature===p.signature))throw Error('全量分页结果重复，已保留已读商品。');
   const saved=scan.pages.find(x=>x.number===p.number);
   if(saved&&saved.signature!==p.signature)throw Error('已读分页内容发生变化，停止扫描，未宣称找全。');
   if(!saved){
    if(p.number!==(scan.pages.at(-1)?.number||0)+1)throw Error('全量扫描页码不连续。');
    scan.pages.push({number:p.number,signature:p.signature});
    const seen=new Set(scan.targets.map(t=>t.productIds[0]));for(const target of result.targets)if(!seen.has(target.productIds[0])){seen.add(target.productIds[0]);scan.targets.push(structuredClone(target));}
   }
   scan.currentPage=p.number;
   run.whitePaging={...(run.whitePaging||{}),strategy:'snapshot',currentPage:p.number,hasNext:p.hasNext,exhausted:false,pageSignature:p.signature,seenPages:scan.pages.map(x=>x.signature)};
   run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail:'全量只读扫描第'+p.number+(p.totalPages?' / '+p.totalPages:'')+'页，累计发现 '+scan.targets.length+' 个'+(io.label||'缺白底图')+'商品；'+(io.pendingText||'尚未开始生成。')});
   if(!p.hasNext){
    if(p.totalPages&&p.number!==p.totalPages)throw Error('分页尚未到末页但下一页不可用，未宣称全量完成。');
    scan.complete=true;run.whitePaging.exhausted=true;run.whitePaging.hasNext=false;
    await io.save(run);await live();return structuredClone(scan.targets);
   }
   if(p.totalPages&&p.number>=p.totalPages)throw Error('末页与下一页状态矛盾。');
   await io.save(run);await live();const next=await io.next();await live();
   if(next?.done||next?.number!==p.number+1)throw Error('下一页翻页未确认；已读结果未当作全量。');
  }
 }
 root.FullWhiteScan={collect};if(typeof module==='object')module.exports=root.FullWhiteScan;
})(globalThis);
