(function(root){
 'use strict';
 const MODES=Object.freeze([
  Object.freeze({key:'market',name:'市场趋势',moduleType:1,mode:'batch',singleBatch:false}),
  Object.freeze({key:'similar',name:'相似款稀缺',moduleType:3,mode:'batch',singleBatch:true}),
  Object.freeze({key:'scarce',name:'同款稀缺',moduleType:4,mode:'per-row',singleBatch:false})
 ]);
 const SCOPE_FIELDS=['shopId','tabId','windowId','sectionKey','activityId','opportunityType'];
 const TERMINAL_INTENTS=new Set(['confirmed','rejected','not_submitted']);
 const BLOCKING_ERRORS=new Set(['LOGIN_REQUIRED','SHOP_MISMATCH','CAPTCHA','SCOPE_MISMATCH','PERMISSION_DENIED','UNKNOWN_SECTION']);
 const copy=x=>structuredClone(x);
 const stamp=()=>new Date().toISOString();
 const makeId=()=>crypto.randomUUID();
 const present=x=>x!==undefined&&x!==null&&String(x).trim()!=='';
 const ids=value=>Array.isArray(value)?[...new Set(value.map(String))].sort():[];
 const validIds=value=>Array.isArray(value)&&value.length>0&&value.every(v=>/^\d{6,}$/.test(String(v)));
 const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
 function scopeKey(scope){return JSON.stringify(SCOPE_FIELDS.map(k=>present(scope?.[k])?(['tabId','windowId'].includes(k)?scope[k]:String(scope[k])):null));}
 function scopeMatches(a,b,fields=SCOPE_FIELDS){return fields.every(k=>present(a?.[k])&&present(b?.[k])&&(['tabId','windowId'].includes(k)?Number.isInteger(a[k])&&a[k]===b[k]:String(a[k])===String(b[k])));}
 function baseScope(run){return run.trend.scope;}
 function currentSection(run){return run.trend.sections[run.trend.sectionIndex]||null;}
 function context(run){const section=currentSection(run),op=run.trend.opportunity;return {...baseScope(run),...(section?{sectionKey:section.key}:{}),...(op?{activityId:op.activityId,opportunityType:op.opportunityType}:{})};}
 function activeItem(run){return run.items.find(i=>i.id===run.trend.activeIntentId)||null;}
 function unsettled(run){const item=activeItem(run);return item?.intent&&!TERMINAL_INTENTS.has(item.intent.state)?item:null;}
 function needsReadback(run){const item=unsettled(run);return !!item&&item.intent.state!=='prepared';}
 function event(run,detail,extra={},at=stamp()){run.events.push({at,phase:run.phase,position:run.position,detail,...extra});}
 function block(run,code,message,at){message=typeof message==='string'?message:message?.message||'平台状态尚未明确，原任务保留。';run.status='blocked';run.enabled=false;run.error=message;run.trend.error={code,message};event(run,message,{code},at);}
 function complete(run,at){run.phase='done';run.status='done';run.enabled=false;run.error='';event(run,'本轮趋势提报已结束；成功、失败和跳过原因见逐批记录，未调用生图。',{},at);}
 function advanceSection(run,at){run.trend.sectionIndex++;run.trend.opportunity=null;run.trend.opportunityCursor=null;run.trend.pageCursor=null;run.trend.seenOpportunityCursors=[];if(currentSection(run)){run.phase='opportunity';event(run,'继续分类：'+currentSection(run).name,{},at);}else complete(run,at);}
 function finishOpportunity(run,at){const op=run.trend.opportunity;if(op){const key=scopeKey(context(run));if(!run.trend.processedActivities.includes(key))run.trend.processedActivities.push(key);run.trend.stats.trendsProcessed++;}run.trend.preflightConsecutiveChanges=0;run.trend.opportunity=null;run.trend.pageCursor=null;if(op?.last)advanceSection(run,at);else{run.trend.opportunityCursor=op?.nextCursor??null;run.phase='opportunity';}}
 function nextPage(run,result,at){if(result.nextCursor===undefined){block(run,'PAGE_STATE_UNKNOWN','候选商品分页结果不明确，保留当前位置。',at);return;}if(result.nextCursor===null){finishOpportunity(run,at);return;}const key=JSON.stringify(result.nextCursor);if(run.trend.seenPageCursors.includes(key)){block(run,'PAGE_LOOP','候选商品分页重复，已停止继续提报。',at);return;}run.trend.seenPageCursors.push(key);run.trend.pageCursor=copy(result.nextCursor);run.phase='page';}
 function create({id,selection={},workTab={},createdAt}={}){
  const shopId=selection.shopId??workTab.shopId,tabId=workTab.tabId??workTab.id,windowId=workTab.windowId;
  if(!present(shopId)||!Number.isInteger(tabId)||tabId<0||!Number.isInteger(windowId)||windowId<0)throw Error('趋势任务必须绑定明确的店铺、原标签页和窗口。');
  const at=createdAt||stamp();
  return {id:id||makeId(),kind:'trend',module:'trend',selection:copy({...selection,paidGeneration:false}),workTab:copy({...workTab,tabId,windowId}),createdAt:at,status:'running',enabled:true,phase:'sections',position:0,items:[],events:[],usedCalls:0,usedCallsByType:{image:0,video:0,text:0},error:'',trend:{schema:1,scope:{shopId:String(shopId),tabId,windowId},sections:[],sectionIndex:0,opportunity:null,opportunityCursor:null,pageCursor:null,seenOpportunityCursors:[],seenPageCursors:[],processedActivities:[],processedProducts:[],activeIntentId:null,controlRevision:0,stats:{trendsProcessed:0,submitted:0,skipped:0,failed:0},consecutiveFailures:0}};
 }
 function assertRun(run){if(run?.module!=='trend'||run.kind!=='trend'||run.trend?.schema!==1)throw Error('不是可恢复的趋势提报任务。');if(run.usedCalls!==0||Object.values(run.usedCallsByType||{}).some(v=>v!==0))throw Error('趋势提报不能包含生图或视频生成调用。');}
 function skippedKey(activityId,productId){return String(activityId)+'|'+String(productId);}
 function restoreSkipped(run){if(Array.isArray(run.trend.skippedProducts))return;run.trend.skippedProducts=[...new Set(run.events.filter(e=>/^跳过商品 /.test(e.detail||'')&&present(e.activityId)&&present(e.productId)).map(e=>skippedKey(e.activityId,e.productId)))];run.trend.stats.skipped=run.trend.skippedProducts.length;}
 function explicitFailure(run,result,at){
  const code=result.code||result.error?.code||'PLATFORM_ERROR',message=typeof result.error==='string'?result.error:result.error?.message||result.message||'平台返回明确错误。';
  run.trend.stats.failed++;run.trend.consecutiveFailures++;event(run,'趋势提报失败：'+message,{code,consecutiveFailures:run.trend.consecutiveFailures},at);
  if(BLOCKING_ERRORS.has(code)){block(run,code,message,at);return;}
  if(run.trend.opportunity)finishOpportunity(run,at);else advanceSection(run,at);
  if(run.trend.consecutiveFailures>=20)block(run,code,'连续 20 次失败，已停止后续提报：'+message,at);
 }
 function verifyReadScope(run,result,full=false){return scopeMatches(result?.scope,context(run),full?SCOPE_FIELDS:currentSection(run)?['shopId','tabId','windowId','sectionKey']:['shopId','tabId','windowId']);}
 function confirmedEvidence(item,result){return result?.intentId===item.intent.id&&scopeMatches(result.scope,item.intent.scope)&&validIds(result.productIds)&&equal(ids(result.productIds),item.intent.productIds)&&present(result.receipt?.api)&&present(result.receipt?.platformStatus);}
 function applyBatchResult(run,result,at){
  const item=activeItem(run)||run.items.find(i=>i.intent?.id===result?.intentId);if(!item)throw Error('趋势提报意向记录缺失。');if(TERMINAL_INTENTS.has(item.intent.state))return;
  if(result?.status==='not_submitted'){
   if(result.code!=='CANDIDATE_CHANGED'||!['candidate-preflight-v2','legacy-candidate-preflight-v1'].includes(result.proofOrigin)||result.dispatchNeverStarted!==true||result.intentId!==item.intent.id||!scopeMatches(result.scope,item.intent.scope)||!validIds(result.productIds)||result.productIds.length!==item.intent.productIds.length||!equal(ids(result.productIds),item.intent.productIds)){block(run,'NOT_SUBMITTED_PROOF_MISSING','未发送提报的证据与原批次不符，保留原意向，仅允许回查。',at);return;}
   const previousState=item.intent.state;item.intent.state='not_submitted';item.status='cancelled_before_submit';item.phase='done';item.detail='提交前候选集合变化，本批未发送；保留原计划并重新读取本活动商品集合。';item.error=item.detail;item.preflight={code:result.code,dispatchNeverStarted:true,checkedAt:at,proofOrigin:result.proofOrigin,previousState,scope:copy(item.intent.scope),productIds:[...item.intent.productIds],pageKey:item.intent.pageKey};
   run.trend.activeIntentId=null;run.position=run.items.length;run.trend.pageCursor=null;run.trend.seenPageCursors=[];run.phase='page';run.trend.preflightConsecutiveChanges=(run.trend.preflightConsecutiveChanges||0)+1;event(run,item.detail,{code:result.code,intentId:item.intent.id,activityId:item.intent.scope.activityId},at);
   if(run.trend.preflightConsecutiveChanges>=3)block(run,'CANDIDATE_CHANGING','候选集合连续变化，尚未发送本批；原任务已保留，等待集合稳定后继续。',at);return;
  }
  if(['confirmed','rejected'].includes(result?.status)){
   if(!confirmedEvidence(item,result)){item.intent.state='unknown';item.status='pending_confirmation';item.detail='平台回执与原活动、商品或提交编号不一致，保留原提交。';run.phase='readback';block(run,'RECEIPT_SCOPE_MISMATCH',item.detail,at);return;}
   item.intent.state=result.status;item.receipt={...copy(result.receipt),source:'platform-readback',resultKind:'trend-report',intentId:item.intent.id,scope:copy(item.intent.scope),activityId:item.intent.scope.activityId,productIds:[...item.intent.productIds]};
   if(result.status==='confirmed'){
    item.phase='done';item.status='verified';item.detail='已核对活动和本批全部商品：'+result.receipt.platformStatus+'。';
    run.trend.stats.submitted+=item.productIds.length;run.trend.consecutiveFailures=0;run.trend.preflightConsecutiveChanges=0;
    for(const productId of item.productIds){const key=scopeKey(item.intent.scope)+'|'+productId;if(!run.trend.processedProducts.includes(key))run.trend.processedProducts.push(key);}
    event(run,item.detail,{activityId:item.intent.scope.activityId,productIds:[...item.productIds],receipt:copy(item.receipt)},at);
    run.trend.activeIntentId=null;run.position=run.items.length;
    if(currentSection(run)?.singleBatch)finishOpportunity(run,at);
    else if(currentSection(run)?.mode==='batch')nextPage(run,{nextCursor:item.context.nextCursor},at);
    else run.phase='page';
   }else{item.status='failed';item.phase='done';item.detail=typeof result.error==='string'?result.error:'平台已明确拒绝本批提报。';run.trend.activeIntentId=null;run.position=run.items.length;explicitFailure(run,result,at);}
   return;
  }
  if(result?.status==='submitted'||result?.status==='pending'){
   if(result.intentId!==item.intent.id||!scopeMatches(result.scope,item.intent.scope)){item.intent.state='unknown';item.status='pending_confirmation';run.phase='readback';block(run,'RECEIPT_SCOPE_MISMATCH','提交回执身份不一致，保留原意向，仅允许回查。',at);return;}
   item.intent.state='submitted';item.phase='readback';item.status='pending_confirmation';item.detail='已提交，等待同活动、同批商品的官方回查。';run.phase='readback';event(run,item.detail,{intentId:item.intent.id},at);return;
  }
  item.intent.state='unknown';item.phase='readback';item.status='pending_confirmation';item.detail=typeof result?.error==='string'?result.error:'原批次提交结果尚未确认；继续时只回查，不重复提报。';run.phase='readback';block(run,result?.code||'SUBMISSION_UNKNOWN',item.detail,at);
 }
 function reduce(original,action){
  assertRun(original);const run=copy(original),at=action.at||stamp();restoreSkipped(run);
  if(action.type==='control'){
   if(!['pause','resume','stop'].includes(action.action))throw Error('未知趋势任务控制动作。');
   run.trend.controlRevision++;
   if(action.action==='resume'){
    if(run.status==='done')return run;
    if(run.phase==='done'){complete(run,at);return run;}
    // The legacy adapter emitted this exact guard before entering dispatch.
    // Transport errors or an unknown POST result never qualify for this recovery.
    const item=activeItem(run),sent=item&&(item.receipt||item.intent.sentAt||item.intent.dispatchedAt||run.events.some(e=>e.intentId===item.intent.id&&e.detail==='已提交，等待同活动、同批商品的官方回查。'));if(!sent&&run.trend.error?.code==='CANDIDATE_CHANGED'&&item?.intent?.state==='unknown'&&item.detail==='本批商品资格或页集合已变化，未提交；继续时先回查。')applyBatchResult(run,{status:'not_submitted',code:'CANDIDATE_CHANGED',dispatchNeverStarted:true,proofOrigin:'legacy-candidate-preflight-v1',intentId:item.intent.id,scope:item.intent.scope,productIds:item.intent.productIds},at);
    run.status='running';run.enabled=true;run.error='';delete run.trend.error;
    if(needsReadback(run))run.phase='readback';event(run,needsReadback(run)?'继续原任务：仅核对原批次提报结果，不重复提交。':'继续原趋势任务。',{},at);
   }else{run.status=action.action==='stop'?'stopped':'paused';run.enabled=false;event(run,action.action==='stop'?'已停止后续提报；原批次意向和回查记录保留。':'已暂停趋势提报。',{},at);}
   return run;
  }
  const result=action.result||{};
  if(action.type==='sections'){
   if(!verifyReadScope(run,result)){block(run,'SCOPE_MISMATCH','分类读取未核对当前店铺、原标签页和窗口。',at);return run;}
   if(result.status==='error'){block(run,result.code||'SECTION_ERROR',result.error||'分类读取失败。',at);return run;}
   if(result.status==='empty'&&result.complete===true&&Array.isArray(result.sections)&&result.sections.length===0){complete(run,at);return run;}
   if(result.status!=='ready'||!Array.isArray(result.sections)||!result.sections.length||result.sections.some(s=>!MODES.some(m=>m.key===s.key))||new Set(result.sections.map(s=>s.key)).size!==result.sections.length){block(run,'UNKNOWN_SECTION','趋势分类尚未就绪或出现未知分类，不能记为空列表完成。',at);return run;}
   const available=new Set(result.sections.map(s=>s.key)),active=result.sections.find(s=>s.active)?.key||result.activeKey||MODES.find(s=>available.has(s.key))?.key;
   const start=MODES.findIndex(s=>s.key===active);
   if(start<0||!available.has(active)){block(run,'UNKNOWN_SECTION','当前趋势分类起点无法确认。',at);return run;}
   run.trend.sections=MODES.slice(start).filter(s=>available.has(s.key)).map(copy);run.trend.sectionIndex=0;run.phase='opportunity';event(run,'从当前分类开始：'+currentSection(run).name,{},at);return run;
  }
  if(action.type==='opportunity'){
   if(!verifyReadScope(run,result)){block(run,'SCOPE_MISMATCH','趋势主题读取与原分类、店铺或标签页不符。',at);return run;}
   if(result.status==='error'){explicitFailure(run,result,at);return run;}
   if(result.status==='end'||result.status==='empty'){advanceSection(run,at);return run;}
   const op=result.opportunity,section=currentSection(run);
   if(result.status!=='ready'||!present(op?.activityId)||!present(op.opportunityType)||result.nextCursor===undefined){block(run,'OPPORTUNITY_UNKNOWN','趋势活动身份、类型或分页未明确，已保留当前位置。',at);return run;}
   const opScope={...baseScope(run),sectionKey:section.key,activityId:String(op.activityId),opportunityType:String(op.opportunityType)};
   if(run.trend.processedActivities.includes(scopeKey(opScope))){block(run,'OPPORTUNITY_LOOP','平台再次返回已处理的同一活动，已停止以免循环提报。',at);return run;}
   run.trend.opportunity={...copy(op),activityId:String(op.activityId),opportunityType:String(op.opportunityType),nextCursor:copy(result.nextCursor),last:result.nextCursor===null};run.trend.pageCursor=null;run.trend.seenPageCursors=[];run.phase='page';event(run,'检查趋势活动：'+(op.title||op.activityId),{activityId:String(op.activityId),sectionKey:section.key},at);return run;
  }
  if(action.type==='page'){
   if(!verifyReadScope(run,result,true)){block(run,'SCOPE_MISMATCH','候选商品页与原活动、店铺或标签页不一致。',at);return run;}
   if(result.status==='error'){explicitFailure(run,result,at);return run;}
   if(result.status==='end'){finishOpportunity(run,at);return run;}
   if(result.status==='empty'){nextPage(run,result,at);return run;}
   if(result.status!=='ready'||!present(result.pageKey)||!Array.isArray(result.items)||result.nextCursor===undefined||result.items.some(i=>!/^\d{6,}$/.test(String(i?.productId||''))||typeof i.eligible!=='boolean')){block(run,'PAGE_UNKNOWN','候选商品集合或分页未明确，不能直接跳过或提报。',at);return run;}
   const scope=context(run),seen=new Set(),fresh=[];
   for(const item of result.items){const productId=String(item.productId),key=scopeKey(scope)+'|'+productId;if(seen.has(productId))continue;seen.add(productId);if(run.trend.processedProducts.includes(key))continue;if(!item.eligible){const skip=skippedKey(scope.activityId,productId);if(!run.trend.skippedProducts.includes(skip)){run.trend.skippedProducts.push(skip);run.trend.stats.skipped++;event(run,'跳过商品 '+productId+'：'+(item.reason||'平台标记不可提报。'),{productId,activityId:scope.activityId},at);}continue;}fresh.push(productId);}
   if(!fresh.length){nextPage(run,result,at);return run;}
   const productIds=ids(currentSection(run).mode==='per-row'?fresh.slice(0,1):fresh),intentId=action.intentId;
   if(!present(intentId))throw Error('生成提报意向前必须提供唯一编号。');
   const intent={id:intentId,scope:copy(scope),productIds,pageKey:result.pageKey,createdAt:at,state:'prepared'};
   run.items.push({id:intentId,productIds:[...productIds],context:{...copy(scope),mode:currentSection(run).mode,pageKey:result.pageKey,cursor:copy(run.trend.pageCursor),nextCursor:copy(result.nextCursor)},phase:'submit',status:'pending',intent,detail:'本批活动和商品范围已冻结，尚未提交。'});
   run.trend.activeIntentId=intentId;run.position=run.items.length-1;run.phase='submit';event(run,'已冻结本批 '+productIds.length+' 个商品，等待提交。',{intentId,activityId:scope.activityId,productIds},at);return run;
  }
  if(action.type==='submitResult'||action.type==='readbackResult'){applyBatchResult(run,result,at);return run;}
  throw Error('未知趋势任务状态变更。');
 }
 function summary(run){assertRun(run);return {id:run.id,status:run.status,phase:run.phase,...copy(run.trend.stats),consecutiveFailures:run.trend.consecutiveFailures,pendingConfirmation:run.items.filter(i=>i.status==='pending_confirmation').length,usedCalls:0};}
 function createRunner({load,save,io,now=stamp,id=makeId}){
  const busy=new Set(),writes=new Map(),controlRequests=new Map();
  function serial(runId,fn){const last=writes.get(runId)||Promise.resolve(),next=last.catch(()=>{}).then(fn);writes.set(runId,next);return next.finally(()=>{if(writes.get(runId)===next)writes.delete(runId);});}
  async function commit(run){return serial(run.id,async()=>{const current=await load(run.id);if(current&&current.trend.controlRevision>run.trend.controlRevision){run=copy(run);run.trend.controlRevision=current.trend.controlRevision;run.status=current.status;run.enabled=current.enabled;run.error=current.error;if(current.trend.error)run.trend.error=copy(current.trend.error);const controls=current.events.filter(e=>e.controlRevision>Number(run.trend.lastMergedControlRevision||0));for(const e of controls)if(!run.events.some(old=>equal(old,e)))run.events.push(copy(e));run.trend.lastMergedControlRevision=current.trend.controlRevision;}await save(run);return run;});}
  async function control(runId,action){controlRequests.set(runId,(controlRequests.get(runId)||0)+1);return serial(runId,async()=>{const run=await load(runId);if(!run)throw Error('原趋势任务不存在。');const next=reduce(run,{type:'control',action,at:now()});next.events[next.events.length-1].controlRevision=next.trend.controlRevision;await save(next);return next;});}
  async function step(runId){
   if(busy.has(runId))return {busy:true};busy.add(runId);const requestRevision=controlRequests.get(runId)||0;
   try{
    let run=await load(runId);if(!run)throw Error('原趋势任务不存在。');assertRun(run);if(!run.enabled)return run;
    if(needsReadback(run)&&run.phase!=='submit')run.phase='readback';
    let action,result;
    try{
     if(run.phase==='sections'){result=await io.scanSections(copy(run));action={type:'sections',result};}
     else if(run.phase==='opportunity'){result=await io.nextOpportunity(copy(run),{...context(run),cursor:copy(run.trend.opportunityCursor)});action={type:'opportunity',result};}
     else if(run.phase==='page'){result=await io.readPage(copy(run),{...context(run),cursor:copy(run.trend.pageCursor)});action={type:'page',result,intentId:id()};}
     else if(run.phase==='submit'){
      const item=activeItem(run);if(!item)throw Error('原批次提报意向不存在。');
      if(item.intent.state!=='prepared'){run.phase='readback';result=await io.readbackBatch(copy(run),copy(item.intent));action={type:'readbackResult',result};}
      else{
       item.intent.state='submitting';item.status='pending_confirmation';item.phase='readback';run.phase='readback';event(run,'提交意向已保存；中断后仅回查该批次，不重复提报。',{intentId:item.intent.id},now());
       run=await commit(run);const live=await serial(runId,()=>load(runId));if((controlRequests.get(runId)||0)!==requestRevision)return await serial(runId,()=>load(runId));if(!live.enabled||live.trend.controlRevision!==run.trend.controlRevision)return live;
       result=await io.submitBatch(copy(run),copy(activeItem(run).intent));action={type:'submitResult',result};
      }
     }else if(run.phase==='readback'){const item=activeItem(run);if(!item)throw Error('没有可回查的原批次。');result=await io.readbackBatch(copy(run),copy(item.intent));action={type:'readbackResult',result};}
     else return run;
    }catch(error){
     if(unsettled(run)){action={type:'readbackResult',result:{status:'unknown',code:error.code||'TRANSPORT_ERROR',error:error.message||String(error)}};}
     else{block(run,error.code||'READ_ERROR','读取趋势任务失败：'+(error.message||error),now());return await commit(run);}
    }
    run=reduce(run,{...action,at:now()});return await commit(run);
   }finally{busy.delete(runId);}
  }
  return {step,control,isBusy:runId=>busy.has(runId)};
 }
 function skipFailure(run,at=stamp()){
  const item=activeItem(run),section=currentSection(run);
  if(item)for(const pid of item.productIds||[]){const key=scopeKey(item.intent?.scope||context(run))+'|'+pid;if(!run.trend.processedProducts.includes(key))run.trend.processedProducts.push(key);}
  run.trend.activeIntentId=null;run.position=run.items.length;run.trend.stats.failed++;run.enabled=true;run.status='running';delete run.trend.error;
  if(item&&section?.mode==='per-row'){run.phase='page';return;}
  if(item&&section?.mode==='batch'&&!section.singleBatch&&item.context?.nextCursor!==undefined){nextPage(run,{nextCursor:item.context.nextCursor},at);if(run.status!=='blocked')return;}
  if(run.trend.opportunity)finishOpportunity(run,at);else if(section)advanceSection(run,at);else complete(run,at);
 }
 const api={MODES,create,reduce,scopeKey,scopeMatches,summary,createRunner,skipFailure};root.FullTrendRun=Object.freeze(api);if(typeof module==='object'&&module.exports)module.exports=api;
})(typeof globalThis==='object'?globalThis:this);
