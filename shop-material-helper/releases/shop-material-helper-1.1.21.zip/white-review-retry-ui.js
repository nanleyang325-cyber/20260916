(function(root){
 'use strict';if(!root.chrome?.runtime?.id)return;const api=root.FullWhiteRetry,owner=crypto.randomUUID(),seen=new Set();let busy=false,current=null,dialog=null;
 const button=document.createElement('button');button.id='btnRetryWhiteReview';button.type='button';button.textContent='审核仍不通过 · 继续采集其他素材';button.hidden=true;button.style.cssText='padding:12px;margin:8px 0;background:#a66b25;color:white;border:1px solid #bd8a45;border-radius:8px;cursor:pointer';(document.querySelector('.task-summary')||document.querySelector('#btnOpenLogDetails')?.parentElement||document.body).append(button);
 async function rpc(body){const result=await chrome.runtime.sendMessage(body);if(!result?.ok)throw Error(result?.error||'操作未确认，请查看原任务。');return result;}
 async function show(run,automatic){if(busy||dialog)return;const item=api.candidate(run);if(!item)return;const generationId=api.token(item),key=run.id+':'+generationId;if(automatic&&seen.has(key))return;busy=true;seen.add(key);try{if(automatic){const claim=await rpc({type:'FULL_WHITE_RETRY_CLAIM',runId:run.id,generationId,owner});if(!claim.offer)return;}if(document.querySelector('dialog[open]'))return;
  const d=document.createElement('dialog');dialog=d;d.id='white-review-retry-confirm';d.style.cssText='width:420px;max-width:calc(100vw - 24px);max-height:calc(100vh - 24px);overflow:auto;box-sizing:border-box;padding:20px;color:#eee;background:#191919;border:1px solid #ad7b39;border-radius:12px';
  const title=document.createElement('h3');title.textContent='审核仍不通过，是否继续采集？';
  const scope=document.createElement('p');scope.textContent='商品 '+item.productIds.join('、')+'；原因：'+(item.reviewOutcome.reason||'平台未提供具体原因');
  const note=document.createElement('p');note.textContent='继续后跳过此前用过的素材，按主图 → 详情图 → SKU 图寻找其他同商品图片。本次最多再生成一张，会产生一次生图费用；仍在原标签页执行。也可导入本地素材图作为参考。没有其他素材时停止并记录原因。';
  const status=document.createElement('p');status.id='white-retry-status';status.setAttribute('role','status');
  const actions=document.createElement('div');actions.style.cssText='display:flex;flex-wrap:wrap;gap:8px';
  const yes=document.createElement('button'),no=document.createElement('button'),importButton=document.createElement('button');yes.id='white-retry-continue';yes.textContent='继续采集';no.id='white-retry-stop';no.textContent='暂不继续';importButton.id='white-retry-import';importButton.textContent='导入素材图';
  const file=document.createElement('input');file.type='file';file.id='white-retry-file';file.accept='.png,.jpg,.jpeg,.webp';file.hidden=true;
  const previewBox=document.createElement('section');previewBox.hidden=true;previewBox.id='white-retry-import-preview';previewBox.style.cssText='margin:12px 0';
  const image=document.createElement('img');image.alt='已导入的素材图预览';image.style.cssText='display:block;width:100%;max-height:200px;object-fit:contain;background:#fff;border-radius:6px';
  const fileInfo=document.createElement('p'),label=document.createElement('label'),identity=document.createElement('input'),use=document.createElement('button');identity.type='checkbox';identity.id='white-retry-import-identity';label.append(identity,'我确认这是商品 '+item.productIds.join('、')+' 的素材图');label.style.display='block';use.id='white-retry-use-import';use.textContent='使用导入图重做';use.disabled=true;previewBox.append(image,fileInfo,label,use);
  for(const b of [yes,no,importButton,use])b.style.cssText='padding:10px;background:#a66b25;color:white;border:0;border-radius:6px;cursor:pointer';actions.append(yes,importButton,no);d.append(title,scope,note,status,actions,file,previewBox);document.body.append(d);d.showModal();
  let pending=false,uploading=false,asset=null;
  function controls(){yes.disabled=pending||uploading;no.disabled=pending;importButton.disabled=pending||uploading;file.disabled=pending||uploading;identity.disabled=pending||uploading;use.disabled=pending||uploading||!asset||!identity.checked;}
  const decide=async choice=>{if(pending||uploading&&choice!=='stop'||choice==='import'&&(!asset||!identity.checked))return;pending=true;controls();try{await rpc({type:'FULL_WHITE_RETRY_DECIDE',runId:run.id,generationId,choice,...(choice==='import'?{assetKey:asset.assetKey,identityConfirmed:true}:{})});d.close();d.remove();dialog=null;button.hidden=choice!=='stop';}catch(e){status.textContent=e.message;pending=false;controls();}};
  importButton.onclick=()=>file.click();identity.onchange=controls;use.onclick=()=>decide('import');
  file.onchange=async()=>{const selected=file.files?.[0];if(!selected||pending||uploading)return;asset=null;identity.checked=false;previewBox.hidden=true;uploading=true;controls();try{
   if(!['image/png','image/jpeg','image/webp'].includes(selected.type)||!selected.size||selected.size>6*1024*1024)throw Error('请选择 PNG、JPG 或 WebP 素材图，大小不超过 6MB。');
   const data=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('本地素材图读取失败，请重新选择。'));reader.readAsDataURL(selected);});
   status.textContent='正在校验导入素材，尚未开始生图…';const result=await rpc({type:'FULL_WHITE_RETRY_IMPORT',runId:run.id,generationId,fileName:selected.name,data});if(dialog!==d||pending)return;
   asset=result;image.src=result.preview;fileInfo.textContent=selected.name;previewBox.hidden=false;status.textContent='导入成功，请确认商品并点击“使用导入图重做”；确认前不会生图或上传店铺。';
  }catch(e){if(dialog===d)status.textContent=e.message;}finally{uploading=false;file.value='';controls();}};
  yes.onclick=()=>decide('continue');no.onclick=()=>decide('stop');d.oncancel=e=>{e.preventDefault();decide('stop');};
 }catch(e){button.title=e.message;}finally{busy=false;}}
 function render(run){current=run;const item=api.candidate(run);button.hidden=!item;if(item)show(run,true);}
 button.onclick=()=>show(current,false);root.addEventListener('material-run-state',e=>render(e.detail));
 const ready=root.FullLogDetailsUI?.ready||root.FullPopupUi?.ready||Promise.resolve();ready.then(()=>render(root.FullLogDetailsUI?.currentRun||root.FullPopupUi?.currentRun));
 root.FullWhiteRetryUI={render,get dialog(){return dialog;}};
})(globalThis);
