'use strict';
importScripts('review-rework.js');
const REVIEW_DRAFT='white-review-draft:',REVIEW_ASSET='white-review-asset:';
async function reviewRead(key){return (await chrome.storage.local.get(key))[key];}
async function reviewWrite(key,value){await chrome.storage.local.set({[key]:value});}
async function reviewIdle(){
 if(typeof executionPaused==='function'&&await executionPaused()||queueBusy||typeof f88HasActive==='function'&&await f88HasActive()||typeof kmtHasActive==='function'&&await kmtHasActive()||typeof studioBatchConflict==='function'&&await studioBatchConflict()||typeof studioBusy!=='undefined'&&studioBusy.size||typeof multiRuns==='function'&&(await multiRuns()).some(r=>r.enabled)||(await flowRuns()).some(r=>r.enabled)||(await autoRuns()).some(r=>r.enabled)||(await queueState())?.backgroundQueues?.some(q=>q.enabled))throw Error('已有流程正在运行，请先等待结束或暂停；不会接管正在处理的页面。');
}
async function reviewTab(id){
 const tab=await chrome.tabs.get(id),u=new URL(tab.url);
 if(tab.pendingUrl||u.protocol!=='https:'||!['qn.taobao.com','myseller.taobao.com'].includes(u.hostname)||u.pathname!=='/home.htm/material-center/material-management')throw Error('原素材中心标签页已关闭或改变，请回到素材中心重新打开此测试页。');
 return tab;
}
async function reviewSnapshot(tab,pid){return (await flowWhiteReviewScene({}, {module:'white',productIds:[pid]},'readReview','',tab)).scene;}
async function reviewDraft(id,check=true){
 const d=await reviewRead(REVIEW_DRAFT+id);if(!d||Date.now()-d.at>30*60000)throw Error('审核信息已过期，请重新读取平台原因。');
 if(check){const current=await reviewSnapshot(await reviewTab(d.tabId),d.snapshot.productId);if(!FullWhiteReview.same(d.snapshot,current)||current.review.reason!==d.snapshot.review.reason)throw Error('平台审核或拒绝原因已变化，请重新读取；未生成或覆盖。');}
 return d;
}
async function reviewAsset(data){
 if(typeof data!=='string'||data.length>9*1024*1024||!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(data))throw Error('请选择有效PNG、JPG或WebP图片，最大6MB。');
 const source=await (await fetch(data)).blob();if(source.size>6*1024*1024)throw Error('导入图超过6MB。');const bitmap=await createImageBitmap(source);
 try{if(bitmap.width<64||bitmap.height<64||bitmap.width>20000||bitmap.height>20000||bitmap.width*bitmap.height>50000000)throw Error('图片尺寸不适用。');const canvas=new OffscreenCanvas(800,800),c=canvas.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,800,800);const scale=Math.min(800/bitmap.width,800/bitmap.height),w=bitmap.width*scale,h=bitmap.height*scale;c.drawImage(bitmap,(800-w)/2,(800-h)/2,w,h);const blob=await canvas.convertToBlob({type:'image/png'});if(blob.size>=3*1024*1024)throw Error('输出PNG须小于3MB。');const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));const sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');return {data:'data:image/png;base64,'+btoa(binary),reference:data,width:800,height:800,sha256};}finally{bitmap.close();}
}
async function reviewState(runId){
 const run=(await flowRuns()).find(r=>r.id===runId&&r.selection?.reviewSpec);if(!run)throw Error('未找到此测试轮次。');
 const item=run.items[0],g=item?.generations?.[0];let file=null;
 if(g?.status==='completed'&&g.available===true)file=await flowWhiteDerivative(g.id);
 const spec=run.selection.reviewSpec,reference=spec.method==='ai'?spec.referenceUrl:(await reviewRead(REVIEW_ASSET+spec.assetKey))?.reference;
 return {runId:run.id,status:run.status,enabled:run.enabled,phase:item?.phase||run.phase,detail:run.error||item?.detail||run.events.at(-1)?.detail||'',review:item?.reviewOutcome||null,productId:run.selection.ids[0],original:item?.reviewOriginal?.url||null,reference,assetId:g?.id||null,file,checks:spec.plan.fixes.map(f=>f.check)};
}
const reviewOriginalPlan=flowPlanGeneration;
flowPlanGeneration=async(run,item)=>{
 if(run.module==='white'&&item.retryImportedReference){
  const ref=item.retryImportedReference,artifact=await reviewRead(REVIEW_ASSET+ref.assetKey),previous=item.reviewAttempts?.at(-1)?.generations?.[0]?.id;
  if(!artifact||artifact.runId!==run.id||artifact.productId!==item.productIds[0]||artifact.sha256!==ref.sha256||artifact.previousGenerationId!==previous)throw Error('导入素材与原商品、任务或文件校验不一致，未生成。');
  item.referenceCollection={productId:item.productIds[0],selectedSource:'import',sha256:artifact.sha256,checkedAt:new Date().toISOString()};
  run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,productId:item.productIds[0],detail:'采用已确认的本地导入素材图作为白底图参考，跳过自动采集；商品、原任务和文件校验一致。'});
  return [{id:crypto.randomUUID(),media:'image',productIds:[...item.productIds],status:'draft',referenceAssetKey:ref.assetKey,referenceSha256:ref.sha256,referenceRunId:run.id,ratio:'1:1',prompt:FullReviewRework.prompt(item.reviewOriginal)}];
 }
 const spec=run.selection?.reviewSpec;if(!spec)return reviewOriginalPlan(run,item);
 if(spec.originalKey!==FullWhiteReview.key(item.reviewOriginal)||spec.plan.reason!==item.reviewOriginal.review.reason)throw Error('本轮原失败图片或拒绝原因已变化，请重新读取。');
 FullReviewRework.plan(item.reviewOriginal,spec.custom);
 if(spec.method==='import_direct'){
  const artifact=await reviewRead(REVIEW_ASSET+spec.assetKey);if(!artifact||artifact.productId!==item.productIds[0])throw Error('导入图片商品绑定不一致。');
  const id=crypto.randomUUID();await reviewWrite('white-review-file:'+id,{...artifact,name:'material-'+id+'.png'});
  return [{id,media:'image',productIds:[...item.productIds],status:'completed',available:true,localArtifactKey:spec.assetKey,sha256:artifact.sha256}];
 }
 const reference=spec.method==='import_ai'?(await reviewRead(REVIEW_ASSET+spec.assetKey))?.reference:spec.referenceUrl;
 if(!reference)throw Error('未选择有效参考图。');
 item.mainImage=reference;
 return [{id:crypto.randomUUID(),media:'image',productIds:[...item.productIds],status:'draft',referenceUrl:reference,ratio:'1:1',prompt:FullReviewRework.prompt(item.reviewOriginal,spec.custom,spec.previous)}];
};
const reviewOriginalInput=flowWhiteGenerationInput;
flowWhiteGenerationInput=async g=>{
 if(g.referenceAssetKey){const a=await reviewRead(REVIEW_ASSET+g.referenceAssetKey);if(!a||a.runId!==g.referenceRunId||a.productId!==g.productIds?.[0]||a.sha256!==g.referenceSha256)throw Error('导入素材绑定或文件校验已变化，未提交生成。');return {reference:a.reference};}
 return g.referenceUrl?.startsWith('data:image/')?{reference:g.referenceUrl}:reviewOriginalInput(g);
};
const reviewOriginalDerivative=flowWhiteDerivative;
flowWhiteDerivative=async id=>await reviewRead('white-review-file:'+id)||reviewOriginalDerivative(id);
const reviewOriginalCheck=flowWhiteReviewCheck;
flowWhiteReviewCheck=async(run,item)=>{
 const result=await reviewOriginalCheck(run,item),spec=run.selection?.reviewSpec;
 if(result.eligible&&spec&&result.current&&(FullWhiteReview.key(result.current)!==spec.originalKey||result.current.review.reason!==spec.plan.reason))return {eligible:false,message:'拒绝原因已变化，请重新读取；未生成或替换。'};
 return result;
};
const reviewOriginalAdvance=FullWhiteReview.advance;
FullWhiteReview.advance=async(run,io)=>{
 const item=run.items[run.position];
 if(run.selection?.reviewSpec&&item&&['attach','quality'].includes(item.phase)&&!item.qualityReceipt){
  run.enabled=false;run.status='awaiting_quality_check';item.phase='quality';
  run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail:'本轮成图已就绪，等待逐项核对原拒绝原因及商品外观；尚未上传或回填。'});await io.save(run);return;
 }
 return reviewOriginalAdvance(run,io);
};
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
 if(!message.type?.startsWith('FULL_REWORK_'))return false;
 if(sender.id!==chrome.runtime.id||sender.url?.split(/[?#]/)[0]!==chrome.runtime.getURL('white-review.html'))return false;
 const action=async()=>{
  if(message.type==='FULL_REWORK_INSPECT'){
   await reviewIdle();if(!/^\d{6,}$/.test(message.productId||''))throw Error('请输入有效商品ID。');const tab=await reviewTab(message.tabId),snapshot=await reviewSnapshot(tab,message.productId);
   if(!FullWhiteReview.eligible(snapshot))throw Error('该商品不是在售实物的明确审核不通过素材，已有通过或待审核不会覆盖。');
   if(!snapshot.review.reason.trim())throw Error('平台没有返回具体拒绝原因，请查清后再处理；未调用生成。');
   const prior=await flowRuns(),previous=prior.filter(r=>r.module==='white').flatMap(r=>(r.items||[]).filter(i=>i.productIds?.includes(message.productId)).map(i=>({status:i.status,reason:i.qualityRejection||i.reviewOutcome?.reason||i.reviewOriginal?.review?.reason||'',materialId:i.reviewOriginal?.materialId}))),draftId=crypto.randomUUID();
   const d={draftId,tabId:tab.id,windowId:tab.windowId,snapshot,previous,candidates:[],at:Date.now()};await reviewWrite(REVIEW_DRAFT+draftId,d);return {draftId,snapshot,previous,candidates:[]};
  }
  if(message.type==='FULL_REWORK_COLLECT'){
   await reviewIdle();const d=await reviewDraft(message.draftId),pid=d.snapshot.productId;let candidates=[];
   for(const kind of ['main','sku'])try{const urls=await flowWhiteDetailImage(pid,kind,'all',d.tabId);candidates.push(...urls.map((url,index)=>({url,source:kind==='main'?'商品主图':'SKU原图',index:index+1})));}catch(error){if(/身份|不匹配/.test(error.message))throw error;}
   d.candidates=candidates.filter((v,i,a)=>a.findIndex(x=>x.url===v.url)===i);if(!d.candidates.length)throw Error('未采集到可核对原图，请导入对应规格的产品图。');await reviewWrite(REVIEW_DRAFT+d.draftId,d);return {candidates:d.candidates};
  }
  if(message.type==='FULL_REWORK_IMPORT'){
   const d=await reviewDraft(message.draftId),asset=await reviewAsset(message.data),assetKey=crypto.randomUUID();await reviewWrite(REVIEW_ASSET+assetKey,{...asset,productId:d.snapshot.productId,draftId:d.draftId});return {assetKey,data:asset.data,sha256:asset.sha256};
  }
  if(message.type==='FULL_REWORK_START'){
   if(!/^[a-f0-9-]{36}$/.test(message.roundId||''))throw Error('本轮编号无效。');const prior=await flowRuns(),existing=prior.find(r=>r.selection?.reviewSpec?.roundId===message.roundId);if(existing)return {runId:existing.id,reused:true};
   await reviewIdle();const d=await reviewDraft(message.draftId),plan=FullReviewRework.plan(d.snapshot,message.custom||'');
   if(!['ai','import_ai','import_direct'].includes(message.method)||message.newRound!==true)throw Error('请明确确认本轮处理方式。');
   if(message.method==='ai'&&!d.candidates.some(c=>c.url===message.referenceUrl))throw Error('请选择已采集且能核对的同商品原图。');
   if(message.method!=='ai'){const a=await reviewRead(REVIEW_ASSET+message.assetKey);if(a?.productId!==d.snapshot.productId||a?.draftId!==d.draftId)throw Error('导入图片未绑定当前商品，请重新导入。');}
   const spec={version:1,roundId:message.roundId,newRound:true,method:message.method,referenceUrl:message.method==='ai'?message.referenceUrl:null,assetKey:message.assetKey||null,originalKey:FullWhiteReview.key(d.snapshot),custom:String(message.custom||'').trim(),plan,previous:d.previous};
   if(FullWhiteReview.claimed(prior,d.snapshot,'new',spec))throw Error('该商品仍有未确认原任务，请回查原任务，不重复生成。');
   // Completed failed provider attempts are terminal; uncertain requests remain blocked.
   const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/history?productId=")+d.snapshot.productId,{signal:AbortSignal.timeout(15000)});if(!response.ok)throw Error('原任务账本尚未确认。');const history=await response.json();if(history.jobs?.some(j=>j.module==='white'&&!['completed','failed'].includes(j.status)))throw Error('同商品仍有运行中或未知任务，请先回查，未新增生成。');
   const run=FullWhiteRun.create({mode:'ids',ids:[d.snapshot.productId],startConsent:true,autoPublish:true,reviewRejected:true,reviewSpec:spec,executionBoundary:{paidGeneration:message.method!=='import_direct',storeWrite:true}});
   run.tabId=d.tabId;run.windowId=d.windowId;run.whitePageOpened=true;await flowSave(run);await chrome.alarms.create('full-flow:'+run.id,{when:Date.now()+100,periodInMinutes:.5});flowTick(run.id).catch(()=>{});return {runId:run.id};
  }
  if(message.type==='FULL_REWORK_STATE')return reviewState(message.runId);
  if(message.type==='FULL_REWORK_KEEP'){
   await reviewIdle();const run=(await flowRuns()).find(r=>r.id===message.runId&&r.selection?.reviewSpec);
   if(!run||run.status!=='awaiting_quality_check')throw Error('本轮不在待选择回填阶段。');
   const item=run.items[0];item.status='skipped';item.phase='done';item.detail='用户选择保留原图，不回填；新成图已保留。';run.enabled=false;run.status='done';run.whiteControlRevision=(run.whiteControlRevision||0)+1;run.position=run.items.length;run.events.push({at:new Date().toISOString(),detail:item.detail});await flowSave(run);return {runId:run.id};
  }
  if(message.type==='FULL_REWORK_REJECT_RESULT'){
   await reviewIdle();const run=(await flowRuns()).find(r=>r.id===message.runId&&r.selection?.reviewSpec),reason=String(message.reason||'').trim();
   if(!run||run.status!=='awaiting_quality_check'||reason.length<2||reason.length>500)throw Error('请填写本轮成图不合格的具体问题。');
   const item=run.items[0];item.qualityRejection=reason;item.status='failed';item.phase='done';item.detail='成图人工核对未通过，未上传：'+reason;run.enabled=false;run.status='done';run.whiteControlRevision=(run.whiteControlRevision||0)+1;run.position=run.items.length;run.events.push({at:new Date().toISOString(),detail:item.detail});await flowSave(run);return {runId:run.id};
  }
  if(message.type==='FULL_REWORK_APPROVE'){
   await reviewIdle();const run=(await flowRuns()).find(r=>r.id===message.runId&&r.selection?.reviewSpec);if(!run||run.status!=='awaiting_quality_check')throw Error('此轮尚未进入成图核对阶段。');
   const item=run.items[0],g=item.generations[0],file=await flowWhiteDerivative(g.id),spec=run.selection.reviewSpec;
   if(message.assetId!==g.id||message.sha256!==file.sha256||message.identityConfirmed!==true||message.publishConfirmed!==true||message.checks!==spec.plan.fixes.length)throw Error('请逐项核对本轮成图和商品身份。');
   const check=await flowWhiteReviewCheck(run,item);if(!check.eligible)throw Error(check.message);item.qualityReceipt={assetId:g.id,sha256:file.sha256,at:new Date().toISOString()};run.enabled=true;run.status='running';run.whiteControlRevision=FullWhiteRun.revision?FullWhiteRun.revision(run)+1:(run.whiteControlRevision||0)+1;item.phase='attach';await flowSave(run);await chrome.alarms.create('full-flow:'+run.id,{when:Date.now()+100,periodInMinutes:.5});flowTick(run.id).catch(()=>{});return {runId:run.id};
  }
  throw Error('未知审核重做操作。');
 };
 // Read-only state polling does not join the mutation queue; all other operations serialize.
 const pending=message.type==='FULL_REWORK_STATE'?action():executionGate(action);
 pending.then(result=>reply({ok:true,...result})).catch(error=>reply({ok:false,error:error.message}));return true;
});
