(function(root){
 'use strict';
 const labels={draft:'待提交',submitting:'提交中',queued:'排队中',running:'生成中',pending:'平台处理中',processing:'生成中',completed:'已完成',failed:'失败',submission_unconfirmed:'提交待确认',not_completed:'未完成',downloaded_unverified:'下载待核验'};
 function plan(settings,files){
  const mode=settings.mode==='clone'?'clone':'free',products=mode==='free'?files.free:files.products,refs=files.references;
  if(!products.length)throw new Error('请先上传产品图。');
  if(mode==='free'&&products.length>5)throw new Error('自由生成最多 5 张同商品参考图。');
  if(mode==='clone'&&(!refs.length||products.length>20||refs.length>40))throw new Error('复刻需要产品款式图和参考图，最多 20 款、40 张参考图。');
  const calls=mode==='free'?1:products.length*refs.length;
  if(calls>100)throw new Error('单批最多 100 个组合，请减少款式或参考图。');
  const productId=String(settings.productId||'').trim();if(productId&&!/^\d{6,}$/.test(productId))throw new Error('商品 ID 应为至少 6 位数字，也可留空。');
  const id=root.crypto.randomUUID(),cells=[];
  if(mode==='free')cells.push({id:root.crypto.randomUUID(),productKey:products[0].key,referenceKeys:products.map(p=>p.key),status:'draft',outputs:[]});
  else for(const [i,product]of products.entries())for(const [j,reference]of refs.entries())cells.push({id:root.crypto.randomUUID(),productKey:product.key,referenceKeys:[product.key,reference.key],productIndex:i,referenceIndex:j,ratio:settings.cloneRatio==='source'?reference.ratio:settings.cloneRatio,status:'draft',outputs:[]});
  return {id,name:settings.name?.trim()||settings.subject?.trim()||products[0].name.replace(/\.[^.]+$/,'')+' · 买家秀',mode,calls,productIds:productId?[productId]:[],settings:{...settings},cells,createdAt:new Date().toISOString(),stopped:false,revisions:[]};
 }
 function prompt(batch,cell){
  const s=batch.settings,palette=s.palette==='yes'?'环境采用奶油白、自然浅木色和浅灰布艺。':'使用自然色彩。';
  const common=`生成 AI 模拟的商品生活场景摄影。商品：${s.subject||'以产品图中的主体为准'}。保留商品真实结构、数量、材质、颜色、标识。不增加未提供的背面细节、配件、功能、认证、促销文字。不冒充真实买家评价。${palette}补充要求：${s.extras||'无'}。`;
  if(batch.mode==='clone')return common+'第一张是自己的商品，第二张是构图参考。仅参考第二张的场景、光线、人物姿态和构图，把第一张商品准确融入该场景；输出一张独立照片，不输出拼图。';
  return common+`输出严格 3 行 3 列、共 9 格的规则九宫格摄影母图。各格等宽等高、无留白、无边框、无文字；每格都是${s.freeRatio}的独立构图，整个母图比例也为${s.freeRatio}。9 格展示同一件商品的不同生活场景和已知细节。${s.style==='model'?'由模特自然展示商品，商品外观准确。':'以商品为主体的生活场景，不出现人物。'}`;
 }
 function request(batch,cell,files){return {id:cell.id,media:'image',model:'nano-banana-pro',module:'buyer',productIds:batch.productIds,prompt:prompt(batch,cell),ratio:batch.mode==='free'?batch.settings.freeRatio:cell.ratio,palette:batch.settings.palette, references:cell.referenceKeys.map(key=>{const file=files[key];if(!file)throw new Error('原参考图丢失，未提交生成。');return file.data;}),consent:true};}
 function syncPayload(batch,productId,files,selected,copy){const ids=[...selected];if(!/^\d{6,}$/.test(productId||''))throw new Error('请输入正确商品 ID');if(!ids.length||ids.length>100||new Set(ids).size!==ids.length)throw new Error('单次同步请选择 1 至 100 张不同图片');const allowed=new Set(batch.cells.flatMap(cell=>cell.outputs||[]));if(ids.some(key=>!allowed.has(key)||!files[key]?.data))throw new Error('所选图片已变化，请重新选图');const title=String(copy.title||'').trim(),body=String(copy.body||'').trim(),facts=String(copy.facts||'').trim(),generateCopy=copy.generateCopy===true;if(!generateCopy&&(!title||!body))throw new Error('使用自己的文案时，请填写种草标题和正文');if(title.length>60||body.length>5000||facts.length>3000)throw new Error('种草文案过长，请缩短后重试');if(ids.some(key=>files[key].data.length>8*1024*1024))throw new Error('所选单张图片超过 8MB，请换图或缩小图片后再确认；尚未派单');const payload={requestId:root.crypto.randomUUID(),batchId:batch.id,productId,images:ids.map(key=>({id:key,data:files[key].data})),generateCopy,title,body,facts,consent:true};if(new TextEncoder().encode(JSON.stringify({type:'FULL_BUYER_SYNC',...payload})).length>48*1024*1024)throw new Error('所选图片和文案超过 48MB，请减少选图后再确认；尚未派单');return payload;}
 root.BuyerCore={plan,prompt,request,syncPayload,labels};if(typeof module!=='undefined')module.exports=root.BuyerCore;
})(globalThis);
