/* GrsAI public catalog + documented legacy API parameters, verified 2026-11-06.
 * Sources and extracted parameter tables are in evidence/v1.1.3 (not shipped).
 * No network or credentials. Shared by the settings page and worker. */
(function(root){
 'use strict';
 const rows=[
  ['gpt-image-2.6',['1K'],['auto']],
  ['nano-banana-2.1',['1K','2K','4K'],['default']],
  ['gpt-image-2.5',['1K'],['auto']],
  ['gpt-image-2.5-sunburst',['1K','2K','4K'],['low','medium','high','xhigh','max']],
  ['gpt-image-2.5-flare',['1K','2K','4K'],['low','medium','high']],
  ['gpt-image-2',['1K'],['auto']],
  ['gpt-image-2-vip',['1K','2K','4K'],['medium']],
  ['nano-banana-pro',['1K','2K','4K'],['default']],
  ['nano-banana-2',['1K','2K','4K'],['default']],
  ['nano-banana-2-lite',['default'],['default']],
  ['nano-banana-fast',['default'],['default']],
  ['nano-banana-2-cl',['1K'],['default']],
  ['nano-banana-pro-cl',['1K'],['default']],
  ['nano-banana-2-2k-cl',['2K'],['default']],
  ['nano-banana-pro-4k-vip',['4K'],['default']],
  ['nano-banana-pro-vip',['1K','2K'],['default']],
  ['nano-banana-2-4k-cl',['4K'],['default']]
 ];
 const catalog=rows.map(([id,resolutions,qualities])=>Object.freeze({id,resolutions:Object.freeze(resolutions),qualities:Object.freeze(qualities),family:id.startsWith('nano-')?'nano':'gpt',defaultResolution:id==='nano-banana-pro'?'2K':resolutions[0],defaultQuality:qualities.includes('medium')?'medium':qualities[0]}));
 const byId=Object.fromEntries(catalog.map(m=>[m.id,m]));
 // Public API's exact pixel examples; do not label a square 4K as 4096x4096.
 const pixels={
  '1:1':['1024x1024','2048x2048','2880x2880'],
  '16:9':['1280x720','2048x1152','3840x2160'],
  '9:16':['720x1280','1152x2048','2160x3840'],
  '4:3':['1152x864','2304x1728','3264x2448'],
  '3:4':['864x1152','1728x2304','2448x3264'],
  '3:2':['1536x1024','2048x1360','3504x2336'],
  '2:3':['1024x1536','1360x2048','2336x3504'],
  '5:4':['1120x896','2240x1792','3200x2560'],
  '4:5':['896x1120','1792x2240','2560x3200'],
  '21:9':['1456x624','2912x1248','3840x1648']
 };
 const oneK={'1:1':'1024x1024','16:9':'1672x941','9:16':'941x1672','4:3':'1443x1090','3:4':'1090x1443','3:2':'1536x1024','2:3':'1024x1536','5:4':'1408x1120','4:5':'1120x1408','21:9':'1920x832'};
 function spec(id){const m=byId[id];if(!m)throw Error('请选择列表中已接入的图片模型');return m;}
 function settings(id,value={}){const m=spec(id),resolution=value.resolution??m.defaultResolution,quality=value.quality??m.defaultQuality;if(!m.resolutions.includes(resolution))throw Error('该模型不支持所选分辨率');if(!m.qualities.includes(quality))throw Error('该模型不支持所选质量');return {resolution,quality};}
 function parameters(id,ratio,value){const m=spec(id),s=settings(id,value);if(ratio!=='auto'&&!pixels[ratio])throw Error('图片比例无效');if(m.family==='nano')return {aspectRatio:ratio,...(s.resolution!=='default'?{imageSize:s.resolution}:{})};
  const square=ratio==='auto'?'1:1':ratio;
  return {aspectRatio:m.resolutions.length>1?pixels[square][['1K','2K','4K'].indexOf(s.resolution)]:oneK[square],quality:s.quality};
 }
 function info(id){const m=spec(id);if(id==='nano-banana-fast'||id==='nano-banana-2-lite')return '按官方模型默认规格生成；未开放分辨率、质量档位，故不发送这些参数。';return m.family==='nano'?'分辨率按所选档位请求；该系列没有独立质量参数。':'按当前任务比例转换为官方像素尺寸；自动比例按1:1请求。4K方图为2880×2880。'+(id==='gpt-image-2.6'?' 本插件用于静态商品图，暂不支持GIF素材归档。':'');}
 const isSearchFallback=id=>typeof id==='string'&&id!=='gpt-image-2.6'&&Object.hasOwn(byId,id);
 const api=Object.freeze({catalog:Object.freeze(catalog),spec,settings,parameters,info,isSearchFallback});root.MaterialImageModels=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
