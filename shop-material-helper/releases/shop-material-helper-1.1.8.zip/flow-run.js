(function(root){
 'use strict';
 const modules=['white','transparent','scene','mainvideo','search','searchvideo','trend','selling','incubate','guanghe','follow'];
 function identity(value){return JSON.stringify(value);}
 function canonical(value){return JSON.stringify(value,(_key,part)=>part&&typeof part==='object'&&!Array.isArray(part)?Object.fromEntries(Object.keys(part).sort().map(key=>[key,part[key]])):part);}
 function scope(run){const value={module:run.module,selection:run.selection};return ['white','transparent','scene','search','searchvideo','trend','guanghe'].includes(run.module)?canonical(value):identity(value);}
 function matchesConsent(run){if(run.consentScope===scope(run))return true;if(!['white','transparent','scene','search','searchvideo','trend','guanghe'].includes(run.module)||typeof run.consentScope!=='string')return false;try{return canonical(JSON.parse(run.consentScope))===scope(run);}catch{return false;}}
 function hasUnsettledIntent(item){return !!(item.videoUploadIntent&&item.status!=='verified'||item.generations?.some(g=>g.media==='video'&&g.intent&&g.status==='completed'&&item.status!=='verified')||item.publication&&item.status!=='verified'||item.generations?.some(g=>g.intent&&g.status!=='completed')||item.uploadIntents&&item.status!=='verified'||item.nativeIntent&&item.status!=='verified'||(item.textIntent||item.textId)&&item.status!=='verified');}
 function searchSkip(run,item,error){
  if(run.module!=='search'||!item||!['prepare','generate'].includes(item.phase)||item.publication||item.receipt||item.videoUploadIntent||item.nativeIntent||item.textIntent||item.textId||item.syncRuns?.length||Object.keys(item.uploadIntents||{}).length||item.prepared?.uploadedAssets?.length||item.generations?.some(g=>g.intent||g.status!=='draft'))return null;
  if(!error&&/(?:差价|运费).*(?:补拍|专拍|专用|链接|补款)|(?:补拍|补交|补付|补缴|补齐|补款).*(?:差价|运费)|^(?:差价|运费)$/.test(item.title||''))return {reason:'non_product_payment_link',detail:'标题明确为差价或运费补拍链接，跳过本条；未生成、上传或发布。'};
  const p=item.referenceValidationFailure;
  if(error&&['SOUTUI_REFERENCE_TOO_SMALL','SOUTUI_REFERENCE_EMPTY'].includes(error.code)&&p?.code===error.code&&identity(p.productIds)===identity(item.productIds)&&p.url===item.mainImage&&Number.isInteger(p.width)&&p.width>0&&Number.isInteger(p.height)&&p.height>0&&(error.code==='SOUTUI_REFERENCE_TOO_SMALL'?(p.width<720||p.height<720):(Number.isFinite(p.variance)&&p.variance<30||Number.isFinite(p.nonWhiteRatio)&&p.nonWhiteRatio<.01)))return {reason:'reference_material_required',detail:'待补素材：同商品原图'+p.width+'×'+p.height+'，'+(error.code==='SOUTUI_REFERENCE_TOO_SMALL'?'不足720像素':'为空白或信息不足')+'；本条未生成、上传或发布，继续其他商品。'};
  return null;
 }
 function upgradeVideoQuality(run,options={}){
  const item=run.items?.[run.position||0],old=item?.generations?.[0];
  if(options.confirmed!==true||options.resolution!=='768p'||run.module!=='searchvideo'||run.enabled||run.status!=='blocked'||run.videoQualityUpgrade||!matchesConsent(run)||run.selection?.mode!=='ids'||run.selection.ids?.length!==1||run.items?.length!==1||item?.productIds?.length!==1||item.productIds[0]!==run.selection.ids[0]||Number(run.usedCalls)!==1||Number(run.selection.maxCalls)!==1||item.publication||item.receipt||item.generations?.length!==1||old?.media!=='video'||old.status!=='completed'||old.resolution!=='480p'||!old.intent||!(Math.min(Number(old.mediaInfo?.width),Number(old.mediaInfo?.height))>0&&Math.min(Number(old.mediaInfo.width),Number(old.mediaInfo.height))<720))throw Error('视频质量修订未明确确认，或原任务已有提交、未知结果或质量修订；保留原记录。');
  const at=new Date().toISOString(),archive={generations:structuredClone(item.generations),prepared:structuredClone(item.prepared||{}),...(item.videoUploadIntent?{videoUploadIntent:structuredClone(item.videoUploadIntent)}:{}),...(item.videoUploadObservation?{videoUploadObservation:structuredClone(item.videoUploadObservation)}:{})};
  run.videoQualityUpgrade={at,priorUsedCalls:run.usedCalls,originalConsentScope:run.consentScope,original:archive,reason:'用户确认将低于720p的原成品改为H3 768p，备用Agnes 720p；保留原任务，仅补一次质量修订。'};
  Object.assign(run.selection,{provider:'grsai',model:'minimax-h3',resolution:'768p',duration:10,videoFallback:{model:'agnes-video-2.5',resolution:'720p'}});
  const g={id:crypto.randomUUID(),media:'video',productIds:[...item.productIds],status:'draft',provider:'grsai',model:'minimax-h3',resolution:'768p',duration:10,videoFallback:{model:'agnes-video-2.5',resolution:'720p'},ratio:old.ratio||run.selection.ratio||'9:16',prompt:old.prompt,referenceUrl:old.referenceUrl};
  item.generations=[g];for(const key of ['videoUploadIntent','videoUploadObservation','submitResult'])delete item[key];for(const key of ['videoContentId','videoRecord','uploadedAssets','contentBaseline'])delete item.prepared?.[key];item.phase='generate';item.status='pending';item.detail='按已确认的新规格继续原单品：H3 768p，备用Agnes 720p。';run.error='';run.consentScope=scope(run);run.events.push({at,phase:run.phase,position:run.position,detail:run.videoQualityUpgrade.reason});return run;
 }
 function create(module,selection={}){
  if(module==='search'&&!['replica','cleanup'].includes(selection.mode)&&selection.searchMode!=='replica'&&(!selection.searchSource||selection.searchSource==='ai')){const groups=Number(selection.searchGroups??0);if(!Number.isInteger(groups)||groups<0||groups>9)throw Error('每商品搜推框数须为0至9。');selection={...selection,scenePlanVersion:2,count:3,searchGroups:groups};}
  if(!modules.includes(module))throw new Error('该入口使用独立网页工作台。');
  if(selection.startConsent!==true)throw new Error('请确认本轮开始执行。');
  const c=root.FullButtonContracts.resolve(module,selection);if(c.kind!=='run')throw new Error('请先完成本模块的运行选项。');
  if(c.variant==='cleanup'&&!c.dryRun&&selection.deleteConfirmed!==true)throw new Error('实际清理须确认精确删除清单，默认只演练。');
  const run={id:crypto.randomUUID(),module,selection:structuredClone(selection),status:'running',enabled:true,phase:'discover',position:0,items:[],usedCalls:0,usedCallsByType:{image:0,video:0,text:0},events:[],createdAt:new Date().toISOString()};run.consentScope=scope(run);return run;
 }
 function validReceipt(item,result){return result?.status==='verified'&&result.receipt?.source==='platform-readback'&&!!result.receipt.contentId&&Array.isArray(result.receipt.productIds)&&identity([...new Set(result.receipt.productIds)].sort())===identity([...item.productIds].sort());}
 async function advance(run,io){
  if(!run.enabled)return;
  const save=async(detail)=>{run.events.push({at:new Date().toISOString(),phase:run.phase,position:run.position,detail});await io.save(run);};
  const check=async()=>{if(run.module==='searchvideo'&&(!['ids','custom'].includes(run.selection.mode)||root.FullButtonContracts.parseIds(run.selection.ids).length!==1||Number(run.selection.count)!==1||Number(run.selection.maxCalls)!==1))throw Error('搜推视频当前仅允许单个商品、最多一条视频；禁止全店或扩大原范围，已保留原记录。');if(!matchesConsent(run))throw new Error('执行范围已经改变，必须重新选择。');if(io.isLive&&!await io.isLive(run))throw Object.assign(new Error('已停止后续操作。'),{stopped:true});};
  try{
   await check();
   const drain=async()=>{run.enabled=false;run.status='drained';await save('已收尾停止；保留原任务与成品，不开始下一个商品或新生成。');};
   if(run.draining&&root.FullSceneGeneration?.enabled(run)&&run.items.some(i=>i.generations?.some(g=>g.intent&&!(g.status==='completed'&&g.available===true)))){await io.parallelGeneration(run,run.items[run.position],{...io,save,check});return;}
   if(run.draining&&(run.phase==='discover'||run.items[run.position]?.phase==='prepare'))return drain();
   if(run.phase==='discover'){
    const targets=await io.discover(run);await check();if(!Array.isArray(targets)||targets.some(t=>!Array.isArray(t.productIds)||!t.productIds.length||t.productIds.some(id=>!/^\d{6,}$/.test(id))))throw new Error('未取得明确商品身份的执行范围。');const requested=root.FullButtonContracts.resolve(run.module,run.selection).scope;if(requested?.type==='ids'&&targets.some(t=>t.productIds.some(id=>!requested.ids.includes(id))))throw new Error('发现结果超出本批明确商品ID范围，未生成或提交。');
    const keys=new Set();run.items=targets.filter(t=>{const k=identity({ids:t.productIds,context:t.context||null});if(keys.has(k))return false;keys.add(k);return true;}).map(t=>({...t,phase:'prepare',status:'pending',id:crypto.randomUUID()}));run.phase='items';await save('已保存明确的商品集合；后续不扩大范围。');return;
   }
   while(run.items[run.position]?.phase==='done')run.position++;
   const item=run.items[run.position];if(!item){run.enabled=false;run.status='done';await save('本轮结束；逐项结果保留成功、跳过及未确认。');return;}
   const retryRejectedDate=async()=>{const result=item.submitResult;if(run.module!=='incubate'||result?.status!=='rejected'||result.reason!=='date_quota'||result.proof!=='platform-explicit-rejection'||!item.publication||result.date!==item.prepared?.startDate)return false;if(!/^\d{4}-\d{2}-\d{2}$/.test(result.date))throw Error('明确拒绝的报名日期无效。');item.quotaRejectedDates=[...new Set([...(item.quotaRejectedDates||[]),result.date])];item.rejectedPublications||=[];if(!item.rejectedPublications.some(p=>p.publication.id===item.publication.id))item.rejectedPublications.push({publication:structuredClone(item.publication),result:structuredClone(result)});if(item.quotaRejectedDates.length>=40)throw Error('已达到明确满额日期保护上限，未继续报名。');delete item.publication;delete item.submitResult;item.phase='prepare';item.status='pending';await save('平台明确拒绝原日期，保留拒绝证据后改选其他日期；未知提交不走此分支。');return true;};
   const next=async(status,detail)=>{item.status=status;item.phase='done';item.detail=detail;run.position++;if(run.draining&&io.finishDrainItem!==true){run.enabled=false;run.status='drained';}await save(detail);};
   const excluded=searchSkip(run,item);if(excluded){item.skipReason=excluded.reason;run.error='';return next('skipped',excluded.detail);}
   if(run.generationOnlyRecovery){const allowed=run.generationOnlyRecovery.assetIds;if(!['generate','attach'].includes(item.phase)||!item.generations?.length||item.generations.some(g=>!allowed.includes(g.id)))throw Error('本次只允许已确认的原编号生图，不上传或发布店铺。');if(item.phase==='attach'){if(!item.generations.every(g=>g.status==='completed'&&g.available===true))throw Error('原图尚未全部落盘');return next('generated','本组原编号生图已完成并落盘；店铺写入关闭，未上传或发布。');}}
   if(run.existingAssetsOnly&&(!run.existingAssetsOnly.itemIds.includes(item.id)||!['attach','publish','readback'].includes(item.phase)||run.usedCalls!==run.existingAssetsOnly.usedCalls))throw Error('本轮只允许已确认原图上传发布，禁止进入新生成或扩大范围。');
   if(item.phase==='prepare'){
    const result=await io.prepare(run,item);await check();
    const excluded=searchSkip(run,item);if(excluded){item.skipReason=excluded.reason;run.error='';return next('skipped',excluded.detail);}
    if(result?.status==='ineligible')return next('skipped',result.message||'平台不具备执行条件。');
    if(result?.productIds&&identity([...result.productIds].sort())!==identity([...item.productIds].sort()))throw new Error('当前表单商品与本轮目标不符。');
    item.prepared=result||{};item.phase=result?.needsCopy?'copy':result?.needsNative?'native':result?.needsGeneration?'generate':result?.needsAttach?'attach':'publish';await save('平台准备完成，保存商品与素材信息。');return;
   }
   if(item.phase==='copy'){
    if(!item.textId){if(run.draining)return drain();if(run.selection.allowCopyFallback!==true)throw new Error('未允许本批付费AI代写，保留平台商品绑定。');if(!Number.isInteger(Number(run.selection.maxCalls))||run.usedCalls>=Number(run.selection.maxCalls))throw new Error('本批剩余调用预算不足一次文案，未请求。');item.textId=crypto.randomUUID();item.textIntent={id:item.textId,at:new Date().toISOString()};run.usedCalls++;run.usedCallsByType||={image:0,video:0,text:0};run.usedCallsByType.text=(run.usedCallsByType.text||0)+1;await save('先登记本帖唯一Gemini文案编号并扣本批一次预算。');await check();if(run.draining)return;await io.submitCopy(run,item);return;}
    const result=await io.queryCopy(run,item);await check();const copy=root.FullFlowHistory.validateCopy(result,item);if(!copy){if(['failed','submission_unconfirmed'].includes(result.status))throw new Error('原AI文案未确认，保留编号不重投。');await save('仅查询原Gemini文案编号。');return;}const filled=await io.fillCopy(run,item,copy);Object.assign(item.prepared,filled||copy);item.phase='publish';await save('同商品原AI文案已精确回填，不冒充平台灵感。');return;
   }
   if(item.phase==='generate'){
    if(typeof io.parallelGeneration==='function'&&(root.FullSearchGeneration?.enabled(run)||root.FullSceneGeneration?.enabled(run))){await io.parallelGeneration(run,item,{...io,save,check});return;}

    if(!item.generations){if(run.draining)return drain();item.generations=await io.planGeneration(run,item);if(!item.generations?.length)throw new Error('未取得生成计划。');await save(run.module==='searchvideo'?'已保存单品视频编号；GrsAI MiniMax H3，768p，10秒，主备通道各最多1次，备用仅主通道确认不可用时启用。':'保存本轮固定素材编号。');return;}
    const pending=item.generations.find(g=>g.status!=='completed');
    if(!pending){item.phase='attach';await save('全部原编号素材已完成。');return;}
    if(!pending.intent){if(run.draining){const inflight=item.generations.find(g=>g.intent&&g.status!=='completed');if(inflight){const result=await io.queryGeneration(run,item,inflight);await check();if(result.id!==inflight.id||identity(result.productIds)!==identity(item.productIds))throw new Error('收尾查询编号或商品身份不符。');if(result.status==='completed'&&result.available===true)Object.assign(inflight,result);else if(['failed','violation','submission_unconfirmed','downloaded_unverified','not_completed','missing'].includes(result.status)){inflight.status=result.status;inflight.error=result.error||result.message||'';throw new Error('收尾原任务未确认（'+result.status+'），不创建替代任务。');}else {inflight.status=result.status||'pending';inflight.error=result.error||result.message||'';inflight.downloadOrigin=result.downloadOrigin||null;}await save('收尾只查询已提交的原任务。');return;}return drain();}const max=Number(run.selection.maxCalls);if(run.module!=='search'&&(!Number.isInteger(max)||run.usedCalls-(run.videoQualityUpgrade?.priorUsedCalls||0)>=max))throw new Error('本轮生成次数上限不足，未发起新请求。');pending.intent={id:pending.id,at:new Date().toISOString()};pending.status='pending';run.usedCalls++;run.usedCallsByType||={image:0,video:0,text:0};run.usedCallsByType[pending.media||'image']=(run.usedCallsByType[pending.media||'image']||0)+1;await save('先持久登记单次生成意图。');await check();if(run.draining)return;await io.submitGeneration(run,item,pending);return;}
    const result=await io.queryGeneration(run,item,pending);await check();
    if(result.id!==pending.id||identity(result.productIds)!==identity(item.productIds))throw new Error('原生成编号或商品身份不符。');
    if(result.status==='completed'&&result.available===true){Object.assign(pending,result);await save('原素材已下载验证。');return;}
    if(['failed','violation','submission_unconfirmed','downloaded_unverified','not_completed','missing'].includes(result.status)){pending.status=result.status;pending.error=result.error||result.message||'';throw new Error('原生成结果未确认（'+result.status+'）：'+pending.error+'；保留编号，禁止重新提交。');}
    pending.status=result.status||'pending';pending.error=result.error||result.message||'';pending.downloadOrigin=result.downloadOrigin||null;if(run.module==='searchvideo'&&result.model){const changed=pending.model!==result.model;Object.assign(pending,{model:result.model,resolution:result.resolution,duration:result.duration,providerRequestCount:result.providerRequestCount,modelAttempts:result.modelAttempts});await save(changed&&result.model==='agnes-video-2.5'?'主通道已确认不可用，接续原任务的备用 agnes-video-2.5 / 720p；只查询已有编号。':'原 GrsAI '+result.model+' / '+result.resolution+' 视频处理中，仅查询。');return;}await save('原任务处理中，仅查询。');return;
   }
   if(item.phase==='native'){
    if(!item.nativeIntent){if(run.draining&&io.finishDrainItem!==true)return drain();item.nativeIntent={at:new Date().toISOString(),productIds:[...item.productIds]};await save('持久登记淘宝原生图片处理意图，不调用GrsAI。');await check();if(run.draining&&io.finishDrainItem!==true)return;await io.startNative(run,item);return;}
    const result=await io.queryNative(run,item);await check();if(result?.status==='completed'){item.nativeResult=result;item.phase='publish';await save('已读取原生处理结果，待单次回填。');return;}if(result?.status==='failed')throw new Error(result.message||'原生处理失败，不重复点击生成。');if(Date.now()-Date.parse(item.nativeIntent.at)>300000)throw new Error('原生处理超过5分钟未确认，继续原任务只能查看，不重复生成。');await save('原生图片处理中，仅查看原结果。');return;
   }
   if(item.phase==='attach'){const result=await io.attach(run,item);await check();if(result?.ok===false)throw new Error(result.error||'平台素材未确认。');item.phase=result?.needsNative?'native':'publish';await save('素材已精确回查并绑定当前表单。');return;}
   if(item.phase==='publish'){
    if(item.publication){item.phase='readback';await save('恢复既有提交意图，仅回查原记录。');return;}
    if(run.selection.autoPublish!==true&&!run.selection.dryRun)throw new Error('未允许本轮自动提交平台。');
    if(run.selection.dryRun){item.preview=await io.preview(run,item);return next('preview','已保存清理演练结果，未删除。');}
    await io.preSubmit(run,item);await check();item.publication={id:crypto.randomUUID(),at:new Date().toISOString(),productIds:[...item.productIds]};item.phase='readback';await save('已持久保存单次提交意图。');await check();const result=await io.publish(run,item);if(result?.status==='not_submitted'&&result.proof==='pre-submit-check-rejection'&&result.actionAttempted===false){item.unexecutedPublications||=[];item.unexecutedPublications.push({publication:structuredClone(item.publication),result:structuredClone(result)});delete item.publication;item.phase='publish';item.status='blocked';run.enabled=false;run.status='blocked';run.error=result.message||'发布前校验未通过，未执行提交。';await save(run.error);return;}item.submitResult=result;await save('提交动作已返回；保留原页面，只读回查平台结果。');await retryRejectedDate();return;
   }
   if(item.phase==='readback'){
    if(await retryRejectedDate())return;
    if(run.module==='search'&&item.readbackWait?.nextAt>Date.now())return;
    const result=await io.readback(run,item);await check();
    if(validReceipt(item,result)){if(item.readbackWait)item.readbackWait={...item.readbackWait,nextAt:0,confirmedAt:Date.now()};item.receipt=result.receipt;if(!run.existingAssetsOnly&&io.syncEnabled?.(run,item)){item.phase='sync';item.status='syncing';await save('搜推已核验；继续已确认的同素材同步策略。');return;}return next('verified','平台目标商品与结果已回查。');}
    if(run.module==='search'){
     item.readbackEvidence={code:result?.code||'CONTENT_READBACK_UNCONFIRMED',...(result?.readbackEvidence||{})};
     const submitted=Date.parse(item.publication?.at),age=Date.now()-submitted,attempts=Number(item.readbackWait?.attempts||0);
     if(result?.status==='submitted_unconfirmed'&&result.retryable===true&&age>=0&&age<120000&&attempts<12){item.readbackWait={attempts:attempts+1,nextAt:Math.min(Date.now()+3000,submitted+120000),deadline:submitted+120000};item.status='awaiting_readback';await save('平台发布列表尚未同步，正在只读回查（'+item.readbackWait.attempts+'/12）；保留原提交与素材，不重新生成或提交。');return;}
     if(result?.retryable===true&&Number.isFinite(submitted)){item.readbackWait={...(item.readbackWait||{attempts}),nextAt:0,deadline:submitted+120000,exhausted:true};}else if(item.readbackWait){item.readbackWait.nextAt=0;item.readbackWait.exhausted=false;}
    }
    item.status='submitted_unconfirmed';run.enabled=false;run.status='blocked';run.error=item.readbackWait?.exhausted?'平台发布列表在限时回查内仍未同步（'+item.readbackEvidence.code+'）；保留原提交与素材，继续时只回查，不重新生成或提交。':result?.message||'提交结果未唯一确认；恢复时只回查，不重复提交。';await save(run.error);return;
   }
   if(item.phase==='sync'){const result=await io.sync(run,item);await check();if(result.done)return next('verified','搜推及已选同步策略均已结算，结果分项保留。');await save('按原子任务同步；未新增生成请求。');return;}
   throw new Error('未知执行阶段。');
  }catch(error){const item=run.items.find(i=>i.id===error.failureItemId)||run.items[run.position];if(error.failureItemId&&item)run.failureItemId=item.id;const excluded=!error.stopped&&matchesConsent(run)&&(!io.isLive||await io.isLive(run))?searchSkip(run,item,error):null;if(excluded){item.skipReason=excluded.reason;item.status='skipped';item.phase='done';item.detail=excluded.detail;run.position++;run.error='';if(run.draining){run.enabled=false;run.status='drained';}await save(excluded.detail);return;}run.enabled=false;run.status=error.stopped?'stopped':'blocked';run.error=error.message;if(item)item.status=item.phase==='sync'&&item.receipt?'sync_blocked':item.publication?'submitted_unconfirmed':'blocked';await save(error.message);}
 }
 const api={create,scope,matchesConsent,advance,validReceipt,hasUnsettledIntent,upgradeVideoQuality};root.FullFlowRun=api;if(typeof module==='object')module.exports=api;
})(globalThis);
