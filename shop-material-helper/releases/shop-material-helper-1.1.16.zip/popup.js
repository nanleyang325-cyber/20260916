(function (root) {
  'use strict';
  const SETTINGS = 'material-feature-settings-v1';
  const DRAFTS = 'material-module-drafts-v1';
  const RUNS = 'material-flow-runs-v1';
  const q = selector => document.querySelector(selector);
  const extension = !!root.chrome?.runtime?.id;
  const boundary = module => ({ paidGeneration: !['transparent','trend'].includes(module), storeWrite: ['white','transparent','trend'].includes(module) });
  let settings = {}, drafts = {}, runs = [], currentRun = null, starting = false;
  let draftChain = Promise.resolve(), previousRunId = null, previousPaused = false;
  let dialogOpen = false, stopPending = false, openingModule = false;
  const modules = {
    white: 'white', transparent: 'transparent', fill_video: 'mainvideo', fill_recommend: 'search',
    fill_recommend_video: 'searchvideo', trend_submit: 'trend',
    material_tending: 'selling', xinpin_incubate: 'incubate', follow_ops: 'follow'
  };

  async function read(key) {
    if (extension) return (await chrome.storage.local.get(key))[key];
    return JSON.parse(localStorage.getItem(key) || 'null');
  }
  async function merge(key, patch) {
    if (extension) return FullStateStore.update(key, old => ({ ...old, ...patch }));
    const next = { ...await read(key), ...patch };
    localStorage.setItem(key, JSON.stringify(next));
    return next;
  }
  async function message(data) {
    if (!extension) throw Error('请从浏览器扩展打开面板；此页面不会直接操作店铺。');
    const result = await chrome.runtime.sendMessage(data);
    if (!result?.ok) throw Object.assign(Error(result?.error || '操作未确认，请查看原任务状态。'), { code: result?.code, runId: result?.runId });
    return result;
  }
  function notice(text, level = 'info') {
    q('#statusPanel').style.display = '';
    q('#statusText').textContent = text;
    root.dispatchEvent(new CustomEvent('material-ui-log', { detail: { text, level } }));
  }
  function noticeStartFail(reason) { notice('⚠ 启动失败：' + reason, 'error'); }
  const guard = fn => Promise.resolve().then(fn).catch(error => noticeStartFail(error.message));
  function setFuncCollapsed(collapsed) {
    q('#funcArea').classList.toggle('collapsed', collapsed);
    q('#funcToggle').style.display = collapsed ? '' : 'none';
    q('#funcToggle').textContent = '▸ 功能按钮（任务运行中已折叠，点此展开）';
  }
  function active(run) { return !!run && (run.enabled || run.status === 'paused'); }
  function hasActive() { return starting || resumePending || runs.some(active) || active(currentRun); }
  function unfinishedOriginal(module) {
    return runs.filter(active).at(-1) || [...runs].reverse().find(run => run.module===module && run.status!=='done' && (run.phase==='discover'||run.phase==='items'||run.items?.some(item=>item.phase!=='done')));
  }
  async function offerOriginal(module) {
    if(starting||resumePending||resumeDialog)return {cancelled:true};
    updateRuns(await read(RUNS));
    const original=unfinishedOriginal(module);
    return original ? resumeOriginalSearch(original) : null;
  }
  function recoverableSearch(module) { return [...runs].reverse().find(run => (module ? run.module === module : ['search','searchvideo','trend'].includes(run.module)) && !active(run) && run.status !== 'done' && (run.kind==='trend'&&run.phase!=='done' || run.module==='searchvideo' && run.selection?.mode==='ids' && run.selection.ids?.length===1 && (run.phase==='discover'||run.phase==='items'&&run.items?.some(item=>item.phase!=='done')) || run.items?.some(item => item.phase !== 'done' && (item.generations?.some(g => g.intent) || item.publication || item.videoUploadIntent || Object.keys(item.uploadIntents || {}).length)))); }
  function recoverableWhite() { return [...runs].reverse().find(run => FullWhiteRun.completedCandidate(run)||run.module==='white' && run.selection?.reviewAutomatic && !active(run) && run.status!=='done' && run.items?.some(i=>i.phase!=='done'||i.status==='needs_attention'&&!i.generations?.some(g=>g.intent)&&!i.publication&&!Object.keys(i.uploadIntents||{}).length&&(i.referenceErrorCode==='WHITE_REFERENCE_UNAVAILABLE'||/SKU参考图未取得/.test(i.detail||'')))); }
  let resumeDialog = null, resumePending = false;const resumeRecoveryPlans=new Map();
  async function confirmOriginalSearch(original) {
    if (resumeDialog) return Promise.resolve(false);const recoveryPlan=await root.FullRecoveryUi?.plan(original);if(recoveryPlan)resumeRecoveryPlans.set(original.id,recoveryPlan);
    const dialog = document.createElement('dialog');resumeDialog = dialog;
    dialog.id = 'resume-search-confirm';dialog.setAttribute('aria-labelledby','resume-original-title');
    dialog.style.cssText = 'position:fixed;inset:0;margin:auto;max-height:calc(100vh - 24px);overflow:auto;width:340px;max-width:calc(100vw - 24px);box-sizing:border-box;padding:18px;background:#191919;color:#eee;border:1px solid #805d1b;border-radius:12px;font:inherit';
    dialog.innerHTML = '<h3 id="resume-original-title" style="margin:0 0 12px">是否继续执行原任务？</h3><p id="resume-original-scope" style="overflow-wrap:anywhere"></p><p>复用已生成图片和已有发布记录，从中断步骤继续，完成搜推、光合发布及回查。</p><p style="font-size:12px;color:#aaa">原页面已关闭时，在当前店铺素材页接着执行，不另开页面。</p><div style="display:flex;gap:8px"><button id="resume-original-confirm" class="scm-btn scm-start" type="button">继续执行</button><button id="resume-original-cancel" class="scm-btn scm-cancel" type="button">暂不继续</button></div>';
    const ids = original.selection?.ids?.length ? original.selection.ids : [...new Set((original.items||[]).flatMap(i=>i.productIds||[]))];
    dialog.querySelector('#resume-original-scope').textContent = '原任务商品：' + (ids.length ? ids.join('、') : '已保存的原范围') + '；当前第 ' + (Number(original.position||0)+1) + ' 组。';
    if(original.module==='searchvideo')dialog.querySelectorAll('p')[1].textContent='复用原视频、上传意图和发布记录，不自动升级清晰度或重新生成。';
    if(original.kind==='trend'){dialog.querySelector('#resume-original-scope').textContent='原店铺：'+(original.selection.shopName||original.trend.scope.shopId)+'；已回查 '+original.trend.stats.submitted+' 个商品提报。';dialog.querySelectorAll('p')[1].textContent='免费继续原分类、活动和商品批次；已提交但结果未知的批次只回查，不重复提报。';dialog.querySelectorAll('p')[2].textContent='复用同店铺现有标签页，不新开页面，不调用生图或视频。';}
    dialog.querySelectorAll('button').forEach(button=>{button.style.cssText='padding:10px 12px;border:1px solid #805d1b;border-radius:6px;background:#30291d;color:#fff;font:inherit;cursor:pointer';});
    dialog.querySelector('#resume-original-confirm').style.background='#b06a13';
    dialog.querySelector('#resume-original-title').textContent='有未完成任务，是否继续？';
    dialog.querySelector('#resume-original-confirm').textContent='继续旧任务';
    dialog.querySelectorAll('p')[1].textContent='复用已有素材、生成编号和发布记录，从原进度继续；已提交但结果未知的步骤先回查，不重复提交。';
    dialog.querySelectorAll('p')[2].textContent='继续原任务的商品范围与设置；尚未完成的步骤仍按原任务预算执行。';
    dialog.querySelector('#resume-original-scope').textContent='原功能：'+(FullCore.MODULES[original.module]?.name||original.module)+'；'+dialog.querySelector('#resume-original-scope').textContent;
    if(original.module==='searchvideo')dialog.querySelectorAll('p')[1].textContent='复用已有视频和提交编号，不自动升级清晰度或重新生成。原视频不满足平台要求时会保留素材并提示原因。';
    if(original.enabled&&original.status!=='paused'){dialog.querySelectorAll('p')[1].textContent='原任务仍在运行。确认后返回原进度，不会重启或重复提交。';dialog.querySelector('#resume-original-confirm').textContent='查看并继续原任务';}
    if(original.cancellation){dialog.querySelector('#resume-original-title').textContent='重新开始已取消的原任务？';dialog.querySelector('#resume-original-confirm').textContent='重新开始，复用原素材';}if(original.module==='white'){dialog.querySelectorAll('p')[1].textContent='继续核对原商品并采集 SKU、主图和详情图；复用已有生成、上传及替换记录，完成后回查。';}
    if(recoveryPlan?.recoveries?.length)dialog.querySelectorAll('p')[1].textContent=root.FullRecoveryUi.summary(recoveryPlan)+' 保留成功素材和提交记录。';document.body.append(dialog);
    return new Promise(resolve=>{const finish=value=>{dialog.close();dialog.remove();resumeDialog=null;resolve(value);};dialog.querySelector('#resume-original-confirm').onclick=()=>finish(true);dialog.querySelector('#resume-original-cancel').onclick=()=>finish(false);dialog.oncancel=event=>{event.preventDefault();finish(false);};dialog.showModal();});
  }
  async function resumeOriginalSearch(original) {
    if (resumePending) return {cancelled:true};
    resumePending=true;
    try {
      if(!await confirmOriginalSearch(original))return {cancelled:true};
      notice(original.module==='searchvideo'?'正在继续原视频任务，复用原视频和发布进度…':'正在继续原任务，复用原图片和发布进度…');
      const latest=await read(RUNS)||[],fresh=latest.find(run=>run.id===original.id);
      if(!fresh)throw Error('原任务记录已变化，请重新查看。');
      if(JSON.stringify(fresh.selection)!==JSON.stringify(original.selection))throw Error('原任务范围已变化，请重新确认。');
      if(fresh.status==='done'){updateRuns(latest);notice('原任务已经结束，素材和记录已保留。');return {ok:true,runId:fresh.id,alreadyDone:true};}
      if(fresh.enabled&&fresh.status!=='paused'){updateRuns(latest);return {ok:true,runId:fresh.id,alreadyRunning:true};}
      original=fresh;
      if(original.status==='paused'){
        const control=await message({type:'FULL_GLOBAL_STATUS'});
        if(control.paused){
          const ids=Object.entries(control.runs||{}).flatMap(([key,ids])=>ids.map(id=>({key,id})));
          if(ids.length!==1||ids[0].key!==RUNS||ids[0].id!==original.id||control.queues?.length||control.studio?.length)throw Error('全局暂停包含其他任务，请到任务与素材页核对后继续；原任务与素材已保留。');
          const result=await message({type:'FULL_GLOBAL_RESUME'});updateRuns(await read(RUNS));return {...result,runId:original.id,resumed:true};
        }
      }
      const failed=FullWhiteRun.completedCandidate(original);
      if(failed){const response=await fetch((chrome.runtime.getURL('local-api').replace(/\/$/,'')+"/api/media/")+failed.generations[0].id,{signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('原生成回查未成功，保留原任务。');const answer=await response.json();if(answer.status!=='completed'||answer.available!==true)throw Error('原生成尚未恢复完成：'+(answer.error||answer.status||'结果未知')+'；未重新生成。');await FullStateStore.update(RUNS,saved=>{if((saved||[]).some(r=>r.enabled||r.status==='paused'))throw Error('已有运行中的任务，未恢复其他记录。');const current=saved?.find(r=>r.id===original.id);FullWhiteRun.restoreCompleted(current,answer);return saved;});}
      const response=await message({type:'FULL_FLOW_RESUME',runId:original.id,confirmResume:true,...(resumeRecoveryPlans.get(original.id)?.recoveries?.length?{recoverCapabilities:true,recoveryPlanSHA256:resumeRecoveryPlans.get(original.id).planSHA256}:{}),...(original.cancellation?{restartCancelled:true}:{})});
      runs=await read(RUNS)||[];
      const resumed=runs.find(run=>run.id===original.id);if(!resumed)throw Error('原任务记录已变化，请重新查看任务日志。');
      applyRunState(resumed);if(active(resumed))q('#statusText').textContent='正在继续原任务，按原进度发布并回查…';
      return {...response,runId:original.id,resumed:true};
    } finally {resumePending=false;resumeRecoveryPlans.delete(original.id);}
  }
  function buttonFor(module) {
    if (module === 'scene') return q('#btnScene');
    if (module === 'guanghe') return q('#btnGuangheDiscover');
    const key = Object.keys(modules).find(key => modules[key] === module);
    return key ? q('[data-modes="' + key + '"]') : null;
  }
  function applyRunState(run) {
    currentRun = run || null;
    const busy = active(run), paused = busy && run.status === 'paused';
    const recoverable = !busy && recoverableSearch();
    q('#btnResumeSearch').hidden = !recoverable;
    if (recoverable) q('#btnResumeSearch').textContent = (recoverable.kind==='trend'?'继续趋势提报原任务 · ':recoverable.module==='searchvideo'?'继续搜推视频原任务 · ':'继续搜推原任务 · ') + (recoverable.selection.ids?.join('、') || '原范围');
    const white = !busy && recoverableWhite();
    q('#btnResumeWhite').hidden = !white;
    if(white)q('#btnResumeWhite').textContent='继续白底图原任务 · '+(white.selection.ids?.join('、')||'原范围');
    const changed = run?.id !== previousRunId || paused !== previousPaused;
    for (const button of document.querySelectorAll('[data-modes],#btnScene,#btnGuangheDiscover,#btnTaskMode')) {
      button.disabled = false; // Keep task entry clickable so unfinished work can be confirmed.
      button.classList.toggle('active', busy && button === buttonFor(run.module));
    }
    q('#controlGroup').style.display = busy ? '' : 'none';
    q('#btnPause').textContent = paused ? '▶ 继续' : '⏸ 暂停';
    q('#btnPause').disabled = !!run?.draining;
    q('#btnStop').textContent = run?.draining ? '⏹ 收尾中 · 再点立即停止' : '⏹ 停止';
    if (busy) {
      q('#statusPanel').style.display = '';
      q('#statusText').textContent = paused ? '已暂停' : run.draining ? '收尾中…' : '运行中...';
      if (changed) setFuncCollapsed(!paused);
    } else {
      setFuncCollapsed(false);
      if (run) {
        q('#statusPanel').style.display = '';
        q('#statusText').textContent = ({ done: '本轮结束', stopped: '已停止', drained: '已收尾停止',
          pending_review: '本轮结束，仍有待确认项', boundary_blocked: '已到执行边界',
          blocked: '已阻塞，需回查', budget_exhausted: '本轮调用预算已耗尽',
          recovery_exhausted: '页面恢复次数已耗尽' })[run.status] || '任务状态待确认';if(run.cancellation)q('#statusText').textContent='已取消，原素材与记录保留';else if(run.selection?.mode==='cleanup'&&run.status==='done')q('#statusText').textContent=run.taskFailures?.length?'清理未完成，请查看原因':run.selection.dryRun?'演练完成，未删除素材':'清理已结束，请核对逐项结果';
      }
    }
    previousRunId = run?.id || null;
    previousPaused = paused;
    root.dispatchEvent(new CustomEvent('material-run-state', { detail: run || null }));
  }
  function updateRuns(next) {
    runs = Array.isArray(next) ? next : [];
    const running = runs.filter(active).at(-1);
    const selected = running || runs.find(run => run.id === currentRun?.id) || runs.at(-1);
    applyRunState(selected);
  }
  function whiteHint(s) {
    const method = s.whiteBgSourceMethod || 'ai_generate', main = s.whiteBgMainImageN ?? 1, sku = s.whiteBgSkuImageN ?? -1;
    if (method === 'ai_generate') return 'AI生图白底';
    if (method === 'image_space_size') return '按尺寸 · 免费';
    if (method === 'detail_main_image') return (main === 1 ? '主图首图' : main === -1 ? '主图倒数第一' : '主图第 ' + main + ' 张') + ' · 免费';
    if (method === 'detail_sku_image') return (sku === 1 ? 'SKU 第 1 个' : sku === -1 ? 'SKU 最后一个' : 'SKU 第 ' + sku + ' 个') + ' · 免费';
    return '来源待确认';
  }
  function refreshHints() {
    q('#whiteBgModeHint').textContent = whiteHint(settings);
    q('#sceneMethodHint').textContent = settings.sceneMethod === 'taobao_ai' ? '淘宝自带 AI' : '香蕉 Pro 模式';
  }
  function parseCustomIds(raw) {
    const result = [], seen = new Set();
    for (const token of String(raw || '').split(/[\s,，、;；]+/)) {
      let value = token.trim().replace(/[０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0));
      if (!value) continue;
      let id = /[?&](?:itemId|id)=(\d{6,})/.exec(value)?.[1] || /^(?:商品|宝贝)?\s*I?D\s*[:：]\s*(\d{6,})/i.exec(value)?.[1];
      if (!id) {
        value = value.replace(/^["'“”‘’]+/, '').replace(/["'“”‘’]+$/, '').replace(/^(?:商品\s*ID|宝贝\s*ID|ID)\s*[:：]?\s*/i, '').replace(/\.0+$/, '');
        if (/^\d{6,}$/.test(value)) id = value;
      }
      if (id && !seen.has(id)) { seen.add(id); result.push(id); }
    }
    return result;
  }
  function saveDraft(patch) {
    Object.assign(drafts, patch);
    draftChain = draftChain.catch(() => {}).then(async () => { drafts = await merge(DRAFTS, patch); });
    return draftChain;
  }
  function normalize(module, selection) {
    const s = { ...FullRunModes.DEFAULTS, ...settings, ...selection,
      mode: selection.mode === 'custom' ? 'ids' : selection.mode,
      startConsent: true, autoPublish: true, executionBoundary: boundary(module) };
    s.startOffsetDays = s.xinpinStartOffsetDays || 5;
    s.sizes = s.targetSizes;
    s.mainImageN = s.whiteBgMainImageN ?? 1;
    s.skuImageN = s.whiteBgSkuImageN ?? -1;
    if (module === 'white') Object.assign(s, { source: s.whiteBgSourceMethod || 'ai_generate', sortBy: s.whiteBgSortBy || 'default',
      facts: '', body: '', prompt: '', extra: '', palette: 'no', count: 1, ratio: '1:1' });
    if (module === 'scene') Object.assign(s, { source: s.sceneMethod || 'banana_pro', sortBy: s.sceneSortBy || 'default' });
    if (module === 'transparent') Object.assign(s, { source: 'existing_white', maxCalls: 0, palette: 'no', count: 1, ratio: '1:1', prompt: '', facts: '', body: '', extra: '', executionBoundary: { paidGeneration: false, storeWrite: true } });
    if (module === 'trend') Object.assign(s,{mode:'all',maxCalls:0,paidGeneration:false,executionBoundary:{paidGeneration:false,storeWrite:true}});
    if (module === 'selling') s.variant = s.sellingMode === 'series' ? 'series' : 'selling';
    if (module === 'follow') { s.variant = s.followMode === 'new' ? 'multi' : 'list'; if (s.mode === 'auto') s.mode = 'all'; }
    if (module === 'guanghe' && s.variant === 'image') s.variant = 'pic';
    if (module === 'search' && s.mode !== 'cleanup' && s.mode !== 'replica' && s.searchMode !== 'replica') {
      s.syncGuanghe = true;
      s.completionPolicy = 'soutui-and-guanghe-readback-v1';
    }
    if (module === 'searchvideo') { if(s.mode!=='ids'||parseCustomIds(s.ids?.join?.(' ')||s.ids||'').length!==1)throw Error('搜推视频只支持一个指定商品，不扫描全店。');s.ids=parseCustomIds(s.ids?.join?.(' ')||s.ids||'');Object.assign(s,{count:1,maxCalls:1,provider:'grsai',model:'minimax-h3',resolution:'768p',duration:10,videoFallback:{model:'agnes-video-2.5',resolution:'720p'},ratio:['9:16','16:9'].includes(s.ratio)?s.ratio:'9:16'}); }
    if (s.mode === 'cleanup') { Object.assign(s,{dryRun:false,deleteConfirmed:true,cleanupExecution:'listed-direct-v1',pictureCleanup:'unreferenced-only',maxCalls:0,syncGuanghe:false,syncMainvideo:false,executionBoundary:{paidGeneration:false,storeWrite:true}});delete s.confirmedContentIds; }
    return s;
  }
  async function start(module, selection) {
    await ready;
    const previous=await offerOriginal(module);if(previous)return previous;
    starting = true;
    try {
      const normalized = normalize(module, selection);
      let response;
      try { response = await message({ type: 'FULL_FLOW_START', module, selection: normalized }); }
      catch (error) {
        if(error.code!=='ORIGINAL_TASK_EXISTS')throw error;
        const latest=await read(RUNS)||[],original=latest.find(run=>run.id===error.runId);if(!original)throw Error('原任务记录已变化，请重新查看任务日志。');runs=latest;
        response=await resumeOriginalSearch(original);if(response.cancelled)throw Object.assign(Error('已取消继续原任务'),{cancelled:true});return response;
      }
      // The acknowledged task is held in UI memory until its storage update arrives.
      currentRun = { id: response.runId, module, selection: normalized, enabled: true, status: 'running' };
      const stored = await read(RUNS).catch(() => null);
      if (Array.isArray(stored)) runs = stored;
      const accepted = runs.find(run => run.id === response.runId) || currentRun;
      applyRunState(accepted);
      if (active(accepted) && accepted.status === 'running') q('#statusText').textContent = module === 'white'
        ? normalized.reviewAutomatic ? '正在运行（白底图·全自动审核重做）...' : normalized.mode === 'ids' ? `正在运行（白底图·自定义ID·${normalized.ids.length} 个商品）...` : '正在运行（白底图·全量跑）...'
        : '正在运行（' + FullCore.MODULES[module].name + '）...';
      return response;
    } finally { starting = false; }
  }
  function openLocal(page) {
    return extension ? chrome.tabs.create({ url: chrome.runtime.getURL(page) }) : root.open(page, '_blank');
  }
  const adapter = {
    settings: () => settings, draft: key => drafts[key] || '',
    saveDraft: (key, value) => saveDraft({ [key]: value }),
    saveSettings: async patch => { settings = await merge(SETTINGS, patch); refreshHints(); },
    autoDefaults: () => ({ maxCalls: 20, palette: 'no', executionBoundary: boundary() }), start,
    polish: async () => { throw Error('当前执行边界未开放付费润色。'); },
    openWorkbench: async (kind, selection = {}) => {
      const ids = selection.lines || selection.ids || [];
      const page = kind === 'buyer' ? 'buyer.html' : 'studio.html?module=' + encodeURIComponent(kind) + (ids.length ? '&ids=' + encodeURIComponent(ids.join('\n')) : '');
      // Opening a workbench does not forward kickoff or generation consent.
      await openLocal(page);
    }
  };
  const runModes = FullRunModes.install(adapter);

  function mountModal(content) {
    const bg = document.createElement('div'), modal = document.createElement('div');
    bg.className = 'soutui-custom-bg'; modal.className = 'soutui-custom-modal';
    modal.innerHTML = content; bg.appendChild(modal); document.body.appendChild(bg);
    dialogOpen = true;
    return { bg, modal, remove() { bg.remove(); dialogOpen = false; } };
  }
  async function confirmWhiteBgScanAll(whiteBtn) {
    await draftChain;
    const data = await read(DRAFTS) || {}, ids = parseCustomIds(data['white:ids']), at = Number(data['white:pendingAt']);
    if (!ids.length || !(at > 0) || Date.now() - at > 300000) return true;
    if (!root.confirm(`你输入的 ${ids.length} 个商品ID还没启动。现在选择的是「全量跑」，会处理全店待补充商品；费用以实际任务记录为准。\n\n确定要扫全店吗？取消可回到自定义弹窗。`)) return false;
    await saveDraft({ 'white:pendingAt': 0 }); return true;
  }
  function showWhiteBgMenu(whiteBtn) {
    if (hasActive()) return noticeStartFail('有任务正在运行，请先停止再选择白底图模式');
    if (dialogOpen) return;
    const box = mountModal('<h3>白底图 · 选择运行方式</h3>' +
      '<div class="scm-actions" style="flex-direction:column;gap:8px;align-items:stretch;">' +
      '<button class="scm-btn scm-start scm-pick scm-menu-all" type="button" style="width:100%;"><span class="scm-pick-t">全量跑</span><span class="scm-pick-s">处理全店待补充白底图的商品</span></button>' +
      '<button class="scm-btn scm-start scm-pick scm-menu-id" type="button" style="width:100%;"><span class="scm-pick-t">自定义商品 ID</span><span class="scm-pick-s">输入商品 ID，只处理指定商品</span></button>' +
      '<button class="scm-btn scm-start scm-pick scm-menu-review" type="button" style="width:100%;"><span class="scm-pick-t">重做审核不通过</span><span class="scm-pick-s">自动识别拒绝原因、生图、上传、替换并回查</span></button>' +
      '<button class="scm-btn scm-cancel" type="button">取消</button></div>');
    const all = box.modal.querySelector('.scm-menu-all'), custom = box.modal.querySelector('.scm-menu-id'), review = box.modal.querySelector('.scm-menu-review'), cancel = box.modal.querySelector('.scm-cancel');
    let busy = false;
    const close = () => { if (!busy) box.remove(); };
    cancel.onclick = close; box.bg.onclick = event => { if (event.target === box.bg) close(); };
    custom.onclick = () => { if (!busy) { box.remove(); showWhiteBgCustomModal(whiteBtn); } };
    review.onclick = () => { if (!busy) { box.remove(); showWhiteBgReviewModal(); } };
    all.onclick = async () => {
      if (busy) return;
      busy = true; all.disabled = custom.disabled = review.disabled = cancel.disabled = true;
      try {
        if (!await confirmWhiteBgScanAll(whiteBtn)) { box.remove(); showWhiteBgCustomModal(whiteBtn); return; }
        await start('white', { ids: [], mode: 'all' });
        box.remove();
      } catch (error) { noticeStartFail(error.message); }
      finally { busy = false; all.disabled = custom.disabled = review.disabled = cancel.disabled = false; }
    };
  }
  function showWhiteBgReviewModal() {

    if (hasActive()) return noticeStartFail('有任务正在运行，请先停止再选择重做范围');
    if (dialogOpen) return;
    const box = mountModal('<h3>白底图 · 全自动重做审核不通过</h3>' +
      '<p class="scm-sub">选择范围后一次开始，自动读取拒绝原因、取同商品SKU参考图、生成、上传、替换并回查。每商品本轮最多生成一次，生图按账户计费；待审核、已通过、下架及售后补差链接跳过。无法识别的原因记录后继续下一件。</p>' +
      '<label style="display:block;margin:8px 0;font-size:12px;"><input type="radio" name="review-scope" value="ids"> 仅指定商品 ID</label>' +
      '<label style="display:block;margin:8px 0;font-size:12px;"><input type="radio" name="review-scope" value="all" checked> 全店审核不通过商品</label>' +
      '<textarea id="review-ids" aria-label="重做商品ID" placeholder="每行一个商品ID，或用逗号分隔"></textarea>' +
      '<div class="scm-count" id="review-count"></div>' +
      '<div class="scm-actions"><button class="scm-btn scm-cancel scm-review-cancel" type="button">取消</button><button class="scm-btn scm-start scm-review-start" type="button" disabled>开始指定ID重做</button></div>');
    const input = box.modal.querySelector('#review-ids'), count = box.modal.querySelector('#review-count'), submit = box.modal.querySelector('.scm-review-start'), cancel = box.modal.querySelector('.scm-review-cancel'), choices = [...box.modal.querySelectorAll('[name="review-scope"]')];
    let busy = false, touched = false, saving = Promise.resolve();
    const mode = () => choices.find(radio => radio.checked).value;
    const refresh = () => { const only = mode() === 'ids', ids = parseCustomIds(input.value); input.hidden = !only; input.style.display = only ? '' : 'none'; count.textContent = only ? '识别到 ' + ids.length + ' 个商品ID' : '范围：全店在售且审核不通过的商品'; submit.textContent = only ? '开始指定ID全自动重做' : '开始全店全自动重做'; submit.disabled = busy || only && !ids.length; };
    const persist = () => saveDraft({ 'white:reviewIds': input.value });
    input.oninput = () => { touched = true; refresh(); saving = persist(); saving.catch(error => noticeStartFail(error.message)); };
    choices.forEach(radio => radio.onchange = refresh);
    const controls = disabled => { input.disabled = cancel.disabled = disabled; choices.forEach(radio => radio.disabled = disabled); refresh(); };
    const close = async () => { if (busy) return; busy = true; controls(true); try { await saving.catch(() => {}); await persist(); box.remove(); } catch (error) { noticeStartFail(error.message); } finally { busy = false; controls(false); } };
    cancel.onclick = close; box.bg.onclick = event => { if (event.target === box.bg) close(); };
    read(DRAFTS).then(data => { if (!touched && !input.value) { input.value = data?.['white:reviewIds'] || data?.['white:ids'] || ''; refresh(); } }).catch(error => noticeStartFail(error.message));
    submit.onclick = async () => { const scope = mode(), ids = parseCustomIds(input.value); if (busy || scope === 'ids' && !ids.length) return; busy = true; controls(true); try { await saving.catch(() => {}); await persist(); await start('white', { mode: scope, ids: scope === 'ids' ? ids : [], reviewRejected: true, reviewAutomatic: true, reviewMaxAttempts: 1, whiteBgSourceMethod: 'ai_generate' }); box.remove(); } catch (error) { noticeStartFail(error.message); } finally { busy = false; controls(false); } };
    refresh(); setTimeout(() => { if (input.isConnected && mode() === 'ids') input.focus(); }, 50);
  }
  function showWhiteBgCustomModal(whiteBtn) {
    if (hasActive()) return noticeStartFail('有任务正在运行，请先停止再用自定义模式');
    if (dialogOpen) return;
    const box = mountModal('<h3>白底图 · 自定义商品ID</h3>' +
      '<p class="scm-sub">只补指定商品的白底图，沿用设置中的图片来源与计费规则。已有白底图或已下架的商品仍按原规则跳过；按输入的商品ID逐个搜索，不扫描全店。</p>' +
      '<textarea id="mode-ids" aria-label="商品ID" placeholder="每行一个商品ID，或用逗号/空格分隔"></textarea>' +
      '<div class="scm-count" id="mode-count">识别到 0 个商品ID</div>' +
      '<div class="scm-actions"><button id="mode-back" class="scm-btn scm-cancel" type="button">取消</button><button id="mode-start" class="scm-btn scm-start" type="button" disabled>开始补白底图</button></div>');
    const input = box.modal.querySelector('textarea'), count = box.modal.querySelector('.scm-count');
    const submit = box.modal.querySelector('.scm-start'), cancel = box.modal.querySelector('.scm-cancel');
    let ids = [], busy = false, touched = false, saving = Promise.resolve();
    const refresh = () => { ids = parseCustomIds(input.value); count.textContent = `识别到 ${ids.length} 个商品ID`; submit.disabled = busy || !ids.length; };
    const persist = () => saveDraft({ 'white:ids': input.value, 'white:pendingAt': ids.length ? Date.now() : 0 });
    input.oninput = () => { touched = true; refresh(); saving = persist(); saving.catch(() => noticeStartFail('商品ID未能保存，请保持弹窗打开并重试')); };
    const close = async () => {
      if (busy) return;
      busy = true; input.disabled = cancel.disabled = true; refresh();
      try { await saving.catch(() => {}); await persist(); box.remove(); }
      catch (error) { noticeStartFail('商品ID未能保存：' + error.message); }
      finally { busy = false; input.disabled = cancel.disabled = false; refresh(); }
    };
    cancel.onclick = close; box.bg.onclick = event => { if (event.target === box.bg) close(); };
    read(DRAFTS).then(data => { if (!touched && data?.['white:ids'] && !input.value) { input.value = data['white:ids']; refresh(); } }).catch(error => noticeStartFail(error.message));
    submit.onclick = async () => {
      if (busy || !ids.length) return;
      busy = true; input.disabled = cancel.disabled = true; refresh();
      try {
        await saving.catch(() => {}); await persist();
        await start('white', { ids: ids.slice(), mode: 'custom' });
        box.remove();
        try { await saveDraft({ 'white:pendingAt': 0 }); }
        catch { notice('任务已登记，草稿标记未保存；请勿重复启动。', 'error'); }
      } catch (error) { noticeStartFail(error.message); }
      finally { busy = false; input.disabled = cancel.disabled = false; refresh(); }
    };
    setTimeout(() => { if (input.isConnected) input.focus(); }, 50);
  }
  async function openModule(module, custom = false) {
    await ready;
    if(starting||resumePending||resumeDialog)return;
    const previous=await offerOriginal(module);if(previous)return previous;
    if (openingModule) return;
    openingModule = true;
    try {
      if(['search','searchvideo','trend'].includes(module)){const original=recoverableSearch(module);if(original){const resumed=await resumeOriginalSearch(original);if(!resumed.cancelled||!custom)return resumed;}}
      if (extension && module!=='trend') await FullMaterialEntry.open({reuseCurrent:['search','searchvideo','white'].includes(module),whiteEntry:module==='white'});
      if (module === 'white') return showWhiteBgMenu(buttonFor('white'));
      if (module === 'transparent') return transparentUI.open();
      return custom ? runModes.openCustom(module) : runModes.open(module);
    } finally { openingModule = false; }
  }
  const transparentUI = FullTransparentUI.install({ start, mount: mountModal, hasActive, hasDialog: () => dialogOpen, parse: parseCustomIds, saveDraft, readDrafts: () => read(DRAFTS), notice: noticeStartFail });
  for (const button of document.querySelectorAll('[data-modes]')) button.onclick = () => guard(() => openModule(modules[button.dataset.modes]));
  for (const [id, module] of Object.entries({ btnScene: 'scene', btnBuyerShowWeb: 'buyer', btnFissionKickoff: 'fission', btnTryonWeb: 'outfit', btnGuangheDiscover: 'guanghe' })) q('#' + id).onclick = () => guard(() => openModule(module));
  for (const [id, module] of Object.entries({ btnSoutuiCustom: 'search', btnSoutuiVideoCustom: 'searchvideo' })) q('#' + id).onclick = event => { event.stopPropagation(); guard(() => openModule(module, true)); };
  q('#btnOpenSettings').onclick = () => guard(() => extension ? chrome.runtime.openOptionsPage() : openLocal('options.html'));
  q('#btnFreeGen').onclick = () => guard(() => openLocal('freegen.html'));
  let balancePending = false;
  async function refreshBalance() {
    if (balancePending) return;
    balancePending = true; q('#balancePill').setAttribute('aria-busy', 'true');
    try {
      const result = await message({ type: 'FULL_CREDITS_QUERY' }), b = result.balance;
      if (!b?.available || typeof b.credits !== 'number' || !Number.isFinite(b.credits)) throw Error();
      q('#balancePillNum').textContent = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 6 }).format(b.credits);
      const at = new Date(b.checkedAt);
      q('#balancePill').title = 'GrsAI APIKey可用积分 · ' + (Number.isFinite(at.getTime()) ? at.toLocaleTimeString('zh-CN') + ' 查询' : '已查询') + ' · 点击刷新';
    } catch {
      q('#balancePillNum').textContent = '—'; q('#balancePill').title = 'GrsAI 积分暂不可用 · 点击重试';
    } finally { balancePending = false; q('#balancePill').removeAttribute('aria-busy'); }
  }
  q('#balancePill').onclick = refreshBalance;
  q('#balancePill').setAttribute('aria-label', '刷新 GrsAI APIKey可用积分');
  if (extension) { refreshBalance(); setInterval(() => { if (!document.hidden) refreshBalance(); }, 60000); }
  q('#btnTaskMode').onclick = () => guard(() => openLocal('options.html#task-mode'));
  q('#btnResetProcessed').onclick = () => notice('重置记录入口尚未接入；现有运行历史已保留。');
  q('#btnMiniWin').onclick = () => notice('小窗操作尚未复刻；当前面板保持原位。');
  q('#funcToggle').onclick = () => {
    const collapsed = q('#funcArea').classList.toggle('collapsed');
    q('#funcToggle').textContent = collapsed ? '▸ 功能按钮（任务运行中已折叠，点此展开）' : '▾ 功能按钮（点此收起）';
  };
  q('#btnResumeWhite').onclick = () => guard(async()=>{await ready;if(hasActive())throw Error('有任务正在运行，请先停止。');const original=recoverableWhite();if(!original)throw Error('没有待继续的白底图原任务。');await resumeOriginalSearch(original);});
  q('#btnResumeSearch').onclick = () => guard(async () => {
    await ready;
    if (hasActive()) throw Error('有任务正在运行，请先停止。');
    const original = recoverableSearch();
    if (!original) throw Error('没有待继续的搜推原任务。');
    await resumeOriginalSearch(original);
  });
  q('#btnPause').onclick = () => guard(async () => {
    if (!active(currentRun)) return;
    const runId = currentRun.id, paused = currentRun.status !== 'paused';
      await message(currentRun.kind==='trend' ? {type:'FULL_TREND_CONTROL',runId,action:paused?'pause':'resume'} : currentRun.module === 'transparent' ? { type: 'FULL_TRANSPARENT_CONTROL', runId, action: 'pause', paused } : currentRun.module === 'white' ? { type: 'FULL_WHITE_PAUSE', runId, paused } : { type: paused ? 'FULL_GLOBAL_PAUSE' : 'FULL_GLOBAL_RESUME' });
    updateRuns(await read(RUNS));
  });
  q('#btnStop').onclick = () => guard(async () => {
    if (!active(currentRun) || stopPending) return;
    stopPending = true;
    try {
      await message(currentRun.kind==='trend' ? {type:'FULL_TREND_CONTROL',runId:currentRun.id,action:'stop'} : currentRun.module === 'transparent' ? { type: 'FULL_TRANSPARENT_CONTROL', runId: currentRun.id, action: currentRun.draining ? 'stop' : 'drain' } : { type: currentRun.draining ? 'FULL_FLOW_STOP' : 'FULL_FLOW_DRAIN', runId: currentRun.id });
      updateRuns(await read(RUNS));
    } finally { stopPending = false; }
  });
  const ready = Promise.all([read(SETTINGS), read(DRAFTS), read(RUNS)]).then(([s, d, r]) => {
    settings = s || {}; drafts = d || {}; refreshHints(); updateRuns(r);
    let manifest = {}; try { manifest = chrome.runtime.getManifest(); } catch {}
    q('#buildId').textContent='后台连接中';
    chrome.runtime.sendMessage({type:'FULL_RUNTIME_PROBE'}).then(info=>{q('#buildId').textContent=info?.version===manifest.version&&info?.build==='material-return-20261017-v2'&&info?.returnReady===true?'v'+manifest.version+' · 后台已校验':'后台待更新';},()=>{q('#buildId').textContent='后台待更新';});
  }).catch(error => { noticeStartFail('面板数据未能读取：' + error.message); throw error; });
  if (extension) chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[SETTINGS]) { settings = changes[SETTINGS].newValue || {}; refreshHints(); }
    if (changes[DRAFTS]) drafts = changes[DRAFTS].newValue || {};
    if (changes[RUNS]) updateRuns(changes[RUNS].newValue);
  });
  root.FullPopupUi = { ready, applyRunState, setFuncCollapsed, notice, parseCustomIds, normalize,
    showWhiteBgMenu, showWhiteBgCustomModal, adapter, get currentRun() { return currentRun; } };
})(globalThis);
