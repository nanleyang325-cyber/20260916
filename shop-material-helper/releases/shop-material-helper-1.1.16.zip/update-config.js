'use strict';
// Public release metadata only. Never put a token, account or API key here.
(function(root){
 const config=Object.freeze({
  schema:1,product:'shop-material-helper-independent',
  origin:'https://raw.githubusercontent.com',
  repository:'nanleyang325-cyber/20260916',directory:'shop-material-helper',
  feedURL:'https://raw.githubusercontent.com/nanleyang325-cyber/20260916/main/shop-material-helper/latest.json',
  releasesURL:'https://github.com/nanleyang325-cyber/20260916/tree/main/shop-material-helper',
  maxPackageBytes:16*1024*1024
 });
 if(typeof module==='object'&&module.exports)module.exports=config;
 else root.MaterialUpdateConfig=config;
})(globalThis);
