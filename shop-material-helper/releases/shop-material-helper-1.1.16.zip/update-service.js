'use strict';
// Public version checks and verified ZIP bytes. No program installation,
// business-store access, task control, remote code execution or native updater.
(function(root){
 const KEY='material-extension-download-update-v1',AUTO_INTERVAL=24*60*60*1000,MANUAL_INTERVAL=60*1000;
 function version(value){
  if(typeof value!=='string'||!/^\d+(?:\.\d+){0,3}$/.test(value))return null;
  const parts=value.split('.').map(Number);return parts.every(n=>n<=65535)?parts:null;
 }
 function newer(a,b){const x=version(a),y=version(b);return !!x&&!!y&&Array.from({length:4},(_,i)=>(x[i]||0)-(y[i]||0)).find(n=>n!==0)>0;}
 function fault(code){return Object.assign(new Error(code),{code});}
 function release(value,config){
  if(!value||value.schema!==1||value.product!==config.product||!version(value.version))throw fault('FEED_INVALID');
  if(!Number.isSafeInteger(value.bytes)||value.bytes<22||value.bytes>config.maxPackageBytes||!/^[a-f0-9]{64}$/.test(value.sha256||''))throw fault('FEED_INVALID');
  let u;try{u=new URL(value.url);}catch{throw fault('FEED_INVALID');}
  const prefix='/'+config.repository+'/',tail='/'+config.directory+'/releases/shop-material-helper-'+value.version+'.zip';
  const revision=u.pathname.slice(prefix.length,u.pathname.length-tail.length);
  if(u.origin!==config.origin||u.username||u.password||u.search||u.hash||!u.pathname.startsWith(prefix)||!u.pathname.endsWith(tail)||!/^[a-f0-9]{40}$/.test(revision))throw fault('FEED_INVALID');
  if(!Array.isArray(value.notes)||value.notes.length>8||value.notes.some(n=>typeof n!=='string'||n.length>240))throw fault('FEED_INVALID');
  if(typeof value.publishedAt!=='string'||value.publishedAt.length>40||!Number.isFinite(Date.parse(value.publishedAt)))throw fault('FEED_INVALID');
  return {schema:1,product:config.product,version:value.version,url:u.href,sha256:value.sha256,bytes:value.bytes,publishedAt:value.publishedAt,notes:[...value.notes]};
 }
 async function bounded(response,limit,signal){
  if(!response.ok)throw fault('NETWORK_FAILED');
  const length=response.headers.get('content-length');
  if(length&&(!/^\d+$/.test(length)||Number(length)>limit))throw fault('RESPONSE_TOO_LARGE');
  if(!response.body?.getReader)throw fault('NETWORK_FAILED');
  const reader=response.body.getReader(),chunks=[];let size=0;
  const abort=()=>{reader.cancel().catch(()=>{});};signal?.addEventListener('abort',abort,{once:true});
  try{for(;;){if(signal?.aborted)throw fault('NETWORK_FAILED');const part=await reader.read();if(signal?.aborted)throw fault('NETWORK_FAILED');if(part.done)break;size+=part.value.byteLength;if(size>limit)throw fault('RESPONSE_TOO_LARGE');chunks.push(part.value);}}
  finally{signal?.removeEventListener('abort',abort);await reader.cancel().catch(()=>{});}
  const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.byteLength;}return bytes;
 }
 function create(chrome,options={}){
  const config=options.config||root.MaterialUpdateConfig,now=options.now||Date.now,fetcher=options.fetch||root.fetch.bind(root),crypto=options.crypto||root.crypto;
  let checking=false,preparing=false,writes=Promise.resolve();
  const current=()=>chrome.runtime.getManifest().version;
  const read=async()=>((await chrome.storage.local.get(KEY))[KEY]||{});
  function save(patch){const next=writes.catch(()=>{}).then(async()=>{const old=await read();await chrome.storage.local.set({[KEY]:{...old,...patch}});});writes=next;return next;}
  async function permitted(){try{return await chrome.permissions.contains({origins:[config.origin+'/*']});}catch{return false;}}
  function cached(record){try{return release(record.release,config);}catch{return null;}}
  async function status(){
   const record=await read(),item=cached(record),permission=await permitted();
   const errors=['NETWORK_FAILED','FEED_INVALID','RESPONSE_TOO_LARGE','FEED_ROLLBACK'];
   return {ok:true,version:current(),extensionId:chrome.runtime.id,permission,source:config.releasesURL,
    release:item,newer:!!item&&newer(item.version,current()),canDownload:!!item&&!newer(current(),item.version)&&permission,
    checkedAt:Number.isFinite(record.checkedAt)?record.checkedAt:null,attemptedAt:Number.isFinite(record.attemptedAt)?record.attemptedAt:null,
    lastError:errors.includes(record.lastError)?record.lastError:null,checking,preparing};
  }
  async function check({automatic=false}={}){
   if(checking)return {ok:false,code:'CHECK_IN_PROGRESS'};
   checking=true;
   try{
    if(!await permitted())return {ok:false,code:'PERMISSION_REQUIRED'};
    const old=await read(),elapsed=now()-old.attemptedAt,interval=automatic?AUTO_INTERVAL:MANUAL_INTERVAL;
    if(Number.isFinite(old.attemptedAt)&&elapsed>=0&&elapsed<interval)return {ok:true,result:'cached'};
    await save({attemptedAt:now()});
    try{
     const signal=AbortSignal.timeout(15000),response=await fetcher(config.feedURL,{method:'GET',credentials:'omit',redirect:'error',cache:'no-store',referrerPolicy:'no-referrer',signal});
     const raw=await bounded(response,64*1024,signal);let decoded;try{decoded=JSON.parse(new TextDecoder().decode(raw));}catch{throw fault('FEED_INVALID');}
     const item=release(decoded,config),previous=cached(old);
     if(previous&&newer(previous.version,item.version))throw fault('FEED_ROLLBACK');
     if(previous&&previous.version===item.version&&(previous.sha256!==item.sha256||previous.bytes!==item.bytes))throw fault('FEED_INVALID');
     await save({release:item,checkedAt:now(),lastError:null});
     return {ok:true,result:newer(item.version,current())?'update_available':'no_update'};
    }catch(error){const code=['FEED_INVALID','RESPONSE_TOO_LARGE','FEED_ROLLBACK'].includes(error?.code)?error.code:'NETWORK_FAILED';await save({lastError:code});return {ok:false,code};}
   }finally{checking=false;}
  }
  async function prepare(request){
   if(preparing)return {ok:false,code:'DOWNLOAD_IN_PROGRESS'};
   preparing=true;
   try{
    if(!await permitted())return {ok:false,code:'PERMISSION_REQUIRED'};
    const item=cached(await read());if(!item||request?.version!==item.version||request?.sha256!==item.sha256)return {ok:false,code:'RELEASE_CHANGED'};
    if(newer(current(),item.version))return {ok:false,code:'OLDER_RELEASE'};
    const signal=AbortSignal.timeout(25000),response=await fetcher(item.url,{method:'GET',credentials:'omit',redirect:'error',cache:'no-store',referrerPolicy:'no-referrer',signal});
    const bytes=await bounded(response,item.bytes,signal);
    if(bytes.byteLength!==item.bytes||bytes[0]!==80||bytes[1]!==75||bytes[2]!==3||bytes[3]!==4)throw fault('PACKAGE_INTEGRITY_FAILED');
    const sha=[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');
    if(sha!==item.sha256)throw fault('PACKAGE_INTEGRITY_FAILED');
    let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
    return {ok:true,release:item,base64:btoa(binary)};
   }catch(error){return {ok:false,code:['PACKAGE_INTEGRITY_FAILED','RESPONSE_TOO_LARGE'].includes(error?.code)?'PACKAGE_INTEGRITY_FAILED':'DOWNLOAD_FAILED'};}
   finally{preparing=false;}
  }
  function install(){
   const pages=new Set(['/updates.html','/popup.html','/panel.html','/options.html','/api-settings.html']);
   chrome.runtime.onMessage.addListener((message,sender,reply)=>{
    if(!['MATERIAL_UPDATE_STATUS','MATERIAL_UPDATE_CHECK','MATERIAL_UPDATE_PREPARE_DOWNLOAD'].includes(message?.type))return false;
    if(sender.id!==chrome.runtime.id)return false;
    let page;try{const u=new URL(sender.url),self=new URL(chrome.runtime.getURL(''));if(u.protocol!=='chrome-extension:'||u.host!==self.host||!pages.has(u.pathname))return false;page=u.pathname;}catch{return false;}
    if(message.type==='MATERIAL_UPDATE_PREPARE_DOWNLOAD'&&page!=='/updates.html')return false;
    const work=message.type==='MATERIAL_UPDATE_STATUS'?status():message.type==='MATERIAL_UPDATE_CHECK'?check({automatic:message.automatic===true}):prepare(message);
    work.then(reply,()=>reply({ok:false,code:'UPDATE_STATUS_UNAVAILABLE'}));return true;
   });
  }
  return {status,check,prepare,install};
 }
 if(typeof module==='object'&&module.exports)module.exports={create,release,newer,version,bounded,KEY};
 else create(root.chrome).install();
})(globalThis);